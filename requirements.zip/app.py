"""This script provides an easy way to run our "Login Example" app.

There are many ways to run a Flask app, and not all of them require run.py.
When running locally, you can use any of the following approaches:

    - Execute this run.py script in Python to start your web app. You could:
        - Open run.py in Visual Studio Code, open the "Run" menu, then select
            "Start Debugging" (or press F5). This only works if you don't have
            a custom launch.json file (see below).
        - Open run.py in Visual Studio Code, right-click anywhere in the code
            editor, select "Run Python", then select "Run Python File in
            Terminal". This works whether or not you have a custom launch.json
            file (see below).
        - From the terminal, type `python run.py`.

    - To simplify running your web app during development, you can create a
        custom launch.json file in Visual Studio Code. This runs your app
        whenever you choose Run/Start Debugging or press F5, regardless of what
        source file you're currently editing. This method doesn't use run.py.
        - Go to the "Run and Debug" tab in the sidebar.
        - Click the link to "create a launch.json file".
        - Select "More Python Debugger options..." from the menu that appears.
        - Choose "Python Debugger: Flask LoginExample".
        - Save the new launch.json file.

    - You can run your Flask app directly from the command line. However,
        you'll need to specify the app to run. For example, to run `loginapp`
        you'll need to enter `python -m flask --app loginapp run`. This method
        doesn't use run.py.
        
On PythonAnywhere and similar WSGI servers, you can do either of the following
in your WSGI configuration file:

    - Import the `app` object from run.py. For example, in PythonAnywhere's
        WSGI file, set the final line to `from run import app as application`.

    - Import the `app` object directly from the `loginapp` module. For example,
        in PythonAnywhere's WSGI file, set the final line to `from loginapp
        import app as application`. This method doesn't require run.py.

Because there are so many ways to start a Python/Flask web app, and many of
them bypass run.py entirely, don't put any of your application code in here.
Think of run.py as a "shortcut" or "launcher" used to run your Flask app,
rather than a core part of the app itself.
"""
from loginapp import app

# If run.py was actually executed (run), not just imported into another script,
# then start our Flask app on a local development server. To learn more about
# how we check for this, refer to https://realpython.com/if-name-main-python/.
if __name__ == '__main__':
    app.run(debug=True)

from flask import (
    Flask, render_template, request, redirect,
    url_for, session, flash
)
import pymysql
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'replace-me-with-a-secure-random-key'

# --- adjust these to match your local MySQL setup ---
DB_CONFIG = {
    'host': 'localhost',
    'user': 'your_db_user',
    'password': 'your_db_password',
    'db': 'brightpathcareers',
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

def get_db_connection():
    return pymysql.connect(**DB_CONFIG)

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db_connection()
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM users WHERE username=%s", (username,))
            user = cur.fetchone()
        conn.close()

        if user and check_password_hash(user['password_hash'], password):
            session.clear()
            session['user_id']  = user['user_id']
            session['username'] = user['username']
            session['role']     = user['role']
            return redirect(url_for(f"{user['role']}_home"))
        else:
            flash('Invalid username or password')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

def login_required(role):
    """Simple decorator factory to enforce login & role checks."""
    def wrapper(fn):
        def decorated_view(*args, **kwargs):
            if 'role' not in session or session['role'] != role:
                return redirect(url_for('login'))
            return fn(*args, **kwargs)
        decorated_view.__name__ = fn.__name__
        return decorated_view
    return wrapper

@app.route('/customer_home')
@login_required('customer')
def customer_home():
    return render_template('customer_home.html')

@app.route('/staff_home')
@login_required('staff')
def staff_home():
    return render_template('staff_home.html')

@app.route('/admin_home')
@login_required('admin')
def admin_home():
    return render_template('admin_home.html')

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = get_db_connection()
    with conn.cursor() as cur:
        cur.execute(
            "SELECT user_id, username, full_name, email, role "
            "FROM users WHERE user_id=%s",
            (session['user_id'],)
        )
        profile = cur.fetchone()
    conn.close()
    return render_template('profile.html', profile=profile)

if __name__ == '__main__':
    app.run(debug=True)