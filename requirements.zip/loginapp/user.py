import os
import re
from flask import flash, redirect, render_template, request, send_from_directory, url_for
from flask_bcrypt import Bcrypt
from werkzeug.utils import secure_filename

from loginapp import db, app  # Import the actual Flask app instance

ALLOWED_RESUME_EXT = {'pdf'}

flask_bcrypt = Bcrypt(app)
DEFAULT_USER_ROLE = 'student'

def allowed_file(filename, allowed):
    """
    Check if the filename has an allowed extension.

    Args:
        filename (str): The name of the file to check.
        allowed (set): A set of allowed file extensions.

    Returns:
        bool: True if the file has an allowed extension, False otherwise.
    """
    return '.' in filename and filename.rsplit('.',1)[1].lower() in allowed

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        u = request.form['username'].strip()
        email = request.form['email'].strip()
        pwd = request.form['password']
        uni = request.form['university'].strip()
        course = request.form['course'].strip()
        resume = request.files.get('resume')

        # 1) Basic validations
        if not re.match(r'^[A-Za-z0-9_]{4,}$', u):
            flash('Username must be ≥4 chars alnum/_')
        elif pwd != request.form['confirm_password']:
            flash('Passwords must match')
        elif resume and not allowed_file(resume.filename, ALLOWED_RESUME_EXT):
            flash('Resume must be PDF')
        else:
            # 2) Uniqueness check
            cur = db.get_db().cursor()
            cur.execute("SELECT 1 FROM users WHERE username=%s OR email=%s", (u,email))
            if cur.fetchone():
                flash('Username or email already taken')
            else:
                # 3) Store user
                pwd_hash = flask_bcrypt.generate_password_hash(pwd).decode()
                cur.execute(
                  "INSERT INTO users (username,email,password_hash,role) "
                  "VALUES (%s,%s,%s,%s)",
                  (u, email, pwd_hash, DEFAULT_USER_ROLE)
                )
                uid = cur.lastrowid
                # 4) Save resume file if provided
                resume_path = None
                if resume:
                    fn = secure_filename(f"user_{uid}_" + resume.filename)
                    resume.save(os.path.join(app.config['UPLOAD_FOLDER'], fn))
                    resume_path = fn
                # 5) Insert into student table
                cur.execute(
                  "INSERT INTO student (user_id,university,course,resume_path) "
                  "VALUES (%s,%s,%s,%s)",
                  (uid, uni, course, resume_path)
                )
                db.get_db().commit()
                flash('Registration successful—please log in')
                return redirect(url_for('login'))
        return redirect(url_for('register'))
    return render_template('register.html')
