from app import login_required
from loginapp import app, db
from flask import flash, render_template, redirect, url_for, session, request

@app.route('/employer/applications')
@login_required('employer')
def view_applications():
    uid = session['user_id']
    # find your emp_id
    cur = db.get_db().cursor()
    cur.execute("SELECT emp_id FROM employer WHERE user_id=%s", (uid,))
    emp = cur.fetchone()['emp_id']
    cur.execute("""
      SELECT a.student_id,a.internship_id,s.resume_path,
             u.full_name, i.title,a.status,a.feedback
       FROM application a
       JOIN student s ON a.student_id=s.student_id
       JOIN users u   ON s.user_id=u.user_id
       JOIN internship i ON a.internship_id=i.internship_id
      WHERE i.company_id=%s
    """, (emp,))
    apps = cur.fetchall()
    return render_template('manage_applications.html', apps=apps)

@app.route('/employer/application/<int:iid>/<int:sid>', methods=['POST'])
@login_required('employer')
def update_application(iid, sid):
    new_status = request.form['status']     # 'accepted' or 'rejected'
    feedback   = request.form.get('feedback')
    cur = db.get_db().cursor()
    cur.execute("""
      UPDATE application 
         SET status=%s, feedback=%s 
       WHERE internship_id=%s AND student_id=%s
    """, (new_status, feedback, iid, sid))
    db.get_db().commit()
    flash('Application updated')
    return redirect(url_for('view_applications'))