-- MySQL Workbench Forward Engineering
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';


CREATE SCHEMA BrightPathCareers;
USE BrightPathCareers;

CREATE TABLE `users` (
  `user_id`       INT NOT NULL AUTO_INCREMENT,
  `username`      VARCHAR(50)      NOT NULL,
  `full_name`     VARCHAR(100),
  `email`         VARCHAR(100)     NOT NULL,
  `password_hash` CHAR(60) BINARY  NOT NULL,
  `profile_image` VARCHAR(255),
  `role`          ENUM('student','employer','admin') NOT NULL,
  `status`        ENUM('active','inactive') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uq_users_username` (`username`)
);

CREATE TABLE `student` (
  `student_id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `university` VARCHAR(100),
  `course` VARCHAR(100),
  `resume_path` VARCHAR(255),
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `uq_student_user` (`user_id`),
  KEY `fk_student_users` (`user_id`),
  CONSTRAINT `fk_student_users`
    FOREIGN KEY (`user_id`)
    REFERENCES `users` (`user_id`)
    ON DELETE CASCADE
);

CREATE TABLE `employer` (
  `emp_id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `company_name` VARCHAR(100) NOT NULL,
  `company_description` TEXT,
  `website` VARCHAR(100),
  `logo_path` VARCHAR(255),
  PRIMARY KEY (`emp_id`),
  UNIQUE KEY `uq_employer_user` (`user_id`),
  KEY `fk_employer_users` (`user_id`),
  CONSTRAINT `fk_employer_users`
    FOREIGN KEY (`user_id`)
    REFERENCES `users` (`user_id`)
    ON DELETE CASCADE
);

CREATE TABLE `internship` (
  `internship_id` INT NOT NULL AUTO_INCREMENT,
  `company_id` INT NOT NULL,
  `title` VARCHAR(100) NOT NULL,
  `description` TEXT NOT NULL,
  `location` VARCHAR(100),
  `duration` VARCHAR(50),
  `skills_required` TEXT,
  `deadline` DATE,
  `stipend` VARCHAR(50),
  `number_of_opening` INT,
  `additional_req` TEXT,
  PRIMARY KEY (`internship_id`),
  KEY `fk_internship_employer` (`company_id`),
  CONSTRAINT `fk_internship_employer`
    FOREIGN KEY (`company_id`)
    REFERENCES `employer` (`emp_id`)
    ON DELETE CASCADE
);

CREATE TABLE `application` (
  `student_id` INT NOT NULL,
  `internship_id` INT NOT NULL,
  `status` ENUM('submitted','reviewed','accepted','rejected') NOT NULL DEFAULT 'submitted',
  `feedback` TEXT,
  PRIMARY KEY (`student_id`,`internship_id`),
  KEY `fk_app_student` (`student_id`),
  KEY `fk_app_internship` (`internship_id`),
  CONSTRAINT `fk_app_student`
    FOREIGN KEY (`student_id`)
    REFERENCES `student` (`student_id`)
    ON DELETE CASCADE,
  CONSTRAINT `fk_app_internship`
    FOREIGN KEY (`internship_id`)
    REFERENCES `internship` (`internship_id`)
    ON DELETE CASCADE
);




ALTER TABLE `brightpathcareers`.`application` 
DROP PRIMARY KEY,
ADD PRIMARY KEY (`internship_id`, `student_id`);
;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

