import axios from 'axios';

const instance = axios.create({
    baseURL: '/api', // 基础 URL，与 Vite 代理匹配
    timeout: 10000, // 请求超时
    headers: {
        'Content-Type': 'application/json',
    },
});

// 请求拦截器
instance.interceptors.request.use(
    (config) => {
        // 可添加 token 等
        console.log('Request:', config);
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// 响应拦截器
instance.interceptors.response.use(
    (response) => {
        console.log('Response:', response);
        // 可统一处理响应数据
        if (response.status === 200) {
            return response.data;
        } else {
            return Promise.reject(new Error('Response error'));
        }
    },
    (error) => {
        console.error('Error:', error);
        // 可处理 401、404 等错误
        return Promise.reject(error);
    }
);

// 封装方法
const http = {
    get(url, params = {}) {
        return instance.get(url, { params });
    },
    post(url, data = {}) {
        return instance.post(url, data);
    },
    put(url, data = {}) {
        return instance.put(url, data);
    },
    delete(url, params = {}) {
        return instance.delete(url, { params });
    },
};

export default http;