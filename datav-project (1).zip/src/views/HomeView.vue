<template>
  <div>
    <el-button @click="fetchData">Get Data</el-button>
    <el-button @click="submitData">Post Data</el-button>
    <p>{{ message }}</p>
    <ul>
      <li v-for="item in list" :key="item.id">{{ item.name }} - {{ item.age }}</li>
    </ul>
  </div>
</template>

<script>
import http from "@/utils/http";

export default {
  data() {
    return {
      message: '',
      list: [],
    };
  },
  methods: {
    async fetchData() {
      try {
        const res = await http.get('/data');
        this.message = res.message;
        this.list = res.data.list;
      } catch (error) {
        console.error('Fetch error:', error);
      }
    },
    async submitData() {
      try {
        const res = await http.post('/submit', { name: 'Test', value: 123 });
        this.message = res.message;
      } catch (error) {
        console.error('Submit error:', error);
      }
    },
  },
};
</script>