<template>
  <div class="container">
    <div class="header">
      <div style="color: #b1f9ff;font-size: 38px;">健康山东驾驶舱</div>
      <dv-decoration-5 style="width:100%;height:50px;"></dv-decoration-5>
    </div>
    <div class="content">
      <div>
        <div class="chart-item">
          <dv-border-box-8>
            <div class="chart-title">客户服务</div>
            <div id="gauge" style="min-height: 220px;"></div>
          </dv-border-box-8>
        </div>

        <div class="chart-item">
          <dv-border-box-8>
            <div class="chart-title">网格化护士落地</div>
            <div class="list" style="min-height: 220px;">
              <div class="item" v-for="(item, index) in progressItems" :key="index">
                <div class="label">{{ item.label }}</div>
                <div class="progress"><i :style="{ width: item.value + '%' }"></i></div>
                <div>{{ item.count }}</div>
              </div>
            </div>
          </dv-border-box-8>
        </div>
      </div>
      <div>
        <div style="display: flex;flex-direction: row;">
          <div class="chart-item">
            <dv-border-box-8>
              <div style="text-align: center; padding: 20px;">
                <span style="color: white; font-size: 14px; display: block;">交易金额</span>
                <span style="color: white; font-size: 24px; display: block;">$1,234.56</span>
              </div>
            </dv-border-box-8>
          </div>
          <div class="chart-item">
            <dv-border-box-8>
              <div style="text-align: center; padding: 20px;">
                <span style="color: white; font-size: 14px; display: block;">健康济南下载量</span>
                <span style="color: white; font-size: 24px; display: block;">154,124</span>
              </div>
            </dv-border-box-8>
          </div>
        </div>
        <div id="mapChart" style="min-height: 600px;"></div>
      </div>
      <div style="min-width: 300px;">
        <div style="display: flex;">
          <div class="chart-item">
            <dv-border-box-8>
              <div class="chart-title">美团式医疗平台</div>
              <div id="LineBarChart" style="min-height: 200px;">

              </div>
            </dv-border-box-8>
          </div>
        </div>
        <div class="chart-item full-width">
          <dv-border-box-8>
            <div class="chart-title">多元生态盈利模式</div>
            <div id="donut" style="min-height: 200px;"></div>
          </dv-border-box-8>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import * as echarts from 'echarts'
// import 'echarts-gl'
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: 'District',
  data() {
    return {
      formattedSales: '00163927'.split(''),
      mapChart: null,
      gaugeOption: {
        tooltip: {formatter: '{a} <br/>{c}%'},
        series: [{
          name: '签约率',
          type: 'gauge',
          radius: '85%',
          center: ['50%', '60%'],
          min: 0,
          max: 100,
          splitNumber: 10,
          axisLine: {
            lineStyle: {
              width: 16,
              color: [[0.2, '#ff4500'], [0.4, '#ffb400'], [0.6, '#ffd400'], [0.8, '#00c0ff'], [1, '#00ff9c']]
            }
          },
          pointer: {width: 4},
          detail: {formatter: '{value}%', fontSize: 16, color: '#dff9ff'},
          data: [{value: 62.89, name: '签约率'}]
        }]
      },
      barLineOption: {
        color: ['#5ec7ff', '#ffd37a', '#8ee1a3'],
        tooltip: {trigger: 'axis'},
        legend: {data: ['医院', '体检机构', '药店'], textStyle: {color: '#fff'}},
        grid: {left: '6%', right: '6%', top: '18%', bottom: '8%', containLabel: true},
        xAxis: {
          type: 'category',
          data: ['济宁', '日照', '临沂', '滨州', '济南'],
          axisLine: {lineStyle: {color: '#ccc'}}
        },
        yAxis: [{
          type: 'value',
          name: '数量',
          axisLine: {lineStyle: {color: '#ccc'}},
          splitLine: {lineStyle: {color: 'rgba(255,255,255,0.03)'}}
        }],
        series: [
          {name: '医院', type: 'bar', data: [120, 80, 125, 60, 180], barGap: '10%'},
          {name: '体检机构', type: 'bar', data: [30, 100, 60, 50, 120]},
          {name: '药店', type: 'line', data: [50, 70, 40, 30, 95], yAxisIndex: 0, smooth: true}
        ]
      },
      pieOption: {
        tooltip: {trigger: 'item'},
        legend: {orient: 'vertical', right: 6, top: 12, textStyle: {color: '#fff'}},
        series: [{
          name: '下载量',
          type: 'pie',
          radius: ['40%', '68%'],
          center: ['45%', '50%'],
          avoidLabelOverlap: false,
          label: {show: false, position: 'center'},
          labelLine: {show: false},
          data: [
            {value: 2361, name: '青岛'},
            {value: 1643, name: '日照'},
            {value: 1248, name: '临沂'},
            {value: 958, name: '济宁'},
            {value: 3620, name: '济南'}
          ],
          emphasis: {itemStyle: {shadowBlur: 10, shadowOffsetX: 0, shadowColor: 'rgba(0,0,0,0.5)'}}
        }]
      },
      donutOption: {
        tooltip: {trigger: 'item'},
        legend: {top: 6, textStyle: {color: '#fff'}},
        series: [{
          name: '下载量',
          type: 'pie',
          radius: ['40%', '70%'],
          avoidLabelOverlap: false,
          label: {show: true, position: 'outside', color: '#fff', formatter: '{b}\n{c}'},
          data: [
            {value: 3620, name: '济南'},
            {value: 2361, name: '青岛'},
            {value: 1643, name: '日照'},
            {value: 1248, name: '临沂'},
            {value: 958, name: '济宁'}
          ]
        }]
      },
      bottomOption: {
        tooltip: {trigger: 'axis'},
        legend: {data: ['绿通', '体检', '总合'], textStyle: {color: '#fff'}},
        grid: {left: '6%', right: '6%', bottom: '8%', top: '14%'},
        xAxis: {
          type: 'category',
          data: ['济南', '青岛', '烟台', '日照', '临沂', '济宁', '枣庄', '东营', '威海', '泰安', '聊城', '潍坊'],
          axisLine: {lineStyle: {color: '#ccc'}}
        },
        yAxis: {type: 'value', axisLine: {lineStyle: {color: '#ccc'}}},
        series: [
          {name: '绿通', type: 'bar', stack: 'a', data: [65, 78, 55, 45, 70, 84, 28, 36, 24, 60, 30, 44]},
          {name: '体检', type: 'bar', stack: 'a', data: [40, 50, 32, 28, 48, 60, 18, 22, 14, 35, 20, 30]},
          {
            name: '总合',
            type: 'line',
            data: [105, 128, 87, 73, 118, 144, 46, 58, 38, 95, 50, 74],
            smooth: true,
            yAxisIndex: 0
          }
        ]
      },
      progressItems: [
        {label: '医生', value: 78, count: '274/人'},
        {label: '网格化护士', value: 48, count: '174/次'},
        {label: '服务站点', value: 78, count: '274/人'}
      ]
    };
  },
  async mounted() {
    this.animateDigits();
    await this.initMapChart();
    this.init3dPieChart() ;
    this.initLineBarChart();
    this.initYiBiao();
  },
  methods: {
    animateDigits() {
      const target = "00163927".split('');
      const digitElems = document.querySelectorAll('#digits .digit');
      const duration = 1000;
      const steps = 30;
      digitElems.forEach((el, i) => {
        const start = 0;
        const end = parseInt(target[i] || '0', 10);
        let step = (end - start) / steps;
        let t = 0;
        const timer = setInterval(() => {
          t++;
          let val = Math.round(start + step * t);
          if (val < 0) val = 0;
          el.textContent = val;
          if (t >= steps) {
            el.textContent = end;
            clearInterval(timer);
          }
        }, duration / steps);
      });
    },
    async initMapChart() {
      // DOM & ECharts 实例
      const chartDom = document.getElementById('mapChart');
      const myChart = echarts.init(chartDom);

      // 异步拉取章丘区 GeoJSON
      const geoUrl = 'https://geo.datav.aliyun.com/areas_v3/bound/370114.json'; // 章丘区 GeoJSON URL
      let zhangqiuGeo = null;
      try {
        const res = await fetch(geoUrl);
        zhangqiuGeo = await res.json();
      } catch (err) {
        console.error('加载 GeoJSON 失败：', err);
        chartDom.innerHTML = '<div style="padding:20px;color:#ffd;font-size:16px;">加载地图失败，请检查网络或更换 GeoJSON 地址。</div>';
        return;
      }

      // 注册地图
      echarts.registerMap('zhangqiu', zhangqiuGeo);

      // 配置选项：3D效果地图
      const option = {
        backgroundColor: 'transparent',
        title: {
          text: '章丘区3D地图',
          left: 'center',
          top: 12,
          textStyle: { color: '#cfefff', fontSize: 18 }
        },
        tooltip: {
          trigger: 'item',
          backgroundColor: 'rgba(3,19,40,0.9)',
          borderColor: '#0eb5ff',
          borderWidth: 1,
          textStyle: { color: '#fff' },
          formatter: params => `${params.name}<br/>值: ${params.data && params.data.value != null ? params.data.value : '无'}`
        },
        geo: [
          // 第一层（最上层）
          {
            map: 'zhangqiu',
            aspectScale: 0.85,
            zoom: 1.2,
            top: '8%',
            left: '10%',
            roam: false,
            z: 5,
            label: {
              show: true,
              color: '#FFFFFF',
              fontWeight: 'bold',
              fontSize: 24
            },
            itemStyle: {
              areaColor: '#1B8ABE',
              borderColor: '#FFFFFF',
              borderWidth: 2,
              shadowColor: '#1B8ABE',
              shadowOffsetX: 0,
              shadowOffsetY: 6,
              shadowBlur: 15
            },
            emphasis: { itemStyle: { areaColor: '#1BDDCD' }, label: { show: false } },
            select: { itemStyle: { areaColor: '#1BDDCD' } },
            tooltip: { show: false }
          },
          // 第二层（中间层）
          {
            map: 'zhangqiu',
            aspectScale: 0.85,
            zoom: 1.2,
            top: '9%',
            left: '10%',
            roam: false,
            z: 4,
            label: {
              show: true,
              color: '#FFFFFF',
              fontWeight: 'bold',
              fontSize: 24
            },
            itemStyle: {
              areaColor: '#85D2E0',
              borderColor: '#FFFFFF',
              borderWidth: 2,
              shadowColor: '#85D2E0',
              shadowOffsetX: 0,
              shadowOffsetY: 6,
              shadowBlur: 15
            },
            emphasis: { itemStyle: { areaColor: '#1BDDCD' }, label: { show: false } },
            select: { itemStyle: { areaColor: '#1BDDCD' } },
            tooltip: { show: false }
          },
          // 第三层（最底层）
          {
            map: 'zhangqiu',
            aspectScale: 0.85,
            zoom: 1.2,
            top: '10%',
            left: '10%',
            roam: false,
            z: 3,
            label: {
              show: true,
              color: '#FFFFFF',
              fontWeight: 'bold',
              fontSize: 24
            },
            itemStyle: {
              areaColor: '#85D2EE',
              borderColor: '#104E8B',
              borderWidth: 2,
              shadowColor: '#104E8B',
              shadowOffsetX: 0,
              shadowOffsetY: 6,
              shadowBlur: 15
            },
            emphasis: { itemStyle: { areaColor: '#1BDDCD' }, label: { show: false } },
            select: { itemStyle: { areaColor: '#1BDDCD' } },
            tooltip: { show: false }
          }
        ],
        series: [
          {
            type: 'map',
            map: 'zhangqiu',
            aspectScale: 0.85,
            zoom: 1.2,
            top: '8%',
            left: '10%',
            roam: false,
            label: {
              show: true,
              color: '#FFFFFF',
              fontWeight: 'bold',
              fontSize: 24
            },
            itemStyle: {
              areaColor: '#87CEFA',
              borderColor: '#FFFFFF',
              borderWidth: 2
            },
            emphasis: { itemStyle: { areaColor: '#1BDDCD' }, label: { show: false } },
            select: { itemStyle: { areaColor: '#1BDDCD' } }
          }
        ]
      };

      myChart.setOption(option);
      window.addEventListener('resize', () => myChart.resize());
    },
    init3dPieChart() {
      const optionData = [
        { name: '汇总', value: 2361, itemStyle: { color: '#22c4ff' } },
        { name: '日照', value: 1643, itemStyle: { color: '#aaff00' } },
        { name: '临沂', value: 1248, itemStyle: { color: '#ffaaff' } },
        { name: '济南', value: 3620, itemStyle: { color: '#00ff7f' } },
        { name: '济宁', value: 958, itemStyle: { color: '#ff4500' } }
      ];

      function initChart() {
        const myChart = echarts.init(document.getElementById('LineBarChart'));
        const option = getPie3D(optionData, 0); // Set internalDiameterRatio to 0 for full pie chart
        myChart.setOption(option);
        bindListen(myChart,option);
      }

      function getPie3D(pieData, internalDiameterRatio)  {
        let series = [];
        let sumValue = 0;
        let startValue = 0;
        let endValue = 0;
        let legendData = [];
        let k = 1 - internalDiameterRatio;

        pieData.sort((a, b) => b.value - a.value);
        for (let i = 0; i < pieData.length; i++) {
          sumValue += pieData[i].value;
          let seriesItem = {
            name: pieData[i].name || `series${i}`,
            type: 'surface',
            parametric: true,
            wireframe: { show: false },
            pieData: pieData[i],
            pieStatus: { selected: false, hovered: false, k: k },
            center: ['50%', '50%']
          };

          if (pieData[i].itemStyle) {
            let itemStyle = {};
            if (pieData[i].itemStyle.color) itemStyle.color = pieData[i].itemStyle.color;
            if (pieData[i].itemStyle.opacity) itemStyle.opacity = pieData[i].itemStyle.opacity;
            seriesItem.itemStyle = itemStyle;
          }
          series.push(seriesItem);
        }

        legendData = [];
        for (let i = 0; i < series.length; i++) {
          endValue = startValue + series[i].pieData.value;
          series[i].pieData.startRatio = startValue / sumValue;
          series[i].pieData.endRatio = endValue / sumValue;
          series[i].parametricEquation = getParametricEquation(
              series[i].pieData.startRatio,
              series[i].pieData.endRatio,
              false,
              false,
              k,
              series[i].pieData.value
          );
          startValue = endValue;
          let bfb = fomatFloat(series[i].pieData.value / sumValue, 4);
          legendData.push({ name: series[i].name, value: bfb });
        }

        let boxHeight = getHeight3D(series, 26);

        return {
          legend: {
            data: legendData,
            orient: 'horizontal',
            left: 10,
            top: 10,
            itemGap: 10,
            textStyle: { color: '#A1E2FF' },
            show: true,
            icon: "circle",
            formatter: function (param) {
              let item = legendData.find(item => item.name === param);
              let bfs = fomatFloat(item.value * 100, 2) + "%";
              return `${item.name}  ${bfs}`;
            }
          },
          labelLine: { show: true, lineStyle: { color: '#7BC0CB' } },
          label: {
            show: true,
            position: 'outside',
            rich: { b: { color: '#7BC0CB', fontSize: 12, lineHeight: 20 }, c: { fontSize: 16 } },
            formatter: '{b|{b} \n}{c|{c}}'
          },
          tooltip: {
            formatter: params => {
              if (params.seriesName !== 'pie2d') {
                let seriesIndex = params.seriesIndex;
                let startRatio = series[seriesIndex].pieData.startRatio;
                let endRatio = series[seriesIndex].pieData.endRatio;
                let bfb = ((endRatio - startRatio) * 100).toFixed(2);
                return `${params.seriesName}<br/>` +
                    `<span style="display:inline-block;margin-right:5px;border-radius:10px;width:10px;height:10px;background-color:${params.color};"></span>` +
                    `${bfb}%`;
              }
            }
          },
          xAxis3D: { min: -1, max: 1 },
          yAxis3D: { min: -1, max: 1 },
          zAxis3D: { min: -1, max: 1 },
          grid3D: {
            show: false,
            boxHeight: boxHeight,
            viewControl: {
              alpha: 40,
              distance: 300,
              rotateSensitivity: 0,
              zoomSensitivity: 0,
              panSensitivity: 0,
              autoRotate: false
            }
          },
          series: series
        };
      }

      function getHeight3D(series, height) {
        series.sort((a, b) => b.pieData.value - a.pieData.value);
        return height * 25 / series[0].pieData.value;
      }

      function getParametricEquation(startRatio, endRatio, isSelected, isHovered, k, h) {
        let midRatio = (startRatio + endRatio) / 2;
        let startRadian = startRatio * Math.PI * 2;
        let endRadian = endRatio * Math.PI * 2;
        let midRadian = midRatio * Math.PI * 2;
        if (startRatio === 0 && endRatio === 1) isSelected = false;
        k = k || 1 / 3;
        let offsetX = isSelected ? Math.cos(midRadian) * 0.1 : 0;
        let offsetY = isSelected ? Math.sin(midRadian) * 0.1 : 0;
        let hoverRate = isHovered ? 1.05 : 1;

        return {
          u: { min: -Math.PI, max: Math.PI * 3, step: Math.PI / 32 },
          v: { min: 0, max: Math.PI * 2, step: Math.PI / 20 },
          x: function(u, v) {
            if (u < startRadian) return offsetX + Math.cos(startRadian) * (1 + Math.cos(v) * k) * hoverRate;
            if (u > endRadian) return offsetX + Math.cos(endRadian) * (1 + Math.cos(v) * k) * hoverRate;
            return offsetX + Math.cos(u) * (1 + Math.cos(v) * k) * hoverRate;
          },
          y: function(u, v) {
            if (u < startRadian) return offsetY + Math.sin(startRadian) * (1 + Math.cos(v) * k) * hoverRate;
            if (u > endRadian) return offsetY + Math.sin(endRadian) * (1 + Math.cos(v) * k) * hoverRate;
            return offsetY + Math.sin(u) * (1 + Math.cos(v) * k) * hoverRate;
          },
          z: function(u, v) {
            if (u < -Math.PI * 0.5) return Math.sin(u);
            if (u > Math.PI * 2.5) return Math.sin(u) * h * .1;
            return Math.sin(v) > 0 ? 1 * h * .1 : -1;
          }
        };
      }

      function fomatFloat(num, n) {
        let f = parseFloat(num);
        if (isNaN(f)) return false;
        f = Math.round(num * Math.pow(10, n)) / Math.pow(10, n);
        let s = f.toString();
        let rs = s.indexOf('.');
        if (rs < 0) { rs = s.length; s += '.'; }
        while (s.length <= rs + n) s += '0';
        return s;
      }

      function bindListen(myChart,option) {
        let selectedIndex = '';
        let hoveredIndex = '';
        myChart.on('click', function(params) {
          let isSelected = !option.series[params.seriesIndex].pieStatus.selected;
          let isHovered = option.series[params.seriesIndex].pieStatus.hovered;
          let k = option.series[params.seriesIndex].pieStatus.k;
          let startRatio = option.series[params.seriesIndex].pieData.startRatio;
          let endRatio = option.series[params.seriesIndex].pieData.endRatio;
          if (selectedIndex !== '' && selectedIndex !== params.seriesIndex) {
            option.series[selectedIndex].parametricEquation = getParametricEquation(option.series[selectedIndex].pieData.startRatio, option.series[selectedIndex].pieData.endRatio, false, false, k, option.series[selectedIndex].pieData.value);
            option.series[selectedIndex].pieStatus.selected = false;
          }
          option.series[params.seriesIndex].parametricEquation = getParametricEquation(startRatio, endRatio, isSelected, isHovered, k, option.series[params.seriesIndex].pieData.value);
          option.series[params.seriesIndex].pieStatus.selected = isSelected;
          isSelected ? selectedIndex = params.seriesIndex : null;
          myChart.setOption(option);
        });
        myChart.on('mouseover', function(params) {
          if (hoveredIndex === params.seriesIndex) return;
          if (hoveredIndex !== '') {
            let isSelected = option.series[hoveredIndex].pieStatus.selected;
            let isHovered = false;
            let startRatio = option.series[hoveredIndex].pieData.startRatio;
            let endRatio = option.series[hoveredIndex].pieData.endRatio;
            let k = option.series[hoveredIndex].pieStatus.k;
            option.series[hoveredIndex].parametricEquation = getParametricEquation(startRatio, endRatio, isSelected, isHovered, k, option.series[hoveredIndex].pieData.value);
            option.series[hoveredIndex].pieStatus.hovered = isHovered;
            hoveredIndex = '';
          }
          let isSelected = option.series[params.seriesIndex].pieStatus.selected;
          let isHovered = true;
          let startRatio = option.series[params.seriesIndex].pieData.startRatio;
          let endRatio = option.series[params.seriesIndex].pieData.endRatio;
          let k = option.series[params.seriesIndex].pieStatus.k;
          option.series[params.seriesIndex].parametricEquation = getParametricEquation(startRatio, endRatio, isSelected, isHovered, k, option.series[params.seriesIndex].pieData.value + 5);
          option.series[params.seriesIndex].pieStatus.hovered = isHovered;
          hoveredIndex = params.seriesIndex;
          myChart.setOption(option);
        });
        myChart.on('globalout', function() {
          if (hoveredIndex !== '') {
            let isSelected = option.series[hoveredIndex].pieStatus.selected;
            let isHovered = false;
            let startRatio = option.series[hoveredIndex].pieData.startRatio;
            let endRatio = option.series[hoveredIndex].pieData.endRatio;
            let k = option.series[hoveredIndex].pieStatus.k;
            option.series[hoveredIndex].parametricEquation = getParametricEquation(startRatio, endRatio, isSelected, isHovered, k, option.series[hoveredIndex].pieData.value);
            option.series[hoveredIndex].pieStatus.hovered = isHovered;
            hoveredIndex = '';
          }
          myChart.setOption(option);
        });
      }
      initChart()
    },
    initYiBiao(){
      var chart = echarts.init(document.getElementById('gauge'));
      var value = 62.89;
      var option = {
        series: [
          {
            type: 'gauge',
            startAngle: 210,
            endAngle: -30,
            min: 0,
            max: 100,
            splitNumber: 10,

            axisLine: {
              lineStyle: {
                width: 15,
                color: [
                  [0.25, '#ffa500'], // 橙
                  [0.5, '#ffff00'],  // 黄
                  [0.75, '#00ff7f'], // 绿
                  [0.9, '#ffff00'],  // 黄
                  [1, '#ffa500']     // 橙
                ]
              },
              roundCap: true // 让环形边缘圆润
            },
            pointer: {
              show: true,
              length: '65%',
              width: 8,
              itemStyle: {
                color: '#4286f4'
              }
            },
            axisTick: {
              show: true,
              inside: true, // 刻度线放内部
              length: 8,
              lineStyle: {
                color: '#fff'
              }
            },
            splitLine: {
              show: true,
              inside: true, // 分隔线也放内部
              length: 15,
              lineStyle: {
                color: '#fff',
                width: 2
              }
            },
            axisLabel: {
              color: '#fff',
              distance: 20,
              fontSize: 14
            },
            detail: {
              valueAnimation: true,
              fontSize: 28,
              offsetCenter: [0, '80%'],
              color: '#ffeb3b',
              formatter: '{value}%'
            },
            data: [
              {
                value: value
              }
            ]
          }
        ]
      };
      chart.setOption(option);
    },
    initLineBarChart() {
      const option = {
        title: {
          text: '绿通 vs 体检套餐对比',
          left: 'center',
          textStyle: { color: '#cfefff' }
        },
        tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
        legend: {
          data: ['绿通', '体检套餐'],
          top: '5%',
          textStyle: { color: '#cfefff' }
        },
        xAxis: {
          type: 'category',
          data: ['济南', '日照', '临沂', '青岛'],
          axisLabel: { color: '#cfefff' },
          axisLine: { lineStyle: { color: '#4650FF' } }
        },
        yAxis: {
          type: 'value',
          axisLabel: { color: '#cfefff' },
          axisLine: { lineStyle: { color: '#4650FF' } },
          splitLine: { lineStyle: { color: 'rgba(70, 80, 255, 0.3)' } }
        },
        series: [
          {
            name: '绿通',
            type: 'bar',
            data: [300, 500, 700, 900],
            itemStyle: { color: '#00FF7F' }
          },
          {
            name: '体检套餐',
            type: 'bar',
            data: [200, 400, 800, 1000],
            itemStyle: { color: '#FFA500' }
          }
        ]
      };
      const myChart = echarts.init(document.getElementById('donut'));
      myChart.setOption(option);
    }
  },
};
</script>

<style scoped>
.container {
  width: 100%;
  height: 100%;
  background: linear-gradient(#021634, #032242);
  color: #fff;
}

.header {
  padding: 16px;
  text-align: center;
}

.content {
  display: flex;
  justify-content: space-around;
  padding: 0px!important;
}

.chart-item {
  flex: 1 1 30%;
  margin: 12px;
}

.full-width {
  flex: 1 1 100%;
}

.chart-title {
  font-size: 16px;
  margin-bottom: 8px;
  text-align: center;
}

.big-number {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px;
}

.label {
  color: #9fd6ff;
  font-size: 16px;
}

.digits {
  display: flex;
  gap: 8px;
}

.digit {
  width: 54px;
  height: 72px;
  border-radius: 6px;
  background: linear-gradient(180deg, rgba(1, 88, 143, 0.14), rgba(2, 40, 80, 0.16));
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 40px;
  color: #dff9ff;
  border: 1px solid rgba(80, 200, 255, 0.12);
}

.list {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-top: 6px;
}

.item {
  display: flex;
  align-items: center;
  gap: 12px;
}

.label {
  width: 80px;
  color: #b7e9ff;
  font-size: 13px;
}

.progress {
  flex: 1;
  height: 12px;
  background: rgba(255, 255, 255, 0.06);
  border-radius: 6px;
  overflow: hidden;
}

.progress > i {
  display: block;
  height: 100%;
  background: linear-gradient(90deg, rgba(61, 200, 255, 0.8), rgba(48, 120, 255, 0.9));
  border-radius: 6px;
}
</style>