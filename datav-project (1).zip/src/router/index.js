import VueRouter from 'vue-router'
import Province from "@/views/Province.vue";
import City from "@/views/City.vue";
import District from "@/views/District.vue";

const routes = [
    {path: '/', redirect: '/district'},
    {path: '/province', name: 'Province', component: Province},
    {path: '/city/', name: 'City', component: City},
    {path: '/district/', name: 'District', component: District},];
const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL, // 使用 Vue CLI 提供的 BASE_URL
    routes: routes
})

export default router
