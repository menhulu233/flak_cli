import Mock from 'mockjs';

Mock.mock('/api/data', 'get', {
    code: 200,
    message: 'Success',
    data: Mock.mock({
        'list|5-10': [{
            'id|+1': 1,
            name: '@name',
            age: '@integer(18, 60)',
        }],
    }),
});

Mock.mock('/api/submit', 'post', (req) => {
    const body = JSON.parse(req.body);
    return {
        code: 200,
        message: 'Submitted successfully',
        data: body,
    };
});
// 省级数据：GET /api/provinces
// 返回 3-5 条省份数据，包含 id 和 name
Mock.mock('/api/provinces', 'get', {
    code: 200,
    message: '获取省级数据成功',
    data: {
        'list|3-5': [
            {
                'id|+1': 1, // ID 从 1 开始递增
                name: '@province', // 随机生成省份名称
            },
        ],
    },
});

// 市级数据：GET /api/cities/:provinceId
// 根据 provinceId 返回 2-4 条城市数据，包含 id, name, provinceId
Mock.mock(/\/api\/cities\/\d+/, 'get', (req) => {
    const provinceId = req.url.match(/\/cities\/(\d+)/)[1]; // 提取 provinceId
    return {
        code: 200,
        message: `获取省 ${provinceId} 的市级数据成功`,
        data: {
            'info': [
                {
                    'id': 101, // 市级 ID 从 101 开始
                    name: '@city', // 随机生成城市名称
                    provinceId: Number(provinceId), // 关联 provinceId
                },
            ],
        },
    };
});

// 区/县级数据：GET /api/districts/:provinceId/:cityId
// 根据 provinceId 和 cityId 返回 2-4 条区/县数据，包含 id, name, provinceId, cityId
Mock.mock(/\/api\/districts\/\d+\/\d+/, 'get', (req) => {
    const [, provinceId, cityId] = req.url.match(/\/districts\/(\d+)\/(\d+)/); // 提取参数
    return {
        code: 200,
        message: `获取省 ${provinceId} 市 ${cityId} 的区/县级数据成功`,
        data: {
            'info': [
                {
                    'id': 1001, // 区/县级 ID 从 1001 开始
                    name: '@county', // 随机生成区/县名称
                    provinceId: Number(provinceId), // 关联 provinceId
                    cityId: Number(cityId), // 关联 cityId
                },
            ],
        },
    };
});