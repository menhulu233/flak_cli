import Vue from 'vue'
import App from './App.vue'
import router from './router'
import ElementUI from 'element-ui'; // 引入 Element UI
import 'element-ui/lib/theme-chalk/index.css'; // 引入 CSS
import './styles/main.css'
import './mock/index'
import VueRouter from "vue-router";
import dataV from '@jiaminghi/data-view'

Vue.use(dataV)
Vue.use(VueRouter)
Vue.use(ElementUI); // 注册 Element UI
const app=new Vue({
  router,
  render: (h) => h(App)
})
app.$mount('#app')
