import {defineConfig} from 'vite'
import vue from '@vitejs/plugin-vue'
import {viteMockServe} from "vite-plugin-mock";
import {resolve} from 'path'
// https://vite.dev/config/
export default defineConfig(({command, mode}) => {
        return {
            plugins: [
                vue(),
                viteMockServe({
                    mockPath: './src/mock',     // 扫描目录
                    localEnabled: true, // 开发期
                    prodEnabled: false,          // 正式包不混入
                    logger: true
                }),
            ],
            resolve: {
                alias: {
                    '@': resolve(__dirname, 'src')
                }
            },
            server: {
                cors: true
            }   // 允许跨域
        }
    }
)
