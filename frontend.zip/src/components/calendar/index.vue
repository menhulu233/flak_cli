<template>
  <div class="calendar">
    <div class="calendar-header">
      <button @click="prevYear">«</button>
      <button @click="prevMonth">‹</button>
      <span>{{ currentYear }}年 {{ currentMonth + 1 }}月</span>
      <button @click="nextMonth">›</button>
      <button @click="nextYear">»</button>
    </div>
    <div class="calendar-body">
      <div class="calendar-weekdays">
        <span v-for="day in weekdays" :key="day">{{ day }}</span>
      </div>
      <div class="calendar-days">
        <span v-for="blank in blanks" :key="'b' + blank" class="calendar-day blank"></span>
        <span
          v-for="(day, index) in daysInMonth"
          :key="index"
          class="calendar-day"
          :class="{ today: isToday(day) }"
        >
          {{ day }}
        </span>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed } from 'vue'

export default {
  name: 'CustomCalendar',
  setup() {
    const currentDate = ref(new Date())
    const currentYear = computed(() => currentDate.value.getFullYear())
    const currentMonth = computed(() => currentDate.value.getMonth())

    const weekdays = ['日', '一', '二', '三', '四', '五', '六']

    const daysInMonth = computed(() => {
      const end = new Date(currentYear.value, currentMonth.value + 1, 0)
      return Array.from({ length: end.getDate() }, (_, i) => i + 1)
    })

    const blanks = computed(() => {
      const start = new Date(currentYear.value, currentMonth.value, 1)
      return Array.from({ length: start.getDay() })
    })

    const isToday = (day) => {
      const today = new Date()
      return (
        day === today.getDate() &&
        currentMonth.value === today.getMonth() &&
        currentYear.value === today.getFullYear()
      )
    }

    const prevMonth = () => {
      currentDate.value.setMonth(currentDate.value.getMonth() - 1)
      currentDate.value = new Date(currentDate.value) // 触发响应
    }

    const nextMonth = () => {
      currentDate.value.setMonth(currentDate.value.getMonth() + 1)
      currentDate.value = new Date(currentDate.value) // 触发响应
    }

    const prevYear = () => {
      currentDate.value.setFullYear(currentDate.value.getFullYear() - 1)
      currentDate.value = new Date(currentDate.value) // 触发响应
    }

    const nextYear = () => {
      currentDate.value.setFullYear(currentDate.value.getFullYear() + 1)
      currentDate.value = new Date(currentDate.value) // 触发响应
    }

    return {
      currentYear,
      currentMonth,
      weekdays,
      daysInMonth,
      blanks,
      isToday,
      prevMonth,
      nextMonth,
      prevYear,
      nextYear
    }
  }
}
</script>

<style scoped>
.calendar {
  width: 100%;
  max-width: 400px;
  margin: 0 auto;
  background-color: #f9f9f9;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  font-family: Arial, sans-serif;
}

.calendar-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  background-color: #333;
  color: #fff;
}

.calendar-header button {
  background: none;
  border: none;
  color: #fff;
  font-size: 18px;
  cursor: pointer;
}

.calendar-body {
  padding: 10px;
}

.calendar-weekdays {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  text-align: center;
  font-weight: bold;
  color: #666;
}

.calendar-days {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  text-align: center;
  margin-top: 5px;
}

.calendar-day {
  padding: 10px;
  border-radius: 4px;
  transition: background-color 0.3s;
}

.calendar-day.today {
  background-color: #333;
  color: #fff;
}

.calendar-day.blank {
  background-color: transparent;
}
</style>
