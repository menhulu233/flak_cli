<template>
  <div class="genre-page">
    <h1>流派详情 - {{ $route.params.id }}</h1>
    <p>待实现：流派 {{ $route.params.id }} 的详细信息</p>
  </div>
</template>

<style scoped>
.genre-page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 16px;
}
</style>