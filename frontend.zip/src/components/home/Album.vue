<template>
  <div class="album-page">
    <h1>专辑详情 - {{ $route.params.id }}</h1>
    <p>待实现：专辑 {{ $route.params.id }} 的详细信息</p>
  </div>
</template>

<style scoped>
.album-page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 16px;
}
</style>