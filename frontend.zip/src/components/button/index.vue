<script>
import { ElButton } from 'element-plus';

export default {
  name: 'CustomButton',
  components: {
    ElButton
  },
  props: {
    type: {
      type: String,
      default: 'button'
    },
    label: {
      type: String,
      required: true
    },
    size: {
      type: String,
      default: 'medium'
    },
    onClick: {
      type: Function,
      default: () => {}
    }
  }
}
</script>

<template>
  <el-button :type="type" :size="size" @click="onClick">
    {{ label }}
  </el-button>
</template>

<style scoped>
@import "/src/css/base.css";

.el-button {
  width: 100px;
  height: 40px;
  font-size: 15px;
  margin-right: 10px;
  padding: 10px 15px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
}
</style>

