<template>
  <a-form :model="form" :rules="rules" @finish="onSubmit" layout="vertical">
    <a-form-item label="用户名" name="username">
      <a-input v-model:value="form.username" placeholder="请输入用户名" size="large" />
    </a-form-item>
    <a-form-item label="邮箱" name="email">
      <a-input v-model:value="form.email" placeholder="请输入邮箱" size="large" />
    </a-form-item>
    <a-form-item label="新密码" name="newPassword">
      <a-input-password v-model:value="form.newPassword" placeholder="请输入新密码" size="large" />
    </a-form-item>
    <a-form-item>
      <a-button type="primary" html-type="submit" block :loading="loading" size="large">
        重置密码
      </a-button>
    </a-form-item>
  </a-form>
</template>

<script setup>
import { ref } from 'vue'
import { defineEmits } from 'vue'

const emit = defineEmits(['submit'])

const form = ref({
  username: '',
  email: '',
  newPassword: ''
})

const loading = ref(false)

const rules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 3, message: '用户名至少3个字符', trigger: 'blur' }
  ],
  email: [
    { required: true, message: '请输入邮箱', trigger: 'blur' },
    { type: 'email', message: '邮箱格式错误', trigger: 'blur' }
  ],
  newPassword: [
    { required: true, message: '请输入新密码', trigger: 'blur' },
    { min: 6, message: '新密码至少6个字符', trigger: 'blur' }
  ]
}

const onSubmit = async () => {
  console.log('ResetPasswordForm: onSubmit triggered', form.value)
  loading.value = true
  try {
    emit('submit', { ...form.value })
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.ant-form {
  width: 100%;
}

.ant-form-item {
  margin-bottom: 16px;
}

.ant-btn {
  border-radius: 4px;
  font-weight: 500;
}

@media (max-width: 768px) {
  .ant-form-item {
    margin-bottom: 12px;
  }
  .ant-btn {
    font-size: 14px;
  }
}
</style>