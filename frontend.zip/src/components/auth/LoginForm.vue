<template>
  <a-form :model="form" :rules="rules" @finish="onSubmit" layout="vertical">
    <a-form-item label="用户名" name="username">
      <a-input v-model:value="form.username" placeholder="请输入用户名" size="large" />
    </a-form-item>
    <a-form-item label="密码" name="password">
      <a-input-password v-model:value="form.password" placeholder="请输入密码" size="large" />
    </a-form-item>
    <a-form-item>
      <a-button type="primary" html-type="submit" block :loading="loading" size="large">
        登录
      </a-button>
    </a-form-item>
  </a-form>
</template>

<script setup>
import { ref } from 'vue'
import { defineEmits } from 'vue'

const emit = defineEmits(['submit'])

const form = ref({
  username: '',
  password: ''
})

const loading = ref(false)

const rules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 3, message: '用户名至少3个字符', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, message: '密码至少6个字符', trigger: 'blur' }
  ]
}

const onSubmit = async () => {
  loading.value = true
  try {
    emit('submit', { ...form.value })
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.ant-form {
  width: 100%;
}

.ant-form-item {
  margin-bottom: 16px;
}

.ant-btn {
  border-radius: 4px;
  font-weight: 500;
}

@media (max-width: 768px) {
  .ant-form-item {
    margin-bottom: 12px;
  }

  .ant-btn {
    font-size: 14px;
  }
}
</style>