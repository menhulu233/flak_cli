<template>
  <a-layout-footer class="footer">
    <div class="footer-content">
      <div class="copyright">
        © 2025 音乐系统. All Rights Reserved.
      </div>
    </div>
  </a-layout-footer>
</template>

<style scoped>
.footer {
  text-align: center;
  background: #f0f2f5;
  padding: 20px 0;
}
.footer-content {
  max-width: 1200px;
  margin: 0 auto;
}
.links a {
  margin: 0 10px;
  color: #1890ff;
  text-decoration: none;
}
.copyright {
  margin-top: 10px;
  color: #888;
}
</style>