<template>
  <a-layout-header class="header">
    <div class="logo">
      <router-link to="/home">音乐系统</router-link>
    </div>
    <a-menu mode="horizontal" :selected-keys="currentRoute" class="nav-menu">
      <a-menu-item key="/home">
        <router-link to="/home">首页</router-link>
      </a-menu-item>
      <a-menu-item key="/explore">
        <router-link to="/explore">探索</router-link>
      </a-menu-item>
      <a-menu-item key="/interaction">
        <router-link to="/interaction">互动</router-link>
      </a-menu-item>
      <a-menu-item key="/profile" v-if="isAuthenticated">
        <router-link to="/profile">个人空间</router-link>
      </a-menu-item>
    </a-menu>
    <div class="search-bar">
      <a-input-search
          v-model:value="searchQuery"
          placeholder="搜索歌曲、歌手、专辑"
          @search="handleSearch"
          size="large"
      />
    </div>
    <div class="user-section">
      <template v-if="isAuthenticated">
        <a-dropdown>
          <a class="ant-dropdown-link">
            <span class="username">{{ user.username }}</span>
            <down-outlined class="dropdown-icon" />
          </a>
          <template #overlay>
            <a-menu>
              <a-menu-item>
                <router-link to="/profile">个人中心</router-link>
              </a-menu-item>
              <a-menu-item @click="logout">退出登录</a-menu-item>
            </a-menu>
          </template>
        </a-dropdown>
      </template>
      <router-link v-else to="/login" class="login-link">登录</router-link>
    </div>
  </a-layout-header>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { DownOutlined } from '@ant-design/icons-vue'
import { useAuthStore } from '@/stores/modules/auth'

const router = useRouter()
const route = useRoute()
const authStore = useAuthStore()

const searchQuery = ref('')
const isAuthenticated = computed(() => authStore.isAuthenticated)
const user = computed(() => authStore.user)
const currentRoute = computed(() => [route.path])

const handleSearch = (value) => {
  console.log('Header: search triggered', value) // 调试日志
  if (value) {
    router.push({ path: '/explore', query: { search: value } })
  }
}

const logout = async () => {
  console.log('Header: logout triggered') // 调试日志
  await authStore.logoutAction()
  router.push('/login')
}
</script>

<style scoped>
.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: linear-gradient(135deg, #ffffff 0%, #f5f7fa 100%);
  padding: 0 24px;
  height: 64px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1001;
}

.logo {
  font-size: 20px;
  font-weight: 700;
  white-space: nowrap;
}

.logo a {
  color: #1890ff;
  text-decoration: none;
  transition: color 0.2s;
}

.logo a:hover {
  color: #40a9ff;
}

.nav-menu {
  flex: 1;
  min-width: 300px;
  background: transparent;
  border-bottom: none;
  margin-right: 24px;
}

.nav-menu :deep(.ant-menu-item) {
  padding: 0 16px;
}

.nav-menu :deep(.ant-menu-item a) {
  color: #595959;
  font-weight: 500;
}

.nav-menu :deep(.ant-menu-item-selected a) {
  color: #1890ff;
}

.nav-menu :deep(.ant-menu-item:hover a) {
  color: #40a9ff;
}

.search-bar {
  display: flex;
  flex: 2;
  max-width: 400px;
  min-width: 200px;
  margin: 0 24px;
}

.search-bar :deep(.ant-input-search) {
  border-radius: 4px;
}

.user-section {
  min-width: 120px;
  display: flex;
  align-items: center;
  justify-content: flex-end;
}

.user-section .ant-dropdown-link {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #1890ff;
  text-decoration: none;
  padding: 8px 12px;
  border-radius: 4px;
  transition: background 0.2s;
}

.user-section .ant-dropdown-link:hover {
  background: rgba(24, 144, 255, 0.1);
}

.user-section .username {
  font-weight: 500;
}

.user-section .dropdown-icon {
  font-size: 12px;
}

.user-section .login-link {
  color: #1890ff;
  text-decoration: none;
  padding: 8px 12px;
  border-radius: 4px;
  transition: background 0.2s;
}

.user-section .login-link:hover {
  background: rgba(24, 144, 255, 0.1);
}

@media (max-width: 768px) {
  .header {
    padding: 0 16px;
    height: 56px;
  }

  .logo {
    font-size: 16px;
  }

  .nav-menu {
    min-width: 200px;
    margin-right: 16px;
  }

  .nav-menu :deep(.ant-menu-item) {
    padding: 0 8px;
  }

  .search-bar {
    max-width: 200px;
    margin: 0 16px;
  }

  .user-section {
    min-width: 80px;
  }

  .user-section .ant-dropdown-link,
  .user-section .login-link {
    padding: 6px 8px;
    font-size: 14px;
  }
}

@media (prefers-color-scheme: dark) {
  .header {
    background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
  }

  .logo a,
  .user-section .ant-dropdown-link,
  .user-section .login-link {
    color: #40a9ff;
  }

  .nav-menu :deep(.ant-menu-item a) {
    color: #d9d9d9;
  }

  .nav-menu :deep(.ant-menu-item-selected a) {
    color: #40a9ff;
  }
}
</style>