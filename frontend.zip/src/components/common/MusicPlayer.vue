<template>
  <div class="music-player" v-if="currentSong">
    <div class="song-info">
      <span>{{ currentSong.title }} - {{ currentSong.artist }}</span>
    </div>
    <div class="controls">
      <a-button @click="togglePlay">
        <template #icon>
          <play-circle-outlined v-if="!isPlaying" />
          <pause-circle-outlined v-else />
        </template>
      </a-button>
      <a-button @click="skipPrevious">
        <backward-outlined />
      </a-button>
      <a-button @click="skipNext">
        <forward-outlined />
      </a-button>
    </div>
    <div class="progress">
      <a-slider
          v-model:value="progress"
          :min="0"
          :max="currentSong.duration"
          @change="seek"
      />
      <span>{{ formatTime(progress) }} / {{ formatTime(currentSong.duration) }}</span>
    </div>
    <div class="volume">
      <a-slider
          v-model:value="volume"
          :min="0"
          :max="100"
          @change="setVolume"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useMusicStore } from '@/stores/modules/music'
import {
  PlayCircleOutlined,
  PauseCircleOutlined,
  BackwardOutlined,
  ForwardOutlined,
} from '@ant-design/icons-vue'
import { format } from '@/utils/format'

const musicStore = useMusicStore()
const currentSong = computed(() => musicStore.currentSong)
const isPlaying = computed(() => musicStore.isPlaying)
const progress = ref(0)
const volume = ref(50)

const togglePlay = () => {
  if (isPlaying.value) {
    musicStore.pause()
  } else {
    musicStore.play()
  }
}

const skipPrevious = () => {
  musicStore.skipPrevious()
}

const skipNext = () => {
  musicStore.skipNext()
}

const seek = (value) => {
  musicStore.seek(value)
  progress.value = value
}

const setVolume = (value) => {
  musicStore.setVolume(value / 100)
}

const formatTime = (seconds) => {
  return format.formatTime(seconds)
}
</script>

<style scoped>
.music-player {
  position: fixed;
  bottom: 0;
  width: 100%;
  background: #fff;
  padding: 10px 20px;
  box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.1);
  display: flex;
  align-items: center;
}
.song-info {
  flex: 1;
  font-size: 14px;
}
.controls {
  margin: 0 20px;
}
.progress {
  flex: 2;
  display: flex;
  align-items: center;
}
.progress .ant-slider {
  flex: 1;
  margin-right: 10px;
}
.volume {
  width: 100px;
}
</style>