<template>
  <div class="clock-widget">
    <div class="clock-date">
      <span>{{ day }}</span>
      <span>{{ date }}</span>
    </div>
    <div class="clock-time">{{ time }}</div>
  </div>
</template>

<script>
export default {
  name: 'ClockWidget',
  data() {
    return {
      time: '',
      date: '',
      day: ''
    }
  },
  created() {
    this.updateTime()
    setInterval(this.updateTime, 1000)
  },
  methods: {
    updateTime() {
      const now = new Date()
      this.time = now.toLocaleTimeString('en-GB', { hour12: false })
      this.date = new Intl.DateTimeFormat('en-GB', { month: '2-digit', day: '2-digit' }).format(now)
      this.day = new Intl.DateTimeFormat('en-GB', { weekday: 'short' }).format(now).toUpperCase()
      this.day = now.toLocaleDateString('en-GB', { weekday: 'short' }).toUpperCase()
    }
  }
}
</script>

<style scoped>
.clock-widget {
  width: 250px;
  background-color: #1a1a1a;
  color: #ccc;
  border-radius: 10px;
  margin: 0 auto;
  padding: 20px;
  text-align: center;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  font-family: 'Courier New', Courier, monospace;
}

.clock-date {
  display: flex;
  justify-content: space-between;
  font-size: 18px;
  margin-bottom: 10px;
}

.clock-time {
  font-size: 32px;
  font-weight: bold;
  background-color: #000;
  color: #ccc;
  padding: 10px;
  border-radius: 5px;
}

.clock-popup {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 250px;
  background-color: #1a1a1a;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  z-index: 1000;
}
</style>
