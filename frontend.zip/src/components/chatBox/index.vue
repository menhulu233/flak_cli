<script>
import CustomButton from '@/components/button/index.vue'
export default {
  name: 'ChatBox'
}
</script>

<template>
  <div class="chatBox">
    <!-- 顶部 -->
    <div class="top-container">
      <div class="content">
        <el-icon><ChatLineSquare /></el-icon>
        <i>{{ $t('chatBox.topContainer.content.title') }}</i>
      </div>
      <div class="btn">
        <CustomButton :label="$t('chatBox.topContainer.buttons.clearConversation')" ></CustomButton>
        <CustomButton :label="$t('chatBox.topContainer.buttons.exportConversation')"></CustomButton>
      </div>
    </div>
    <!-- 对话框 -->
    <div class="answer" ref="answerBox">
      <div v-for="(msg, index) in messages" :key="index" class="message" :class="msg.type">
        <div class="bubble">{{ msg.text }}</div>
      </div>
      <!-- 用于滚动到底部的占位元素 -->
      <div ref="endOfMessages"></div>
    </div>
    <!-- 提问 -->
    <div class="ask">
      <el-input
        v-model="question"
        :placeholder="$t('chatBox.ask.placeholder')"
        class="input"
      />
      <CustomButton :label="$t('chatBox.sendButton')" @click="sendMessage"></CustomButton>
    </div>
  </div>
</template>


<script setup>
import { ref, nextTick } from 'vue'

const question = ref('')
const messages = ref([])
const endOfMessages = ref(null)

const sendMessage = () => {
  if (question.value.trim()) {
    messages.value.push({ text: `Q: ${question.value}`, type: 'question' })
    // 模拟回答
    messages.value.push({ text: `A: 这是对问题 "${question.value}" 的回答`, type: 'answer' })
    question.value = ''
    scrollToBottom()
  }
}

const scrollToBottom = () => {
  nextTick(() => {
    endOfMessages.value.scrollIntoView({ behavior: 'smooth' })
  })
}
</script>

<style scoped>
@import "/src/css/base.css";
@import "./index.css"
</style>
