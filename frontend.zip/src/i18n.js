import { createI18n } from 'vue-i18n';
import zh from './locales/zh-cn.json';
import en from './locales/en-us.json';

const i18n = createI18n({
  legacy: false, // 确保 legacy 模式为 false
  locale:  'zh-cn',
  fallbackLocale: 'en-us',
  messages: {
    'zh-cn': zh,
    'en-us': en,
  },
});

export default i18n;
