<template>
  <a-layout class="login-page">
    <a-layout-content>
      <div class="login-container">
        <h1 class="login-title">音乐系统登录</h1>
        <LoginForm @submit="handleLogin" />
        <div class="extra-links">
          <router-link to="/register">没有账号？立即注册</router-link>
          <router-link to="/reset-password">忘记密码？</router-link>
        </div>
      </div>
    </a-layout-content>
  </a-layout>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/modules/auth'
import { message } from 'ant-design-vue'
import LoginForm from '@/components/auth/LoginForm.vue'

const router = useRouter()
const authStore = useAuthStore()

const handleLogin = async ({ username, password }) => {
  try {
    const result = await authStore.loginAction({ username, password })
    if (result.success) {
      message.success('登录成功')
      await router.push('/home')
    } else {
      message.error(result.error)
    }
  } catch (error) {
    message.error('登录失败，请稍后重试')
  }
}
</script>

<style scoped>
.login-page {
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
}

.login-container {
  width: 100%;
  max-width: 400px;
  padding: 20px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  text-align: center;
}

.login-title {
  font-size: 24px;
  margin-bottom: 20px;
  color: #262626;
}

.extra-links {
  margin-top: 16px;
  display: flex;
  justify-content: space-between;
}

.extra-links a {
  color: #1890ff;
  text-decoration: none;
  font-size: 14px;
}

.extra-links a:hover {
  text-decoration: underline;
}

@media (max-width: 768px) {
  .login-container {
    max-width: 90%;
    padding: 15px;
  }

  .login-title {
    font-size: 20px;
  }
}
</style>