<script>
import CustomButton from "@/components/button/index.vue";
import CustomTitle from "@/components/title/index.vue";
import { ref, watch } from 'vue';
import { marked } from 'marked';

export default {
  name: 'StudyPlan',
  components: {
    CustomButton,
    CustomTitle,
  },
  setup() {
    const durationOptions = ['1周', '2周', '3周', '4周'];
    const selectedDuration = ref('');
    const subject = ref(''); // 绑定学习科目
    const goal = ref(''); // 绑定学习目标
    const duration = ref(''); // 绑定计划时长

    // 默认 Markdown 模板
    const markdownTemplate = `# Vue.js 学习笔记

## 1. 概述
记录 Vue.js 的核心概念和学习过程中的重点内容。

## 2. 目标
- 掌握 Vue.js 基础语法
- 理解组件化开发
- 熟悉 Vuex 状态管理

## 3. 核心内容

### 3.1 Vue 实例
- **创建实例**：
  \`\`\`javascript
  const app = new Vue({
    el: '#app',
    data: {
      message: 'Hello Vue!'
    }
  });
  \`\`\`
`;

    const markdownInput = ref(markdownTemplate); // 绑定用户输入的 Markdown 内容
    const parsedMarkdown = ref(marked(markdownTemplate)); // 存储解析后的 HTML

    // 监听 markdownInput 的变化，实时解析 Markdown
    watch(markdownInput, (newValue) => {
      parsedMarkdown.value = marked(newValue);
    });

    const generatePlan = () => {
      // 生成规划的逻辑
      console.log('生成规划');
    };

    return {
      durationOptions,
      selectedDuration,
      subject,
      goal,
      duration,
      markdownInput,
      parsedMarkdown,
      generatePlan,
    };
  },
};
</script>

<template>
  <div class="study-plan">
    <div class="header">
      <CustomTitle :title="$t('study-plan.exportPlan')" icon="Edit"></CustomTitle>
      <CustomButton :label="$t('study-plan.exportPlan')"></CustomButton>
    </div>
    <div class="body">
      <div class="left">
        <form class="study-form">
          <div class="form-group">
            <label for="subject">{{ $t('study-plan.subjectPlaceholder') }}：</label>
            <input type="text" id="subject" v-model="subject" :placeholder="$t('study-plan.subjectPlaceholder')" />
          </div>
          <div class="form-group">
            <label for="goal">{{ $t('study-plan.goalPlaceholder') }}：</label>
            <textarea id="goal" v-model="goal" :placeholder="$t('study-plan.goalPlaceholder')"></textarea>
          </div>
          <div class="form-group">
            <label for="duration">{{ $t('study-plan.durationPlaceholder') }}：</label>
            <el-select id="duration" v-model="duration" :placeholder="$t('study-plan.durationPlaceholder')">
              <el-option
                v-for="option in durationOptions"
                :key="option" :value="option"
                :label="option"
                style="padding-left: 20px; font-size: 15px;"
              />
            </el-select>
          </div>
          <CustomButton :label="$t('study-plan.generatePlan')" @click="generatePlan" style="width: 150px;"></CustomButton>
        </form>
      </div>
      <div class="middle">
        <!-- Markdown 输入框 -->
        <el-input
          v-model="markdownInput"
          type="textarea"
          :rows="15"
          placeholder="在这里输入 Markdown 笔记..."
          class="markdown-input"
          spellcheck="false"
        />
      </div>
      <div class="right" >
        <!-- Markdown 预览 -->
        <div class="preview" v-html="parsedMarkdown" style="overflow: auto; height: 100%;"></div>
      </div>
    </div>
  </div>
</template>

<style scoped>
@import "/src/css/base.css";
@import "/src/css/study-plan/index.css";

</style>
