<script>
export default {
  name: 'HomeIndex',
}
</script>

<template>
  <div class="welcome-container">
  </div>
</template>

<style scoped>
@import '/src/css/home/index.css'
</style>
