<template>
  <a-layout class="reset-password-page">
    <a-layout-content>
      <div class="reset-password-container">
        <h1 class="reset-password-title">重置密码</h1>
        <ResetPasswordForm @submit="handleResetPassword" />
        <div class="extra-links">
          <router-link to="/login">返回登录</router-link>
          <router-link to="/register">没有账号？立即注册</router-link>
        </div>
      </div>
    </a-layout-content>
  </a-layout>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/modules/auth'
import { message } from 'ant-design-vue'
import ResetPasswordForm from '@/components/auth/ResetPassword.vue'

const router = useRouter()
const authStore = useAuthStore()

const handleResetPassword = async ({ username, email, newPassword }) => {
  console.log('ResetPassword.vue: handleResetPassword triggered', { username, email, newPassword })
  try {
    const result = await authStore.resetPasswordAction({ username, email, newPassword })
    console.log('ResetPassword.vue: reset result', result)
    if (result.success) {
      message.success(result.message)
      await router.push('/login')
    } else {
      message.error(result.error)
    }
  } catch (error) {
    console.error('ResetPassword.vue: error', error)
    message.error('密码重置失败，请稍后重试')
  }
}
</script>

<style scoped>
.reset-password-page {
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
}

.reset-password-container {
  width: 100%;
  max-width: 400px;
  padding: 20px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  text-align: center;
}

.reset-password-title {
  font-size: 24px;
  margin-bottom: 20px;
  color: #262626;
}

.extra-links {
  margin-top: 16px;
  display: flex;
  justify-content: space-between;
}

.extra-links a {
  color: #1890ff;
  text-decoration: none;
  font-size: 14px;
}

.extra-links a:hover {
  text-decoration: underline;
}

@media (max-width: 768px) {
  .reset-password-container {
    max-width: 90%;
    padding: 15px;
  }
  .reset-password-title {
    font-size: 20px;
  }
}
</style>