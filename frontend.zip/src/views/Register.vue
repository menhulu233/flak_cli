<template>
  <a-layout class="register-page">
    <a-layout-content>
      <div class="register-container">
        <h1 class="register-title">音乐系统注册</h1>
        <RegisterForm @submit="handleRegister" />
        <div class="extra-links">
          <router-link to="/login">已有账号？立即登录</router-link>
          <router-link to="/reset-password">忘记密码？</router-link>
        </div>
      </div>
    </a-layout-content>
  </a-layout>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/modules/auth'
import { message } from 'ant-design-vue'
import RegisterForm from '@/components/auth/RegisterForm.vue'

const router = useRouter()
const authStore = useAuthStore()

const handleRegister = async ({ username, email, password }) => {
  console.log('Register.vue: handleRegister triggered', { username, email, password })
  try {
    const result = await authStore.registerAction({ username, email, password })
    console.log('Register.vue: register result', result)
    if (result.success) {
      message.success(result.message)
      router.push('/login')
    } else {
      message.error(result.error)
    }
  } catch (error) {
    console.error('Register.vue: error', error)
    message.error('注册失败，请稍后重试')
  }
}
</script>

<style scoped>
.register-page {
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
}

.register-container {
  width: 100%;
  max-width: 400px;
  padding: 20px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  text-align: center;
}

.register-title {
  font-size: 24px;
  margin-bottom: 20px;
  color: #262626;
}

.extra-links {
  margin-top: 16px;
  display: flex;
  justify-content: space-between;
}

.extra-links a {
  color: #1890ff;
  text-decoration: none;
  font-size: 14px;
}

.extra-links a:hover {
  text-decoration: underline;
}

@media (max-width: 768px) {
  .register-container {
    max-width: 90%;
    padding: 15px;
  }
  .register-title {
    font-size: 20px;
  }
}
</style>