<script>
import { ref } from 'vue'
import ChatBox from "@/components/chatBox/index.vue"
export default {
    name: "QuestionAnswer",
    setup() {
      const chatHistory = ref([
      { id: 1, history: "历史记录", time: "12-31 10:20", isSelected: true },
      { id: 2, history: "你好", time: "12-31 10:16", isSelected: false },
      { id: 3, history: "新对话", time: "12-31 10:21", isSelected: false },
    ]);
    const selectItem = (item) => {
      chatHistory.value.forEach(chatItem => {
        chatItem.isSelected = false;
      });
      item.isSelected = true;
    };
    return {
      chatHistory,
      selectItem,
    }
  },
    components: {
        ChatBox
    },
}

</script>

<template>
  <main class="question-answer">
    <div class="left">
        <div class="header">
          <div class="content">
            <el-icon><DocumentCopy /></el-icon>
            <i>{{ $t('qa.chatHistory') }}</i>
          </div>
          <input type="text" :placeholder="$t('qa.searchPlaceholder')" class="search-input">
          <button class="new-chat">{{ $t('qa.newChat') }}</button>
        </div>
        <ul class="chat-list">
            <li class="chat-item"
            v-for="chat in chatHistory"
            :key="chat.id"
            :class="{ selected: chat.isSelected }"
            @click="selectItem(chat)">
                <span>{{ chat.history }}</span>
                <span class="timestamp">{{ chat.time }}</span>
            </li>
        </ul>
    </div>

    <div class="right">
      <ChatBox></ChatBox>
    </div>
  </main>
</template>

<style scoped>
@import "/src/css/base.css";
@import "/src/css/question-answer/index.css";
</style>
