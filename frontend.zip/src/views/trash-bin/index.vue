<script>
// import TodoList from "@/components/todoList/index.vue"
import TimeTable from "@/components/timeTable/index.vue"
export default {
  name: 'TrashBinPage',
  components: {
    // TodoList
    TimeTable
  }
}
</script>

<template>
  <div>
    <!-- <TodoList></TodoList> -->
    <TimeTable></TimeTable>
  </div>
</template>

<style scoped>
div {
  height: 100%;
}
</style>
