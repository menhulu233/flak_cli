<script setup lang="ts">

</script>

<template>
<div>关于</div>
</template>

<style scoped>

</style>