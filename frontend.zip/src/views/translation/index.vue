<script>
import CustomTitle from "@/components/title/index.vue";
export default {
  name: 'TranslationPage',
  components: {
    CustomTitle
  }
}
</script>

<template>
  <div class="translation-container">
    <CustomTitle :title="$t('Translation.title')" icon="Connection" style="margin-bottom: 20px;"></CustomTitle>
    <div class="select">
      <ul>
        <li>
          <router-link to="/translation/content-translation" class="icon-text-block">
            <i>{{ $t('Translation.contentTranslation') }}</i>
          </router-link>
        </li>
        <li>
          <router-link to="/translation/file-translation" class="icon-text-block">
            <i>{{ $t('Translation.fileTranslation') }}</i>
          </router-link>
        </li>
      </ul>
    </div>
    <div class="body">
      <router-view></router-view>
    </div>

  </div>
</template>

<style scoped>
@import "/src/css/base.css";
@import "/src/css/translation/index.css"
</style>
