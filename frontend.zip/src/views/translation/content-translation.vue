<script>
import { reactive } from 'vue';

export default {
  name: 'ContentTranslationPage',
  setup() {
    const form = reactive({
      sourceText: '',
      sourceLanguage: '',
      targetLanguage: '',
      translatedText: ''
    });

    const languages = [
      { label: '中文', value: 'zh' },
      { label: '英文', value: 'en' },
      { label: '西班牙文', value: 'es' },
      { label: '法文', value: 'fr' },
      { label: '德文', value: 'de' }
      // 可以添加更多语言选项
    ];

    const translateText = () => {
      // 这里可以添加实际的翻译逻辑或者调用翻译API
      // 示例：假设我们有一个翻译函数translate
      form.translatedText = translate(form.sourceText, form.sourceLanguage, form.targetLanguage);
    };

    const translate = (text, sourceLang, targetLang) => {
      // 这是一个模拟的翻译函数
      // 实际开发中，你需要根据你的翻译服务提供商的API来实现
      return `这是 ${targetLang} 语言的翻译结果：${text}`;
    };

    return {
      form,
      languages,
      translateText
    };
  }
};
</script>

<template>
  <div class="content-translation-container">
    <el-form :model="form" label-width="100px" style="display: flex; width: 100%;">
      <div class="form-column left">
        <el-form-item :label="$t('Translation.content.labels.inputText')">
          <el-input
            v-model="form.sourceText"
            type="textarea"
            :rows="10"
            :placeholder="$t('Translation.content.placeholders.inputText')"
            class="textarea-input"
          />
        </el-form-item>
        <el-form-item :label="$t('Translation.content.labels.sourceLanguage')">
          <el-select v-model="form.sourceLanguage" :placeholder="$t('Translation.content.placeholders.selectSourceLanguage')" class="select-input" style="width: 50%;">
            <el-option
              v-for="language in languages"
              :key="language.value"
              :label="language.label"
              :value="language.value"
              style="padding-left: 20px; font-size: 15px;"
            />
          </el-select>
        </el-form-item>
      </div>
      <div class="form-column right">
        <el-form-item :label="$t('Translation.content.labels.translatedText')">
          <el-input
            v-model="form.translatedText"
            type="textarea"
            :rows="10"
            :placeholder="$t('Translation.content.placeholders.translatedText')"
            readonly
            class="textarea-input"
            style="width: 300px;"
          />
        </el-form-item>
        <el-form-item :label="$t('Translation.content.labels.targetLanguage')">
          <el-select v-model="form.targetLanguage" :placeholder="$t('Translation.content.placeholders.selectTargetLanguage')" class="select-input" style="width: 50%;">
            <el-option
              v-for="language in languages"
              :key="language.value"
              :label="language.label"
              :value="language.value"
              style="padding-left: 20px; font-size: 15px;"
            />
          </el-select>
        </el-form-item>
      </div>
    </el-form>
    <div class="button-container">
      <el-button type="primary" @click="translateText">{{ $t('Translation.content.buttons.translate') }}</el-button>
    </div>
  </div>
</template>

<style scoped>
@import "/src/css/base.css";
@import "/src/css/translation/content-translation.css"
</style>
