<script>
import CustomButton from "@/components/button/index.vue";
import CustomTitle from "@/components/title/index.vue";
import SearchBox from "@/components/searchBox/index.vue"
export default {
  name: 'NoteManagement',
  components: {
    CustomButton,
    CustomTitle,
  },
}
</script>

<template>
  <div class="note-management">
    <div class="header">
      <CustomTitle :title="$t('note-summary.header.title')" icon="Notebook"></CustomTitle>
      <CustomButton :label="$t('note-summary.header.newNote')"></CustomButton>
    </div>
    <div class="content">
      <div class="left">
        <SearchBox :content="$t('note-summary.left.searchNotes')" :label="$t('note-summary.left.search')"></SearchBox>
        <ul>
          <li v-for="item in noteList" :key="item.id" class="note">
            <div class="together">
              <div class="title">{{ item.title }}</div>
              <div class="date">{{ item.date }}</div>
            </div>
            <div class="body">{{ item.content }}</div>
          </li>
        </ul>
      </div>

      <div class="right">
        <div class="functionButtons">
          <CustomButton :label="$t('note-summary.right.uploadFile')" style="width: 140px;"></CustomButton>
          <CustomButton :label="$t('note-summary.right.generateSummary')" style="width: 140px;"></CustomButton>
          <CustomButton :label="$t('note-summary.right.saveNote')" style="width: 140px;"></CustomButton>
          <CustomButton :label="$t('note-summary.right.deleteNote')" style="width: 140px;"></CustomButton>
        </div>
        <div class="title">
          <el-input v-model="input" :placeholder="$t('note-summary.right.noteTitle')"></el-input>
        </div>
        <div class="label">
          <SearchBox :content="$t('note-summary.right.addTitle')" :label="$t('note-summary.right.add')"></SearchBox>
          <el-tag
            v-for="tag in tags"
            :key="tag.name"
            closable
            :type="tag.type">
            {{tag.name}}
          </el-tag>
        </div>
        <div class="body">
           <el-input
            v-model="noteContent"
            type="textarea"
            :rows="15"
            :placeholder="$t('note-summary.right.startWriting')"
            class="note-input"
           />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";

const noteList = ref([
  {
    id: 1,
    title: "Vue3 学习笔记",
    content: "Vue3 学习笔记...",
    date: "2022-01-01",
  },
  {
    id: 2,
    title: "Django 学习笔记",
    content: "Django 学习笔记...",
    date: "2022-01-01",
  },
  {
    id: 2,
    title: "Django 学习笔记",
    content: "Django 学习笔记...",
    date: "2022-01-01",
  },
  {
    id: 2,
    title: "Django 学习笔记",
    content: "Django 学习笔记...",
    date: "2022-01-01",
  },
  {
    id: 2,
    title: "Django 学习笔记",
    content: "Django 学习笔记...",
    date: "2022-01-01",
  },
  {
    id: 2,
    title: "Django 学习笔记",
    content: "Django 学习笔记...",
    date: "2022-01-01",
  },
  {
    id: 2,
    title: "Django 学习笔记",
    content: "Django 学习笔记...",
    date: "2022-01-01",
  },
  {
    id: 2,
    title: "Django 学习笔记",
    content: "Django 学习笔记...",
    date: "2022-01-01",
  },
  {
    id: 2,
    title: "Django 学习笔记",
    content: "Django 学习笔记...",
    date: "2022-01-01",
  },
  {
    id: 2,
    title: "Django 学习笔记",
    content: "Django 学习笔记...",
    date: "2022-01-01",
  },
  {
    id: 2,
    title: "Django 学习笔记",
    content: "Django 学习笔记...",
    date: "2022-01-01",
  },
  {
    id: 2,
    title: "Django 学习笔记",
    content: "Django 学习笔记...",
    date: "2022-01-01",
  },
  {
    id: 2,
    title: "Django 学习笔记",
    content: "Django 学习笔记...",
    date: "2022-01-01",
  },
]);

const input = ref("");

const noteContent = ref("");

const tags = ref([
    { name: '标签一', type: '' },
    { name: '标签二', type: '' },
    { name: '标签三', type: '' },
    { name: '标签四', type: '' },
    { name: '标签五', type: '' }
]);
</script>

<style scoped>
@import "/src/css/base.css";
@import "/src/css/note-management/index.css";

</style>
