<script>
import { ref } from 'vue';
import { useRouter } from 'vue-router';

export default {
  name: 'LoginIndex',
  setup() {
    const router = useRouter();
    const isRightPanelActive = ref(false);
    const verificationCode = ref('');
    const signUpPhoneNumber = ref('');
    const signUpPassword = ref('');
    const signInPhoneNumber = ref('');
    const signInPassword = ref('');

    // 从 localStorage 中读取用户数据
    const users = ref(JSON.parse(localStorage.getItem('users')) || []);

    const toggleToSignIn = () => {
      isRightPanelActive.value = false;
    };

    const toggleToSignUp = () => {
      isRightPanelActive.value = true;
    };

    const forgotPassword = () => {
      alert('Forgot Password');
    };

    const sendVerificationCode = () => {
      if (!signUpPhoneNumber.value) {
        alert('请输入手机号');
        return;
      }
      console.log('发送验证码到:', signUpPhoneNumber.value);
      alert('验证码已发送到您的手机号');
    };

    const handleSignUp = () => {
      if (!signUpPhoneNumber.value || !signUpPassword.value || !verificationCode.value) {
        alert('请填写完整信息');
        return;
      }

      // 模拟验证码验证
      if (verificationCode.value !== '123456') {
        alert('验证码错误');
        return;
      }

      // 检查是否已注册
      const isUserExist = users.value.some(user => user.phoneNumber === signUpPhoneNumber.value);
      if (isUserExist) {
        alert('该手机号已注册');
        return;
      }

      // 注册用户
      const newUser = {
        id: Date.now(), // 使用时间戳作为唯一 ID
        name: '新用户', // 默认名称
        phone: signUpPhoneNumber.value,
        avatar: '/src/assets/avatar.jpg', // 默认头像
        selected: false,
      };

      users.value.push(newUser);
      localStorage.setItem('users', JSON.stringify(users.value)); // 保存到 localStorage

      alert('注册成功');
      router.push('/home'); // 跳转到 /home 页面
    };

    const handleSignIn = () => {
      if (!signInPhoneNumber.value || !signInPassword.value) {
        alert('请填写手机号和密码');
        return;
      }

      // 查找用户
      const user = users.value.find(user => user.phone === signInPhoneNumber.value);

      if (!user) {
        alert('用户未注册');
        return;
      }

      if (user.password !== signInPassword.value) {
        alert('密码错误');
        return;
      }

      alert('登录成功');
      router.push('/home'); // 跳转到 /home 页面
    };

    return {
      isRightPanelActive,
      verificationCode,
      signUpPhoneNumber,
      signUpPassword,
      signInPhoneNumber,
      signInPassword,
      toggleToSignIn,
      toggleToSignUp,
      forgotPassword,
      sendVerificationCode,
      handleSignUp,
      handleSignIn,
    };
  },
};
</script>

<template>
  <div class="login-container">
    <div class="container" :class="{ 'right-panel-active': isRightPanelActive }">
      <!-- Sign Up -->
      <div class="container__form container--signup">
        <form action="#" class="form" id="form1" @submit.prevent="handleSignUp">
          <h2 class="form__title">{{ $t('login.signUp') }}</h2>
          <input type="text" v-model="signUpPhoneNumber" :placeholder="$t('login.phoneNumber')" class="input" />
          <input type="password" v-model="signUpPassword" :placeholder="$t('login.password')" class="input" />
          <div class="verification-row">
            <input type="text" v-model="verificationCode" :placeholder="$t('login.verificationCode')" class="input" />
            <button type="button" class="btn send-btn" @click="sendVerificationCode">{{ $t('login.sendVerificationCode') }}</button>
          </div>
          <button type="submit" class="btn">{{ $t('login.signUp') }}</button>
        </form>
      </div>

      <!-- Sign In -->
      <div class="container__form container--signin">
        <form action="#" class="form" id="form2" @submit.prevent="handleSignIn">
          <h2 class="form__title">{{ $t('login.signIn') }}</h2>
          <input type="text" v-model="signInPhoneNumber" :placeholder="$t('login.phoneNumber')" class="input" />
          <input type="password" v-model="signInPassword" :placeholder="$t('login.password')" class="input" />
          <a href="#" class="link" @click.prevent="forgotPassword">{{ $t('login.forgotPassword') }}</a>
          <button type="submit" class="btn">{{ $t('login.signIn') }}</button>
        </form>
      </div>

      <!-- Overlay -->
      <div class="container__overlay">
        <div class="overlay">
          <div class="overlay__panel overlay--left">
            <button class="btn" @click="toggleToSignIn">{{ $t('login.signIn') }}</button>
          </div>
          <div class="overlay__panel overlay--right">
            <button class="btn" @click="toggleToSignUp">{{ $t('login.signUp') }}</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<style scoped>
@import "/src/css/base.css";
@import "/src/css/login/index.css";
</style>
