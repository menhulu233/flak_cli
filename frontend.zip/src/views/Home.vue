<template>
  <div class="home-page">
    <!-- 轮播 -->
    <section class="banner-section">
      <a-carousel autoplay :autoplay-speed="3000" arrows dots-class="slick-dots">
        <div v-for="banner in banners" :key="banner.id" class="banner-item">
          <img :src="banner.image" :alt="banner.title" class="banner-image" />
          <div class="banner-overlay">
            <h2>{{ banner.title }}</h2>
            <a-button type="primary" size="large" @click="goToBanner(banner)">
              立即播放
            </a-button>
          </div>
        </div>
      </a-carousel>
    </section>

    <!-- 推荐歌手 -->
    <section class="section">
      <div class="section-inner">
        <h2 class="section-title">推荐歌手</h2>
        <div class="card-grid">
          <div v-for="artist in artists" :key="artist.id" class="card artist-card">
            <img :src="artist.image" :alt="artist.name" class="card-image" />
            <h3 class="card-title">{{ artist.name }}</h3>
            <p class="card-desc">{{ artist.description }}</p>
            <router-link :to="`/artist/${artist.id}`" class="card-link">查看详情</router-link>
          </div>
        </div>
      </div>
    </section>

    <!-- 推荐专辑 -->
    <section class="section">
      <div class="section-inner">
        <h2 class="section-title">推荐专辑</h2>
        <div class="card-grid">
          <div v-for="album in albums" :key="album.id" class="card album-card">
            <img :src="album.image" :alt="album.title" class="card-image" />
            <h3 class="card-title">{{ album.title }}</h3>
            <p class="card-desc">{{ album.artist }}</p>
            <router-link :to="`/album/${album.id}`" class="card-link">查看详情</router-link>
          </div>
        </div>
      </div>
    </section>

    <!-- 推荐流派 -->
    <section class="section">
      <div class="section-inner">
        <h2 class="section-title">推荐流派</h2>
        <div class="card-grid">
          <div v-for="genre in genres" :key="genre.id" class="card genre-card">
            <h3 class="card-title">{{ genre.name }}</h3>
            <p class="card-desc">{{ genre.description }}</p>
            <router-link :to="`/genre/${genre.id}`" class="card-link">探索流派</router-link>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/modules/auth'
import { message } from 'ant-design-vue'
import {getRecommendations} from "@/api/home.js";

const router = useRouter()
const authStore = useAuthStore()

const banners = ref([])
const artists = ref([])
const albums = ref([])
const genres = ref([])

const fetchRecommendations = async () => {
  console.log('Home.vue: fetchRecommendations called')
  try {
    const data = await getRecommendations()
    console.log('Home.vue: fetchRecommendations response', data)
      banners.value = data.banners
      artists.value = data.artists
      albums.value = data.albums
      genres.value = data.genres
      message.error('获取推荐数据失败')
  } catch (error) {
    console.error('Home.vue: fetch error', error)
    message.error('获取推荐数据失败，请稍后重试')
  }
}

const goToBanner = (banner) => {
  console.log('Home.vue: goToBanner', banner)
  if (banner.type === 'album') {
    router.push(`/album/${banner.id}`)
  } else if (banner.type === 'song') {
    router.push(`/song/${banner.id}`)
  }
}

onMounted(async () => {
  await authStore.initializeAuth()
  await fetchRecommendations()
})
</script>

<style scoped>
/* ---------- 基础 ---------- */
.home-page {
  width: 100%;
  background: #f5f7fa;
}

/* 轮播占满 */
.banner-section {
  width: 100%;
}
.banner-item {
  position: relative;
  width: 100%;
  aspect-ratio: 16 / 6;          /* 根据图片比例自行调整 */
}
.banner-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
.banner-overlay {
  position: absolute;
  inset: auto auto 24px 32px;
  color: #fff;
  text-shadow: 0 2px 8px rgba(0,0,0,.6);
}

/* 内容区：想要纯满屏就把 .section-inner 删掉即可 */
.section-inner {
  max-width: 1400px;              /* 阅读宽度，可自行调整或去掉 */
  margin: 0 auto;
  padding: 32px 16px;
}
.section-title {
  font-size: 24px;
  font-weight: 600;
  margin-bottom: 20px;
}

/* 卡片网格 */
.card-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;                      /* 卡片间距 */
}
.card {
  flex: 1 1 calc(20% - 16px);     /* 5 列，gap 16px */
  background: #fff;
  border-radius: 8px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  box-shadow: 0 2px 6px rgba(0,0,0,.06);
  transition: transform .2s;
}
.card:hover {
  transform: translateY(-2px);
}

.card-image {
  width: 100%;
  aspect-ratio: 1 / 1;            /* 正方形封面 */
  object-fit: cover;
}
.card-title {
  font-size: 16px;
  margin: 12px 12px 4px;
}
.card-desc {
  font-size: 14px;
  color: #666;
  margin: 0 12px 12px;
  flex: 1 1 auto;
}
.card-link {
  display: block;
  text-align: center;
  padding: 8px 0;
  color: #1890ff;
  text-decoration: none;
  border-top: 1px solid #f0f0f0;
}
.card-link:hover {
  background: #e6f7ff;
}

/* ---------- 响应式 ---------- */
@media (max-width: 1200px) {
  .card { flex: 1 1 calc(25% - 16px); }   /* 4 列 */
}
@media (max-width: 900px) {
  .card { flex: 1 1 calc(33.333% - 16px); } /* 3 列 */
}
@media (max-width: 600px) {
  .card { flex: 1 1 calc(50% - 16px); }   /* 2 列 */
  .banner-item { aspect-ratio: 16 / 9; }
  .section-inner { padding: 24px 12px; }
}
@media (max-width: 400px) {
  .card { flex: 1 1 100%; }               /* 1 列 */
}

/* ---------- 深色模式 ---------- */
@media (prefers-color-scheme: dark) {
  .home-page { background: #121212; }
  .card { background: #1e1e1e; color: #e5e5e5; }
  .card-desc { color: #aaa; }
  .card-link { border-color: #333; color: #69b1ff; }
  .card-link:hover { background: #003a8c; }
}
</style>