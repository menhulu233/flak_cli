<script>
export default {
  name: 'SettingPage'
}
</script>

<script setup>
</script>

<template>
  <div class="main">
    <div class="header">
      <el-icon><Setting /></el-icon>
      <h2>{{ $t('Setting.header.settings') }}</h2>
    </div>
    <div class="body">
      <div class="left">
        <ul>
          <li>
            <router-link to="/setting/user-setting" class="icon-text-block">
              <i>{{ $t('Setting.left-menu.userSetting') }}</i>
            </router-link>
          </li>
          <li>
            <router-link to="/setting/system-setting" class="icon-text-block">
              <i>{{ $t('Setting.left-menu.systemSetting') }}</i>
            </router-link>
          </li>
          <li>
            <router-link to="/setting/hobby-setting" class="icon-text-block">
              <i>{{ $t('Setting.left-menu.preferenceSetting') }}</i>
            </router-link>
          </li>
          <li>
            <router-link to="/setting/security-setting" class="icon-text-block">
              <i>{{ $t('Setting.left-menu.securitySetting') }}</i>
            </router-link>
          </li>
          <li>
            <router-link to="/setting/about-setting" class="icon-text-block">
              <i>{{ $t('Setting.left-menu.about') }}</i>
            </router-link>
          </li>
        </ul>
      </div>
      <div class="right">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<style scoped>
@import '/src/css/base.css';
@import '/src/css/setting/index.css';
</style>
