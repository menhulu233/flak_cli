<script>
import { ref } from 'vue';

export default {
  name: 'user-setting',
};
</script>

<template>
  <div class="settings-container">
    <h2>{{ $t('Setting.user.basicInfo') }}</h2>

    <el-upload
      class="avatar-uploader"
      action="https://jsonplaceholder.typicode.com/posts/"
      :show-file-list="true"
      :on-success="handleAvatarSuccess"
      :before-upload="beforeAvatarUpload"
    >
      <img v-if="imageUrl" :src="imageUrl" class="avatar" />
      <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
    </el-upload>

    <div class="info-row">
      <span>{{ $t('Setting.user.username') }}：</span>
      <span>{{ username }}</span>
      <el-input v-model="username" style="width: 240px" :placeholder="$t('Setting.user.usernamePlaceholder')" />
      <el-button type="primary" plain @click="updateUsername">{{ $t('Setting.user.change') }}</el-button>
    </div>

    <div class="info-row">
      <span>{{ $t('Setting.user.userId') }}：</span>
      <span>{{ userId }}</span>
    </div>

    <div class="info-row">
      <span>{{ $t('Setting.user.gender') }}：</span>
      <span>{{ gender }}</span>
      <el-radio-group v-model="gender" style="margin-right: 20px">
        <el-radio label="男">{{ $t('Setting.user.male') }}</el-radio>
        <el-radio label="女">{{ $t('Setting.user.female') }}</el-radio>
      </el-radio-group>
    </div>

    <div class="info-row">
      <span>{{ $t('Setting.user.introduction') }}：</span>
      <span>{{ introduction }}</span>
      <el-input v-model="introduction" style="width: 240px" :placeholder="$t('Setting.user.introductionPlaceholder')" />
      <el-button type="primary" plain @click="updateIntroduction">{{ $t('Setting.user.change') }}</el-button>
    </div>

    <div class="info-row">
      <span>{{ $t('Setting.user.location') }}：</span>
      <span>{{ location }}</span>
      <el-input v-model="location" style="width: 240px" :placeholder="$t('Setting.user.locationPlaceholder')" />
      <el-button type="primary" plain @click="updateLocation">{{ $t('Setting.user.change') }}</el-button>
    </div>

    <div class="info-row">
      <span>{{ $t('Setting.user.birthdate') }}：</span>
      <span>{{ birthdate }}</span>
      <div class="demo-date-picker">
        <div class="block">
          <el-date-picker
            v-model="birthdate"
            type="date"
            :placeholder="$t('Setting.user.birthdatePlaceholder')"
            style="width: 240px;"
          />
        </div>
      </div>
      <el-button type="primary" plain @click="updateBirthdate">{{ $t('Setting.user.change') }}</el-button>
    </div>
    <el-button type="primary" plain @click="updateBirthdate" class="save-btn">{{ $t('Setting.user.save') }}</el-button>
  </div>
</template>

<script setup>
import { ElMessage } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'


const username = ref('风雷雷LLL');
const userId = ref('2301_79883587');
const gender = ref('男');
const introduction = ref('大学小白');
const location = ref('哈尔滨市');
const birthdate = ref('1999-09-09');

//input框里输入的内容
// 这些不需要定义，因为每个字段都有自己的输入框

//日期选择器
// birthdate 已经在第一个script中返回，不需要重复定义

// 图片上传不需要在这里定义，已经在第一个script中
// 定义更新方法
const updateUsername = () => {
  console.log('更新用户昵称：', username.value);
};


const updateIntroduction = () => {
  console.log('更新个人介绍：', introduction.value);
};

const updateLocation = () => {
  console.log('更新所在地区：', location.value);
};

const updateBirthdate = () => {
  console.log('更新出生日期：', birthdate.value);
};



const imageUrl = ref('')

const handleAvatarSuccess = (
  response,
  uploadFile
) => {
  imageUrl.value = URL.createObjectURL(uploadFile.raw);
  console.log(imageUrl.value);
}


const beforeAvatarUpload = (rawFile) => {
  if (rawFile.type !== 'image/jpeg') {
    ElMessage.error('Avatar picture must be JPG format!')
    return false
  } else if (rawFile.size / 1024 / 1024 > 2) {
    ElMessage.error('Avatar picture size can not exceed 2MB!')
    return false
  }
  return true
}

</script>

<style scoped>
@import '/src/css/base.css';
@import "/src/css/setting/user-setting.css";
</style>
