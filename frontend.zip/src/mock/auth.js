import Mock from 'mockjs'

const users = [
    { username: 'admin', email: 'admin@example.com', password: 'admin123', role: 'admin' },
    { username: 'user', email: 'user@example.com', password: 'user123', role: 'user' },
    { username: 'root', email: 'root@example.com', password: '123456', role: 'admin' } // 添加 root 用户
]

export default [
    {
        url: '/api/auth/login',
        method: 'post',
        response: ({ body }) => {
            const data = typeof body === 'string' ? JSON.parse(body) : body // 解析 JSON 字符串
            const { username, password } = data
            console.log('Mock: /api/auth/login called', { username, password })
            const user = users.filter(u => u.username === username && u.password === password)
            console.log('Mock: /api/auth/login response', { user })
            if (user) {
                return {
                    code: 200,
                    message: '登录成功',
                    data: {
                        token: Mock.Random.guid(),
                        user: { username: user[0].username, email: user[0].email, role: user[0].role }
                    }
                }
            }
            return { code: 401, message: '用户名或密码错误' }
        }
    },
    {
        url: '/api/auth/register',
        method: 'post',
        response: ({ body }) => {
            const data = typeof body === 'string' ? JSON.parse(body) : body
            const { username, email, password } = data
            console.log('Mock: /api/auth/register called', { username, email })
            if (users.some(u => u.username === username || u.email === email)) {
                return { code: 400, message: '用户名或邮箱已存在' }
            }
            users.push({ username, email, password, role: 'user' })
            return { code: 200, message: '注册成功' }
        }
    },
    {
        url: '/api/auth/reset-password',
        method: 'post',
        response: ({ body }) => {
            const data = typeof body === 'string' ? JSON.parse(body) : body
            const { username, email, newPassword } = data
            console.log('Mock: /api/auth/forgot-password called', { username, email })
            const user = users.find(u => u.username === username && u.email === email)
            if (user) {
                user.password = newPassword
                return { code: 200, message: '密码重置成功' }
            }
            return { code: 400, message: '用户名与邮箱不匹配' }
        }
    },
    {
        url: '/api/auth/logout',
        method: 'post',
        response: () => {
            console.log('Mock: /api/auth/logout called')
            return {
                code: 200,
                message: '登出成功',
                data: null
            }
        }
    },
    {
        url: '/api/auth/user',
        method: 'get',
        response: () => {
            console.log('Mock: /api/auth/user called')
            const user = users.find(u => u.username === 'admin') // 模拟当前用户
            if (user) {
                return {
                    code: 200,
                    data: {
                        username: user.username,
                        email: user.email,
                        role: user.role
                    }
                }
            }
            return { code: 401, message: '未登录' }
        }
    }
]