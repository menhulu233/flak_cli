import Mock from 'mockjs'

export default [
    {
        url: '/api/home/recommend',
        method: 'get',
        response: () => {
            console.log('Mock: /api/home/recommend called')
            return {
                code: 200,
                message: '获取推荐数据成功',
                data: {
                    banners: [
                        {
                            id: 1,
                            title: '热门单曲：夜曲',
                            image: 'https://via.placeholder.com/1200x300?text=Banner1',
                            type: 'song'
                        },
                        {
                            id: 2,
                            title: '新专辑：未来世界',
                            image: 'https://via.placeholder.com/1200x300?text=Banner2',
                            type: 'album'
                        }
                    ],
                    artists: [
                        {
                            id: 1,
                            name: '周杰伦',
                            image: 'https://via.placeholder.com/200x120?text=JayChou',
                            description: '华语流行天王'
                        },
                        {
                            id: 2,
                            name: '林俊杰',
                            image: 'https://via.placeholder.com/200x120?text=JJLin',
                            description: '创作才子'
                        },
                        {
                            id: 3,
                            name: '王菲',
                            image: 'https://via.placeholder.com/200x120?text=FayeWong',
                            description: '天后级歌手'
                        }
                    ],
                    albums: [
                        {
                            id: 1,
                            title: '叶惠美',
                            image: 'https://via.placeholder.com/200x120?text=Album1',
                            artist: '周杰伦'
                        },
                        {
                            id: 2,
                            title: '江南',
                            image: 'https://via.placeholder.com/200x120?text=Album2',
                            artist: '林俊杰'
                        },
                        {
                            id: 3,
                            title: '天空',
                            image: 'https://via.placeholder.com/200x120?text=Album3',
                            artist: '王菲'
                        }
                    ],
                    genres: [
                        { id: 1, name: '流行', description: '热门流行音乐' },
                        { id: 2, name: '摇滚', description: '热血摇滚乐' },
                        { id: 3, name: '电子', description: '潮流电子音乐' }
                    ]
                }
            }
        }
    }
]