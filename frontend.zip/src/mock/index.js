import Mock from 'mockjs'
import authMocks from './auth' // 使用相对路径，避免 @/mock
import homeMocks from './home.js'
console.log('Mock initialized:', Mock) // 调试：确认 Mock.js 加载
const mocks = [...authMocks,...homeMocks]
mocks.forEach(({ url, method, response }) => {
    console.log('Registering mock:', { url, method }) // 调试：确认注册
    Mock.mock(url, method.toLowerCase(), response)
})
export default Mock