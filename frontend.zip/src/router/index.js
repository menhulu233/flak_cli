import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/home/index.vue'
import QuestionAnswer from '../views/question-answer/index.vue'
import User from '../views/user/index.vue'
import Setting from '../views/setting/index.vue'
import LoginIndex from '../views/login/index.vue'
import StudyPlan from '../views/study-plan/index.vue'
import NoteManagement from '../views/note-management/index.vue'
import History from '../views/history/index.vue'
import TrashBin from '../views/trash-bin/index.vue'
import Translation from '../views/translation/index.vue'
import StudyDesktop from '../views/studyDesktop/index.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'homePage',
      component: Home,
      redirect: '/login',
    },
    {
      path: '/home',
      name: 'home',
      component: Home,
    },
    {
      path: '/question-answer',
      name: 'question-answer',
      component: QuestionAnswer,
    },
    {
      path: '/user',
      name: 'user',
      component: User,
    },
    {
      path: '/setting',
      name: 'setting',
      component: Setting,
      redirect: '/setting/user-setting',
      children: [
        {
          path: 'user-setting' ,
          name: 'user-setting',
          component: () => import('../views/setting/user-setting.vue')
        },
        {
          path: 'system-setting' ,
          name: 'system-setting',
          component: () => import('../views/setting/system-setting.vue')
        },
        {
          path: 'hobby-setting' ,
          name: 'hobby-setting',
          component: () => import('../views/setting/hobby-setting.vue')
        },
        {
          path: 'about-setting' ,
          name: 'about-setting',
          component: () => import('../views/setting/about-setting.vue')
        },
        {
          path: 'security-setting' ,
          name: 'security-setting',
          component: () => import('../views/setting/security-setting.vue')
        },
      ]
    },
    {
      path: '/login',
      name: 'login',
      component: LoginIndex,
    },
    {
      path: '/study-plan',
      name: 'study-plan',
      component: StudyPlan
    },
    {
      path: '/note-management',
      name: 'note-management',
      component: NoteManagement
    },
    {
      path: '/history',
      name: 'history',
      component: History
    },
    {
      path: '/trash-bin',
      name: 'trash-bin',
      component: TrashBin
    },
    {
      path: '/translation',
      name: 'translation',
      component: Translation,
      redirect: '/translation/content-translation',
      children: [
        {
          path: 'content-translation' ,
          name: 'content-translation',
          component: () => import('../views/translation/content-translation.vue')
        },
        {
          path: 'file-translation' ,
          name: 'file-translation',
          component: () => import('../views/translation/file-translation.vue')
        }
      ]
    },
    {
      path: '/studyDesktop',
      name: 'studyDesktop',
      component: StudyDesktop
    },
  ],
})

export default router
