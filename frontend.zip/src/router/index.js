import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/modules/auth'
import Home from '@/views/Home.vue'
import Login from '@/views/Login.vue'
import Register from '@/views/Register.vue'
import ResetPassword from '@/views/ResetPassword.vue'
import Explore from '@/views/Explore.vue'
import Interaction from '@/views/Interaction.vue'
import Profile from '@/views/Profile.vue'
import Playlist from '@/views/Playlist.vue'
import Song from '@/views/Song.vue'
import Genre from "@/components/home/Genre.vue";
import Artist from "@/components/home/Artist.vue";
import Album from "@/components/home/Album.vue";

const routes = [
    {
        path: '/',
        redirect: '/home',
    },
    {
        path: '/home',
        name: 'Home',
        component: Home,
    },
    {
        path: '/login',
        name: 'Login',
        component: Login,
        meta: { requiresGuest: true },
    },
    {
        path: '/register',
        name: 'Register',
        component: Register,
        meta: { requiresGuest: true },
    },
    {
        path: '/reset-password',
        name: 'ResetPassword',
        component: ResetPassword,
        meta: { requiresGuest: true },
    },
    {
        path: '/explore',
        name: 'Explore',
        component: Explore,
    },
    {
        path: '/interaction',
        name: 'Interaction',
        component: Interaction,
        meta: { requiresAuth: true },
    },
    {
        path: '/profile',
        name: 'Profile',
        component: Profile,
        meta: { requiresAuth: true },
    },
    {
        path: '/genre/:id',
        name: 'Genre',
        component: Genre,
    },
    {
        path: '/artist/:id',
        name: 'Artist',
        component: Artist,
    },
    {
        path: '/album/:id',
        name: 'Album',
        component: Album,
        meta: { requiresAuth: true }
    },
    {
        path: '/playlist/:id',
        name: 'Playlist',
        component: Playlist,
    },
    {
        path: '/song/:id',
        name: 'Song',
        component: Song,
    },
]

const router = createRouter({
    history: createWebHistory(),
    routes,
})

// 路由守卫
router.beforeEach((to, from, next) => {
    const authStore = useAuthStore()
    const isAuthenticated = authStore.isAuthenticated

    // 需要登录的页面，检查是否已认证
    if (to.meta.requiresAuth && !isAuthenticated) {
        next({ name: 'Login', query: { redirect: to.fullPath } })
    }
    // 需要访客身份的页面（未登录），检查是否已登录
    else if (to.meta.requiresGuest && isAuthenticated) {
        next({ name: 'Home' })
    }
    else {
        next()
    }
})

export default router