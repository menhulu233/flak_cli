import { defineStore } from 'pinia'
import { ref } from 'vue'
import { login, register, resetPassword, fetchUser, logout as logoutApi } from '@/api/auth'

export const useAuthStore = defineStore('auth', () => {
    const isAuthenticated = ref(false)
    const user = ref(null)

    const initializeAuth = async () => {
        const token = localStorage.getItem('auth_token')
        if (token) {
            try {
                const userData = await fetchUser()
                user.value = userData
                isAuthenticated.value = true
            } catch (error) {
                console.error('Failed to initialize auth:', error.message)
                localStorage.removeItem('auth_token')
                isAuthenticated.value = false
                user.value = null
            }
        }
    }

    const loginAction = async (credentials) => {
        try {
            const { token, user: userData } = await login(credentials)
            localStorage.setItem('auth_token', token)
            user.value = userData
            isAuthenticated.value = true
            return { success: true }
        } catch (error) {
            return { success: false, error: error.message }
        }
    }

    const registerAction = async (userData) => {
        try {
            const response = await register(userData)
            return { success: true, message: response.message }
        } catch (error) {
            return { success: false, error: error.message }
        }
    }

    const resetPasswordAction = async (userData) => {
        try {
            const response = await resetPassword(userData)
            return { success: true, message: response.message }
        } catch (error) {
            return { success: false, error: error.message }
        }
    }

    const logoutAction = async () => {
        try {
            await logoutApi()
        } catch (error) {
            console.error('Logout failed:', error.message)
        } finally {
            localStorage.removeItem('auth_token')
            isAuthenticated.value = false
            user.value = null
        }
    }

    return {
        isAuthenticated,
        user,
        initializeAuth,
        loginAction,
        registerAction,
        resetPasswordAction,
        logoutAction
    }
})