import {defineStore} from 'pinia'
import {ref, computed} from 'vue'
import {fetchSong} from '@/api/music'

export const useMusicStore = defineStore('music', () => {
    // 状态
    const currentSong = ref(null) // 当前歌曲：{ id, title, artist, duration, url }
    const isPlaying = ref(false) // 播放状态
    const playlist = ref([]) // 播放列表：[{ id, title, artist, duration, url }, ...]
    const currentIndex = ref(-1) // 当前歌曲在播放列表中的索引
    const volume = ref(0.5) // 音量（0-1）
    const progress = ref(0) // 播放进度（秒）
    const audio = ref(new Audio()) // HTML5 Audio 实例

    // 计算属性：是否可以播放上一首/下一首
    const canSkipPrevious = computed(() => currentIndex.value > 0)
    const canSkipNext = computed(() => currentIndex.value < playlist.value.length - 1)

    // 初始化音频事件
    const initializeAudio = () => {
        audio.value.addEventListener('timeupdate', () => {
            progress.value = audio.value.currentTime
        })
        audio.value.addEventListener('ended', () => {
            if (canSkipNext.value) {
                skipNext()
            } else {
                pause()
            }
        })
    }

    // 加载歌曲
    const loadSong = async (songId) => {
        try {
            const song = await fetchSong(songId)
            currentSong.value = song
            audio.value.src = song.url
            audio.value.volume = volume.value
            progress.value = 0
            if (playlist.value.length === 0 || !playlist.value.some(s => s.id === song.id)) {
                playlist.value.push(song)
                currentIndex.value = playlist.value.length - 1
            } else {
                currentIndex.value = playlist.value.findIndex(s => s.id === song.id)
            }
        } catch (error) {
            console.error('Failed to load song:', error.message)
        }
    }

    // 播放
    const play = async () => {
        if (currentSong.value) {
            try {
                await audio.value.play()
                isPlaying.value = true
            } catch (error) {
                console.error('Play failed:', error)
            }
        }
    }

    // 暂停
    const pause = () => {
        audio.value.pause()
        isPlaying.value = false
    }

    // 上一首
    const skipPrevious = () => {
        if (canSkipPrevious.value) {
            currentIndex.value--
            currentSong.value = playlist.value[currentIndex.value]
            audio.value.src = currentSong.value.url
            if (isPlaying.value) {
                play()
            }
        }
    }

    // 下一首
    const skipNext = () => {
        if (canSkipNext.value) {
            currentIndex.value++
            currentSong.value = playlist.value[currentIndex.value]
            audio.value.src = currentSong.value.url
            if (isPlaying.value) {
                play()
            }
        }
    }

    // 调整进度
    const seek = (value) => {
        audio.value.currentTime = value
        progress.value = value
    }

    // 设置音量
    const setVolume = (value) => {
        volume.value = value
        audio.value.volume = value
    }

    // 添加到播放列表
    const addToPlaylist = (song) => {
        if (!playlist.value.some(s => s.id === song.id)) {
            playlist.value.push(song)
        }
    }

    // 初始化
    initializeAudio()

    return {
        currentSong,
        isPlaying,
        playlist,
        currentIndex,
        volume,
        progress,
        canSkipPrevious,
        canSkipNext,
        loadSong,
        play,
        pause,
        skipPrevious,
        skipNext,
        seek,
        setVolume,
        addToPlaylist
    }
})