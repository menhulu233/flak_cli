import request from "@/utils/request";

export const fetchSong = async (songId) => {
    try {
        const response = await request.get(`/api/song/${songId}`)
        return response.data
    } catch (error) {
        throw new Error(error.response?.data?.message || '获取歌曲失败')
    }
}