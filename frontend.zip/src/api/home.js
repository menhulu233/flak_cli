import request from "@/utils/request.js";

export const getRecommendations = async () => {
    console.log('api/home: getRecommendations called')
    try {
        const response = await request.get('/home/recommend')
        console.log('api/home: getRecommendations response', response)
        return response.data
    } catch (error) {
        console.error('api/home: getRecommendations error', error)
        throw new Error(error.response?.data?.message || '获取推荐数据失败')
    }
}