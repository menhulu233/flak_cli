import request from "@/utils/request";

export const login = async (credentials) => {
    console.log('login', credentials)
    try {
        const response = await request.post('/auth/login', credentials)
        console.log(response.data)
        return response.data
    } catch (error) {
        console.log(error)
        throw new Error(error.response?.data?.message || '登录失败')
    }
}

export const register = async (userData) => {
    try {
        const response = await request.post('/auth/register', userData)
        return response
    } catch (error) {
        throw new Error(error.response?.data?.message || '注册失败')
    }
}

export const resetPassword = async (userData) => {
    try {
        const response = await request.post('/auth/reset-password', userData)
        return response
    } catch (error) {
        throw new Error(error.response?.data?.message || '密码重置请求失败')
    }
}

export const fetchUser = async () => {
    try {
        const response = await request.get('/auth/user', {
            headers: { Authorization: `Bearer ${localStorage.getItem('auth_token')}` }
        })
        return response.data
    } catch (error) {
        throw new Error(error.response?.data?.message || '获取用户信息失败')
    }
}

export const logout = async () => {
    try {
        const response = await request.post('/auth/logout', null, {
            headers: { Authorization: `Bearer ${localStorage.getItem('auth_token')}` }
        })
        return response.data
    } catch (error) {
        throw new Error(error.response?.data?.message || '登出失败')
    }
}