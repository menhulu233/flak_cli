import axios from 'axios'
import { message, Modal } from 'ant-design-vue'
import { useAuthStore } from '@/stores/modules/auth'
import router from '@/router'

// Create axios instance
const service = axios.create({
    baseURL: import.meta.env.VITE_API_BASE_URL || '/api',
    timeout: 10 * 1000
})

// Request interceptor
service.interceptors.request.use(
    config => {
        const authStore = useAuthStore()
        const token = authStore.token
        if (token) {
            config.headers.Authorization = `Bearer ${token}`
        }
        return config
    },
    error => Promise.reject(error)
)

// Response interceptor
service.interceptors.response.use(
    response => {
        const status = response.status
        const data = response.data
        const msg = response.data.message
        console.log('response', response)
        if (status === 200) return data
        message.error(msg || 'Service Error').then(r => console.log(r) )
        return Promise.reject(new Error(msg || 'Error'))
    },
    error => {
        const { response } = error
        if (response?.status === 401) {
            const authStore = useAuthStore()
            authStore.logout()
            Modal.confirm({
                title: 'Session Expired',
                content: 'Please login again',
                okText: 'OK',
                cancelText: 'Cancel',
                onOk: () => {
                    router.replace('/login?redirect=' + encodeURIComponent(window.location.pathname))
                }
            })
        } else {
            message.error(response?.data?.message || error.message || 'Network Error')
        }
        return Promise.reject(error)
    }
)

// HTTP methods
export default {
    get(url, params = {}, config = {}) {
        return service.get(url, { params, ...config })
    },
    post(url, data = {}, config = {}) {
        console.log('post', url, data)
        return service.post(url, data, config)
    },
    put(url, data = {}, config = {}) {
        return service.put(url, data, config)
    },
    del(url, config = {}) {
        return service.delete(url, config)
    },
    upload(url, file, extraData = {}) {
        const fd = new FormData()
        fd.append('file', file)
        Object.keys(extraData).forEach(k => fd.append(k, extraData[k]))
        return service.post(url, fd, {
            headers: { 'Content-Type': 'multipart/form-data' }
        })
    }
}