<template>
  <div class="app">
    <!-- 左侧菜单 -->
    <div class="left-sidebar">
      <aside class="sidebar">
        <div class="project-name">学塔</div>
        <div class="logo">LearnTower</div>
        <nav class="menu">
          <ul>
            <li>
              <router-link to="/studyDesktop" class="icon-text-block">
                <el-icon><Files /></el-icon>
                <i>{{ $t('App.menu-items.studyDesktop') }}</i>
              </router-link>
            </li>
            <li>
              <router-link to="/study-plan" class="icon-text-block">
                <el-icon><Edit /></el-icon>
                <i>{{ $t('App.menu-items.studyPlan') }}</i>
              </router-link>
            </li>
            <li>
              <router-link to="/note-management" class="icon-text-block">
                <el-icon><Notebook /></el-icon>
                <i>{{ $t('App.menu-items.noteManagement') }}</i>
              </router-link>
            </li>
            <li>
              <router-link to="/question-answer" class="icon-text-block">
                <el-icon><ChatLineSquare /></el-icon>
                <i>{{ $t('App.menu-items.questionAnswer') }}</i>
              </router-link>
            </li>
            <li>
              <router-link to="/history" class="icon-text-block">
                <el-icon><DocumentCopy /></el-icon>
                <i>{{ $t('App.menu-items.history') }}</i>
              </router-link>
            </li>
            <li>
              <router-link to="/translation" class="icon-text-block">
                <el-icon><Connection /></el-icon>
                <i>{{ $t('App.menu-items.translation') }}</i>
              </router-link>
            </li>
          </ul>
        </nav>
      </aside>
    </div>

    <!-- 右侧内容 -->
    <div class="right-content">
      <div class="top-sidebar">
        <input
          type="text"
          :placeholder="$t('App.top-sidebar.searchPlaceholder')"
          class="search-bar"
        />
        <div class="user-settings">
          <span>
            <router-link to="/setting" class="icon-text-block no-style">
              <div class="setting-icon">
                <el-icon :size="20"><Setting /></el-icon>
              </div>
              <div class="setting-text">{{ $t('App.top-sidebar.user-settings.settings') }}</div>
            </router-link>
          </span>
          <span>
            <router-link to="/user" class="icon-text-block no-style">
              <div class="setting-icon">
                <el-icon :size="20"><User /></el-icon>
              </div>
              <div class="setting-text">{{ $t('App.top-sidebar.user-settings.user') }}</div>
            </router-link>
          </span>
        </div>
      </div>

      <!-- 内容 -->
      <div class="content">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue';
import avatar from './assets/avatar.jpg';

export default {
  name: 'App',
  setup() {
    const circleUrl = ref(avatar);

    return {
      circleUrl,
    };
  },
};
</script>

<style scoped>
@import '/src/css/base.css';
@import './css/App.css';
</style>
