<template>
  <a-layout id="app-layout">
    <Header />
    <a-layout-content id="main-content" class="main-content">
      <router-view />
    </a-layout-content>
    <MusicPlayer />
    <Footer />
  </a-layout>
</template>

<script setup>
import Header from '@/components/common/Header.vue'
import Footer from '@/components/common/Footer.vue'
import MusicPlayer from '@/components/common/MusicPlayer.vue'
</script>

<style>
/* 全局样式重置和基础设置 */
* {
  box-sizing: border-box;
}

html, body {
  height: 100%;
  min-height: 100vh;
  margin: 0;
  padding: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  overflow-x: hidden;
}

#app {
  height: 100%;
  width: 100%;
  min-height: 100vh;
  position: relative;
}

#app-layout {
  height: 100%;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

/* Header 样式 */
.header {
  height: 64px;
  line-height: 64px;
  background: linear-gradient(135deg, #ffffff 0%, #f5f7fa 100%);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  z-index: 1001;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
}

/* Main Content 样式 */
.main-content {
  flex: 1 0 auto;
  min-height: calc(100vh - 64px - 60px - 60px); /* header 64px + player 60px + footer 60px */
  padding: 84px 20px 100px 20px; /* padding-top: 64px(header) + 20px */
  overflow-y: auto;
  background: #f5f7fa;
  position: relative;
  width: 100%;
  box-sizing: border-box;
}

/* 确保 router-view 有内容高度 */
.main-content > * {
  min-height: 100%;
}

/* Footer 样式 */
.footer {
  height: 60px;
  background: #f0f2f5;
  border-top: 1px solid #d9d9d9;
  z-index: 999;
  flex-shrink: 0;
}

/* Music Player 样式 */
.music-player {
  z-index: 1000;
  height: 60px;
  position: fixed;
  bottom: 60px; /* 贴着 footer 上方 */
  left: 0;
  right: 0;
  background: #fff;
  box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.1);
}

/* 响应式适配 */
@media (max-width: 768px) {
  .header {
    height: 56px;
    line-height: 56px;
  }

  .main-content {
    padding: 76px 10px 120px 10px; /* padding-top: 56px(header) + 20px */
    min-height: calc(100vh - 56px - 50px - 50px); /* header 56px + player 50px + footer 50px */
  }

  .footer {
    height: 50px;
  }

  .music-player {
    height: 50px;
    bottom: 50px;
  }
}

/* 深色模式适配 */
@media (prefers-color-scheme: dark) {
  .header {
    background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
  }

  .main-content {
    background: #1f1f1f;
  }

  .footer {
    background: #2d2d2d;
    border-top: 1px solid #3f3f3f;
  }

  .music-player {
    background: #2d2d2d;
    box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.2);
  }
}

/* 调试样式：临时边框（生产环境移除） */
.main-content {
  border: 1px solid red;
}

/* 确保 Ant Design 布局正确 */
:deep(.ant-layout) {
  height: 100%;
  min-height: 100vh;
}

:deep(.ant-layout-content) {
  flex: 1 0 auto;
  display: block;
}
</style>