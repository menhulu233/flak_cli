import {createApp} from 'vue'
import '@/styles/style.css'
import App from './App.vue'
import pinia from "@/stores";
import router from "@/router";
import Antd from 'ant-design-vue';
import '@/mock/index.js'   // 确保这行被执行

const app = createApp(App)
app.use(router)
app.use(pinia)
app.use(Antd)
app.mount('#app')
