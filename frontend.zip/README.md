# XuetaGPT

This template should help get you started developing with Vue 3 in Vite.
本模板应能帮助你在 Vite 中使用 Vue 3 开始开发

## 推荐的 IDE 设置

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur).

## 自定义配置

See [Vite Configuration Reference](https://vite.dev/config/).

## 项目设置

```sh
npm install
```

### 开发环境下的编译和热重载

```sh
npm run dev
```

### 生产环境下的编译和压缩

```sh
npm run build
```

### 使用 Vitest 运行单元测试[Vitest](https://vitest.dev/)

```sh
npm run test:unit
```

### 使用 ESLint 代码检查 [ESLint](https://eslint.org/)

```sh
npm run lint
```
