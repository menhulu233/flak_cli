"""
URL configuration for NewSciSeek project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import TemplateView
from django.http import JsonResponse
from django.shortcuts import redirect
from chat.views import chat_view
from users.views import home_view
import logging

# API根视图
def api_root(request):
    return JsonResponse({
        'version': 'v1',
        'endpoints': {
            'users': '/api/users/',
            'chat': '/api/chat/',
            'billing': '/api/billing/',
        }
    })

# API路由
api_urlpatterns = [
    path('users/', include('users.urls', namespace='users_api')),
    path('billing/', include('billing.urls', namespace='billing_api')),
    path('chat/', include('chat.urls')),
]

# 用户相关路由
user_patterns = [
    path('', include('users.urls', namespace='users_web')),
]

# 支付相关路由
billing_patterns = [
    path('', include('billing.urls', namespace='billing_web')),
    path('payment/status/<str:order_id>/', 
         lambda request, order_id: redirect(f'/api/billing/payment/status/{order_id}/')),
]

# 静态页面路由
static_patterns = [
    path('', home_view, name='home'),
    path('recharge-agreement/', TemplateView.as_view(template_name='pages/recharge_agreement.html'), name='recharge_agreement'),
    path('user-agreement/', TemplateView.as_view(template_name='pages/user_agreement.html'), name='user_agreement'),
    path('privacy-policy/', TemplateView.as_view(template_name='pages/privacy_policy.html'), name='privacy_policy'),
    path('about-us/', TemplateView.as_view(template_name='pages/about_us.html'), name='about_us'),
    path('suggestions/', TemplateView.as_view(template_name='pages/suggestions.html'), name='suggestions'),
]

# 主URL配置
urlpatterns = [
    # 管理后台
    path('admin/', admin.site.urls),
    
    # API认证
    path('api-auth/', include('rest_framework.urls')),
    
    # API路由 (users, billing)
    path('api/', include(api_urlpatterns)),
    
    # Chat API 路由
    path('chat/', chat_view, name='chat_page'),
    
    # 用户相关路由
    path('users/', include(user_patterns)),
    
    # 支付相关路由
    path('billing/', include(billing_patterns)),
    
    # 静态页面
    path('', include(static_patterns)),
]

# 开发环境媒体文件服务和 Debug Toolbar URL
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    # 添加 Django Debug Toolbar URL
    import debug_toolbar
    urlpatterns = [
        path('__debug__/', include(debug_toolbar.urls)),
    ] + urlpatterns
