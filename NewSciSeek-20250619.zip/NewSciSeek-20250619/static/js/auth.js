/**
 * 认证相关的工具函数
 */

// 常量定义
const CSRF_TOKEN_NAME = 'csrftoken';
const AUTH_TOKEN_KEY = 'auth_token';
const USER_ID_KEY = 'user_id';
const USERNAME_KEY = 'username';

const META_CSRF_TOKEN = 'meta[name="csrf-token"]';
const META_USER_AUTHENTICATED = 'meta[name="user-authenticated"]';
const META_USER_ID = 'meta[name="user-id"]';
const META_USERNAME = 'meta[name="username"]';

const HEADER_CONTENT_TYPE = 'Content-Type';
const HEADER_CSRF_TOKEN = 'X-CSRFToken';
const HEADER_AUTHORIZATION = 'Authorization';
const CONTENT_TYPE_JSON = 'application/json';

const API_LOGIN_URL = '/api/users/login/';
const API_LOGOUT_URL = '/api/users/logout/';
const API_USER_INFO_URL = '/api/users/info/';

const LOGIN_URL = '/login/';

// 缓存从 meta 标签获取的 CSRF Token
let cachedCsrfTokenFromMeta = null;

// 初始化函数：检查 meta 标签并更新 localStorage
function initAuthStatusFromMeta() {
    const authMeta = document.querySelector(META_USER_AUTHENTICATED);
    if (authMeta && authMeta.getAttribute('content') === 'true') {
        const userIdMeta = document.querySelector(META_USER_ID);
        const usernameMeta = document.querySelector(META_USERNAME);
        if (userIdMeta && usernameMeta) {
            localStorage.setItem(USER_ID_KEY, userIdMeta.getAttribute('content'));
            localStorage.setItem(USERNAME_KEY, usernameMeta.getAttribute('content'));
            // 注意：这里不设置 auth_token，因为 Django 认证不一定涉及 API token
        }
    }
}

// 获取 CSRF Token
function getCsrfToken() {
    const name = CSRF_TOKEN_NAME;
    let cookieValue = null;
    // 优先从 cookie 获取
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    // 如果 cookie 中没有，尝试从缓存或 meta 标签获取
    if (!cookieValue) {
        if (cachedCsrfTokenFromMeta !== null) {
            return cachedCsrfTokenFromMeta;
        }
        const csrfTokenElement = document.querySelector(META_CSRF_TOKEN);
        if (csrfTokenElement) {
            cachedCsrfTokenFromMeta = csrfTokenElement.getAttribute('content');
            cookieValue = cachedCsrfTokenFromMeta;
        }
    }
    return cookieValue;
}

// 获取认证令牌
function getAuthToken() {
    return localStorage.getItem(AUTH_TOKEN_KEY);
}

// 设置认证令牌
function setAuthToken(token) {
    localStorage.setItem(AUTH_TOKEN_KEY, token);
}

// 移除认证令牌
function removeAuthToken() {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    // 同时清除关联的用户信息
    localStorage.removeItem(USER_ID_KEY);
    localStorage.removeItem(USERNAME_KEY);
}

// 检查是否已登录 (简化版)
function isAuthenticated() {
    // 检查 localStorage 中是否有用户 ID (来自 meta 初始化或 API 登录)
    // 或者检查是否有 API 认证 token
    return localStorage.getItem(USER_ID_KEY) !== null || getAuthToken() !== null;
}

// 获取基础认证头 (不含 Content-Type，供 fetchApi 使用)
function getBaseAuthHeaders() {
    const token = getAuthToken();
    const csrfToken = getCsrfToken();
    const headers = {};

    if (csrfToken) {
        headers[HEADER_CSRF_TOKEN] = csrfToken;
    }
    if (token) {
        headers[HEADER_AUTHORIZATION] = `Token ${token}`;
    }
    return headers;
}

// --- 新增：API 请求辅助函数 ---
async function fetchApi(url, options = {}) {
    const baseHeaders = getBaseAuthHeaders();
    const headers = {
        ...baseHeaders,
        [HEADER_CONTENT_TYPE]: CONTENT_TYPE_JSON,
        ...(options.headers || {}), // 合并传入的 headers
    };

    // 准备 fetch 参数
    const fetchOptions = {
        ...options,
        headers,
    };

    // 确保 body 是字符串 (如果存在且是对象)
    if (fetchOptions.body && typeof fetchOptions.body === 'object') {
        fetchOptions.body = JSON.stringify(fetchOptions.body);
    }

    try {
        const response = await fetch(url, fetchOptions);

        // 处理 401 未授权: 清除 token 并抛出特定错误或重定向
        if (response.status === 401) {
            removeAuthToken();
            // 根据需要决定是抛出错误让调用者处理，还是直接重定向
            // window.location.href = LOGIN_URL;
            throw new Error('认证失败或令牌已过期'); // 抛出错误
        }

        // 尝试解析响应体 (即使是错误响应也可能包含信息)
        let responseData = null;
        try {
            // 处理 204 No Content
            if (response.status === 204) {
                responseData = null; 
            } else {
                responseData = await response.json();
            }
        } catch (e) {
            // 如果解析 JSON 失败 (例如响应体为空或非 JSON)
            console.warn(`无法解析来自 ${url} 的 JSON 响应`);
            // 如果响应本身是成功的，但没有内容，这可能是正常的
            if (!response.ok) {
                // 如果响应是失败的，且无法解析 JSON，抛出通用 HTTP 错误
                 throw new Error(`HTTP 错误 ${response.status}: ${response.statusText}`);
            }
            // 如果响应成功但无法解析 JSON (可能是空响应), responseData 保持 null
        }

        // 检查非 2xx 状态码 (除已处理的 401)
        if (!response.ok) {
            // 尝试从解析的数据中获取错误消息
            const errorMessage = responseData?.error || responseData?.message || `HTTP 错误 ${response.status}`;
            throw new Error(errorMessage);
        }

        // 返回成功解析的数据
        return responseData;

    } catch (error) {
        console.error(`API 请求失败 (${url}):`, error);
        // 重新抛出错误，以便上层可以捕获
        throw error;
    }
}

// --- 重构 API 调用函数 --- 

// 登录函数 (使用 fetchApi)
async function login(username, password) {
    try {
        const data = await fetchApi(API_LOGIN_URL, {
            method: 'POST',
            body: {
                phone: username, // 确认后端期望的字段名
                password: password,
            },
            // login 通常不需要 Authorization 头，但需要 CSRF
            // fetchApi 会自动处理 CSRF (如果 getBaseAuthHeaders 能获取到)
            // 如果登录 API 不需要 CSRF，可以在这里覆盖 headers
            // headers: { [HEADER_CONTENT_TYPE]: CONTENT_TYPE_JSON } 
        });

        // 假设成功响应包含 { data: { token: '...', user: {...} } }
        if (data?.data?.token) {
            setAuthToken(data.data.token);
            if (data.data.user) {
                localStorage.setItem(USER_ID_KEY, data.data.user.id);
                localStorage.setItem(USERNAME_KEY, data.data.user.username);
            } else {
                 // 如果 token 存在但用户信息缺失，打印警告，但不阻止登录流程
                 console.warn('登录响应成功，但缺少用户信息。');
            }
            return data; // 返回原始响应数据
        } else {
            // API 成功返回 (2xx)，但数据格式不符合预期
            throw new Error('登录响应格式不正确');
        }
    } catch (error) {
        // fetchApi 已经打印了错误，这里可以选择性地再次抛出或处理
        console.error('登录流程失败:', error.message);
        throw error; // 重新抛出，让调用者处理 UI 反馈等
    }
}

// 登出函数 (使用 fetchApi)
async function logout() {
    try {
        // 调用登出 API，通常不需要关心响应体
        await fetchApi(API_LOGOUT_URL, {
            method: 'POST',
            // fetchApi 会自动添加 Authorization 和 CSRF 头
        });
        // 不论 API 调用是否成功 (除非是网络错误或严重服务器错误被 fetchApi 捕获)
        // 都应该清除本地状态并重定向
    } catch (error) {
        // 如果 fetchApi 抛出错误 (例如 401 已被处理, 或其他网络/服务器错误)
        console.error('登出 API 调用失败或发生错误:', error.message);
        // 即使 API 调用失败，也继续执行清理和重定向
    } finally {
        // 确保总是清除本地信息并重定向
        removeAuthToken(); // removeAuthToken 已包含清除 user_id 和 username
        window.location.href = LOGIN_URL;
    }
}

// 获取当前用户信息 (使用 fetchApi)
async function getCurrentUser() {
    // 优先从 localStorage 获取
    const userId = localStorage.getItem(USER_ID_KEY);
    const username = localStorage.getItem(USERNAME_KEY);
    if (userId && username) {
        return { id: userId, username: username };
    }

    // localStorage 没有，再尝试从 API 获取
    try {
        const data = await fetchApi(API_USER_INFO_URL, {
            method: 'GET',
            // fetchApi 会自动添加必要的认证头
        });

        // 假设成功响应包含 { data: { id: ..., username: ... } }
        const user = data?.data;
        if (user?.id && user?.username) {
            // 获取成功后，更新 localStorage
            localStorage.setItem(USER_ID_KEY, user.id);
            localStorage.setItem(USERNAME_KEY, user.username);
            return user;
        } else {
            // API 成功返回 (2xx)，但数据格式不符合预期
            console.warn('API 返回的用户信息格式不正确:', data);
             // 清除可能存在的无效本地信息
             removeAuthToken();
            throw new Error('获取到的用户信息无效');
        }
    } catch (error) {
        // fetchApi 会处理 401 并清除 token
        // 其他错误由 fetchApi 抛出并在此捕获
        console.error('获取用户信息失败:', error.message);
         // 确保清除可能存在的无效本地信息 (以防万一 fetchApi 的 401 处理未覆盖所有情况)
         // removeAuthToken(); // fetchApi 中的 401 处理和 logout 的 finally 会处理清理
        throw error; // 重新抛出，让调用者处理
    }
}

// --- 移除旧的 handleAuthError --- 

// 导出函数
export {
    initAuthStatusFromMeta,
    getCsrfToken,
    getAuthToken,
    setAuthToken,
    removeAuthToken,
    isAuthenticated,
    // getAuthHeaders, // 不再需要导出，由 fetchApi 内部使用 getBaseAuthHeaders
    // handleAuthError, // 已移除
    login,
    logout,
    getCurrentUser
}; 