// 全局函数定义
window.showRegisterModal = function() {
    // Use getOrCreateInstance to prevent multiple instances
    const registerModal = bootstrap.Modal.getOrCreateInstance(document.getElementById('registerModal'));
    registerModal.show();
};

window.showLoginModal = function() {
    // Use getOrCreateInstance to prevent multiple instances
    const loginModal = bootstrap.Modal.getOrCreateInstance(document.getElementById('loginModal'));
    
    // 确保next参数从URL中获取并设置到表单中
    const nextUrl = new URLSearchParams(window.location.search).get('next');
    if (nextUrl) {
        const nextInput = document.querySelector('#loginModal input[name="next"]');
        if (nextInput) {
            nextInput.value = nextUrl;
        }
    }
    
    loginModal.show();
};

// 在DOM加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    // 获取CSRF令牌的辅助函数 (增强版，回退检查 meta 标签)
    function getCsrfToken() {
        const name = 'csrftoken'; // Standard Django CSRF cookie name
        let cookieValue = null;
        // 优先从 cookie 获取
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    console.log('CSRF token found in cookie.');
                    break;
                }
            }
        }
        // 如果 cookie 中没有，尝试从 meta 标签获取
        // 注意：这要求 HTML 的 <head> 中存在 <meta name="csrf-token" content="{{ csrf_token }}"> 标签
        if (!cookieValue) {
             const csrfTokenElement = document.querySelector('meta[name="csrf-token"]');
             if (csrfTokenElement) {
                 cookieValue = csrfTokenElement.getAttribute('content');
                 console.log('CSRF token found in meta tag.');
             }
        }
        // 如果依然没有找到，则返回 null 或记录错误
        if (!cookieValue) {
             console.warn('CSRF token not found in cookie or meta tag.'); // 添加警告
        }
        return cookieValue;
    }

    // 显示错误消息
    function showError(message) {
        const errorDiv = document.getElementById('loginError') || document.getElementById('registerError');
        if (errorDiv) {
            errorDiv.textContent = message;
            errorDiv.style.display = 'block';
        } else {
            // Fallback to alert if specific error divs aren't found
            alert(message);
        }
    }
    
    // 显示成功消息 (如果需要)
    function showSuccess(message) {
         // 查找或创建一个用于显示成功消息的区域
         let successDiv = document.getElementById('globalSuccessMessage'); 
         if (!successDiv) {
             // 尝试在 header 或 body 顶部创建
             const container = document.querySelector('header .header-container') || document.body;
             successDiv = document.createElement('div');
             successDiv.id = 'globalSuccessMessage';
             successDiv.className = 'alert alert-success alert-dismissible fade show fixed-top m-3'; // 样式
             successDiv.style.zIndex = '1050'; // 确保在模态框之上
             successDiv.setAttribute('role', 'alert');
             container.insertBefore(successDiv, container.firstChild);
         }
         // Make sure i18next is ready before translating
         const messageText = (window.i18next && window.i18next.isInitialized) ? window.t(message) : message;
         const closeText = (window.i18next && window.i18next.isInitialized) ? window.t('common:actions.close') : 'Close';
         successDiv.innerHTML = `${messageText} <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="${closeText}"></button>`;
         successDiv.style.display = 'block';
         // 自动关闭
         setTimeout(() => {
             const instance = bootstrap.Alert.getOrCreateInstance(successDiv);
             if (instance) instance.close();
         }, 5000);
    }

    // ---------- WeChat Login Logic (from login_modal.html) ----------
    function wechatLogin() {
        const loginBtn = document.getElementById('wechat-login-btn');
        if (!loginBtn) return;

        const originalHtml = loginBtn.innerHTML;
        const loadingText = (window.i18next && window.i18next.isInitialized) ? window.t('common:status_loading') : 'Loading...';
        const requestFailedText = (window.i18next && window.i18next.isInitialized) ? window.t('auth:login.wechat-login-request-failed') : 'WeChat login request failed';
        const getQrcodeFailedText = (window.i18next && window.i18next.isInitialized) ? window.t('auth:login.wechat-get-qrcode-failed') : 'Failed to get WeChat QR code';

        loginBtn.disabled = true;
        loginBtn.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ${loadingText}`;
        
        fetch('/api/users/wx/login/')
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.login_url) {
                    window.location.href = data.login_url; 
                } else {
                    throw new Error('No login_url received from server.');
                }
            })
            .catch(error => {
                console.error(requestFailedText, error);
                showError(getQrcodeFailedText); // Use showError for consistency
                // Restore button state
                loginBtn.disabled = false;
                loginBtn.innerHTML = originalHtml;
            });
    }
    // Attach wechatLogin to the button if it exists
    const wechatLoginBtn = document.getElementById('wechat-login-btn');
    if (wechatLoginBtn) {
        wechatLoginBtn.addEventListener('click', function(e) {
            e.preventDefault();
            wechatLogin();
        }, { passive: false });
    }
    // ---------- End of WeChat Login Logic ----------

    // 添加登录/注册链接的点击事件处理
    const loginLinks = document.querySelectorAll('.login-link');
    loginLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            showLoginModal();
        }, { passive: false });
    });
    
    const registerLinks = document.querySelectorAll('.register-link');
    registerLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            showRegisterModal();
        }, { passive: false });
    });
    
    // 检查URL中是否有next参数，如果有则显示登录模态框
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('next')) {
        // Delay showing modal slightly to ensure elements are ready
        setTimeout(showLoginModal, 100); 
    }
    
    // ----------- Consolidated Login Form Handling -----------
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        let originalButtonHtml; // Define variable here for wider scope within the listener

        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // 1. Get form data into a plain object first
            const form = e.target;
            const formDataObject = {};
            new FormData(form).forEach((value, key) => {
                // Exclude the potentially stale hidden csrfmiddlewaretoken field
                if (key !== 'csrfmiddlewaretoken') {
                    formDataObject[key] = value;
                }
            });

            // 2. Get the fresh CSRF token
            const csrfToken = getCsrfToken(); // Call once here
            if (!csrfToken) {
                console.error('CSRF token not found');
                showError('CSRF token missing. Please refresh the page.');
                return; // Stop if no token
            }
            
            // 3. Add the fresh token to the data object
            formDataObject['csrfmiddlewaretoken'] = csrfToken; 

            // --- CSRF Debugging (Updated) ---
            console.log('Data to be sent:', formDataObject); // Log the object we're sending
            console.log('Token from getCsrfToken() (used for both header and data):', csrfToken);
            console.log('Current document.cookie:', document.cookie); 
            // --- End CSRF Debugging ---

            const rememberCheckbox = document.getElementById('remember');
            if (rememberCheckbox) {
                 // formData.set('remember', rememberCheckbox.checked);
                 formDataObject['remember'] = rememberCheckbox.checked; // Update the object
            }
           
            // CSRF token already checked above
            // if (!csrfToken) { ... } // No need to check again

            const submitButton = loginForm.querySelector('button[type="submit"]');
            originalButtonHtml = submitButton.innerHTML; // Assign button HTML before disabling
            const loadingText = (window.i18next && window.i18next.isInitialized) ? window.t('common:status_logging_in') : 'Logging in...';
            
            submitButton.disabled = true;
            submitButton.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ${loadingText}`;
            
            axios.post(form.action, formDataObject, { // Send the object, not FormData instance
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRFToken': csrfToken // Header still uses the same fresh token
                }
            })
            .then(response => {
                // --- 修改：检查嵌套的 data 对象中的 status 和 redirect_url ---
                if (response.data && response.data.data && response.data.data.status === 'success') {
                    try {
                        // 获取嵌套的 redirect_url
                        const redirectUrl = response.data.data.redirect_url || '/';

                        // Hide modal *before* redirecting
                        const loginModalElement = document.getElementById('loginModal');
                        const loginModalInstance = bootstrap.Modal.getInstance(loginModalElement);
                        if (loginModalInstance) {
                             console.log('Modal instance found. Adding hidden listener and hiding.');
                             // Add event listener to redirect after modal is fully hidden
                             loginModalElement.addEventListener('hidden.bs.modal', function onHidden() {
                                 console.log('Modal hidden event triggered. Redirecting to:', redirectUrl);
                                 window.location.href = redirectUrl;
                             }, { once: true });
                             loginModalInstance.hide();
                        } else {
                             console.warn('Modal instance not found. Redirecting directly.');
                             window.location.href = redirectUrl;
                        }
                    } catch (modalError) {
                        console.error('Error during modal hide/redirect after successful login:', modalError);
                        // Still redirect, as login was successful server-side
                        console.warn('Redirecting despite modal error.');
                        // 使用从响应中获取的 URL 进行重定向
                        window.location.href = (response.data && response.data.data && response.data.data.redirect_url) || '/';
                        // NOTE: We intentionally DO NOT call showError here to avoid the generic message
                    }
                } else {
                    // Handle failed login (status !== 'success' or structure mismatch)
                    // 优先使用后端返回的 message，如果嵌套在 data 里，也尝试获取
                    const errorMessage = (response.data && response.data.message) || 
                                         (response.data && response.data.data && response.data.data.message) || 
                                         'Login failed. Please check your credentials.';
                    showError(errorMessage); 
                    // Restore button state only on explicit login failure
                    if (submitButton) {
                        submitButton.disabled = false;
                        submitButton.innerHTML = originalButtonHtml;
                    }
                }
            })
            .catch(error => {
                // This catch should now primarily handle network errors or truly unexpected issues
                console.error('Outer Login error catcher:', error);
                let errorMessage = 'errors.unexpected-error'; // Use the key directly for i18n
                if (error.response && error.response.data && error.response.data.message) {
                    // Use server message if available, otherwise keep the default
                    errorMessage = error.response.data.message;
                } else if (error.message && !error.response) { // Network errors etc.
                     errorMessage = error.message; // Show network error message directly
                }

                showError(errorMessage); // Show the error

                // Restore button state in case of caught errors
                 if (submitButton) {
                     submitButton.disabled = false;
                     // Use originalButtonHtml captured before the request
                     submitButton.innerHTML = originalButtonHtml || (window.t ? window.t('auth:login.login-button') : 'Login'); 
                 }
            });
        }, { passive: false });
    }
    // ----------- End of Consolidated Login Form Handling -----------
    
    // ----------- Consolidated Register Form Handling -----------
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const csrfToken = getCsrfToken(); // Use helper function
            if (!csrfToken) {
                console.error('CSRF token not found');
                showError('CSRF token missing. Please refresh the page.');
                return;
            }

            const submitButton = registerForm.querySelector('button[type="submit"]');
            const originalButtonHtml = submitButton.innerHTML;
            const loadingText = (window.i18next && window.i18next.isInitialized) ? window.t('common:status_registering') : 'Registering...'; // Add i18n key

            submitButton.disabled = true;
            submitButton.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ${loadingText}`;

            axios.post(this.action, formData, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRFToken': csrfToken 
                }
            })
            .then(response => {
                if (response.data.status === 'success') {
                    // Hide registration modal
                    const registerModalElement = document.getElementById('registerModal');
                    const registerModalInstance = bootstrap.Modal.getInstance(registerModalElement);
                    
                    if (registerModalInstance) {
                         // Blur active element before hiding to prevent focus issues
                         if (document.activeElement) document.activeElement.blur();
                         
                         // Show login modal AFTER registration modal is hidden
                         registerModalElement.addEventListener('hidden.bs.modal', function onRegisterHidden() {
                             showLoginModal();
                             // Display success message inside login modal *after* it's shown
                             setTimeout(() => { // Delay slightly to ensure modal is visible
                                 const loginModalBody = document.querySelector('#loginModal .modal-body');
                                 const successAlert = document.createElement('div');
                                 successAlert.className = 'alert alert-success alert-dismissible fade show';
                                 successAlert.setAttribute('role', 'alert');
                                 const messageText = (window.i18next && window.i18next.isInitialized) ? window.t(response.data.message) : response.data.message;
                                 const closeText = (window.i18next && window.i18next.isInitialized) ? window.t('common:actions.close') : 'Close';
                                 successAlert.innerHTML = `
                                     ${messageText}
                                     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="${closeText}"></button>
                                 `;
                                 // Insert before the form
                                 const formElement = loginModalBody.querySelector('form');
                                 if (formElement) {
                                     loginModalBody.insertBefore(successAlert, formElement);
                                 } else {
                                     loginModalBody.appendChild(successAlert); // Fallback
                                 }
                             }, 200); // Adjust delay if needed
                             registerModalElement.removeEventListener('hidden.bs.modal', onRegisterHidden);
                         }, { once: true });
                         registerModalInstance.hide();
                    } else {
                         // Fallback if instance not found
                         showLoginModal(); 
                         // Consider adding the success message here too as a fallback
                    }
                } else {
                    showError(response.data.message || 'Registration failed. Please try again.');
                    submitButton.disabled = false;
                    submitButton.innerHTML = originalButtonHtml;
                }
            })
            .catch(error => {
                 console.error('Registration error:', error);
                 let errorMessage = 'An unexpected error occurred during registration.';
                 if (error.response && error.response.data && error.response.data.message) {
                     errorMessage = error.response.data.message;
                 } else if (error.message) {
                      errorMessage = error.message;
                 }
                 showError(errorMessage); 
                 submitButton.disabled = false;
                 submitButton.innerHTML = originalButtonHtml;
            });
        }, { passive: false });
    }
     // ----------- End of Consolidated Register Form Handling -----------

    // 切换密码可见性
    const toggleButtons = document.querySelectorAll('.toggle-password');
    toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
            const input = this.closest('.input-group').querySelector('input');
            const icon = this.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }, { passive: false });
    });
    
    // 处理发送验证码
    const sendCodeButton = document.getElementById('sendVerificationCodeBtn');
    if (sendCodeButton) {
        sendCodeButton.addEventListener('click', function() {
            const emailInput = document.getElementById('register_email');
            const email = emailInput.value;
            if (!email || !email.includes('@')) {
                showError('请输入有效的邮箱地址'); // TODO: i18n
                return;
            }
            
            const csrfToken = getCsrfToken();
            if (!csrfToken) {
                showError('CSRF token missing. Cannot send code.');
                return;
            }
            const button = this;
            const originalButtonText = button.textContent; // Store original text
            button.disabled = true;
            button.textContent = '发送中...'; // TODO: i18n

            axios.post('/users/send-verification-code/', { email: email }, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRFToken': csrfToken,
                    'Content-Type': 'application/x-www-form-urlencoded' // 使用表单编码
                },
                 // 将数据转换为表单数据
                 transformRequest: [(data, headers) => {
                    const formData = new URLSearchParams();
                    for (const key in data) {
                        if (Object.hasOwnProperty.call(data, key)) {
                            formData.append(key, data[key]);
                        }
                    }
                    return formData;
                }]
            })
            .then(response => {
                if (response.data.status === 'success') {
                    showSuccess(response.data.message); // 显示成功消息
                    // 开始倒计时
                    let seconds = 60;
                    const sendingText = (window.i18next && window.i18next.isInitialized) ? window.t('auth:register.resend-in-seconds', { count: seconds }) : `${seconds}秒后重发`;
                    button.textContent = sendingText;
                    const interval = setInterval(() => {
                        seconds--;
                        if (seconds <= 0) {
                            clearInterval(interval);
                            button.disabled = false;
                            button.textContent = originalButtonText; // Restore original text
                        } else {
                             const resendText = (window.i18next && window.i18next.isInitialized) ? window.t('auth:register.resend-in-seconds', { count: seconds }) : `${seconds}秒后重发`;
                            button.textContent = resendText;
                        }
                    }, 1000);
                } else {
                    // --- 修改开始: 根据后端消息显示具体错误 ---
                    let errorMessage = response.data.message || '发送失败'; // 默认消息
                    if (errorMessage.includes('有效')) {
                        errorMessage = '请输入有效的邮箱地址'; // 更具体的错误
                    } else if (errorMessage.includes('注册')) {
                        errorMessage = '该邮箱已被注册'; // 更具体的错误
                    }
                    showError(errorMessage); // 显示错误
                    // --- 修改结束 ---
                    button.disabled = false;
                    button.textContent = originalButtonText; // Restore original text
                }
            })
            .catch(error => {
                 console.error('Send verification code error:', error);
                 // --- 修改开始: 尝试从 error response 获取具体消息 ---
                 let detailedErrorMessage = '发送验证码时出错，请稍后再试'; // 默认网络/通用错误
                 if (error.response && error.response.data && error.response.data.message) {
                    detailedErrorMessage = error.response.data.message;
                    if (detailedErrorMessage.includes('有效')) {
                        detailedErrorMessage = '请输入有效的邮箱地址';
                    } else if (detailedErrorMessage.includes('注册')) {
                        detailedErrorMessage = '该邮箱已被注册';
                    }
                    // 如果没有匹配到特定错误，就使用后端返回的原始消息
                 } else if (error.message) { 
                     detailedErrorMessage = error.message; // e.g., Network Error
                 }
                 showError(detailedErrorMessage);
                 // --- 修改结束 ---
                button.disabled = false;
                button.textContent = originalButtonText; // Restore original text
            });
        });
    }
    
    // Add listener for modal show to handle 'next' parameter (moved from login_modal.html)
    const loginModalElement = document.getElementById('loginModal');
    if (loginModalElement) {
        loginModalElement.addEventListener('show.bs.modal', function () {
             // Ensure i18next is ready
             if (window.i18next && window.i18next.isInitialized) {
                 updateNextParam();
             } else {
                 document.addEventListener('i18next-ready', updateNextParam, { once: true });
             }
        });
    }

    function updateNextParam() {
        const urlParams = new URLSearchParams(window.location.search);
        const nextParam = urlParams.get('next');
        if (nextParam) {
            const nextInput = document.getElementById('login-next-input');
            if (nextInput) {
                nextInput.value = nextParam;
                // console.log('Next parameter set in login modal:', nextParam);
            }
        }
    }
    
    // Removed custom event listeners for 'hidden.bs.modal' and close button click
    // Relying on standard Bootstrap data-bs-dismiss="modal" behavior now

}); // End of DOMContentLoaded 