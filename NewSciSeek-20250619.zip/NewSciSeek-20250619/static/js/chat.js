// 页面初始化
document.addEventListener('DOMContentLoaded', function() {
    // 获取页面上的主要 DOM 元素
    const chatInput = document.getElementById('chatInput');
    const sendButton = document.getElementById('sendButton');
    const chatMessages = document.getElementById('chatMessages');
    const mobileToggle = document.getElementById('mobileToggle');
    const sidebar = document.getElementById('sidebar');
    const newChatBtn = document.getElementById('newChatBtn');
    const renameDialog = document.getElementById('renameDialog');
    const newTitleInput = document.getElementById('newTitleInput');
    const renameDialogConfirm = document.getElementById('renameDialogConfirm');
    const renameDialogCancel = document.getElementById('renameDialogCancel');
    const langToggle = document.getElementById('lang-toggle');
    const chatContainer = document.querySelector('.chat-container'); // 获取父容器
    const majorQuestionsToggle = document.getElementById('majorQuestionsToggle'); // 获取重大问题切换按钮
    const majorQuestionsArea = document.getElementById('majorQuestionsArea'); // 获取重大问题区域
    const conversationsList = document.getElementById('conversationsList'); // 获取会话列表容器
    
    // ---- 调试日志：检查元素获取情况 ----
    // console.log('[DEBUG Elements] majorQuestionsToggle:', majorQuestionsToggle);
    // console.log('[DEBUG Elements] majorQuestionsArea:', majorQuestionsArea);
    // ---- 结束调试日志 ----
    
    // 绑定语言切换按钮事件 (当前由 i18next 接管)
    if (langToggle) {
        langToggle.addEventListener('click', function(e) {
            e.preventDefault();
            // console.log('语言切换按钮点击（事件监听器移除 - i18next接管）');
            // 下面的逻辑不再需要，因为i18next-init.js会监听按钮并处理
            /*
            if (typeof window.i18n !== 'undefined' && typeof window.i18n.toggleLanguage === 'function') {
                window.i18n.toggleLanguage();
            } else if (typeof window.toggleLanguage === 'function') {
                window.toggleLanguage();
            } else {
                console.error('toggleLanguage 函数不存在');
            }
            */
            return false;
        });
    }
    
    // 初始化时自动聚焦输入框
    if (chatInput) {
        setTimeout(() => {
            chatInput.focus();
        }, 500);
    }
    
    // 绑定余额不足模态框关闭按钮事件
    const closeModalBtn = document.getElementById('closeModal');
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', function() {
            const modal = document.getElementById('balanceModal');
            if (modal) {
                modal.style.display = 'none';
            }
        });
    }
    
    // ---- 全局状态变量 ----
    let activeConversationId = document.querySelector('.chat-container').dataset.conversationId || null; // 当前活动会话ID
    let isStreaming = false; // 是否正在接收流式响应
    let currentTaskId = null; // 当前流式任务的 Task ID (用于停止)
    let isFirstMessage = !activeConversationId || document.querySelectorAll('.message.user').length === 0; // 是否是当前会话的第一条消息
    let shouldAutoRename = isFirstMessage; // 是否应在收到回复后自动重命名会话
    let messageElement = null; // 当前正在处理的助手消息的 DOM 元素
    let firstUserMessageContent = null; // 存储用户的第一条消息内容，用于自动重命名

    // --- State for Details Block Parsing (处理流式响应中可能出现的 <details> 思考块) ---
    // let detailsBlockParsed = false; // 思考块是否已被完整解析或确认不存在
    // let detailsBlockEndIndex = 0; // 思考块在累积消息中的结束位置索引
    let accumulatedRawMessage = ''; // 累积的原始流式消息内容 (可能包含思考块)
    let indicatorRemoved = false; // 当前流式响应的打字指示器是否已被移除
    // --- End State ---
    
    // --- Thinking Mode Handling --- 
    const thinkingModeGroup = document.getElementById('thinkingModeGroup');
    const thinkingModeRadios = thinkingModeGroup ? thinkingModeGroup.querySelectorAll('input[type="radio"]') : [];
    const conversationThinkingMode = chatContainer.dataset.thinkingMode;
    const hasMessages = chatContainer.dataset.hasMessages === 'true';

    window.thinkingModeDisabled = false; // Flag to track if disabled

    function disableThinkingModeRadios() {
        if (window.thinkingModeDisabled || thinkingModeRadios.length === 0) return;
        thinkingModeRadios.forEach(radio => {
            radio.disabled = true;
        });
        if (thinkingModeGroup) {
            thinkingModeGroup.classList.add('disabled-group');
             // Add CSS for .disabled-group label { opacity: 0.65; cursor: not-allowed; } if needed
        }
        window.thinkingModeDisabled = true; // Set flag
    }

    function enableThinkingModeRadios() {
        if (!window.thinkingModeDisabled || thinkingModeRadios.length === 0) return;
        thinkingModeRadios.forEach(radio => {
            radio.disabled = false;
        });
         if (thinkingModeGroup) {
            thinkingModeGroup.classList.remove('disabled-group');
        }
        window.thinkingModeDisabled = false; // Reset flag
    }

    function setAndDisableThinkingMode(mode) {
        if (!mode || thinkingModeRadios.length === 0) {
            disableThinkingModeRadios(); // Disable if no mode or no radios
            return;
        }
        thinkingModeRadios.forEach(radio => {
            if (radio.value === mode) {
                radio.checked = true;
            }
        });
        disableThinkingModeRadios();
    }

    // Initial state setup
    if (conversationThinkingMode) { 
        // Existing conversation: set the mode from data attribute and disable
        setAndDisableThinkingMode(conversationThinkingMode);
    } else if (hasMessages) {
        // Existing conversation but no thinking mode set (legacy?): disable anyway
        disableThinkingModeRadios(); 
    } else {
        // New conversation: ensure enabled and 'simple' is checked
        enableThinkingModeRadios();
        const simpleRadio = document.getElementById('simpleThinking');
        if (simpleRadio) simpleRadio.checked = true;
    }
    // --- End Thinking Mode Handling ---
    
    // 页面加载完成后自动滚动到对话底部
    if (chatMessages) {
        scrollToBottom();
    }
    
    // 自动调整输入框高度
    chatInput.addEventListener('input', function() {
        // this.style.height = 'auto'; // 注释掉：禁用自动高度调整
        // this.style.height = Math.min(this.scrollHeight, 120) + 'px'; // 注释掉：禁用自动高度调整
        
        // 启用/禁用发送按钮
        if (this.value.trim() === '') {
            sendButton.disabled = true;
        } else {
            sendButton.disabled = false;
        }
    });
    
    // 调整输入框高度函数
    function adjustTextareaHeight() {
        // chatInput.style.height = 'auto'; // 注释掉：禁用自动高度调整
        // chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px'; // 注释掉：禁用自动高度调整
    }
    
    // 发送按钮点击事件 (区分发送和停止)
    sendButton.addEventListener('click', function() {
        // console.log('发送按钮被点击');
        if (isStreaming) {
            // 如果正在流式传输，点击按钮应该停止
            stopStreaming();
        } else {
            // 否则正常发送消息
            sendMessage();
        }
    });
    
    // Enter 键发送消息 (排除 Shift+Enter 换行)
    chatInput.addEventListener('keydown', function(event) {
        // 如果按下了Enter键且没有同时按下Shift键
        if (event.keyCode === 13 && !event.shiftKey) {
            event.preventDefault();
            // 只有在有内容时才发送消息
            if (this.value.trim() !== '') {
                sendMessage();
            }
        }
    });
    
    // 移动端/桌面端侧边栏切换
    mobileToggle.addEventListener('click', function() {
        const isMobile = window.innerWidth <= 768;
        chatContainer.classList.toggle('sidebar-collapsed');

        // Update localStorage based on the NEW state of the class
        const isNowCollapsedClassPresent = chatContainer.classList.contains('sidebar-collapsed');
        localStorage.setItem('sidebarCollapsed', isNowCollapsedClassPresent ? 'true' : 'false');
        // Note: The meaning of 'sidebarCollapsed' in localStorage is now overloaded:
        // - true on desktop means: visually collapsed
        // - true on mobile means: visually expanded (class is present)
        // - false on desktop means: visually expanded
        // - false on mobile means: visually hidden (class is absent)
    });

    // 新建对话按钮
    if (newChatBtn) { // 添加检查确保按钮存在
        newChatBtn.addEventListener('click', function() {
            // console.log('New Chat button clicked. Redirecting to /chat/'); // 更新日志
            window.location.href = '/chat/';
        });
    } else {
        console.error("Element with ID 'newChatBtn' not found."); // 如果按钮不存在，添加错误日志
    }

    // 在移动端点击遮罩关闭侧边栏 (使用事件委托)
    chatContainer.addEventListener('click', function(event) {
        const isMobile = window.innerWidth <= 768;
        // Only act on mobile when the sidebar is currently expanded (class is ABSENT)
        if (isMobile && !chatContainer.classList.contains('sidebar-collapsed')) {
            // Check if the click was outside the sidebar and not on the toggle button itself
            const sidebar = document.getElementById('sidebar'); // Ensure sidebar is defined in this scope
            const mobileToggle = document.getElementById('mobileToggle'); // Ensure toggle is defined
            if (sidebar && mobileToggle && !sidebar.contains(event.target) && !mobileToggle.contains(event.target)) {
                chatContainer.classList.add('sidebar-collapsed'); // Hide the sidebar by ADDING the class
                localStorage.setItem('sidebarCollapsed', 'true'); // Update state: class added, so set to 'true' (hidden on mobile)
            }
        }
    });

    // Function to apply sidebar state based on localStorage and screen width
    function applySidebarState() {
        const isMobile = window.innerWidth <= 768;
        const shouldHaveCollapsedClass = localStorage.getItem('sidebarCollapsed') === 'true';

        // Reset classes first
        chatContainer.classList.remove('sidebar-collapsed');

        if (isMobile) {
            // Mobile: CSS hides sidebar by default. '.sidebar-collapsed' class needs to be PRESENT to hide it.
            // Always ensure sidebar is hidden (class is present) on mobile initial load/resize,
            // ignoring localStorage for the initial state to enforce default hidden.
            chatContainer.classList.add('sidebar-collapsed');
            // --- REVERTED: Default to hidden, respect localStorage --- 
            // We revert to the logic where it only shows if localStorage indicates it was open.
            // chatContainer.classList.add('sidebar-collapsed'); // Removed forced visibility
            // --- END REVERT ---
            
            // Original logic (respect localStorage) - Restored:
            /* // Comment out the previous logic block
            if (shouldHaveCollapsedClass) { // If localStorage flag is 'true', EXPAND it on mobile
                chatContainer.classList.add('sidebar-collapsed');
            }
            */
            // If flag is 'false' or null, it remains hidden (default CSS)
        } else {
            // Desktop: CSS shows sidebar by default. '.sidebar-collapsed' class COLLAPSES it.
            if (shouldHaveCollapsedClass) { // If localStorage flag is 'true', COLLAPSE it on desktop
                chatContainer.classList.add('sidebar-collapsed');
            }
            // If flag is 'false' or null, it remains expanded (default CSS)
        }
    }

    // Initial state application
    applySidebarState();

    // Update state on resize
    window.addEventListener('resize', applySidebarState);
    
    // 为滚动相关事件添加passive选项 (提升滚动性能)
    chatMessages.addEventListener('touchstart', function() {}, { passive: true });
    chatMessages.addEventListener('touchmove', function() {}, { passive: true });
    chatMessages.addEventListener('wheel', function() {}, { passive: true });
    document.addEventListener('touchstart', function() {}, { passive: true });
    document.addEventListener('touchmove', function() {}, { passive: true });
    document.addEventListener('wheel', function() {}, { passive: true });
    
    // 封装需要在 i18next 初始化后执行的绑定 (更新UI文本和事件)
    window.initChatI18nBindings = function() {
        // console.log('chat.js: initChatI18nBindings called.');
        
        // 更新确认对话框文本 (如果存在且可见)
        const confirmDialog = document.getElementById('confirmDialog');
        if (confirmDialog && confirmDialog.classList.contains('show')) {
            const titleKey = confirmDialog.dataset.titleKey; // 假设 key 存储在 data 属性中
            const messageKey = confirmDialog.dataset.messageKey; // 假设 key 存储在 data 属性中
            if (titleKey) confirmDialog.querySelector('#confirmDialogTitle').textContent = window.t(titleKey);
            if (messageKey) confirmDialog.querySelector('#confirmDialogMessage').textContent = window.t(messageKey);
            confirmDialog.querySelector('#confirmDialogConfirm').textContent = window.t('common:actions.confirm'); // 使用 common 命名空间
            confirmDialog.querySelector('#confirmDialogCancel').textContent = window.t('common:actions.cancel'); // 使用 common 命名空间
        }

        // 更新重命名对话框文本 (如果存在且可见)
        const renameDialogElem = document.getElementById('renameDialog');
        if (renameDialogElem && renameDialogElem.classList.contains('show')) {
            renameDialogElem.querySelector('.rename-dialog-title').textContent = window.t('chat:rename-conversation');
            renameDialogElem.querySelector('#newTitleInput').placeholder = window.t('chat:enter-new-title');
            renameDialogElem.querySelector('#renameDialogConfirm').textContent = window.t('common:actions.save'); // 使用 common 命名空间
            renameDialogElem.querySelector('#renameDialogCancel').textContent = window.t('common:actions.cancel'); // 使用 common 命名空间
        }
        
        // 更新欢迎信息 (如果存在)
        const welcomeMessageElement = document.getElementById('welcomeMessage');
        if (welcomeMessageElement) {
            const titleElement = welcomeMessageElement.querySelector('h4');
            const messageElement = welcomeMessageElement.querySelector('p');
            if (titleElement) {
                titleElement.textContent = window.t('chat:welcome-title');
            }
            if (messageElement) {
                messageElement.textContent = window.t('chat:welcome-message');
            }
        }
        
        // 注意：更新时间戳的逻辑比较复杂，因为它依赖于实际的时间值，
        // 而不是固定的翻译键。这里暂时不将其移入此函数，
        // 除非您希望在语言切换时重新格式化所有时间戳。
        // 如果需要，可以在这里添加重新格式化时间戳的逻辑。

        // ---- 移动重大问题切换按钮的事件绑定到这里 ----
        // console.log('[DEBUG Setup] Checking if toggle and area elements exist for listener binding (inside initChatI18nBindings)...');
        if (majorQuestionsToggle && majorQuestionsArea) {
            // console.log('[DEBUG Setup] Elements found, adding click listener to toggle (inside initChatI18nBindings).');
            majorQuestionsToggle.removeEventListener('click', toggleMajorQuestions); // 确保移除旧监听器
            majorQuestionsToggle.addEventListener('click', toggleMajorQuestions);
            
            // 点击问题填充输入框的逻辑也应该在这里绑定，以确保 majorQuestionsArea 可用
            if (!majorQuestionsArea.dataset.listenerAttached) {
                majorQuestionsArea.addEventListener('click', function(event) {
                    if (event.target.tagName === 'LI') {
                        const questionText = event.target.textContent || event.target.innerText;
                        if (chatInput) {
                            chatInput.value = questionText.trim();
                            chatInput.focus(); 
                            adjustTextareaHeight(); 
                            sendButton.disabled = false; 
                        }
                        majorQuestionsArea.style.display = 'none';
                        scrollToBottom(); 
                    }
                });
                 majorQuestionsArea.dataset.listenerAttached = 'true'; // Mark as attached
            }
        } else {
            // console.warn('[DEBUG Setup] Major questions toggle or area element NOT found! Listener not bound (inside initChatI18nBindings).');
        }
        // ---- 结束移动的代码 ----

        // *** 在 i18next 准备好后绑定事件 ***
        // console.log('chat.js: Binding delete and rename buttons after i18next ready.');
        bindDeleteButtons();
        bindRenameEvents();
    };

    function toggleMajorQuestions() {
        // console.log('Major questions toggle clicked!');
        const isHidden = majorQuestionsArea.style.display === 'none' || majorQuestionsArea.style.display === '';
        if (isHidden) {
            majorQuestionsArea.style.display = 'block';
            // console.log('Showing major questions area.');
        } else {
            majorQuestionsArea.style.display = 'none';
            // console.log('Hiding major questions area.');
        }
    }

    // 再次确保滚动到底部
    if (chatMessages) {
        scrollToBottom();
    }
    
    // --- Function to disable thinking mode ---
    function disableThinkingMode() {
        if (window.thinkingModeDisabled) return; // Already disabled

        const thinkingModeRadios = document.querySelectorAll('#thinkingModeGroup input[type="radio"]');
        thinkingModeRadios.forEach(radio => {
            radio.disabled = true;
        });
        const thinkingModeGroup = document.getElementById('thinkingModeGroup');
        if (thinkingModeGroup) {
            thinkingModeGroup.classList.add('disabled-group');
             // Add CSS for .disabled-group label { opacity: 0.65; cursor: not-allowed; } if needed
        }
        window.thinkingModeDisabled = true; // Set flag
    }

    // --- Initial check on page load ---
    if (chatContainer && chatContainer.dataset.hasMessages === 'true') {
        disableThinkingMode();
    }
    // --- End initial check ---

    // 发送消息的主函数
    function sendMessage() {
        const message = chatInput.value.trim();
        if (message === '') {
            return; // 如果消息为空，则不发送
        }

        // Disable thinking mode AFTER the first message is sent in a NEW conversation
        if (!activeConversationId) { // Check if it's a new conversation (no ID yet)
             disableThinkingModeRadios(); // Call the disabling function
        }

        // Store first user message if this is the first interaction
        if (isFirstMessage) {
            firstUserMessageContent = message; // Store the message content
        }

        // 获取当前选中的思考模式 (this will be the initial mode for new convos)
        const selectedThinkingMode = document.querySelector('input[name="thinkingMode"]:checked').value;
        // console.log('Thinking mode selected in JS:', selectedThinkingMode); // <-- 添加日志

        // 显示用户消息
        addMessage('user', message);

        // 如果是重度思考模式，显示提示信息
        if (selectedThinkingMode === 'heavy') {
            addStatusMessage(window.t ? window.t('chat:heavy-thinking-notice') : 'Heavy Thinking mode activated. Responses may take several minutes...');
        }

        isFirstMessage = false; // 第一条消息已发送
        // 清空输入框并调整高度
        chatInput.value = '';
        adjustTextareaHeight();
        sendButton.disabled = true; // 禁用发送按钮

        // 构建发送的数据
        const postData = {
            message: message,
            conversation_id: activeConversationId,
            thinking_mode: selectedThinkingMode // 添加思考模式
        };

        // 发送消息到后端 (恢复 fetch 调用)
        fetch('/api/chat/stream', { // Make sure this endpoint is correct
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCookie('csrftoken')
            },
            body: JSON.stringify(postData)
        })
        .then(response => {
            // 处理 402 Payment Required 响应
            if (response.status === 402) {
                const modal = document.getElementById('balanceModal');
                if (modal) modal.style.display = 'flex';
                response.text().then(text => {
                    let errorMsg = window.t('chat:balance-insufficient-api-default');
                    try {
                        const data = JSON.parse(text);
                        if (data.error) errorMsg = data.error;
                    } catch (e) { /* ignore parsing error */ }
                    addMessage('assistant', `<div class="error-message">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-exclamation-circle" viewBox="0 0 16 16">
                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                            <path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z"/>
                        </svg>
                        <span>${errorMsg}</span>
                        <a href="/billing/account/recharge/" class="recharge-button">${window.t('chat:recharge-now-inline')}</a>
                    </div>`);
                });
                throw new Error(window.t('chat:balance-insufficient-error'));
            }

            if (!response.ok) {
                throw new Error(window.t('chat:request-failed-status', { status: response.status }));
            }

            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            return processStream(reader, decoder); // Ensure processStream function exists
        })
        .catch(error => {
            console.error('Stream error:', error); // Keep the error log
            // Don't call finishStreaming here directly, let finally handle it.
            // finishStreaming();
            const errorMsg = error.message || window.t('chat:request-failed-default');
            // Avoid duplicate error message if it's the balance issue already handled
            if (!errorMsg.includes(window.t('chat:balance-insufficient-error'))) {
                addMessage('assistant', window.t('chat:error-prefix', { error: errorMsg }));
            }
        })
        .finally(() => {
            // console.log('[DEBUG Cleanup] Fetch finally block reached.'); // Comment out
            // FINALLY BLOCK CLEANUP: Ensure streaming state is always reset
            if (isStreaming) {
                console.warn("[Cleanup] isStreaming was true in finally. Forcing finishStreaming()."); // Keep warning for debugging
                finishStreaming(); // Force cleanup if still marked as streaming
            } else {
                // console.log('[DEBUG Cleanup] isStreaming is false, cleanup likely done.'); // Comment out
                // Ensure button state is correct even if not streaming (e.g., initial error)
                sendButton.disabled = (chatInput.value.trim() === '');
                updateSendButtonIcon(false);
            }
            // Re-enable thinking mode radios if needed (handle potential race condition)
            // Consider if enableThinkingModeRadios() should be here or inside finishStreaming()
            // enableThinkingModeRadios();
        });
    }
    
    // 处理流式响应的核心函数
    async function processStream(reader, decoder) {
        // Reset details parsing state for the new stream
        // let detailsBlockParsed = false;
        // let detailsBlockEndIndex = 0;
        accumulatedRawMessage = '';
        // isParsingDetails = true; // Start by assuming we might parse details - This was likely removed or commented already

        // 设置流式传输状态
        isStreaming = true;
        updateSendButtonIcon(true); // Update button to stop
        sendButton.disabled = false; // <<< ENSURE BUTTON IS CLICKABLE TO STOP STREAMING

        // 创建初始助手消息（空内容）
        messageElement = createMessageElement('assistant', ''); // Content is initially empty
        chatMessages.appendChild(messageElement);
        scrollToBottom(); // Scroll after adding the empty bubble

        // Show typing indicator *inside* the new empty message bubble
        showTypingIndicator(); // Call it AFTER messageElement is created

        let buffer = '';
        // let currentMessage = ''; // No longer needed here

        try {
            while (true) {
                const { done, value } = await reader.read();

                if (done) {
                    // Process final buffer if any (should ideally be handled by message_end)
                    if (buffer) {
                        // Pass accumulatedRawMessage for context if needed, but modify state inside
                        processEventData(buffer); // Remove currentMessage argument
                    }
                    break;
                }

                // 解码并添加到缓冲区
                const text = decoder.decode(value, { stream: true });
                // console.log("收到原始数据块:", text);
                buffer += text;

                // 处理缓冲区中的完整事件
                let lines = buffer.split('\n');

                // 检查是否是纯文本响应而不是SSE格式
                if (lines.length === 1 && !buffer.includes('data: ') && !buffer.includes('event: ')) {
                    // 可能是纯文本响应，但需要确保缓冲区已完整
                    if (buffer.trim()) {
                        try {
                            // 尝试作为JSON解析
                            const data = JSON.parse(buffer);
                            // currentMessage = processJsonData(data, currentMessage); // Modify state inside instead
                            processJsonData(data);
                            buffer = '';
                        } catch (e) {
                            // 不是JSON，可能是部分数据，或者是不期望的纯文本 (如 "Thinking...")
                            // 我们应该忽略这种非结构化的数据，只处理 data: {} 格式的SSE事件
                            // console.warn('Non-JSON data received outside SSE format, ignoring:', buffer);
                            // ... (existing handling for non-JSON) ...
                        }
                    }
                } else {
                    // 正常SSE格式处理
                    buffer = lines.pop() || ''; // 保留最后一个不完整的行

                    for (const line of lines) {
                        if (line.trim()) {  // 只处理非空行
                            // 传递currentMessage变量并获取更新后的值
                            // currentMessage = processEventData(line, currentMessage); // Modify state inside instead
                            processEventData(line);
                        }
                    }
                }
            }
        } catch (error) {
            // console.error("流处理错误:", error); // Commented out, Stream error logged in catch block of fetch
            const contentElement = messageElement.querySelector('.message-content');
            if (contentElement) { // Check if element exists
                contentElement.textContent += `\\n\\n[${window.t ? window.t('chat:stream-error-suffix') : 'Stream Error'}]`;
            }
        } finally {
            // finishStreaming is now called within the message_end event handler
            // finishStreaming();

            // Auto-rename logic is now handled within the message_end event handler
            // if (shouldAutoRename && activeConversationId) { ... }
        }
        // Return value might not be needed
        // return accumulatedRawMessage;
    }

    // 处理JSON数据
    function processJsonData(data) { // Remove currentMessage argument
        // console.log("处理JSON数据:", data); // Comment out
        let contentElement = null; // Declare contentElement here with initial null value
        if (messageElement) {
             // Try to get it initially if messageElement already exists
             contentElement = messageElement.querySelector('.message-content');
        }

        // 优先处理后端发送的本地会话ID
        if (data.event === 'conversation_created' || data.local_conversation_id) {
            const localId = data.local_conversation_id || (data.data ? data.data.id : null); // Handle both structures
            if (localId && !activeConversationId) {
                // console.log('Received local conversation ID:', localId); // 注释掉日志
                activeConversationId = localId;
                // 更新浏览器历史记录中的URL，避免刷新后丢失会话
                window.history.replaceState({}, '', `?conversation_id=${activeConversationId}`);
                // If a message element was created before we got the ID, update it
                if (messageElement && !messageElement.dataset.conversationId) {
                    messageElement.dataset.conversationId = activeConversationId;
                }
            }
        }

        // 尝试获取任务ID
        if (data.task_id && !currentTaskId) {
            currentTaskId = data.task_id;
        }
        const workflowRunId = data.workflow_run_id; // Store workflow run ID if present

        // Assign to existing contentElement, do not redeclare
        contentElement = messageElement ? messageElement.querySelector('.message-content') : null; 
        if (!contentElement) {
             console.warn("Message element content area not found for UI update."); // Keep important warning
             // Attempt to find the last assistant message if messageElement is null
             const messages = chatMessages.querySelectorAll('.message.assistant');
             if (messages.length > 0) {
                 messageElement = messages[messages.length - 1];
                 contentElement = messageElement.querySelector('.message-content');
             }
             if (!contentElement) {
                 console.error("Could not find a suitable message element to update."); // Keep critical error
                 return; // Cannot update UI
             }
        }


        // --- Event-based Handling ---
        switch (data.event) {
            case 'workflow_started':
            case 'node_started':
            case 'node_finished':
            case 'workflow_finished':
                // User requested not to show workflow details, so we do nothing here.
                // console.log('Ignoring workflow event:', data.event, data.data ? data.data.title : '');
                break; // Simply ignore these events for UI updates

            case 'message':
                 if (!messageElement) {
                    // console.warn(`'message' event received but messageElement is missing.`); // Comment out
                    // Attempt to find the last assistant message if messageElement is null
                    const messages = chatMessages.querySelectorAll('.message.assistant');
                    if (messages.length > 0) {
                        messageElement = messages[messages.length - 1];
                    }
                    if (!messageElement) {
                       console.error("Cannot append message chunk: message element not found."); // Keep critical error
                       break;
                    }
                 }
                 // Assign to the existing contentElement, do not redeclare with let
                 contentElement = messageElement.querySelector('.message-content'); 
                 if (!contentElement) {
                     console.error("Could not find message content element for UI update."); // Keep critical error
                     break; // Cannot update UI
                 }

                 let chunk = data.answer !== undefined ? data.answer : null;
                 if (chunk !== null) {
                    accumulatedRawMessage += chunk;
                    // console.log('[DEBUG RenderFlow] Raw Accumulated:', JSON.stringify(accumulatedRawMessage)); // Log raw accumulated - Comment out

                    // --- Clean the CURRENT accumulated message using String methods (NO REGEX) ---
                    let cleanedAccumulatedMessage = accumulatedRawMessage;
                    const thinkStartIdx = cleanedAccumulatedMessage.indexOf('<think>');
                    const thinkEndIdx = cleanedAccumulatedMessage.indexOf('</think>');

                    if (thinkStartIdx !== -1 && thinkEndIdx !== -1 && thinkEndIdx > thinkStartIdx) {
                        // Found a complete <think>...</think> block
                        const beforeThink = cleanedAccumulatedMessage.substring(0, thinkStartIdx);
                        const afterThink = cleanedAccumulatedMessage.substring(thinkEndIdx + '</think>'.length);
                        cleanedAccumulatedMessage = (beforeThink + afterThink).trim();
                        // console.log('[DEBUG RenderFlow StringClean] Removed complete block.'); // Comment out
                    } else if (thinkStartIdx !== -1) {
                        // Found the start tag, but not the end tag (or end is before start)
                        // Treat as if the thinking block is still ongoing, effectively empty content for now
                        const beforeThink = cleanedAccumulatedMessage.substring(0, thinkStartIdx);
                        cleanedAccumulatedMessage = beforeThink.trim(); // Keep only content before <think>
                         // console.log('[DEBUG RenderFlow StringClean] Found start, cleaning to empty (or prefix).'); // Comment out
                    } else {
                        // No <think> tag found, message is likely clean already (or only has end tag, which is weird but we ignore)
                        cleanedAccumulatedMessage = cleanedAccumulatedMessage.trim();
                         // console.log('[DEBUG RenderFlow StringClean] No start tag found, assuming clean.'); // Comment out
                    }
                    // --- End String method cleaning ---
                    
                    // console.log('[DEBUG RenderFlow] Cleaned Accumulated (String Method):', JSON.stringify(cleanedAccumulatedMessage)); // Log cleaned - Comment out

                    // --- Get the PREVIOUSLY rendered cleaned message (or empty if first render) ---
                    const previouslyRenderedCleanedText = contentElement.dataset.renderedText || "";
                    // console.log('[DEBUG RenderFlow] Previously Rendered:', JSON.stringify(previouslyRenderedCleanedText)); // Log previously rendered - Comment out

                    // --- Decide whether to render ---
                    const shouldRender = cleanedAccumulatedMessage.length > 0 && cleanedAccumulatedMessage !== previouslyRenderedCleanedText;
                    // console.log('[DEBUG RenderFlow] Should Render Condition Result:', shouldRender); // Log condition result - Comment out

                    if (shouldRender) {
                        // FINAL SAFETY CHECK: Log if <think> is still present somehow
                        if (cleanedAccumulatedMessage.startsWith('<think>')) {
                            console.error('[DEBUG RenderFlow ERROR] Trying to render content starting with <think> despite cleaning! Text:', JSON.stringify(cleanedAccumulatedMessage)); // Keep potentially useful error
                        }
                        // We have new, non-empty cleaned content to render
                        // console.log('[DEBUG RenderFlow] >>> Rendering new content:', JSON.stringify(cleanedAccumulatedMessage)); // Log entering render block - Comment out
                        renderMessageContent(contentElement, cleanedAccumulatedMessage);
                        contentElement.dataset.renderedText = cleanedAccumulatedMessage; // Store what we just rendered
                        scrollToBottom();
                        // Indicator removal is handled within renderMessageContent
                    } else if (cleanedAccumulatedMessage.length === 0) {
                        // Cleaned message is empty (still in thinking block or just started)
                        // console.log('[DEBUG RenderFlow] --- Cleaned message is empty, ensuring indicator.'); // Log entering empty block - Comment out
                        // Ensure the indicator is shown if it's not already there.
                        if (!contentElement.querySelector('.typing-indicator-inline')) { // Check correct class
                             // console.log('[DEBUG RenderFlow] --- Indicator not found, showing it.'); // Comment out
                             showTypingIndicator(); // Call showTypingIndicator which replaces content
                        } else {
                             // console.log('[DEBUG RenderFlow] --- Indicator already present.'); // Comment out
                        }
                    } else {
                        // Cleaned message is not empty, but it's the same as what's already rendered. Do nothing.
                        // console.log('[DEBUG RenderFlow] === Cleaned message is same as rendered, doing nothing.'); // Log entering no-op block - Comment out
                    }
                 } else {
                     console.warn("Message event received without 'answer' field:", data); // Keep important warning
                 }
                 break;

            case 'message_end':
                 // --- Ensure contentElement is valid before using --- 
                 if (!contentElement || !messageElement) {
                     // Attempt to find the last assistant message if not already set
                     const messages = chatMessages.querySelectorAll('.message.assistant');
                     if (messages.length > 0) {
                         messageElement = messages[messages.length - 1];
                         // Assign to existing contentElement, do not redeclare
                         contentElement = messageElement.querySelector('.message-content'); 
                     }
                 }
                 // --- End element validation ---

                 // Ensure final render with potentially cleaned message
                 if (contentElement) {
                    // --- Clean the final accumulated message (Use Global Regex) --- 
                    const detailsThinkingRegexGlobal = /<details[\s\S]*?>\s*<summary[\s\S]*?>[\s\S]*?Thinking\.*[\s\S]*?<\/summary>[\s\S]*?<\/details>/gi;
                    const simpleThinkRegexGlobal = /<think>[\s\S]*?<\/think>/gi;
                    let finalCleanedMessage = accumulatedRawMessage.replace(detailsThinkingRegexGlobal, '').trim();
                    finalCleanedMessage = finalCleanedMessage.replace(simpleThinkRegexGlobal, '').trim();
                    // --- End cleaning --- 
                    renderMessageContent(contentElement, finalCleanedMessage);
                 }

                finishStreaming(); // Call finishStreaming when message_end is received (will NOT remove indicator now)

                // Auto-rename if needed, using the USER'S first message
                if (shouldAutoRename && activeConversationId && firstUserMessageContent) { // Check firstUserMessageContent exists
                    // Use user's first message for title guess
                    let titleGuess = firstUserMessageContent;
                    // Limit length
                    titleGuess = titleGuess.length > 30 ? titleGuess.substring(0, 30) + '...' : titleGuess;
                    if (titleGuess) { // Only rename if we have a title guess
                       renameConversation(activeConversationId, titleGuess, true);
                    }
                    shouldAutoRename = false; // Prevent renaming again for this session
                    isFirstMessage = false; // Mark as no longer the first message interaction
                    firstUserMessageContent = null; // Clear the stored message
                 }
                break;
            
            case 'tts_message':
                // Placeholder for TTS handling
                 // console.log("Received TTS message chunk:", data.audio ? data.audio.length : 0, "bytes"); // Comment out
                 break;
            
            case 'tts_message_end':
                 // Placeholder for TTS handling
                 // console.log("Received TTS message end."); // Comment out
                 break;

            // Handle conversation_created explicitly if not handled at the top
            case 'conversation_created':
                 // ID handling is already done at the top
                 // console.log("Conversation created event processed (ID handled earlier)."); // Comment out
                 break;

            default:
                // Fallback for unknown events or data without an 'event' field
                console.warn("Received unknown SSE event type or data format:", data); // Keep important warning
                // Attempt to render if possible, respecting details block state
                let fallbackContent = null;
                if (data.answer !== undefined) fallbackContent = data.answer;
                else if (data.text !== undefined) fallbackContent = data.text; // eslint-disable-line sonarjs/no-collapsible-if
                else if (data.content !== undefined) fallbackContent = data.content; // eslint-disable-line sonarjs/no-collapsible-if
                else if (data.message !== undefined) fallbackContent = data.message; // eslint-disable-line sonarjs/no-collapsible-if
                else if (typeof data === 'string') fallbackContent = data; // eslint-disable-line sonarjs/no-collapsible-if // Simple string response

                if (fallbackContent !== null && contentElement) {
                    accumulatedRawMessage += fallbackContent;
                    // Attempt to render using the same state logic
                    let fallbackSubstring = accumulatedRawMessage.substring(detailsBlockEndIndex).trim();
                    // Render only if details are parsed AND resulting message is not empty
                    if (detailsBlockParsed && fallbackSubstring.length > 0) {
                        // Flag indicator removal
                        // if (!indicatorRemoved) {
                        //    indicatorRemoved = true;
                        // }
                        renderMessageContent(contentElement, fallbackSubstring);
                        scrollToBottom();
                    } else {
                        // console.log('[DEBUG Details Parsing] Fallback content received, waiting for details block resolution.'); // Comment out
                    }
                 }
        }
        // --- End Event-based Handling ---

        // Return value is less critical now state manages accumulation
        // return accumulatedRawMessage;
    }

    // Helper function to escape special characters for regex
    function escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&'); // $& means the whole matched string
    }

    // Basic HTML escaping
    function escapeHtml(unsafe) {
        return unsafe
             .replace(/&/g, "&amp;")
             .replace(/</g, "&lt;")
             .replace(/>/g, "&gt;")
             .replace(/"/g, "&quot;")
             .replace(/'/g, "&#039;");
     }

    // 渲染消息内容的辅助函数 (策略：占位符 -> Markdown -> Highlight -> KaTeX)
    function renderMessageContent(contentElement, messageText) {
        // console.log('[DEBUG Render Start] Raw messageText:', JSON.stringify(messageText)); // Comment out
        let currentText = messageText.trim();

        const typingIndicator = contentElement.querySelector('.typing-indicator-inline');
        if (typingIndicator) typingIndicator.remove();

        if (currentText.length === 0) {
            contentElement.style.display = 'none';
            return;
        } else {
            contentElement.style.display = '';
        }

        const katexSources = {};
        let placeholderIdCounter = 0;
        const placeholderPrefix = "katex-placeholder-";

        // 1. 查找并替换 KaTeX 公式为占位符
        // IMPORTANT: Replacement order matters. Replace longer delimiters first (e.g., ```math, $$, \\[, before $, \\()

        // 1a. Replace Block Math (```math ... ```)
        currentText = currentText.replace(/```math\\n([\\s\\S]*?)\\n```/g, (match, latexSource) => {
            const id = placeholderPrefix + 'block-' + placeholderIdCounter++;
            katexSources[id] = latexSource.trim(); // Store trimmed LaTeX
            // console.log(`[DEBUG Placeholder] Found block math. ID: ${id}, Source: ${JSON.stringify(latexSource)}`); // Comment out
            // Use a div for block placeholders
            return `<div class="katex-placeholder-block" data-katex-id="${id}"></div>`;
        });

        // 1b. Replace standalone \\boxed{...} commands (Treat as display math) - MOVED HERE
        const boxedRegex = /\\boxed\\{([\\s\\S]+?)\\}/g;
        const boxedPlaceholderName = 'boxed_implicit';
        currentText = currentText.replace(boxedRegex, (match) => {
            const id = placeholderPrefix + 'display-' + boxedPlaceholderName + '-' + placeholderIdCounter++;
            // Store the *full* match for KaTeX, including \\boxed
            katexSources[id] = match;
            // console.log(`[DEBUG Placeholder] Found standalone \\boxed. ID: ${id}, Source: ${JSON.stringify(match)}`); // Comment out
            // Use display mode placeholder (using span for now, could change to div if needed)
            return `<span class="katex-placeholder-inline" data-katex-id="${id}" data-display-mode="true"></span>`;
        });

        // 1c. Replace Block Math ($$...$$ and \\\\[...\\\\]) - Now 1c
        const blockDelimiters = [
            { regex: /\\$\\$([\\s\\S]+?)\\$\\$/g, name: 'dollar' },
            // Using new RegExp() constructor for bracket regex
            (() => { // Use IIFE to contain try-catch and return the object
                const patternString = '\\\\\\[([\\s\\S]+?)\\\\\\]'
                const flags = 'g'
                // console.log(`[DEBUG RegExp] Attempting to create RegExp for bracket: new RegExp(\\\'\${patternString}\\\', \\\'\${flags}\\\')`); // Comment out
                try {
                    return { regex: new RegExp(patternString, flags), name: 'bracket' };
                } catch (e) {
                    console.error(`[DEBUG RegExp Error] Failed to create RegExp for bracket. Pattern: \"\${patternString}\\\", Flags: \"\${flags}\\\"`, e); // Keep error
                    // Return a non-matching regex or null as fallback to avoid breaking the loop
                    return { regex: /NEVER_MATCH_ANYTHING/, name: 'bracket_error' };
                }
            })() // Immediately invoke the function expression
        ];
        blockDelimiters.forEach(delimiter => {
            // Ensure regex exists before using it
            if (delimiter.regex && typeof delimiter.regex.test === 'function') { // Check if regex is valid
               currentText = currentText.replace(delimiter.regex, (match, latexSource) => {
                    const id = placeholderPrefix + 'display-' + delimiter.name + '-' + placeholderIdCounter++;
                    katexSources[id] = latexSource.trim();
                    // console.log(`[DEBUG Placeholder] Found display math (${delimiter.name}). ID: ${id}, Source: ${JSON.stringify(latexSource)}`); // Comment out
                    return `<span class="katex-placeholder-inline" data-katex-id="${id}" data-display-mode="true"></span>`;
                });
            } else {
                 console.warn(`[DEBUG Placeholder] Skipping delimiter due to regex error: ${delimiter.name}`); // Keep warning
            }
        });

        // 1d. Replace Inline Math ($...$ and \\(...\\)) - Now 1d
        const inlineDelimiters = [
             // Regex for $...$: Matches $ followed by non-$ characters, or escaped $, until the next unescaped $
            { regex: /\$((?:\\.|[^\$\\])+?)\$/g, name: 'dollar' },
            // Regex for \(...\): Matches \( followed by any characters until \)
            { regex: /\\\(([\s\S]+?)\\\)/g, name: 'paren' }
        ];
        inlineDelimiters.forEach(delimiter => {
            // Ensure regex is valid before using it
            if (delimiter.regex && typeof delimiter.regex.test === 'function') {
                currentText = currentText.replace(delimiter.regex, (match, latexSource) => {
                    const id = placeholderPrefix + 'inline-' + delimiter.name + '-' + placeholderIdCounter++;
                    katexSources[id] = latexSource.trim();
                    // console.log(`[DEBUG Placeholder] Found inline math (${delimiter.name}). ID: ${id}, Source: ${JSON.stringify(latexSource)}`); // Comment out
                    return `<span class="katex-placeholder-inline" data-katex-id="${id}" data-display-mode="false"></span>`;
                });
            } else {
                 console.warn(`[DEBUG Placeholder] Skipping inline delimiter due to regex error: ${delimiter.name}`); // Keep warning
            }
        });

        // --- Removed the old \\boxed block from here ---

        // console.log('[DEBUG Placeholder] Text after placeholder replacement:', JSON.stringify(currentText)); // Comment out

        // 2. Markdown Processing (Handles text with placeholders)
        let finalHtml;
        if (typeof marked !== 'undefined') {
            // console.log('[DEBUG Markdown Process] Applying marked.parse to text with placeholders...'); // Comment out
            // Enable the 'breaks' option to treat single newlines as <br>
            finalHtml = marked.parse(currentText, { breaks: true, gfm: true }); // Added breaks: true and gfm: true
            // console.log('[DEBUG Markdown Process] Marked result:', JSON.stringify(finalHtml)); // Comment out
        } else {
            console.warn('[DEBUG Markdown Process] marked object not found. Falling back to basic rendering.'); // Keep warning
            finalHtml = currentText.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
            // Placeholders might still need manual fixing in fallback?
        }

        // 3. Set Initial HTML (Generated by Marked with placeholders intact)
        contentElement.innerHTML = finalHtml;
        // console.log('[DEBUG Content Set] HTML after Marked (with placeholders) set.'); // Comment out

        // 4. Apply Syntax Highlighting (Highlight.js) - Should ignore placeholders and math blocks
        if (typeof hljs !== 'undefined') {
            // console.log('[DEBUG HighlightJS] Applying highlightElement...'); // Comment out
            contentElement.querySelectorAll('pre code').forEach((block) => {
                // Check if the block itself IS a placeholder or contains one (unlikely for pre code, but safe)
                if (block.hasAttribute('data-katex-id') || block.querySelector('[data-katex-id]')) {
                    // console.log('[DEBUG HighlightJS] Skipping block containing KaTeX placeholder.'); // Comment out
                } else if (block.classList.contains('language-math')) { // <--- 添加这个检查
                    // console.log('[DEBUG HighlightJS] Skipping math block for highlight.js.'); // <--- 添加日志 - Comment out
                } else {
                    // Only highlight if it's not a placeholder and not a math block
                    try {
                        hljs.highlightElement(block);
                        // console.log('[DEBUG HighlightJS] Highlighted code block:', block); // Comment out
                    } catch (e) {
                        console.error('[DEBUG HighlightJS] Highlight.js error:', e); // Keep error
                    }
                }
            });
             // console.log('[DEBUG HighlightJS] Highlight.js processing finished.'); // Comment out
        } else {
            console.warn('[DEBUG HighlightJS] hljs object not found. Skipping highlighting.'); // Keep warning
        }

        // 5. Render KaTeX from Placeholders
        if (typeof katex !== 'undefined') {
            // console.log('[DEBUG KaTeX Render] Rendering KaTeX from placeholders...'); // Comment out
            contentElement.querySelectorAll('[data-katex-id]').forEach((element) => {
                const id = element.getAttribute('data-katex-id');
                const latexSource = katexSources[id];
                const isDisplay = element.getAttribute('data-display-mode') === 'true' || element.classList.contains('katex-placeholder-block');

                if (latexSource !== undefined) {
                    // --- ADD LOGGING ---
                    console.log(`[DEBUG KaTeX Render] Rendering ID: ${id}, Display: ${isDisplay}, Source: ${JSON.stringify(latexSource)}`);
                    // --- END LOGGING ---
                    try {
                        katex.render(latexSource, element, {
                            displayMode: isDisplay,
                            throwOnError: false, // Render error message instead of throwing
                            strict: false // Add this line to ignore warnings like unicodeTextInMathMode
                        });
                        // console.log(`[DEBUG KaTeX Render] Successfully rendered ID: ${id} into element:`, element); // Comment out
                        // Remove the placeholder attribute/class after rendering if desired
                        // element.removeAttribute('data-katex-id');
                        // element.classList.remove('katex-placeholder-inline', 'katex-placeholder-block');
                    } catch (e) {
                        console.error(`[DEBUG KaTeX Render] Error rendering ID ${id}, LaTeX: "${latexSource}"`, e);
                        element.textContent = `[KaTeX Error] ${e.message}`;
                        element.style.color = 'red';
                    }
                } else {
                     console.warn(`[DEBUG KaTeX Render] No source found for KaTeX placeholder ID: ${id}`); // Keep warning
                     element.textContent = `[KaTeX Error: Source not found for ID ${id}]`;
                     element.style.color = 'orange';
                }
            });
            // console.log('[DEBUG KaTeX Render] KaTeX rendering from placeholders finished.'); // Comment out
        } else {
            console.warn('[DEBUG KaTeX Render] katex object not found. Skipping KaTeX rendering from placeholders.'); // Keep warning
            // Optionally display a message in placeholders if KaTeX isn't loaded
            contentElement.querySelectorAll('[data-katex-id]').forEach(el => {
                el.textContent = '[KaTeX not loaded]';
                el.style.color = 'grey';
            });
        }

        // console.log('[DEBUG Render End] Function finished.'); // Comment out
    }

    // 处理 SSE 事件行数据 (解析 data: 行)
    function processEventData(line) { 
        // 忽略 event: 行 (信息在 data: 行中)
        if (line.startsWith('event: ')) {
            return; 
        }
        // 处理 data: 行
        if (line.startsWith('data: ')) {
            try {
                const jsonStr = line.substring(6).trim(); // 提取 JSON 字符串
                if (jsonStr) { 
                     const jsonData = JSON.parse(jsonStr); // 解析 JSON
                     processJsonData(jsonData); // 将解析后的数据传递给处理函数
                 }
            } catch (error) {
                console.error("解析 SSE data 行错误:", error, "行:", line); // Keep error
            }
        } 
        // 忽略其他类型的行 (例如注释行 :)
    }
    
    // 请求停止当前流式生成
    function stopStreaming() {
        if (currentTaskId) { // 必须有 Task ID 才能停止
            fetch(`/api/chat/stop/${currentTaskId}`, { // 发送停止请求
                method: 'POST',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken')
                }
            })
            .then(response => response.json())
            .then(data => {
                // console.log('停止流式传输', data); // Comment out
            })
            .catch(error => {
                console.error('停止流式传输错误:', error); // Keep error
            })
            .finally(() => {
                finishStreaming(); // 无论成功失败，都结束前端状态
            });
        } else {
            finishStreaming(); // 如果没有 Task ID，直接结束前端状态
        }
    }
    
    // 完成流式处理的清理工作
    function finishStreaming() {
        isStreaming = false; // 重置流状态
        currentTaskId = null; // 清除 Task ID
        indicatorRemoved = false; // 重置指示器移除标志，为下次流准备
        // let detailsBlockParsed = false; // 重置思考块解析状态
        // let detailsBlockEndIndex = 0;
        accumulatedRawMessage = '';
        messageElement = null; // 清除对当前助手消息元素的引用
        
        // 恢复发送按钮状态
        updateSendButtonIcon(false); 
        // 根据输入框是否为空决定是否禁用发送按钮
        sendButton.disabled = (chatInput.value.trim() === '');
    }
    
    // 显示行内打字指示器 (在助手消息气泡内)
    function showTypingIndicator() {
        if (!messageElement) { // 必须先有消息元素
            console.warn("无法显示打字指示器：messageElement 为空。"); // Keep warning
            return;
        }
        const contentElement = messageElement.querySelector('.message-content');
        if (contentElement) {
            // 设置指示器 HTML 为内容
            contentElement.innerHTML = '<div class="typing-indicator-inline"><span></span><span></span><span></span></div>';
            scrollToBottom();
            // console.log('[DEBUG Indicator] Inline typing indicator shown.'); // Comment out
        } else {
            console.warn("无法显示打字指示器：在 messageElement 中未找到 .message-content。"); // Keep warning
        }
    }
    
    // 移除加载指示器 (现在主要管理标志位，实际 DOM 操作在 renderMessageContent)
    function removeTypingIndicator() {
        if (!indicatorRemoved) { // 如果标志位还是 false
           // console.log('[DEBUG Indicator] 标记指示器待移除。'); // Comment out
           indicatorRemoved = true; // 设置标志位为 true
        }
    }
    
    // 添加消息到 UI (通用函数)
    function addMessage(role, content) {
        const messageElement = createMessageElement(role, content); // 创建消息元素
        chatMessages.appendChild(messageElement); // 添加到消息列表
        scrollToBottom(); // 滚动到底部
    }
    
    // 创建单个消息的 DOM 元素
    function createMessageElement(role, content) {
        const messageWrapper = document.createElement('div');
        messageWrapper.className = 'message-wrapper'; // Add a wrapper for message + actions
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${role}`; // 根据角色添加 class
        
        // 创建头像元素
        const avatar = document.createElement('div');
        avatar.className = 'avatar';
        avatar.innerHTML = (role === 'user') ? '<i class="fas fa-user"></i>' : '<i class="fas fa-robot"></i>';
        
        // 创建消息内容元素
        const messageContent = document.createElement('div');
        messageContent.className = 'message-content';
        
        // --- 处理消息内容显示 --- 
        if (role === 'assistant') {
            // 对于助手消息，内容直接传入 (可能为空字符串，由 renderMessageContent 更新)
             messageContent.innerHTML = content; // 初始为空，由 render 处理
        } else { // 用户消息
            // 转义特殊字符并处理换行
            let escapedContent = content
                .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') // 基本 HTML 转义
                .replace(/event:/g, 'event&#58;') // 防止被解析为 SSE 命令
                .replace(/data:/g, 'data&#58;')
                .replace(/\n/g, '<br>'); // 转换换行为 <br>
            messageContent.innerHTML = escapedContent;
        }
        
        // 创建消息时间元素
        const messageTime = document.createElement('div');
        messageTime.className = 'message-time';
        const now = new Date();
        const locale = window.i18next && window.i18next.language === 'zh' ? 'zh-CN' : 'en-US'; // 根据当前语言设置 locale
        const timeString = now.toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' }); 
        messageTime.textContent = timeString;
        
        // 组装消息元素
        messageDiv.appendChild(avatar);
        messageDiv.appendChild(messageContent);
        messageDiv.appendChild(messageTime);

        // --- 创建并添加消息操作按钮 --- 
        const messageActions = document.createElement('div');
        messageActions.className = 'message-actions';
        // 添加复制按钮
        const copyButton = document.createElement('button');
        copyButton.className = 'copy-message-btn';
        copyButton.innerHTML = '<i class="far fa-copy"></i>';
        copyButton.title = window.t ? window.t('chat:copy-message') : 'Copy message'; // 添加 title 属性
        messageActions.appendChild(copyButton);
        // 可以根据需要添加其他按钮，例如删除、编辑等
        // const deleteButton = document.createElement('button'); ...

        // --- 将消息和操作按钮放入包装器 --- 
        messageWrapper.appendChild(messageDiv);
        messageWrapper.appendChild(messageActions);
        
        return messageWrapper; // 返回包装器
    }
    
    // 清空消息区域并显示欢迎消息
    function clearMessages() {
        chatMessages.innerHTML = ''; // 清空
        // 添加欢迎信息
        const welcomeDiv = document.createElement('div');
        // ... 设置欢迎信息内容和样式 ...
        chatMessages.appendChild(welcomeDiv);
    }
    
    // 更新主聊天区域顶部的标题
    function updateChatTitle(title) {
        document.querySelector('.chat-title').textContent = title;
    }
    
    // 滚动消息区域到底部
    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // 从 cookie 中获取 CSRF Token
    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
    
    // 新增：添加状态消息到 UI
    function addStatusMessage(text) {
        const statusDiv = document.createElement('div');
        statusDiv.className = 'message status-message'; // 使用特定类名
        statusDiv.textContent = text;
        chatMessages.appendChild(statusDiv);
        scrollToBottom();
    }

    // 请求删除指定 ID 的会话 (重命名并添加基础实现)
    function deleteConversationRequest(conversationId) {
        const csrftoken = getCookie('csrftoken');
        // console.log(`Attempting to delete conversation: ${conversationId}`); // Log attempt
        fetch(`/api/chat/conversation/${conversationId}/delete/`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrftoken,
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            // console.log(`Delete response status for ${conversationId}: ${response.status}`); // Log status - Comment out
            if (response.ok) {
                // 从列表中移除对话项
                const itemToRemove = conversationsList.querySelector(`.conversation-item[data-id="${conversationId}"]`);
                if (itemToRemove) {
                    itemToRemove.remove();
                    // console.log(`Removed conversation item ${conversationId} from list.`); // Log removal - Comment out
                } else {
                    console.warn(`Conversation item ${conversationId} not found in the list for removal.`); // Keep warning
                }

                // 检查当前活动对话是否是被删除的对话
                if (activeConversationId === conversationId) {
                    // console.log('Active conversation was deleted. Redirecting to /chat/'); // Log redirect - Comment out
                    // 如果是，跳转到新的聊天页面 (根目录)
                    window.location.href = '/chat/';
                } else {
                     // console.log('Deleted conversation was not the active one.'); // Log if not active - Comment out
                     // 如果不是，可以显示一个成功的提示信息
                     showToast(window.t ? window.t('chat:conversation-deleted-success') : 'Conversation deleted successfully.', 'success');
                }
            } else {
                 console.error('Failed to delete conversation:', response.statusText); // Log error - Keep error
                 response.json().then(data => {
                     console.error('Error details:', data); // Keep error details
                     showToast(window.t ? window.t('chat:error-deleting-conversation', { error: data.error || response.statusText }) : `Error deleting conversation: ${data.error || response.statusText}`, 'error');
                 }).catch(() => {
                    showToast(window.t ? window.t('chat:error-deleting-conversation-generic') : 'Error deleting conversation.', 'error');
                 });
            }
        })
        .catch(error => {
            console.error('Network error during delete request:', error); // Log network error - Keep error
            showToast(window.t ? window.t('chat:error-deleting-conversation-network') : 'Network error while deleting conversation.', 'error');
        });
    }
    
    // 修改 showConfirmDialog 以处理焦点管理
    function showConfirmDialog(titleKey, messageKey, confirmCallback, triggerElement = document.activeElement) {
        const confirmDialog = document.getElementById('confirmDialog');
        if (!confirmDialog) {
            console.error('Confirm dialog element not found!'); // Keep critical error
            return;
        }
        const modalInstance = bootstrap.Modal.getOrCreateInstance(confirmDialog);

        const confirmTitle = confirmDialog.querySelector('#confirmDialogTitle');
        const confirmMessage = confirmDialog.querySelector('#confirmDialogMessage');
        const confirmBtn = confirmDialog.querySelector('#confirmDialogConfirm');
        const cancelBtn = confirmDialog.querySelector('#confirmDialogCancel');
        const closeBtn = confirmDialog.querySelector('.btn-close');

        // 翻译内容
        if (typeof window.t === 'function') {
            confirmTitle.textContent = window.t(titleKey || 'chat:confirm-title');
            confirmMessage.textContent = window.t(messageKey || 'chat:confirm-message-default');
            confirmBtn.textContent = window.t('common:actions_confirm');
            cancelBtn.textContent = window.t('common:actions_cancel');
            closeBtn.setAttribute('aria-label', window.t('common:close'));
        } else {
             console.warn('i18next `t` function not ready for confirm dialog'); // Keep warning
             confirmTitle.textContent = 'Confirm Action';
             confirmMessage.textContent = 'Are you sure?';
             confirmBtn.textContent = 'Confirm';
             cancelBtn.textContent = 'Cancel';
             closeBtn.setAttribute('aria-label', 'Close');
        }

        // --- 存储模态框打开前拥有焦点的元素 ---
        const elementToFocusOnHide = triggerElement instanceof HTMLElement ? triggerElement : document.body;

        // --- 隐藏时的焦点管理 (移至 hidden.bs.modal 事件) ---
        const handleModalHide = () => {
            // console.log('[Focus Management] Modal hidden. Returning focus to:', elementToFocusOnHide); // Comment out
            if (elementToFocusOnHide && elementToFocusOnHide.isConnected && typeof elementToFocusOnHide.focus === 'function' && elementToFocusOnHide.offsetParent !== null) {
                 try {
                    elementToFocusOnHide.focus({ preventScroll: true }); // 添加 preventScroll 选项以避免不必要的滚动
                 } catch (e) {
                     console.error('[Focus Management] Error focusing original element:', e); // Keep error
                     // Fallback if focusing original element fails
                     const fallbackList = document.getElementById('conversationsList');
                     const fallbackButton = document.getElementById('newChatBtn');
                     if (fallbackList) {
                        // Make the list focusable if it isn't already
                         if (fallbackList.getAttribute('tabindex') === null) {
                             fallbackList.setAttribute('tabindex', '-1'); // Allow programmatic focus
                             fallbackList.style.outline = 'none'; // Hide focus ring if desired
                         }
                         try { fallbackList.focus({ preventScroll: true }); } catch (fe) { document.body.focus(); }
                     } else if (fallbackButton) {
                         try { fallbackButton.focus({ preventScroll: true }); } catch (fe) { document.body.focus(); }
                     } else {
                         document.body.focus(); // Final fallback
                     }
                 }
            } else {
                 console.warn('[Focus Management] Element to focus is no longer valid or visible. Trying fallbacks.'); // Keep warning
                 // Fallback if original element is invalid/invisible
                 const fallbackList = document.getElementById('conversationsList');
                 const fallbackButton = document.getElementById('newChatBtn');
                 if (fallbackList) {
                     // Make the list focusable if it isn't already
                     if (fallbackList.getAttribute('tabindex') === null) {
                         fallbackList.setAttribute('tabindex', '-1'); // Allow programmatic focus
                         fallbackList.style.outline = 'none'; // Hide focus ring if desired
                     }
                      try { fallbackList.focus({ preventScroll: true }); } catch (fe) { document.body.focus(); }
                 } else if (fallbackButton) {
                      try { fallbackButton.focus({ preventScroll: true }); } catch (fe) { document.body.focus(); }
                 } else {
                     document.body.focus(); // Final fallback
                 }
            }
             // 清理事件监听器 (虽然 once: true 会自动移除，但显式移除更安全)
             confirmDialog.removeEventListener('hidden.bs.modal', handleModalHide);
        };

        // --- 移除旧的 hidden.bs.modal 监听器 (以防万一) ---
        confirmDialog.removeEventListener('hidden.bs.modal', handleModalHide);
        // --- 为 hidden.bs.modal 事件添加监听器 (只执行一次) ---
        confirmDialog.addEventListener('hidden.bs.modal', handleModalHide, { once: true });


        // 定义处理函数
        const confirmHandler = () => {
           
            confirmCallback();
            modalInstance.hide();
        };
        const cancelHandler = () => {

            modalInstance.hide();
        };

        // --- 事件监听器管理 (简化: 克隆并替换以移除旧监听器) ---
        const newConfirmBtn = confirmBtn.cloneNode(true);
        confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);

        const newCancelBtn = cancelBtn.cloneNode(true);
        cancelBtn.parentNode.replaceChild(newCancelBtn, cancelBtn);

        const newCloseBtn = closeBtn.cloneNode(true);
        closeBtn.parentNode.replaceChild(newCloseBtn, closeBtn);

        // 添加新监听器到克隆后的按钮
        newConfirmBtn.addEventListener('click', confirmHandler);
        newCancelBtn.addEventListener('click', cancelHandler);
        newCloseBtn.addEventListener('click', cancelHandler); // 关闭按钮通常行为类似取消

        modalInstance.show();
    }

    function showToast(message, type = 'info', duration = 3000) {
        const toastContainer = document.body;
        const toastElement = document.createElement('div');
        // 修正 type 映射，确保是有效的 Bootstrap 背景色类
        const bgClass = type === 'error' ? 'bg-danger' : (type === 'success' ? 'bg-success' : (type === 'warning' ? 'bg-warning' : 'bg-info'));
        toastElement.className = `toast align-items-center text-white ${bgClass} border-0 show`;
        toastElement.style.position = 'fixed';
        toastElement.style.top = '20px';
        toastElement.style.right = '20px';
        toastElement.style.zIndex = '1090';
        toastElement.setAttribute('role', 'alert');
        toastElement.setAttribute('aria-live', 'assertive');
        toastElement.setAttribute('aria-atomic', 'true');

        // 修正模板字面量结束符，并确保 message 被正确插入
        toastElement.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `; // 确保反引号正确闭合

        toastContainer.appendChild(toastElement);

        const bsToast = bootstrap.Toast.getOrCreateInstance(toastElement);

        // Auto-hide
        const hideTimeout = setTimeout(() => {
            bsToast.hide();
        }, duration);

        // Remove element after hiding animation
        toastElement.addEventListener('hidden.bs.toast', () => {
            toastElement.remove();
            clearTimeout(hideTimeout); // 清除定时器以防万一
        }, { once: true });

         // Allow manual close
         const closeButton = toastElement.querySelector('.btn-close');
         closeButton.addEventListener('click', () => {
              bsToast.hide();
              // hidden.bs.toast 事件会处理移除
              // toastElement.remove(); // 不在此处立即移除，让事件监听器处理
              clearTimeout(hideTimeout); // 清除自动隐藏定时器
         });
    }

    function bindDeleteButtons() {
        if (!conversationsList) return;

        conversationsList.addEventListener('click', function(event) {
            const deleteButton = event.target.closest('.delete-conversation');
            if (deleteButton) {
                event.stopPropagation();
                const conversationId = deleteButton.dataset.id;
                if (!conversationId) {
                    console.error('Delete button clicked but conversation ID not found.');
                    return;
                }
                // console.log(`Delete button clicked for conversation: ${conversationId}`); // Comment out

                // 调用 showConfirmDialog 并传递触发元素
                showConfirmDialog(
                    'chat:confirm-delete-title',
                    'chat:confirm-delete-message',
                    () => { deleteConversationRequest(conversationId); },
                    deleteButton // Pass the clicked button as the trigger element
                );
            }

            const renameButton = event.target.closest('.rename-conversation');
            if (renameButton) {
                 event.stopPropagation();
                 const conversationId = renameButton.dataset.id;
                 if (conversationId) {
                     showRenameDialog(conversationId);
                 } else {
                     console.error('Rename button clicked but conversation ID not found.');
                 }
            }
        });
    }

    function bindRenameEvents() {
        if (!renameDialog || !renameDialogConfirm || !renameDialogCancel || !newTitleInput) {
             console.warn('Rename dialog elements not found, skipping rename event binding.'); // Keep warning
             return;
        }
        let currentRenameId = null;

        window.showRenameDialog = function(conversationId) {
            currentRenameId = conversationId;
            const conversationItem = conversationsList.querySelector(`.conversation-item[data-id="${conversationId}"]`);
            const currentTitle = conversationItem ? conversationItem.querySelector('.conversation-title').textContent : '';
            newTitleInput.value = currentTitle;
            renameDialog.classList.add('show');
            setTimeout(() => newTitleInput.focus(), 50);
        };

        function hideRenameDialog() {
            renameDialog.classList.remove('show');
            newTitleInput.value = '';
            currentRenameId = null;
        }

        renameDialogConfirm.addEventListener('click', () => {
            const newTitle = newTitleInput.value.trim();
            if (newTitle && currentRenameId) {
                 renameConversation(currentRenameId, newTitle);
            } else if (!newTitle) {
                showToast(window.t ? window.t('chat:error-empty-title') : 'Title cannot be empty.', 'warning');
            }
        });

        renameDialogCancel.addEventListener('click', hideRenameDialog);

        newTitleInput.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault();
                renameDialogConfirm.click();
            } else if (event.key === 'Escape') {
                hideRenameDialog();
            }
        });

         renameDialog.addEventListener('click', (event) => {
             if (event.target === renameDialog) {
                 hideRenameDialog();
             }
         });
    }

    function renameConversation(conversationId, newTitle, autoRename = false) {
        // 如果是自动重命名且未提供标题，尝试从 firstUserMessageContent 获取
        if (autoRename && !newTitle && firstUserMessageContent) {
             newTitle = firstUserMessageContent.length > 30 ? firstUserMessageContent.substring(0, 30) + '...' : firstUserMessageContent; // 调整长度限制为 30
        } else if (autoRename && !newTitle) {
             console.warn('Auto-rename failed: No first user message content available.'); // 添加日志 - Keep warning
             return; // 没有用户消息，无法自动重命名
        }

        if (!newTitle) {
            console.warn('Rename failed: Title is empty.'); // 添加日志 - Keep warning
            return; // 如果最终没有标题，不执行
        }

        // console.log(`Renaming conversation ${conversationId} to "${newTitle}" (Auto: ${autoRename})`); // 添加日志 - Comment out

        const csrftoken = getCookie('csrftoken'); // 获取 CSRF token

      
        // --- 添加：即使没有后端请求，也立即更新UI并关闭对话框（如果适用）---
        console.log('[DEBUG Rename Disabled] Backend request skipped. Updating UI directly.');
        // 1. 更新侧边栏列表项
        const conversationItem = conversationsList.querySelector(`.conversation-item[data-id="${conversationId}"] .conversation-title`);
        if (conversationItem) {
            conversationItem.textContent = newTitle;
        }
        // 2. 如果当前活动对话是被重命名的对话，更新主聊天区标题
        if (activeConversationId === conversationId) {
            updateChatTitle(newTitle);
        }
        // 3. 如果是通过对话框重命名的，关闭对话框
        if (!autoRename) {
            const renameDialogElem = document.getElementById('renameDialog');
            if (renameDialogElem && renameDialogElem.classList.contains('show')) {
                 renameDialogElem.classList.remove('show'); // 隐藏对话框
                 document.getElementById('newTitleInput').value = ''; // 清空输入框
            }
        }
        // 可以在这里添加一个不同的提示，表明仅在前端更新了标题
        // showToast('Title updated locally (backend request disabled).', 'info');
        // --- 结束添加的直接更新UI逻辑 ---
    }

    // 更新发送按钮图标 (发送图标 vs 停止图标)
    function updateSendButtonIcon(isStreaming) {
        const sendButtonIcon = sendButton.querySelector('i');
        if (sendButtonIcon) {
            // ... 根据 isStreaming 状态切换 class 和 title ...
             if (isStreaming) {
                 sendButtonIcon.classList.remove('fa-paper-plane');
                 sendButtonIcon.classList.add('fa-stop');
                 sendButton.title = window.t ? window.t('chat:stop-generation') : 'Stop generation'; // 国际化 Title
             } else {
                 sendButtonIcon.classList.remove('fa-stop');
                 sendButtonIcon.classList.add('fa-paper-plane');
                 sendButton.title = window.t ? window.t('chat:send-message') : 'Send message'; // 国际化 Title
             }
        } else {
            console.error('未找到发送按钮图标元素。');
        }
    }

    // 点击会话列表项进行导航 (使用事件委托)
    if (conversationsList) {
        conversationsList.addEventListener('click', function(event) {
            // console.log('[DEBUG Nav Click] Click detected on conversationsList. Target:', event.target);
            // 检查点击的是否是删除按钮或其内部元素
            const deleteButton = event.target.closest('.delete-conversation');
            const renameButton = event.target.closest('.rename-conversation'); // Also check for rename button
            
            // console.log('[DEBUG Nav Click] deleteButton found:', deleteButton);
            // console.log('[DEBUG Nav Click] renameButton found:', renameButton);

            if (deleteButton || renameButton) {
                // console.log('[DEBUG Nav Click] Click was on delete or rename button. Stopping navigation.');
                return; 
            }
            
            // 否则，查找被点击的会话项
            const conversationItem = event.target.closest('.conversation-item');
            // console.log('[DEBUG Nav Click] conversationItem found:', conversationItem);
            if (conversationItem) {
                const conversationId = conversationItem.dataset.id;
                if (conversationId) {
                    // console.log('[DEBUG Nav Click] Navigating to conversation:', conversationId);
                    window.location.href = '?conversation_id=' + conversationId;
                }
            }
        });
    }

    function handleChatMessageActions(event) {
        // console.log("[DEBUG] handleChatMessageActions triggered by click on:", event.target);
        const target = event.target;
        const copyButton = target.closest('.copy-message-btn');

        if (copyButton) {
            // console.log("[DEBUG] Copy button found:", copyButton);
            // With unified structure, always find the wrapper first
            const messageWrapper = copyButton.closest('.message-wrapper');
            if (!messageWrapper) {
                console.error('[DEBUG] Could not find parent .message-wrapper for copy button.');
                return;
            }
            // console.log("[DEBUG] Message wrapper found:", messageWrapper);

            // Find the message content within the wrapper
            const messageContentElement = messageWrapper.querySelector('.message-content');
            // console.log("[DEBUG] Attempting to find message content element inside wrapper:", messageContentElement);
            if (messageContentElement) {
                const textToCopy = messageContentElement.innerText;
                // console.log("[DEBUG] Text to copy:", textToCopy);
                if (typeof copyToClipboard === 'function') {
                    // console.log("[DEBUG] Calling copyToClipboard function...");
                    copyToClipboard(textToCopy, copyButton);
                } else {
                    console.error("[DEBUG] copyToClipboard function is not defined!");
                }
            } else {
                console.error('[DEBUG] Could not find .message-content within the message wrapper:', messageWrapper);
            }
        } else {
            // console.log("[DEBUG] Click was not on a copy button or its child.");
        }
    }

    // --- Core Functions ---

    // Function to copy text to clipboard and provide feedback
    async function copyToClipboard(text, buttonElement) {
        try {
            await navigator.clipboard.writeText(text);
            // Provide feedback
            const originalIcon = buttonElement.innerHTML;
            buttonElement.innerHTML = '<i class="fas fa-check text-success"></i>'; // Change to checkmark
            buttonElement.disabled = true; // Disable briefly
            setTimeout(() => {
                buttonElement.innerHTML = originalIcon; // Restore original icon
                buttonElement.disabled = false; // Re-enable
            }, 1500); // Show feedback for 1.5 seconds
        } catch (err) {
            console.error('Failed to copy text: ', err); // Keep error
            alert(window.t('chat:copy-failed')); // Notify user of failure
        }
    }


    // Function to handle sending a message
    function handleSendMessage() {
        // ... existing code ...
    }

    // 新增：为聊天消息区域添加事件委托，处理复制按钮点击
    if (chatMessages) {
        chatMessages.addEventListener('click', handleChatMessageActions);
    }

    // --- Initial KaTeX Auto-Rendering for existing content ---
    if (typeof renderMathInElement === 'function') {
        // console.log('[DEBUG KaTeX AutoRender] Running initial render on document body...');
        renderMathInElement(document.body, {
            // Define the delimiters KaTeX should search for
            delimiters: [
                {left: "$$", right: "$$", display: true},
                {left: "$", right: "$", display: false},
                {left: "\\(", right: "\\)", display: false},
                {left: "\\[", right: "\\]", display: true},
                // Potentially add ```math if needed for initial load, but maybe not?
                // {left: "```math\\n", right: "\\n```", display: true, renderer: (latex) => katex.renderToString(latex.trim(), { displayMode: true, throwOnError: false })},
                // Boxed is usually inside other delimiters, maybe not needed here explicitly.
            ],
            // Useful options:
            throwOnError: false // Don't halt rendering on error
        });
        // console.log('[DEBUG KaTeX AutoRender] Initial render finished.');
    } else {
        console.warn('[DEBUG KaTeX AutoRender] renderMathInElement function not found. Skipping initial render.');
    }
    // --- End Initial KaTeX Auto-Rendering ---

    // --- New Function to Render Existing Messages on Load ---
    function renderExistingMessages() {
        console.log('[DEBUG Initial Render] Starting renderExistingMessages...');
        // Select only assistant message content divs that haven't been processed yet
        const existingAssistantMessages = document.querySelectorAll('.message.assistant .message-content:not([data-initial-rendered])');
        console.log(`[DEBUG Initial Render] Found ${existingAssistantMessages.length} assistant messages to render.`);

        existingAssistantMessages.forEach((contentElement, index) => {
            // Get the raw text content. linebreaksbr in template means we lost original newlines,
            // but textContent is usually better than trying to parse innerHTML with <br>.
            // renderMessageContent handles markdown line breaks etc.
            // let rawText = contentElement.textContent || '';
            // --- Switch to innerHTML and replace <br> tags --- 
            let rawHtml = contentElement.innerHTML || '';
            // Replace <br> tags (case-insensitive, potentially with spaces/slash) with newlines
            let rawText = rawHtml.replace(/<br\s*\/?\s*>/gi, '\n');
            // console.log(`[DEBUG Initial Render ${index}] Processing element. Raw text (from innerHTML replaced): ${JSON.stringify(rawText)}`);

            // Mark as processed to avoid re-rendering if called again
            contentElement.setAttribute('data-initial-rendered', 'true');

            if (rawText.trim().length > 0) {
                 // Always call renderMessageContent to handle markdown and KaTeX formatting.
                 // It internally checks for KaTeX delimiters and applies markdown.
                 // console.log(`[DEBUG Initial Render ${index}] Calling renderMessageContent.`);
                 try {
                     renderMessageContent(contentElement, rawText);
                     // console.log(`[DEBUG Initial Render ${index}] renderMessageContent finished.`);
                 } catch (e) {
                     console.error(`[DEBUG Initial Render ${index}] Error calling renderMessageContent for existing message:`, e);
                     // Optionally display an error message within the element
                     contentElement.innerHTML = `<span style="color: red;">[Error rendering content]</span> ${contentElement.innerHTML}`;
                 }
            } else {
                // console.log(`[DEBUG Initial Render ${index}] Element has no text content. Skipping.`);
                // Ensure empty elements are hidden if renderMessageContent logic requires it
                 contentElement.style.display = 'none';
            }
        });
        console.log('[DEBUG Initial Render] renderExistingMessages finished.');
    }

    // Call the function to render existing messages after the DOM is ready
    renderExistingMessages();
    // --- End Initial Rendering Logic ---

}); // End of DOMContentLoaded