// 等待文档加载完成
$(document).ready(function() {
    
    // 为导航栏添加滚动效果
    $(window).on('scroll', {passive: true}, function() {
        if ($(this).scrollTop() > 50) {
            $('.navbar').addClass('navbar-scrolled'); // 注意：i18next 可能尚未完成对 navbar 内元素的翻译
        } else {
            $('.navbar').removeClass('navbar-scrolled');
        }
    });
    
    // 为所有卡片添加动画效果
    $('.card').addClass('fade-in');
    
    // 平滑滚动到锚点
    $('a[href^="#"]').on('click', function(e) {
        e.preventDefault();
        
        const href = $(this).attr('href');
        // 只有当href不仅仅是#时才进行滚动
        if(href.length > 1) {
            $('html, body').animate({
                scrollTop: $(href).offset().top - 100
            }, 500, 'linear');
        }
    });
    
    // 回到顶部按钮
    $(window).on('scroll', {passive: true}, function() {
        if ($(this).scrollTop() > 300) {
            $('#backToTop').fadeIn();
        } else {
            $('#backToTop').fadeOut();
        }
    });
    
    // 点击回到顶部
    $('#backToTop').on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({scrollTop: 0}, 800);
    });
    
    // 禁用空链接的默认行为
    $('a[href="#"]').on('click', function(e) {
        e.preventDefault();
    });
    
    // 输入框焦点事件
    $('input, textarea').on('focus', {passive: true}, function() {
        $(this).removeClass('is-invalid');
    });
    
    // 添加返回上一页功能
    $('.btn-back').on('click', function(e) {
        e.preventDefault();
        window.history.back();
    });

});

// 对图片懒加载
document.addEventListener("DOMContentLoaded", function() {
    const lazyImages = [].slice.call(document.querySelectorAll("img.lazy"));

    if ("IntersectionObserver" in window) {
        let lazyImageObserver = new IntersectionObserver(function(entries, observer) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    let lazyImage = entry.target;
                    lazyImage.src = lazyImage.dataset.src;
                    lazyImage.classList.remove("lazy");
                    lazyImageObserver.unobserve(lazyImage);
                }
            });
        });

        lazyImages.forEach(function(lazyImage) {
            lazyImageObserver.observe(lazyImage);
        });
    } else {
        // 不支持 IntersectionObserver 的浏览器降级处理
        let active = false;

        const lazyLoad = function() {
            if (active === false) {
                active = true;

                setTimeout(function() {
                    lazyImages.forEach(function(lazyImage) {
                        if ((lazyImage.getBoundingClientRect().top <= window.innerHeight && lazyImage.getBoundingClientRect().bottom >= 0) && getComputedStyle(lazyImage).display !== "none") {
                            lazyImage.src = lazyImage.dataset.src;
                            lazyImage.classList.remove("lazy");

                            lazyImages = lazyImages.filter(function(image) {
                                return image !== lazyImage;
                            });

                            if (lazyImages.length === 0) {
                                document.removeEventListener("scroll", lazyLoad);
                                window.removeEventListener("resize", lazyLoad);
                                window.removeEventListener("orientationchange", lazyLoad);
                            }
                        }
                    });

                    active = false;
                }, 200);
            }
        };

        document.addEventListener("scroll", lazyLoad, { passive: true });
        window.addEventListener("resize", lazyLoad, { passive: true });
        window.addEventListener("orientationchange", lazyLoad, { passive: true });
    }
}); 

// Fix for Bootstrap modal focus accessibility warning
document.addEventListener('DOMContentLoaded', function() {
    const loginModalElement = document.getElementById('loginModal');
    const registerModalElement = document.getElementById('registerModal');
    const logoLink = document.querySelector('header .logo'); // Find the logo link

    const handleModalHidden = function() {
        // After modal is fully hidden, set focus to a known stable element
        if (logoLink) {
            logoLink.focus();
        }
    };

    if (loginModalElement) {
        loginModalElement.addEventListener('hidden.bs.modal', handleModalHidden);
    }

    if (registerModalElement) {
        registerModalElement.addEventListener('hidden.bs.modal', handleModalHidden);
    }
}); 