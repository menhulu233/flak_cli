document.addEventListener('DOMContentLoaded', () => {
  // --- Helper Function: Update Switcher Text & URL ---
  // Moved outside setupLanguageSwitcher to be accessible in .then()
  function updateSwitcherTextAndURL() {
      const switcher = document.getElementById('lang-toggle');
      if (!switcher || !i18next.isInitialized) return; // Check switcher and init state

      const currentLang = i18next.language;
      // console.log(` i18next: 更新切换器文本，当前语言: ${currentLang}`);
      const langText = currentLang === 'en' ? '中文' : 'English';
      switcher.textContent = langText;

      try {
          const url = new URL(window.location);
          if (url.searchParams.get('lang') !== currentLang) {
              // console.log(` i18next: 更新 URL lang 参数为 ${currentLang}`);
              url.searchParams.set('lang', currentLang);
              window.history.replaceState({ lang: currentLang }, '', url);
          }
      } catch(e) {
          console.error("Error updating URL:", e);
      }
  }
  // --- End Helper Function ---

  // +++ 新增: 定义 bindPageSpecificEvents 函数 +++
  /**
   * 绑定页面特定的事件监听器。
   * 这个函数在每次 updateContent 执行后被调用，
   * 以确保在 DOM 内容（例如，翻译文本）更新后，
   * 必要的事件监听器仍然有效或被重新附加。
   * @param {boolean} isUpdate - 指示这是否是内容更新后的调用 (来自 updateContent)。
   */
  function bindPageSpecificEvents(isUpdate = false) {
      // console.log(`i18next-init: ${isUpdate ? 'Re-binding' : 'Binding'} page specific events after content update...`);

      // 在这里添加需要在内容更新后重新绑定的事件
      // 例如：如果 auth_modals.js 中的事件绑定因为 updateContent 而失效，
      // 你可能需要在这里重新调用相关的绑定函数，或者重新绑定特定的监听器。
      // 示例：
      // if (typeof window.rebindAuthModalEvents === 'function') {
      //     window.rebindAuthModalEvents();
      // }

      // 检查 main.js 或 auth_modals.js 中的事件绑定是否需要在这里重新应用。
      // 如果 main.js 中的绑定是基于类名或 ID，并且这些元素本身没有被 i18next 替换，
      // 那么 $(document).ready() 中的绑定通常不需要重新应用。
      // 但如果 login/register 链接是通过 auth_modals.js 绑定的，
      // 并且 updateContent 修改了这些链接，则可能需要重新绑定。

      // 目前，我们可以先留空或只添加一个日志，直到确定哪些事件需要重新绑定。
      // console.log('bindPageSpecificEvents: No specific re-bindings currently implemented.');
  }
  // +++ 结束新增部分 +++

  i18next
    .use(i18nextBrowserLanguageDetector)
    .use(i18nextHttpBackend)
    .init({
      // --- i18next Configuration ---
      debug: false, // Disable debug logging
      fallbackLng: 'zh', // Fallback language if detected is unavailable
      supportedLngs: ['zh', 'en'], // Supported languages
      // List ALL namespaces used across the site
      ns: [
        'common', 'auth', 'chat', 'errors', 'about', 'profile',
        'home', 'verification', 'recharge', 'privacy', 'suggestions',
        'userAgreement'
      ],
      defaultNS: 'common', // Default namespace
      nsSeparator: ':', // Namespace separator (e.g., common:key)
      keySeparator: '.', // Key separator for nested keys (e.g., section.title)
      backend: {
        // Path to load translation files
        loadPath: '/static/js/i18n/locales/{{lng}}/{{ns}}.json',
      },
      detection: {
        // Order of language detection methods
        order: ['querystring', 'localStorage', 'navigator'],
        // Query string parameter for language
        lookupQuerystring: 'lang',
        // LocalStorage key for language preference
        lookupLocalStorage: 'prefLang',
        // Cache user language choice to LocalStorage
        caches: ['localStorage']
      }
      // --- End Configuration ---
    })
    .then((t) => {
      // --- Initialization Successful ---
      // console.log('i18next 初始化成功 (Promise)! 当前语言:', i18next.language);

      // Setup the language switcher UI/listeners FIRST (attaches the listener)
      setupLanguageSwitcher();

      // Call page-specific bindings that DON'T rely on immediate translation
      initializePageSpecificBindings();

      // Enable buttons or elements that need i18next core ready
      enableStaticElements();

      // --- Explicit Initial Content Update ---
      // console.log('i18next: 初始化完成，手动触发首次内容更新...');
      updateContent(); // Explicitly call updateContent here

      // Update switcher text based on initial language
      updateSwitcherTextAndURL(); // Call the moved function

      // +++ 触发 i18next 就绪事件 +++
      // console.log('i18next-init: Dispatching i18next-ready event.');
      document.dispatchEvent(new CustomEvent('i18next-ready'));
      // +++ 结束 +++

      // console.log('i18next: 首次内容更新已触发。');
      // We no longer need the "waiting for languageChanged" log here.
      // console.log('i18next: 等待 languageChanged 事件触发首次内容更新...');
      // --- End Init Success ---
    })
    .catch((err) => {
      // --- Initialization Failed ---
      console.error('i18next 初始化失败 (Promise)', err);
      // Consider fallback behavior if init fails (e.g., show an error message)
      // Maybe still try to setup the switcher to allow manual language selection?
      // setupLanguageSwitcher();
      // --- End Init Failure ---
    });

  // --- Function to Update Page Content ---
  function updateContent() {
    // console.log(`i18next: 更新内容，当前语言: ${i18next.language}`);

    // Select all elements needing translation
    const elementsToTranslate = document.querySelectorAll('[data-i18n], [data-i18n-key]');

    elementsToTranslate.forEach(el => {
      const keyAttr = el.hasAttribute('data-i18n') ? 'data-i18n' : 'data-i18n-key';
      const key = el.getAttribute(keyAttr);
      const attributeMatch = key.match(/^\[(.*?)](.*)$/); // Match [attribute]key format

      try {
        if (attributeMatch) {
          // --- Attribute Translation ---
          const attr = attributeMatch[1];
          const actualKey = attributeMatch[2];
          // Use returnObjects=false for safety, though default usually works
          const translation = i18next.t(actualKey, { returnObjects: false });

          if (translation === actualKey && i18next.language !== i18next.options.fallbackLng) {
             // Log if key wasn't found and it's not the fallback language
             console.warn(`i18next::translator: missingKey ${i18next.language} ${actualKey.includes(':') ? actualKey.split(':')[0] : i18next.options.defaultNS} ${actualKey}`);
          }

          // Apply translation to specific attributes
          if (attr === 'placeholder' && el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
            el.placeholder = translation;
          } else if (attr === 'title') {
            el.title = translation;
          } else if (attr === 'alt' && el.tagName === 'IMG') {
            el.alt = translation;
          } else if (attr === 'aria-label') {
            el.setAttribute('aria-label', translation);
          } else if (el.hasAttribute(attr)) { // Generic attribute handling
            el.setAttribute(attr, translation);
          } else {
            console.warn(`i18next: Unhandled attribute [${attr}] for key "${key}" on element:`, el);
          }
          // --- End Attribute Translation ---

        } else {
          // --- Text Content Translation ---
          // Use returnObjects=false for safety
          const translation = i18next.t(key, { returnObjects: false });

           if (translation === key && i18next.language !== i18next.options.fallbackLng) {
             // Log if key wasn't found and it's not the fallback language
             console.warn(`i18next::translator: missingKey ${i18next.language} ${key.includes(':') ? key.split(':')[0] : i18next.options.defaultNS} ${key}`);
           }

          el.textContent = translation;
          // --- End Text Content Translation ---
        }
      } catch (error) {
          console.error(`i18next: Error translating key "${key}" for element:`, el, error);
      }
    });

    // Update HTML lang attribute
    document.documentElement.lang = i18next.language === 'zh' ? 'zh-CN' : i18next.language;
    // console.log('i18next: 内容更新完成。');
    bindPageSpecificEvents(true); // 每次内容更新后重新绑定页面特定事件

    // +++ 新增：翻译 Flash Messages +++
    translateFlashMessages(); 
    // +++ 结束新增部分 +++
  }
  // --- End updateContent ---

  // +++ 新增：翻译 Flash Messages 的函数 +++
  function translateFlashMessages() {
    if (!i18next.isInitialized) {
        // console.warn('i18next not ready for flash message translation');
        return;
    }

    // 选择所有 Django messages (使用更具体的选择器，如果你的 flash messages 有特定的容器)
    const flashMessages = document.querySelectorAll('.alert-container .alert'); // 假设消息在 .alert-container 内

    flashMessages.forEach(messageElement => {
        const closeButton = messageElement.querySelector('.btn-close');
        let originalText = '';
        let textNode = null;

        // 查找主要的文本节点 (忽略关闭按钮等)
        messageElement.childNodes.forEach(node => {
            if (node.nodeType === Node.TEXT_NODE && node.textContent.trim().length > 0) {
                if (!textNode) { // 只取第一个非空文本节点
                     textNode = node;
                     originalText = node.textContent.trim();
                }
            }
        });

        // 如果没有找到文本节点或者文本为空，则跳过
        if (!textNode || !originalText) {
            return;
        }

        // 定义需要特殊处理的消息和它们的 i18n 键
        // 注意：你需要确保这些键存在于对应的 JSON 文件中
        const messagesToTranslate = {
            // --- 来自 request_email_change 的消息 ---
            '验证邮件已发送至您的新邮箱，请查收并点击链接完成更改。': 'profile:email_verification_sent',
            '发送验证邮件失败，请稍后重试或联系管理员。': 'profile:email_verification_failed', // 需要添加这个键
            '请修正表单中的错误。': 'common:fix_form_errors', // 需要添加这个键
            // --- 来自 confirm_email_change 的消息 ---
            '邮箱更改失败：该邮箱地址已被其他用户使用。': 'profile:email_change_failed_taken', // 需要添加
            '您的邮箱地址已成功更新。': 'profile:email_change_success', // 需要添加
            '邮箱验证链接无效或已过期，请重新请求更改。': 'profile:email_link_invalid', // 需要添加
            // --- 其他可能的 Django messages ---
            '身份验证成功，您现在可以使用所有功能': 'profile:identity_verify_success', // 需要添加
            '身份验证失败：信息不匹配': 'profile:identity_verify_mismatch', // 需要添加（或其他具体错误）
            '此身份信息已被其他账号使用，如有疑问请联系客服': 'profile:identity_verify_taken', // 需要添加
            '身份验证服务暂时不可用，请稍后再试': 'profile:identity_verify_error' // 需要添加
            // ... 添加其他需要翻译的 Django flash messages
        };

        // 检查原始文本是否在需要翻译的列表里
        if (messagesToTranslate[originalText]) {
            const i18nKey = messagesToTranslate[originalText];
            const translatedText = i18next.t(i18nKey);

            // 只更新找到的文本节点的内容
            if (translatedText && translatedText !== i18nKey) { // 确保翻译成功且不是返回键名
                 textNode.textContent = translatedText + ' '; // 更新文本，加个空格保持间距
                 // console.log(`Translated flash message: ${originalText} -> ${translatedText}`);
            }
        }
    });
  }
  // +++ 结束新增部分 +++

  // --- Function to Setup Language Switcher ---
  function setupLanguageSwitcher() {
    const switcher = document.getElementById('lang-toggle');
    if (!switcher) {
         console.warn('未找到ID为 lang-toggle 的语言切换按钮');
         return;
    }
    // console.log('i18next: 设置语言切换器。');

    // Add click listener to the switcher button
    switcher.addEventListener('click', (e) => {
      e.preventDefault();
      if (!i18next.isInitialized) return; // Prevent action if not ready

      const currentLang = i18next.language;
      const newLang = currentLang === 'zh' ? 'en' : 'zh';
      // console.log(`i18next: 按钮点击，尝试切换语言从 ${currentLang} 到 ${newLang}`);

      // changeLanguage handles loading resources and triggers 'languageChanged'
      i18next.changeLanguage(newLang).catch((err) => {
        console.error('i18next: 语言切换失败', err);
        // Optionally update UI to show error
      });
    });

     // --- CRITICAL: Handle languageChanged Event ---
     i18next.on('languageChanged', (lng) => {
         // console.log(`i18next: 检测到 languageChanged 事件，新语言: ${lng}。直接更新内容...`);
         updateContent(); // 这个函数内部会调用 translateFlashMessages

         // 更新切换器文本/URL
         updateSwitcherTextAndURL();

         // 重新运行依赖翻译的页面特定绑定 (如果需要)
         // initializePageSpecificBindings(true);

         // 设置 Django 语言 cookie
         const djangoLang = lng === 'zh' ? 'zh-hans' : lng;
         document.cookie = `django_language=${djangoLang}; path=/; max-age=31536000; SameSite=Lax`;
         // console.log(`i18next: 设置 django_language cookie 为 ${djangoLang}`);

         // console.log(`i18next: languageChanged 处理完毕，语言: ${lng}`);

         // 不再需要显式加载命名空间，因为 init/changeLanguage 应已处理
         /*
         i18next.loadNamespaces(i18next.options.ns)
             .then(() => {
                 console.log(`i18next: 所有命名空间已为语言 ${lng} 加载完毕。正在更新内容...`);
                 updateContent();
                 updateSwitcherTextAndURL();
                 const djangoLang = lng === 'zh' ? 'zh-hans' : lng;
                 document.cookie = `django_language=${djangoLang}; path=/; max-age=31536000; SameSite=Lax`;
                 console.log(`i18next: 设置 django_language cookie 为 ${djangoLang}`);
                 console.log(`i18next: languageChanged 处理完毕，语言: ${lng}`);
             })
             .catch(err => {
                 console.error(`i18next: 加载命名空间失败，语言: ${lng}:`, err);
                 updateSwitcherTextAndURL();
             });
         */
     });
     // --- End languageChanged Handler ---

  } // --- End setupLanguageSwitcher ---


  // --- Function for Page-Specific Bindings ---
  // Runs ONCE after i18next.init resolves
  function initializePageSpecificBindings(isLanguageChange = false) {
      // console.log(`i18next-init: ${isLanguageChange ? '重新绑定' : '初始化'}页面特定事件...`);
       // Example: If chat bindings need i18n *after* translation is ready,
       // call them from within languageChanged's .then() instead of here.
       // If they only need i18next core, calling here is fine.
       if (typeof window.initChatI18nBindings === 'function' && !isLanguageChange) {
           // console.log('i18next-init: Calling initChatI18nBindings...');
           window.initChatI18nBindings();
       }
       if (typeof window.initProfileI18nBindings === 'function' && !isLanguageChange) {
           // console.log('i18next-init: Calling initProfileI18nBindings...');
           window.initProfileI18nBindings();
       }
       // Add other page-specific init calls here
  }
  // --- End initializePageSpecificBindings ---


  // --- Function to Enable Static Elements ---
  // Runs ONCE after i18next.init resolves
  function enableStaticElements() {
      // console.log('i18next-init: 启用静态元素...');
      // Example: Enable buttons that don't depend on translation text
      const identitySubmitButton = document.querySelector('#verificationForm button[type="submit"]');
      if (identitySubmitButton) {
          // console.log('i18next-init: Found identity submit button. Enabling...');
          identitySubmitButton.disabled = false;
          // console.log('i18next-init: Enabled identity verification submit button.');
      } else {
          if (window.location.pathname.includes('/users/identity/')) {
              // Kept this error as it might indicate a real issue
              console.error('i18next-init: Could not find identity submit button after init!');
          }
      }
      // Add other elements to enable here
  }
  // --- End enableStaticElements ---


  // --- Global 't' function Helper ---
  // Provides a safe way to call i18next.t with fallback logic
  window.t = function(key, options) {
    const lng = i18next.language;
    const nsSeparator = i18next.options.nsSeparator || ':';
    const keySeparator = i18next.options.keySeparator || '.';
    const defaultNS = i18next.options.defaultNS || 'common'; // Ensure defaultNS exists
    let ns = defaultNS;

    if (key.includes(nsSeparator)) {
        ns = key.split(nsSeparator)[0];
    }

    // Keep the warning for when i18n isn't ready
    if (!i18next.isInitialized || !lng || !i18next.hasResourceBundle(lng, ns)) {
        console.warn(`i18next 尚未就绪或命名空间 "${ns}" 未加载 (语言: ${lng})，无法翻译键: ${key}`);
        // Provide a more generic fallback if translation isn't ready
        const fallbackKey = key.includes(nsSeparator) ? key.split(nsSeparator)[1] : key;
        const defaultText = fallbackKey.split(keySeparator).pop().replace(/[-_]/g, ' ');
        const formattedText = typeof defaultText === 'string' ? defaultText.charAt(0).toUpperCase() + defaultText.slice(1) : String(fallbackKey); // Format as Title Case, fallback to key part
        return formattedText;
    }

    // Proceed with translation attempts if ready
    // Try translation with the original key, return null if not found
    // Pass lng explicitly for robustness
    let translation = i18next.t(key, { ...options, lng: lng, returnNull: true });

    // Fallback logic (optional, based on your key naming conventions)
    if (translation === null && key.includes('-')) {
      const altKey = key.replace(/-/g, '_');
      translation = i18next.t(altKey, { ...options, lng: lng, returnNull: true });
    }
    if (translation === null && key.includes('_')) {
      const altKey = key.replace(/_/g, '-');
      translation = i18next.t(altKey, { ...options, lng: lng, returnNull: true });
    }

    return translation !== null ? translation : i18next.t(key, { ...options, lng: lng });
  };
  // --- End Global 't' function ---

}); // --- End DOMContentLoaded ---