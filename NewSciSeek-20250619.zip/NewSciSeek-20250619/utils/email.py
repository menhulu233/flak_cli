import random
import string
from django.core.mail import send_mail
from django.conf import settings
from django.core.cache import cache
import logging

logger = logging.getLogger('utils')

class EmailVerification:
    """邮箱验证码工具类"""
    
    @staticmethod
    def generate_code(length=6):
        """生成指定长度的验证码"""
        return ''.join(random.choices(string.digits, k=length))
    
    @staticmethod
    def send_verification_code(email):
        """发送验证码邮件
        
        Args:
            email: 接收验证码的邮箱地址
            
        Returns:
            bool: 是否发送成功
        """
        logger.info(f"开始发送验证码邮件 - 目标邮箱: {email}")
        try:
            # 生成6位数字验证码
            code = EmailVerification.generate_code()
            logger.debug(f"生成验证码: {code} for {email}")
            
            # 邮件主题
            subject = 'NewSciSeek - 邮箱验证码'
            
            # 邮件内容
            message = f'''
            您好！
            
            您的验证码是：{code}
            
            验证码有效期为5分钟，请尽快完成验证。
            
            如果这不是您的操作，请忽略此邮件。
            
            祝您使用愉快！
            新科探索团队
            '''
            
            # 检查邮件配置
            if not settings.EMAIL_HOST_USER or not settings.EMAIL_HOST_PASSWORD:
                logger.error("邮件配置错误：未设置邮箱账号或密码")
                return False
                
            # 发送邮件
            send_mail(
                subject=subject,
                message=message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[email],
                fail_silently=False,
            )
            
            # 将验证码存入缓存，设置5分钟过期
            cache_key = f'email_verification_{email}'
            cache.set(cache_key, code, 300)  # 300秒 = 5分钟
            logger.info(f"验证码已存入缓存 - Key: {cache_key}")
            
            logger.info(f"验证码邮件发送成功 - 邮箱: {email}")
            return True
            
        except Exception as e:
            logger.error(f"验证码邮件发送失败 - 邮箱: {email}, 错误: {str(e)}")
            # 记录更详细的错误信息
            logger.error(f"邮件配置信息: HOST={settings.EMAIL_HOST}, PORT={settings.EMAIL_PORT}, "
                      f"TLS={settings.EMAIL_USE_TLS}, FROM={settings.DEFAULT_FROM_EMAIL}")
            return False
    
    @staticmethod
    def verify_code(email, code):
        """验证验证码是否正确
        
        Args:
            email: 邮箱地址
            code: 用户输入的验证码
            
        Returns:
            bool: 验证是否通过
        """
        logger.info(f"开始验证验证码 - 邮箱: {email}, 输入验证码: {code}")
        try:
            cache_key = f'email_verification_{email}'
            cached_code = cache.get(cache_key)
            logger.debug(f"从缓存获取验证码 - Key: {cache_key}, Value: {cached_code}")
            
            if not cached_code:
                logger.info(f"验证码已过期或不存在 - 邮箱: {email}")
                return False
                
            # 验证成功后删除缓存
            if cached_code == code:
                cache.delete(cache_key)
                logger.info(f"验证码已从缓存中删除 - Key: {cache_key}")
                logger.info(f"验证码验证成功 - 邮箱: {email}")
                return True
                
            logger.info(f"验证码验证失败 - 邮箱: {email}, 输入: {code}, 缓存中: {cached_code}")
            return False
            
        except Exception as e:
            logger.error(f"验证码验证过程出错 - 邮箱: {email}, 错误: {str(e)}")
            return False 