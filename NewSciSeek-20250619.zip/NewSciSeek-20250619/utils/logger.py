import os
import time
import logging
from django.conf import settings

# 定义日志配置
def get_log_config():
    """
    获取日志配置字典
    """
    # 确保日志目录存在
    log_dir = os.path.join(settings.BASE_DIR, 'logs')
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # 日志文件路径
    debug_log = os.path.join(log_dir, f'debug-{time.strftime("%Y-%m-%d")}.log')
    error_log = os.path.join(log_dir, f'error-{time.strftime("%Y-%m-%d")}.log')
    info_log = os.path.join(log_dir, f'info-{time.strftime("%Y-%m-%d")}.log')
    
    # 日志格式
    standard_format = '[%(asctime)s][%(levelname)s][%(filename)s:%(lineno)d] - %(message)s'
    simple_format = '[%(levelname)s][%(asctime)s] - %(message)s'
    
    # 配置字典
    LOGGING = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'standard': {
                'format': standard_format
            },
            'simple': {
                'format': simple_format
            },
        },
        'filters': {
            'require_debug_true': {
                '()': 'django.utils.log.RequireDebugTrue',
            },
        },
        'handlers': {
            'console': {
                'level': 'DEBUG',
                'class': 'logging.StreamHandler',
                'formatter': 'simple'
            },
            'file_debug': {
                'level': 'DEBUG',
                'class': 'logging.handlers.RotatingFileHandler',
                'filename': debug_log,
                'maxBytes': 1024 * 1024 * 50,  # 50 MB
                'backupCount': 5,
                'formatter': 'standard',
                'encoding': 'utf-8',
            },
            'file_info': {
                'level': 'INFO',
                'class': 'logging.handlers.RotatingFileHandler',
                'filename': info_log,
                'maxBytes': 1024 * 1024 * 50,  # 50 MB
                'backupCount': 5,
                'formatter': 'standard',
                'encoding': 'utf-8',
            },
            'file_error': {
                'level': 'ERROR',
                'class': 'logging.handlers.RotatingFileHandler',
                'filename': error_log,
                'maxBytes': 1024 * 1024 * 50,  # 50 MB
                'backupCount': 5,
                'formatter': 'standard',
                'encoding': 'utf-8',
            },
        },
        'loggers': {
            '': {
                'handlers': ['console', 'file_debug'],
                'level': 'DEBUG',
                'propagate': False,
            },
            'django': {
                'handlers': ['console', 'file_info', 'file_error'],
                'level': 'INFO',
                'propagate': False,
            },
            'django.request': {
                'handlers': ['console', 'file_error'],
                'level': 'DEBUG',
                'propagate': False,
            },
            'django.db.backends': {
                'handlers': ['console', 'file_debug'],
                'level': 'DEBUG',
                'propagate': False,
            },
            'ip_verify': {
                'handlers': ['console', 'file_info', 'file_error'],
                'level': 'INFO',
                'propagate': False,
            },
            'users': {
                'handlers': ['console', 'file_info', 'file_error'],
                'level': 'DEBUG',
                'propagate': False,
            },
        },
    }
    
    return LOGGING 

def get_logger(name):
    """
    获取指定名称的日志记录器
    
    Args:
        name: 日志记录器名称
        
    Returns:
        logging.Logger: 日志记录器对象
    """
    logger = logging.getLogger(name)
    
    # 确保日志目录存在
    log_dir = os.path.join(settings.BASE_DIR, 'logs')
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # 如果日志记录器没有处理程序，添加默认处理程序
    if not logger.handlers:
        # 控制台处理程序
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.DEBUG if settings.DEBUG else logging.INFO)
        console_formatter = logging.Formatter('[%(levelname)s][%(asctime)s] - %(message)s')
        console_handler.setFormatter(console_formatter)
        
        # 文件处理程序
        file_handler = logging.FileHandler(
            os.path.join(log_dir, f'{name}-{time.strftime("%Y-%m-%d")}.log'),
            encoding='utf-8'
        )
        file_handler.setLevel(logging.INFO)
        file_formatter = logging.Formatter('[%(asctime)s][%(levelname)s][%(filename)s:%(lineno)d] - %(message)s')
        file_handler.setFormatter(file_formatter)
        
        # 添加处理程序到日志记录器
        logger.addHandler(console_handler)
        logger.addHandler(file_handler)
        
        # 设置日志级别
        logger.setLevel(logging.DEBUG if settings.DEBUG else logging.INFO)
        
        # 设置不传播到上级日志记录器
        logger.propagate = False
    
    return logger 