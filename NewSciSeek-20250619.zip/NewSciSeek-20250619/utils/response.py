from rest_framework.response import Response
from rest_framework import status


class APIResponse(Response):
    """
    统一API响应格式
    """
    def __init__(self, data=None, code=200, msg="success", status=None, headers=None, **kwargs):
        # 默认响应体
        response_data = {
            'code': code,
            'message': msg
        }
        
        # 如果有数据，则添加到响应体中
        if data is not None:
            response_data['data'] = data
            
        # 添加其他关键字参数到响应体
        if kwargs:
            response_data.update(kwargs)
            
        # 调用父类的初始化方法
        super().__init__(data=response_data, status=status, headers=headers)


def success_response(data=None, msg="操作成功", **kwargs):
    """
    成功响应
    """
    return APIResponse(data=data, code=200, msg=msg, status=status.HTTP_200_OK, **kwargs)


def error_response(msg="操作失败", code=400, status_code=status.HTTP_400_BAD_REQUEST, **kwargs):
    """
    错误响应
    """
    return APIResponse(code=code, msg=msg, status=status_code, **kwargs)


def not_found_response(msg="资源不存在", **kwargs):
    """
    资源不存在响应
    """
    return APIResponse(code=404, msg=msg, status=status.HTTP_404_NOT_FOUND, **kwargs)


def unauthorized_response(msg="未授权", **kwargs):
    """
    未授权响应
    """
    return APIResponse(code=401, msg=msg, status=status.HTTP_401_UNAUTHORIZED, **kwargs)


def forbidden_response(msg="禁止访问", **kwargs):
    """
    禁止访问响应
    """
    return APIResponse(code=403, msg=msg, status=status.HTTP_403_FORBIDDEN, **kwargs)


def server_error_response(msg="服务器内部错误", **kwargs):
    """
    服务器内部错误响应
    """
    return APIResponse(code=500, msg=msg, status=status.HTTP_500_INTERNAL_SERVER_ERROR, **kwargs) 