import logging
from rest_framework.views import exception_handler
from rest_framework import status
from .response import error_response, not_found_response, server_error_response, unauthorized_response, forbidden_response

# 获取日志记录器
logger = logging.getLogger('django')

def custom_exception_handler(exc, context):
    """
    自定义异常处理器
    """
    # 先调用REST框架的默认异常处理
    response = exception_handler(exc, context)
    
    # 获取异常信息
    error_message = str(exc)
    
    # 如果REST框架已处理异常，则转换为自定义响应格式
    if response is not None:
        error_data = None
        status_code = response.status_code
        
        # 准备错误数据
        if hasattr(response, 'data'):
            error_data = response.data
            
        # 按状态码处理不同类型的错误
        if status_code == status.HTTP_404_NOT_FOUND:
            return not_found_response(msg=error_message)
        elif status_code == status.HTTP_401_UNAUTHORIZED:
            return unauthorized_response(msg=error_message)
        elif status_code == status.HTTP_403_FORBIDDEN:
            return forbidden_response(msg=error_message)
        elif status_code == status.HTTP_500_INTERNAL_SERVER_ERROR:
            return server_error_response(msg=error_message)
        else:
            return error_response(
                msg=error_message,
                code=status_code,
                status_code=status_code,
                error=error_data
            )
            
    # 如果REST框架未处理异常，则记录并作为服务器错误处理
    logger.error(f"Unhandled Exception: {error_message}")
    return server_error_response(msg="服务器内部错误")

class InsufficientBalanceError(Exception):
    """
    余额不足异常
    当用户账户余额不足以支付API调用费用时抛出
    """
    pass

class APIException(Exception):
    """
    API调用异常
    当调用外部API发生错误时抛出
    """
    pass 