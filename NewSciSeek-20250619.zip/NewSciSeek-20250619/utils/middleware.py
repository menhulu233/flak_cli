import json
import logging
import traceback
from django.http import JsonResponse
from django.conf import settings
from rest_framework import status
from utils.response import server_error_response

# 配置日志记录器
logger = logging.getLogger('django')

class GlobalExceptionMiddleware:
    """
    全局异常处理中间件
    捕获视图函数中的异常，并返回统一的API响应
    """
    def __init__(self, get_response):
        self.get_response = get_response
        
    def __call__(self, request):
        # 处理请求前的代码
        response = self.get_response(request)
        # 处理请求后的代码
        return response
        
    def process_exception(self, request, exception):
        """
        处理视图函数中的异常
        """
        # 记录异常信息
        error_message = str(exception)
        error_traceback = traceback.format_exc()
        
        # 记录详细日志
        logger.error(f"Unhandled Exception: {error_message}")
        logger.error(f"Traceback: {error_traceback}")
        
        # 开发环境返回详细错误信息，生产环境返回简洁信息
        if settings.DEBUG:
            error_data = {
                'detail': error_message,
                'traceback': error_traceback.split('\n')
            }
            return server_error_response(
                msg="服务器内部错误",
                error=error_data
            )
        else:
            # 生产环境只返回简单错误信息
            return server_error_response(
                msg="服务器内部错误，请稍后再试"
            )

class LanguageMiddleware:
    """
    处理语言选择的中间件
    支持从URL参数、Cookie、浏览器设置中检测语言
    """
    
    def __init__(self, get_response):
        self.get_response = get_response
    
    def __call__(self, request):
        # 尝试从URL参数获取语言
        lang_code = request.GET.get('lang')
        
        # 如果URL中没有语言参数，尝试从Cookie获取
        if not lang_code:
            lang_code = request.COOKIES.get('django_language')
        
        # 如果设置了有效的语言，激活它
        if lang_code:
            from django.utils import translation
            if lang_code in ['en', 'zh-hans']:
                translation.activate(lang_code)
                request.LANGUAGE_CODE = lang_code
        
        response = self.get_response(request)
        
        # 确保语言设置保存到Cookie中
        if hasattr(request, 'LANGUAGE_CODE') and request.LANGUAGE_CODE:
            response.set_cookie('django_language', request.LANGUAGE_CODE)
        
        return response 