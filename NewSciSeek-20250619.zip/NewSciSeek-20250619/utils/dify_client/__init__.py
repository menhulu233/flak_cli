"""
Dify API 客户端封装
基于官方 dify_client 包实现

主要功能：
1. 聊天功能 (ChatClient)
   - 发送消息
   - 获取会话列表
   - 获取会话消息
   - 管理会话

2. 补全功能 (CompletionClient)
   - 文本补全

3. 工作流功能 (WorkflowClient)
   - 运行工作流
   - 管理工作流任务

4. 知识库功能 (KnowledgeBaseClient)
   - 管理数据集
   - 管理文档
   - 文档分段管理

使用示例：
    from utils.dify_client import ChatClient
    
    # 创建聊天客户端
    chat_client = ChatClient(api_key="your-api-key")
    
    # 发送消息
    response = chat_client.create_chat_message(
        inputs={},
        query="你好",
        user="user-123",
        response_mode="streaming"
    )
"""

from .client import (
    DifyClient,
    ChatClient,
    CompletionClient,
    WorkflowClient,
    KnowledgeBaseClient
)

__version__ = "1.0.0"
__all__ = [
    'DifyClient',
    'ChatClient',
    'CompletionClient',
    'WorkflowClient',
    'KnowledgeBaseClient'
]
