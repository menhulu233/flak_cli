from django.utils.translation import gettext_lazy as _
from django.utils import translation

def get_translated_field(obj, field_name, language=None):
    """
    获取模型的多语言字段值
    约定：字段_en, 字段_zh 格式
    
    例如：
    - title_zh: 中文标题
    - title_en: 英文标题
    
    用法：
    get_translated_field(article, 'title')  # 根据当前语言返回对应标题
    get_translated_field(article, 'title', 'en')  # 强制返回英文标题
    
    :param obj: 模型实例
    :param field_name: 字段基本名称 (不带语言后缀)
    :param language: 指定语言代码 (可选)
    :return: 翻译后的字段值
    """
    # 如果没有指定语言，获取当前激活的语言
    if not language:
        current_lang = translation.get_language()
        # Django的语言代码格式可能是zh-hans，我们需要处理一下
        if current_lang.startswith('zh'):
            language = 'zh'
        else:
            language = current_lang.split('-')[0]
    
    # 构建对应语言的字段名
    lang_field = f"{field_name}_{language}"
    
    # 如果对象有这个语言的字段，并且值不为空
    if hasattr(obj, lang_field) and getattr(obj, lang_field):
        return getattr(obj, lang_field)
    
    # 回退到默认语言 (中文)
    default_field = f"{field_name}_zh"
    if hasattr(obj, default_field) and getattr(obj, default_field):
        return getattr(obj, default_field)
    
    # 如果没有默认语言字段或为空，尝试获取原始字段
    if hasattr(obj, field_name):
        return getattr(obj, field_name)
    
    # 实在没有，返回空字符串
    return ""

def get_language_choices():
    """
    返回系统支持的语言选择，用于表单选择字段
    :return: 元组列表 [('zh', '中文'), ('en', 'English')]
    """
    return [
        ('zh', _('中文')),
        ('en', _('English')),
    ] 