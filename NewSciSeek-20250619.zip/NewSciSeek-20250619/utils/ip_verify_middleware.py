import requests
import logging
from django.shortcuts import redirect
from django.urls import reverse
from django.utils.deprecation import MiddlewareMixin
from django.conf import settings
from django.contrib import messages
from django.utils.translation import gettext as _

logger = logging.getLogger('ip_verify')

class ChinaIPVerificationMiddleware(MiddlewareMixin):
    """
    中国大陆IP认证中间件
    检查用户IP是否来自中国大陆，如果是，则验证用户是否已实名认证
    未实名认证的中国大陆用户将被重定向到实名认证页面
    """
    
    def __init__(self, get_response):
        self.get_response = get_response
        # 缓存已检查过的IP
        self.ip_cache = {}
        
    def process_request(self, request):
        """
        处理请求，检查IP是否来自中国大陆，并验证用户身份认证状态
        (修改：移除全局检查逻辑，仅依赖装饰器)
        """
        # # 排除静态资源和认证相关的URL (注释掉)
        # if self._should_skip(request):
        #     return None
            
        # # 获取客户端IP (注释掉)
        # client_ip = self._get_client_ip(request)
        
        # # 检查IP是否来自中国大陆 (注释掉)
        # is_china_ip = self._is_china_ip(client_ip)
        
        # # 如果是中国大陆IP，检查用户是否已认证 (注释掉)
        # if is_china_ip and request.user.is_authenticated:
        #     if not request.user.is_verified:
        #         # 排除身份验证页面本身和API，防止重定向循环
        #         if not request.path.startswith('/api/users/identity/verify') and not request.path == '/users/identity/':
        #             messages.warning(request, _('根据相关规定，中国大陆用户必须完成实名认证才能使用本系统'))
        #             return redirect('/users/identity/')
                    
        # 直接返回 None，不执行任何检查
        return None
        
    def _should_skip(self, request):
        """
        判断是否应该跳过验证
        跳过静态资源、登录注册页面和认证API
        """
        # 静态资源
        if request.path.startswith(('/static/', '/media/')):
            return True
            
        # 不需要验证的页面
        exempt_paths = [
            '/login/',
            '/register/',
            '/logout/',
            '/admin/',  # 管理员页面
            '/api/users/login/',
            '/api/users/register/',
            '/api/users/wx/',  # 微信登录
            '/chat/',         # 聊天页面
            '/api/chat/',     # 聊天 API
        ]
        
        for path in exempt_paths:
            if request.path.startswith(path):
                return True
                
        return False
        
    def _get_client_ip(self, request):
        """
        获取客户端IP地址
        """
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0]
        else:
            ip = request.META.get('REMOTE_ADDR')
        return ip
        
    def _is_china_ip(self, ip):
        """
        检查IP是否来自中国大陆
        使用IP-API.com提供的免费IP地理位置API
        """
        # 如果IP已经在缓存中，直接返回结果
        if ip in self.ip_cache:
            return self.ip_cache[ip]
            
        # 如果是本地IP或测试环境，根据设置返回
        if ip in ('127.0.0.1', 'localhost', '::1') or settings.DEBUG:
            # 在开发环境下可以通过设置强制识别为中国IP进行测试
            force_china_ip = getattr(settings, 'FORCE_CHINA_IP', False)
            self.ip_cache[ip] = force_china_ip
            return force_china_ip
            
        try:
            # 使用ip-api.com的免费服务查询IP地理位置
            response = requests.get(f'http://ip-api.com/json/{ip}?fields=status,country,countryCode', timeout=3)
            data = response.json()
            
            if data['status'] == 'success':
                # 检查国家代码是否为CN (中国)
                is_china = data['countryCode'] == 'CN'
                self.ip_cache[ip] = is_china
                return is_china
                
        except Exception as e:
            logger.error(f"IP地理位置查询失败: {str(e)}")
            # 查询失败，默认不拦截
            return False
            
        # 默认情况，不拦截
        return False 