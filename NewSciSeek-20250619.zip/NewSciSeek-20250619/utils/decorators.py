from functools import wraps
from django.shortcuts import redirect
from django.utils.translation import gettext as _
from django.contrib import messages
from .ip_verify_middleware import ChinaIPVerificationMiddleware

def require_china_verification(view_func):
    """
    装饰器：要求中国大陆IP用户必须实名认证
    可用于特定视图函数，比一般的中间件更精确
    """
    @wraps(view_func)
    def _wrapped_view(self, request, *args, **kwargs):
        # 跳过未登录用户的检查
        if not request.user.is_authenticated:
            return view_func(self, request, *args, **kwargs)
            
        # 获取IP检测中间件的实例
        middleware = ChinaIPVerificationMiddleware(get_response=lambda r: None)
        
        # 获取客户端IP
        client_ip = middleware._get_client_ip(request)
        
        # 检查是否为中国大陆IP
        is_china_ip = middleware._is_china_ip(client_ip)
        
        # 如果是中国大陆IP且用户未实名认证，则重定向到实名认证页面
        if is_china_ip and not request.user.is_verified:
            # 检查是否为API请求
            if request.path.startswith('/api/'):
                from rest_framework.response import Response
                from rest_framework import status
                return Response({
                    'error': _('根据相关规定，中国大陆用户必须完成实名认证才能使用此功能'),
                    'verification_required': True
                }, status=status.HTTP_403_FORBIDDEN)
            else:
                messages.warning(request, _('根据相关规定，中国大陆用户必须完成实名认证才能使用此功能'))
                return redirect('/users/identity/')
            
        # 通过验证，继续执行视图函数
        return view_func(self, request, *args, **kwargs)
        
    return _wrapped_view 