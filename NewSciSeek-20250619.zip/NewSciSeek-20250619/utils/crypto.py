import hashlib
import secrets
import string
import base64
from django.conf import settings

class CryptoUtils:
    """
    加密工具类，提供常用的加密和哈希函数
    """
    
    @staticmethod
    def generate_salt(length=16):
        """
        生成随机盐值
        :param length: 盐值长度
        :return: 随机盐值字符串
        """
        alphabet = string.ascii_letters + string.digits
        return ''.join(secrets.choice(alphabet) for _ in range(length))
    
    @staticmethod
    def hash_password(password, salt=None):
        """
        哈希密码
        :param password: 原始密码
        :param salt: 盐值，如果为None则自动生成
        :return: (hashed_password, salt)
        """
        if salt is None:
            salt = CryptoUtils.generate_salt()
            
        # 组合密码和盐值
        salted_password = password + salt
        
        # 使用SHA-256哈希算法
        hash_obj = hashlib.sha256(salted_password.encode('utf-8'))
        hashed_password = hash_obj.hexdigest()
        
        return hashed_password, salt
    
    @staticmethod
    def verify_password(password, hashed_password, salt):
        """
        验证密码
        :param password: 待验证的明文密码
        :param hashed_password: 存储的哈希密码
        :param salt: 密码盐值
        :return: 是否匹配
        """
        # 计算哈希值
        calculated_hash, _ = CryptoUtils.hash_password(password, salt)
        
        # 比较计算的哈希值和存储的哈希值
        return calculated_hash == hashed_password
    
    @staticmethod
    def generate_token(length=32):
        """
        生成随机令牌
        :param length: 令牌长度
        :return: 随机令牌字符串
        """
        return secrets.token_hex(length)
    
    @staticmethod
    def encode_base64(data):
        """
        Base64编码
        :param data: 要编码的数据
        :return: Base64编码字符串
        """
        if isinstance(data, str):
            data = data.encode('utf-8')
        return base64.b64encode(data).decode('utf-8')
    
    @staticmethod
    def decode_base64(encoded_data):
        """
        Base64解码
        :param encoded_data: Base64编码的字符串
        :return: 解码后的数据
        """
        return base64.b64decode(encoded_data).decode('utf-8') 