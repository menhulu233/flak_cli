# Generated manually on 2025-03-29

from django.db import migrations
from decimal import Decimal

def add_unified_pricing_plan(apps, schema_editor):
    """添加统一定价计划数据"""
    PricingPlan = apps.get_model('billing', 'PricingPlan')
    
    # 清除所有现有定价计划
    PricingPlan.objects.all().delete()
    
    # 创建统一定价计划
    PricingPlan.objects.create(
        name='统一定价计划',
        description='适用于所有模型的统一定价计划',
        prompt_price_per_million_tokens=Decimal('5.0'),
        completion_price_per_million_tokens=Decimal('10.0'),
        is_active=True
    )


class Migration(migrations.Migration):

    dependencies = [
        ('billing', '0005_obsolete_merge'),
    ]

    operations = [
        migrations.RunPython(add_unified_pricing_plan),
    ] 