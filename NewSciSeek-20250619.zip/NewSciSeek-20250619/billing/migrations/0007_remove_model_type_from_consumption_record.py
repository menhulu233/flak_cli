# Generated manually on 2025-03-29

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('billing', '0006_add_unified_pricing'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='consumptionrecord',
            name='model_type',
        ),
    ]
