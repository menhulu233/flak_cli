"""
计费系统服务层
提供Token计数、扣费等核心功能
"""
import json
import datetime
from decimal import Decimal
from django.db import transaction
from django.db.models import Sum, F
from django.utils import timezone
from utils.logger import get_logger
from utils.exceptions import InsufficientBalanceError
from .models import AccountBalance, ConsumptionRecord, TokenUsage, PricingPlan

logger = get_logger('billing')

class TokenCounter:
    """Token计数器"""
    
    @staticmethod
    def count_tokens_from_messages(messages):
        """
        计算消息列表中的Token数量
        简单实现，后续可以接入更准确的Token计数算法
        
        Args:
            messages: 消息列表
            
        Returns:
            int: Token数量
        """
        token_count = 0
        for message in messages:
            content = message.get('content', '')
            # 简单估算，每个字符按1个Token计算
            # 实际中应使用更准确的分词算法
            token_count += len(content)
        return token_count
    
    @staticmethod
    def count_tokens_from_text(text):
        """
        计算文本中的Token数量
        简单实现，后续可以接入更准确的Token计数算法
        
        Args:
            text: 文本内容
            
        Returns:
            int: Token数量
        """
        # 简单估算，每个字符按1个Token计算
        # 实际中应使用更准确的分词算法
        return len(text)
    
    @staticmethod
    def count_tokens_from_response(response):
        """
        从API响应中提取Token统计信息
        
        Args:
            response: API响应结果
            
        Returns:
            dict: 包含prompt_tokens, completion_tokens, total_tokens的字典
        """
        usage = response.get('usage', {})
        return {
            'prompt_tokens': usage.get('prompt_tokens', 0),
            'completion_tokens': usage.get('completion_tokens', 0),
            'total_tokens': usage.get('total_tokens', 0)
        }


class BillingService:
    """计费服务"""
    
    @staticmethod
    def check_balance(user, account_balance=None):
        """
        检查用户余额是否充足以支付基本的对话消费
        只要余额大于0即可
        
        Args:
            user: 用户对象
            account_balance (AccountBalance, optional): 预先获取的余额对象. Defaults to None.
            
        Returns:
            tuple: (是否充足, 余额金额, 最低消费金额)
        """
        try:
            # 如果没有传入 account_balance 对象，则从数据库获取
            if account_balance is None:
                logger.debug(f"AccountBalance not provided for user {user.id}, fetching from DB.")
                account_balance, created = AccountBalance.objects.get_or_create(user=user)
            else:
                 # 确保传入的是正确的类型，以防万一
                 if not isinstance(account_balance, AccountBalance) or account_balance.user != user:
                     logger.warning(f"Provided account_balance is invalid for user {user.id}. Fetching from DB.")
                     account_balance, created = AccountBalance.objects.get_or_create(user=user)
                 else:
                     logger.debug(f"Using provided AccountBalance for user {user.id}.")
            
            # 只要余额大于0就视为充足
            balance = account_balance.balance
            is_sufficient = balance > Decimal('0')
            
            # 最低消费金额为0.0001
            min_cost = Decimal('0.0001')
            
            # 添加详细日志
            logger.info(f"用户余额检查 - 用户:{user.username}, 余额:{balance}, 充足:{is_sufficient}")
            
            return (is_sufficient, balance, min_cost)
        except Exception as e:
            logger.error(f"检查余额出错: {str(e)}", exc_info=True)
            # 出错时假设余额充足，避免阻止用户正常使用
            # TODO: 考虑在出错时返回更明确的状态，或不允许操作
            return (True, Decimal('0'), Decimal('0'))
    
    @staticmethod
    def get_price_per_token(model_type=None):
        """
        获取当前激活的定价计划的每Token价格
        
        Args:
            model_type: 模型类型（为了保持向后兼容，但不再使用）
            
        Returns:
            tuple: (prompt_price_per_token, completion_price_per_token) 提示词和回复的每Token价格
        """
        try:
            plan = PricingPlan.objects.filter(is_active=True).first()
            if plan:
                # 转换为每个Token的价格
                prompt_price = plan.prompt_price_per_million_tokens / 1000000
                completion_price = plan.completion_price_per_million_tokens / 1000000
                return (prompt_price, completion_price)
            else:
                logger.warning("未找到激活的定价计划，使用默认价格")
                return (Decimal('0.000001'), Decimal('0.000002'))  # 默认价格，提示词较便宜
        except Exception as e:
            logger.error(f"获取定价计划出错: {str(e)}", exc_info=True)
            return (Decimal('0.000001'), Decimal('0.000002'))  # 默认价格
    
    @staticmethod
    @transaction.atomic
    def record_consumption(user, tokens_used, model_type=None, request_type="other", request_content="", request_id=None, prompt_tokens=None, completion_tokens=None):
        """
        记录消费并扣除余额
        
        Args:
            user: 用户对象
            tokens_used: 使用的Token总数量
            model_type: 模型类型（为了保持向后兼容，但不再使用）
            request_type: 请求类型(chat/text/other)
            request_content: 请求内容
            request_id: 请求ID
            prompt_tokens: 提示词token数，如果为None，假设所有tokens都是prompt
            completion_tokens: 回复token数，如果为None，假设为0
            
        Returns:
            ConsumptionRecord: 消费记录对象
        """
        # 计算消费金额
        prices = BillingService.get_price_per_token()
        prompt_price, completion_price = prices
        
        # 如果未提供明确的token分类，则根据请求类型做简单假设
        if prompt_tokens is None and completion_tokens is None:
            if request_type == 'chat':
                # 对话场景，假设60%是提示词，40%是回复
                prompt_tokens = int(tokens_used * 0.6)
                completion_tokens = tokens_used - prompt_tokens
            else:
                # 其他场景，假设全部是提示词
                prompt_tokens = tokens_used
                completion_tokens = 0
        
        # 计算总价格
        prompt_cost = Decimal(prompt_tokens or 0) * prompt_price
        completion_cost = Decimal(completion_tokens or 0) * completion_price
        amount = prompt_cost + completion_cost
        
        # 获取或创建账户余额
        account_balance, created = AccountBalance.objects.get_or_create(user=user)
        
        # 检查余额是否充足
        # if not account_balance.is_balance_sufficient(amount):
        #     # 原本在此处抛出异常，现在改为允许扣费为负
        #     # raise InsufficientBalanceError(f"余额不足，当前余额:{account_balance.balance}，需要:{amount}")
        #     # 可选：如果余额不足，可以记录一个警告日志
        #     logger.warning(f"用户 {user.username} 余额不足，扣费后将变为负数。当前余额:{account_balance.balance}，扣除:{amount}")
        #     pass # 允许继续执行扣费
        # 无论余额是否充足，都执行扣费
        account_balance.balance -= amount
        account_balance.save()
        
        # 记录消费
        consumption = ConsumptionRecord.objects.create(
            user=user,
            tokens_used=tokens_used,
            amount=amount,
            type=request_type,
            request_content=request_content[:1000] if request_content else "",  # 限制长度
            request_id=request_id
        )
        
        # 更新Token使用统计
        today = timezone.now().date()
        token_usage, created = TokenUsage.objects.get_or_create(
            user=user,
            date=today,
            defaults={
                'prompt_tokens': 0,
                'completion_tokens': 0,
                'total_tokens': 0
            }
        )
        
        # 更新token使用情况，区分prompt和completion
        token_usage.prompt_tokens += prompt_tokens or 0
        token_usage.completion_tokens += completion_tokens or 0
        token_usage.total_tokens += tokens_used
        token_usage.save()
        
        return consumption
    
    @staticmethod
    def get_usage_stats(user, start_date=None, end_date=None):
        """
        获取用户的使用统计
        
        Args:
            user: 用户对象
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            dict: 使用统计信息
        """
        query = TokenUsage.objects.filter(user=user)
        
        if start_date:
            query = query.filter(date__gte=start_date)
        if end_date:
            query = query.filter(date__lte=end_date)
        
        # 按日期分组统计
        daily_stats = query.values('date').annotate(
            total=Sum('total_tokens'),
            prompt=Sum('prompt_tokens'),
            completion=Sum('completion_tokens')
        ).order_by('date')
        
        # 总计
        total_stats = query.aggregate(
            total=Sum('total_tokens'),
            prompt=Sum('prompt_tokens'),
            completion=Sum('completion_tokens')
        )
        
        return {
            'daily_stats': list(daily_stats),
            'total_stats': total_stats
        }
    
    @staticmethod
    def get_consumption_records(user, start_date=None, end_date=None, request_type=None, limit=50):
        """
        获取用户的消费记录
        
        Args:
            user: 用户对象
            start_date: 开始日期
            end_date: 结束日期
            request_type: 请求类型
            limit: 记录数量限制
            
        Returns:
            QuerySet: 消费记录查询集
        """
        query = ConsumptionRecord.objects.filter(user=user)
        
        if start_date:
            query = query.filter(created_at__date__gte=start_date)
        if end_date:
            query = query.filter(created_at__date__lte=end_date)
        if request_type:
            query = query.filter(type=request_type)
        
        return query.order_by('-created_at')[:limit] 