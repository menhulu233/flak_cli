from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class BillingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'billing'
    verbose_name = _('计费系统')
    
    def ready(self):
        """应用启动时执行的操作"""
        # 初始化API包装
        try:
            from .middleware import wrap_dify_api
            wrap_dify_api()
        except ImportError:
            pass
