from django.urls import path
from django.views.generic import TemplateView
from .views import (
    AccountBalanceView, 
    ConsumptionRecordView, 
    TokenUsageStatsView, 
    RechargeView,
    PaymentCallbackView,
    PaymentStatusView,
    # SimulatePaymentView # Removed import
    # QRCodeView # 移除这个名字的导入
)

app_name = 'billing'  # 添加应用命名空间

urlpatterns = [
    path('account/balance/', AccountBalanceView.as_view(), name='account_balance'),
    path('account/check/', AccountBalanceView.as_view(), name='account_balance_check'),
    path('consumption/records/', ConsumptionRecordView.as_view(), name='consumption_records'),
    path('usage/stats/', TokenUsageStatsView.as_view(), name='token_usage_stats'),
    path('account/recharge/', RechargeView.as_view(), name='account_recharge'),
    
    # 支付相关路由
    path('payment/callback/<str:payment_method>/', PaymentCallbackView.as_view(), name='payment_callback'),
    path('payment/status/<str:order_id>/', PaymentStatusView.as_view(), name='payment_status'),
    # path('payment/simulate/<str:order_id>/', SimulatePaymentView.as_view(), name='simulate_payment'), # Removed URL pattern
    # 移除 QRCodeView 的路由 (已注释)
    # path('payment/qrcode/<str:order_id>/', QRCodeView.as_view(), name='payment_qrcode'),
]

# 添加主站点URL配置中的路径，因为logs中的404错误是针对/billing/payment/status/路径
# 这个需要添加到主项目的urls.py中
# 在项目根目录的urls.py中添加以下路径:
# path('billing/payment/status/<str:order_id>/', include('billing.urls')),
# 这个注释是提醒添加到主urls.py，不会直接执行 