from django.shortcuts import render, redirect
from django.utils.translation import gettext as _
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from datetime import datetime, timedelta
from .services import BillingService
from .models import AccountBalance, ConsumptionRecord, PaymentOrder, RechargeRecord
from django.contrib.auth import get_user_model
from django.utils import timezone
from django.http import HttpResponse, JsonResponse
from .payments import get_payment_service, process_payment_notification, PaymentError
import json
import logging
from django.conf import settings
from utils.decorators import require_china_verification
import os
from wechatpy.pay import WeChatPay
from wechatpy.exceptions import WeChatPayException, InvalidSignatureException
import xmltodict

logger = logging.getLogger('billing')

# 增加调试日志语句
def debug_log_order_info(order_id):
    """打印订单和余额信息以帮助调试"""
    try:
        order = PaymentOrder.objects.get(order_id=order_id)
        account_balance = AccountBalance.objects.filter(user=order.user).first()
        recharge_record = RechargeRecord.objects.filter(order=order).first()
        
        logger.info("========== 订单调试信息 ==========")
        logger.info(f"订单ID: {order_id}")
        logger.info(f"状态: {order.status}")
        logger.info(f"金额: {order.amount}")
        logger.info(f"积分: {order.credits}")
        logger.info(f"用户: {order.user.username}")
        logger.info(f"交易号: {order.transaction_id}")
        logger.info(f"创建时间: {order.created_at}")
        logger.info(f"支付时间: {order.payment_time}")
        
        if account_balance:
            logger.info(f"当前余额: {account_balance.balance}")
            logger.info(f"最后充值时间: {account_balance.last_recharge_at}")
        else:
            logger.info("用户没有余额记录")
            
        if recharge_record:
            logger.info(f"充值记录: 金额={recharge_record.amount}, 积分={recharge_record.credits}, 时间={recharge_record.created_at}")
        else:
            logger.info("订单没有对应的充值记录")
        
        logger.info("================================")
    except Exception as e:
        logger.error(f"获取订单调试信息失败: {str(e)}")

class AccountBalanceView(APIView):
    """账户余额查询接口"""
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        """获取当前用户的账户余额"""
        # 在这里获取一次 AccountBalance 对象
        account_balance, created = AccountBalance.objects.get_or_create(user=request.user)
        
        # 将获取到的 account_balance 传递给 check_balance
        is_sufficient, balance_unused, min_cost = BillingService.check_balance(
            request.user, 
            account_balance=account_balance # 传入对象
        )
        
        # 使用 account_balance 对象获取余额和其他信息
        return Response({
            'success': True,
            'data': {
                'balance': account_balance.balance, # 直接从对象获取
                'last_recharge_at': account_balance.last_recharge_at,
                'warning_threshold': account_balance.warning_threshold,
                'is_warning': account_balance.warning_balance(),
                'is_sufficient': is_sufficient, # is_sufficient 仍然来自 check_balance
                'min_cost': min_cost
            }
        })
    
    def post(self, request):
        """设置预警阈值"""
        threshold = request.data.get('warning_threshold')
        if not threshold:
            return Response({'error': _('预警阈值不能为空')}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            threshold = float(threshold)
            if threshold < 0:
                return Response({'error': _('预警阈值不能为负数')}, status=status.HTTP_400_BAD_REQUEST)
                
            account_balance, created = AccountBalance.objects.get_or_create(user=request.user)
            account_balance.warning_threshold = threshold
            account_balance.save()
            
            return Response({
                'balance': account_balance.balance,
                'warning_threshold': account_balance.warning_threshold,
                'is_warning': account_balance.warning_balance()
            })
        except ValueError:
            return Response({'error': _('预警阈值必须是数字')}, status=status.HTTP_400_BAD_REQUEST)


class ConsumptionRecordView(APIView):
    """消费记录查询接口"""
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        """获取当前用户的消费记录"""
        try:
            # 解析查询参数
            start_date_str = request.query_params.get('start_date')
            end_date_str = request.query_params.get('end_date')
            record_type = request.query_params.get('type')  # 'recharge' 或 'consumption'
            page = int(request.query_params.get('page', 1))
            page_size = int(request.query_params.get('page_size', 10))
            
            # 处理日期参数
            start_date = None
            end_date = None
            
            if start_date_str:
                try:
                    start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
                except ValueError:
                    return Response({
                        'success': False,
                        'message': _('开始日期格式不正确，应为YYYY-MM-DD')
                    }, status=status.HTTP_400_BAD_REQUEST)
                    
            if end_date_str:
                try:
                    end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
                except ValueError:
                    return Response({
                        'success': False,
                        'message': _('结束日期格式不正确，应为YYYY-MM-DD')
                    }, status=status.HTTP_400_BAD_REQUEST)
            
            # 获取消费记录和充值记录
            records = []
            
            # 根据类型过滤记录
            if record_type == 'recharge':
                # 获取充值记录 - 这里需要实现充值记录的查询
                records = PaymentOrder.objects.filter(
                    user=request.user,
                    status='paid'
                ).order_by('-created_at')
                
                # 格式化充值记录
                formatted_records = []
                for record in records:
                    formatted_records.append({
                        'id': record.id,
                        'amount': record.amount,
                        'type': 'recharge',
                        'description': _('账户充值'),
                        'status': 'success',
                        'created_at': record.payment_time.strftime('%Y-%m-%d %H:%M:%S') if record.payment_time else record.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                    })
                
            elif record_type == 'consumption':
                # 获取消费记录
                records = BillingService.get_consumption_records(
                    user=request.user,
                    start_date=start_date,
                    end_date=end_date,
                    limit=1000  # 设置较大的限制，然后在后面分页
                )
                
                # 格式化消费记录
                formatted_records = []
                for record in records:
                    formatted_records.append({
                        'id': record.id,
                        'tokens_used': record.tokens_used,
                        'amount': record.amount,
                        'type': 'consumption',
                        'description': _('AI对话消费') if record.type == 'chat' else record.type,
                        'status': record.get_status_display(),
                        'created_at': record.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                    })
            else:
                # 获取所有记录
                consumption_records = BillingService.get_consumption_records(
                    user=request.user,
                    start_date=start_date,
                    end_date=end_date,
                    limit=500
                )
                
                recharge_records = PaymentOrder.objects.filter(
                    user=request.user,
                    status='paid'
                ).order_by('-created_at')[:500]
                
                # 格式化消费记录
                formatted_records = []
                
                for record in consumption_records:
                    formatted_records.append({
                        'id': record.id,
                        'tokens_used': record.tokens_used,
                        'amount': record.amount,
                        'type': 'consumption',
                        'description': _('AI对话消费') if record.type == 'chat' else record.type,
                        'status': record.get_status_display(),
                        'created_at': record.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                    })
                
                for record in recharge_records:
                    formatted_records.append({
                        'id': record.id,
                        'amount': record.amount,
                        'type': 'recharge',
                        'description': _('账户充值'),
                        'status': 'success',
                        'created_at': record.payment_time.strftime('%Y-%m-%d %H:%M:%S') if record.payment_time else record.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                    })
                
                # 按创建时间排序
                formatted_records.sort(key=lambda x: x['created_at'], reverse=True)
            
            # 手动分页
            total_records = len(formatted_records)
            start_idx = (page - 1) * page_size
            end_idx = start_idx + page_size
            
            paginated_records = formatted_records[start_idx:end_idx]
            
            # 构建分页响应
            response_data = {
                'success': True,
                'data': {
                    'count': total_records,
                    'next': page + 1 if end_idx < total_records else None,
                    'previous': page - 1 if page > 1 else None,
                    'results': paginated_records
                }
            }
            
            return Response(response_data)
            
        except Exception as e:
            logger.exception(f"获取交易记录异常: {str(e)}")
            return Response({
                'success': False,
                'message': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class TokenUsageStatsView(APIView):
    """Token使用统计接口"""
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        """获取当前用户的Token使用统计"""
        # 解析查询参数
        start_date_str = request.query_params.get('start_date')
        end_date_str = request.query_params.get('end_date')
        model_type = request.query_params.get('model_type')
        
        # 处理日期参数
        start_date = None
        end_date = None
        
        if start_date_str:
            try:
                start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
            except ValueError:
                return Response({'error': _('开始日期格式不正确，应为YYYY-MM-DD')}, status=status.HTTP_400_BAD_REQUEST)
                
        if end_date_str:
            try:
                end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
            except ValueError:
                return Response({'error': _('结束日期格式不正确，应为YYYY-MM-DD')}, status=status.HTTP_400_BAD_REQUEST)
        
        # 默认查询最近30天
        if not start_date:
            start_date = datetime.now().date() - timedelta(days=30)
        if not end_date:
            end_date = datetime.now().date()
        
        # 获取使用统计
        stats = BillingService.get_usage_stats(
            user=request.user,
            start_date=start_date,
            end_date=end_date,
            model_type=model_type
        )
        
        return Response(stats)


class RechargeView(APIView):
    """账户充值接口"""
    permission_classes = [IsAuthenticated]
    
    @require_china_verification
    def get(self, request):
        """获取充值页面或充值选项"""
        # 检查是否是 API 请求
        if request.headers.get('Accept', '').startswith('application/json'):
            # API 请求返回 JSON 数据
            account_balance, created = AccountBalance.objects.get_or_create(user=request.user)
            return Response({
                'success': True,
                'data': {
                    'balance': account_balance.balance,
                    'last_recharge_at': account_balance.last_recharge_at,
                    'warning_threshold': account_balance.warning_threshold,
                    'is_warning': account_balance.warning_balance()
                }
            })
        else:
            # Web 请求返回充值页面
            return render(request, 'billing/recharge.html')
    
    @require_china_verification
    def post(self, request):
        """处理充值请求"""
        try:
            # 解析参数
            amount = request.data.get('amount')
            payment_method = request.data.get('payment_method')
            
            if not amount or not payment_method:
                return Response({
                    'error': _('金额和支付方式不能为空')
                }, status=status.HTTP_400_BAD_REQUEST)
            
            # 验证金额
            try:
                amount = float(amount)
                if amount <= 0:
                    return Response({
                        'error': _('充值金额必须大于0')
                    }, status=status.HTTP_400_BAD_REQUEST)
            except ValueError:
                return Response({
                    'error': _('金额格式不正确')
                }, status=status.HTTP_400_BAD_REQUEST)
            
            # 验证支付方式
            if payment_method not in ['wechat', 'paypal']:
                return Response({
                    'error': _('不支持的支付方式')
                }, status=status.HTTP_400_BAD_REQUEST)
            
            # 创建支付服务
            payment_service = get_payment_service(request.user, amount, payment_method)
            
            # 创建支付
            payment_result = payment_service.create_payment()
            
            # 返回支付信息
            return Response(payment_result)
            
        except PaymentError as e:
            return Response({
                'error': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logger.exception(f"创建充值订单异常: {str(e)}")
            return Response({
                'error': _('创建充值订单失败，请稍后重试')
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def admin_recharge(self, request):
        """充值账户余额（仅管理员可用）"""
        # 检查用户是否为管理员
        if not request.user.is_staff:
            return Response({'error': _('没有权限执行此操作')}, status=status.HTTP_403_FORBIDDEN)
        
        # 解析参数
        user_id = request.data.get('user_id')
        amount = request.data.get('amount')
        
        if not user_id or not amount:
            return Response({'error': _('用户ID和金额不能为空')}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            # 获取用户
            User = get_user_model()
            user = User.objects.get(id=user_id)
            
            # 转换金额
            amount = float(amount)
            if amount <= 0:
                return Response({'error': _('充值金额必须大于0')}, status=status.HTTP_400_BAD_REQUEST)
            
            # 获取或创建账户余额
            account_balance, created = AccountBalance.objects.get_or_create(user=user)
            
            # 更新余额
            account_balance.balance += amount
            account_balance.last_recharge_at = timezone.now()
            account_balance.save()
            
            return Response({
                'user_id': user.id,
                'username': user.username,
                'balance': account_balance.balance,
                'recharge_amount': amount,
                'recharge_time': account_balance.last_recharge_at
            })
            
        except User.DoesNotExist:
            return Response({'error': _('用户不存在')}, status=status.HTTP_404_NOT_FOUND)
        except ValueError:
            return Response({'error': _('金额必须是数字')}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class PaymentCallbackView(APIView):
    """支付回调处理接口 (V2, 使用 wechatpy)"""
    permission_classes = []

    def post(self, request, payment_method):
        """处理微信支付 V2 回调通知"""
        if payment_method != 'wechat':
            logger.warning(f"[Callback-wechatpy V2] 收到不支持的回调方法: {payment_method}")
            return HttpResponse("Unsupported payment method", status=400)

        # 获取 V2 回调 XML 数据
        try:
            body = request.body
            # 使用 xmltodict 解析 XML
            # 注意：xmltodict.parse 返回的字典可能包含根节点，如 {'xml': {...}}
            parsed_data = xmltodict.parse(body)
            # 假设微信回调的根节点是 'xml'
            data = parsed_data.get('xml', parsed_data) # 提取根节点下的数据，或使用原始解析结果
            if not isinstance(data, dict):
                 logger.error(f"解析微信支付 V2 回调XML后的数据格式不正确: {parsed_data}")
                 raise ValueError("Parsed XML is not a dictionary")
            logger.info(f"微信支付 V2 回调接收 (wechatpy, XML解析后): {data}")
        except Exception as e:
            logger.error(f"解析微信支付 V2 回调XML失败 (wechatpy): {e}")
            return HttpResponse('<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[XML解析失败]]></return_msg></xml>', content_type='application/xml')

        # --- V2 回调签名验证 --- 
        try:
            pay_client = WeChatPay(
                 appid=settings.WECHAT_PAY_APPID,
                 api_key=settings.WECHAT_PAY_API_KEY,
                 mch_id=settings.WECHAT_PAY_MCH_ID
            )
            if not pay_client.check_signature(data):
                 logger.error("微信支付 V2 回调签名验证失败 (wechatpy)")
                 return HttpResponse('<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[签名验证失败]]></return_msg></xml>', content_type='application/xml')
            logger.info("微信支付 V2 回调签名验证成功 (wechatpy)")
        except InvalidSignatureException:
             logger.error("微信支付 V2 回调签名验证失败 (wechatpy InvalidSignatureException)") 
             return HttpResponse('<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[签名验证失败]]></return_msg></xml>', content_type='application/xml')
        except Exception as e:
             logger.exception(f"执行微信支付 V2 签名验证时出错 (wechatpy): {e}")
             return HttpResponse('<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[验签异常]]></return_msg></xml>', content_type='application/xml')
        # --- 签名验证结束 --- 

        # 处理业务逻辑
        try:
            if process_payment_notification(payment_method, data):
                logger.info("微信支付 V2 回调业务处理成功 (wechatpy)")
                return HttpResponse('<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>', content_type='application/xml')
            else:
                logger.error("微信支付 V2 回调业务处理失败 (wechatpy)")
                return HttpResponse('<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[业务处理失败]]></return_msg></xml>', content_type='application/xml')
        except Exception as e:
            logger.exception(f"处理微信支付 V2 回调业务逻辑时发生未知错误 (wechatpy): {str(e)}")
            return HttpResponse('<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[服务器内部错误]]></return_msg></xml>', content_type='application/xml')

class PaymentStatusView(APIView):
    """支付状态查询接口"""
    permission_classes = [IsAuthenticated]
    
    def get(self, request, order_id):
        try:
            order = PaymentOrder.objects.get(order_id=order_id, user=request.user)
            payment_service = get_payment_service(request.user, order.amount, order.payment_method)
            status_result = payment_service.query_order_status(order_id)
            return Response(status_result)
        except PaymentOrder.DoesNotExist:
            return Response({'error': _('订单不存在')}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            logger.exception(f"查询支付状态异常 (view): {str(e)}")
            return Response({'error': _('查询支付状态失败')}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
