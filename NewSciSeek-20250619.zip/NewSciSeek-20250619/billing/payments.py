# -*- coding: utf-8 -*-
"""
处理支付相关逻辑，包括创建订单、处理支付成功、集成微信支付等。
"""

import uuid
import time
import logging
import random
import string
import json
from decimal import Decimal

# Django imports
from django.conf import settings
from django.utils import timezone
from django.utils.translation import gettext as _
from django.urls import reverse

# Third-party imports
from wechatpy.pay import WeChatPay
from wechatpy.exceptions import WeChatPayException

# Local imports
from .models import PaymentOrder, RechargeRecord, AccountBalance

logger = logging.getLogger('billing')

# 移除 weixin 库的导入注释
# from weixin import WeixinPay, WeixinError


class PaymentError(Exception):
    """支付相关异常基类"""
    pass

class WeChatConfigError(PaymentError):
    """微信支付配置错误异常"""
    pass


def generate_order_id():
    """生成唯一的支付订单号 (ORDER + timestamp + 8位随机字符)"""
    timestamp = int(time.time())
    random_str = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
    return f"ORDER{timestamp}{random_str}"


class PaymentBase:
    """支付处理基类，定义通用流程"""
    def __init__(self, user, amount, payment_method):
        if not isinstance(amount, Decimal):
            try:
                amount = Decimal(amount)
            except Exception:
                raise ValueError("支付金额必须是有效的数字或 Decimal 类型")
        if amount <= 0:
            raise ValueError("支付金额必须大于 0")

        self.user = user
        self.amount = amount
        self.payment_method = payment_method
        # 假设积分与金额比例为 1:1，子类可覆盖
        self.credits = self.amount

    def create_order(self):
        """
        在数据库中创建一条支付订单记录。

        Returns:
            PaymentOrder: 创建的支付订单对象。
        """
        order_id = generate_order_id()
        order = PaymentOrder.objects.create(
            order_id=order_id,
            user=self.user,
            amount=self.amount,
            credits=self.credits,
            payment_method=self.payment_method,
            status='pending'
        )
        logger.info(f"创建订单成功: ID={order_id}, 用户={self.user.username}, 金额={self.amount}, 方式={self.payment_method}")
        return order

    def process_payment_success(self, order, transaction_id=None):
        """
        处理支付成功的逻辑：更新订单状态、创建充值记录、更新用户余额。

        Args:
            order (PaymentOrder): 需要处理的支付订单对象。
            transaction_id (str, optional): 支付平台返回的交易流水号。Defaults to None.

        Returns:
            RechargeRecord: 创建的充值记录对象，如果订单已处理则返回 None。
        """
        if order.status == 'paid':
            logger.warning(f"订单 {order.order_id} 状态已为 'paid'，跳过支付成功处理")
            return None # 或者返回已存在的 RechargeRecord

        logger.info(f"开始处理支付成功: 订单={order.order_id}, 用户={order.user.username}, 金额={order.amount}")
        order.status = 'paid'
        order.payment_time = timezone.now()
        if transaction_id:
            order.transaction_id = transaction_id
        order.save(update_fields=['status', 'payment_time', 'transaction_id'])
        logger.info(f"订单状态更新为 'paid': {order.order_id}")

        # 使用 get_or_create 处理账户余额，避免并发问题
        account_balance, created = AccountBalance.objects.get_or_create(user=order.user)
        old_balance = account_balance.balance

        # 检查是否已存在对应的充值记录，防止重复创建 (例如重复收到通知)
        recharge_record, record_created = RechargeRecord.objects.get_or_create(
            order=order,
            defaults={
                'user': order.user,
                'amount': order.amount,
                'credits': order.credits,
            }
        )
        # Log the result of get_or_create for RechargeRecord
        logger.info(f"[process_payment_success] RechargeRecord.get_or_create for order {order.order_id} returned: record_created={record_created}")

        if record_created:
            # Log entering the balance update block
            logger.info(f"[process_payment_success] Entering balance update block for order {order.order_id}. Old balance: {old_balance}")
            
            logger.info(f"充值记录创建成功: 订单={order.order_id}, 积分={order.credits}, 流水号={transaction_id}")
            # 只有在新创建记录时才更新余额
            account_balance.balance += order.credits
            account_balance.last_recharge_at = timezone.now()
            account_balance.save(update_fields=['balance', 'last_recharge_at'])
            
            # Log after saving the updated balance
            logger.info(f"[process_payment_success] User {order.user.username} balance saved. New balance: {account_balance.balance}")
            logger.info(f"用户 {order.user.username} 余额更新: {old_balance} -> {account_balance.balance} (+{order.credits})")
        else:
            # Log skipping the balance update block
            logger.warning(f"[process_payment_success] Skipping balance update for order {order.order_id} because record_created is False.")
            logger.warning(f"订单 {order.order_id} 已存在充值记录，未重复创建或更新余额。")

        logger.info(f"支付成功处理完成: 订单={order.order_id}")
        return recharge_record


class WechatPayment(PaymentBase):
    """微信支付V2接口实现 (使用 wechatpy 库)"""
    def __init__(self, user, amount):
        super().__init__(user, amount, 'wechat')
        self.wechat_pay = self._initialize_wechat_client()

    def _initialize_wechat_client(self):
        """初始化微信支付 V2 客户端"""
        try:
            appid = settings.WECHAT_PAY_APPID
            mch_id = settings.WECHAT_PAY_MCH_ID
            api_key = settings.WECHAT_PAY_API_KEY
            
            # Log the values read directly from settings
            logger.debug(f"[WeChat Init] Reading from settings - APPID: {appid}, MCH_ID: {mch_id}, API_KEY: {'*' * len(api_key) if api_key else 'None'}")

            if not all([appid, mch_id, api_key]):
                # Log the exact values causing the failure
                logger.error(f"[WeChat Init] Config check failed! APPID='{appid}', MCH_ID='{mch_id}', API_KEY present: {bool(api_key)}")
                raise WeChatConfigError("微信支付配置不完整 (APPID, MCH_ID, API_KEY 必须设置)")

            logger.debug("初始化 wechatpy.WeChatPay V2 客户端...")
            client = WeChatPay(
                appid=appid,
                api_key=api_key, # V2 使用这个 key
                mch_id=mch_id,
                # mch_cert=settings.WECHAT_PAY_MCH_CERT, # V2 退款/企业付款等需要证书
                # mch_key=settings.WECHAT_PAY_MCH_KEY # V2 退款/企业付款等需要证书
            )
            logger.debug("wechatpy.WeChatPay V2 客户端初始化成功。")
            return client
        except AttributeError as e:
            logger.error(f"微信支付配置缺失，请检查 Django settings: {e}")
            raise WeChatConfigError(f"微信支付配置项缺失: {e}")
        except Exception as e:
            logger.exception(f"初始化 wechatpy.WeChatPay V2 客户端失败: {e}")
            raise PaymentError(f"初始化微信支付V2客户端时发生错误: {e}")

    def create_payment(self):
        """
        创建微信 Native 支付（扫码支付）。

        Returns:
            dict: 包含订单信息和二维码链接。
                  {
                      'order_id': str,
                      'amount': float,
                      'qr_code_url': str,
                      'payment_method': 'wechat'
                  }
        Raises:
            PaymentError: 创建支付失败或微信接口返回错误。
        """
        order = self.create_order()

        try:
            notify_url = settings.WECHAT_PAY_NOTIFY_URL
            if not notify_url:
                raise WeChatConfigError("微信支付回调地址 WECHAT_PAY_NOTIFY_URL 未配置")

            logger.info(f"准备调用微信 Native 支付统一下单: 订单={order.order_id}, 金额={order.amount}")
            # Log the MCH ID being used
            logger.debug(f"[WeChat Pay] Using MCH ID: {self.wechat_pay.mch_id}") 
            result = self.wechat_pay.order.create(
                trade_type='NATIVE',
                body=f'充值 - {order.order_id}', # 建议包含订单号
                out_trade_no=order.order_id,
                total_fee=int(order.amount * 100), # 微信支付金额单位为分
                notify_url=notify_url,
                # spbill_create_ip 建议传入服务器外网 IP (Native 支付时非用户 IP)
                spbill_create_ip=getattr(settings, 'SERVER_EXTERNAL_IP', '127.0.0.1')
            )
            logger.debug(f"微信 Native 支付统一下单接口返回: {result}")

            if result.get('return_code') == 'SUCCESS' and result.get('result_code') == 'SUCCESS':
                qr_code_url = result.get('code_url')
                if not qr_code_url:
                     logger.error(f"微信 Native 支付创建成功但未返回 code_url: 订单={order.order_id}")
                     raise PaymentError("创建 Native 支付失败: 未获取到 code_url")

                logger.info(f"微信 Native 支付创建成功: 订单={order.order_id}, QR Code URL 已获取")
                return {
                    'order_id': order.order_id,
                    'amount': float(order.amount),
                    'qr_code_url': qr_code_url,
                    'payment_method': 'wechat'
                }
            else:
                error_msg = result.get('err_code_des') or result.get('return_msg', '未知错误')
                logger.error(f"创建微信 Native 支付失败: {error_msg} (Return: {result.get('return_code')}, Result: {result.get('result_code')}), 订单={order.order_id}")
                raise PaymentError(f"创建支付失败: {error_msg}")

        except WeChatPayException as e:
            logger.exception(f"微信 Native 支付 API 调用异常: {e}, 订单={order.order_id}")
            raise PaymentError(f"创建支付失败: 微信接口异常 ({e})")
        except WeChatConfigError as e:
            logger.error(f"微信支付配置错误: {e}")
            raise e # 直接抛出配置错误
        except Exception as e:
            logger.exception(f"创建微信 Native 支付时发生未知异常: {e}, 订单={order.order_id}")
            # DEBUG 模式下的模拟返回已移除，应统一抛出异常
            raise PaymentError(f"创建微信 Native 支付时发生内部错误: {e}")

    def create_jsapi_payment(self, openid, spbill_create_ip):
        """
        创建微信 JSAPI 支付（公众号/小程序内支付）。

        Args:
            openid (str): 用户的 OpenID。
            spbill_create_ip (str): 发起支付请求的终端用户 IP 地址。

        Returns:
            dict: 包含传递给前端 JSAPI 调用的支付参数。
                  参考 wechatpy 文档获取所需参数结构。
        Raises:
            PaymentError: 创建支付失败或微信接口返回错误。
            WeChatConfigError: 配置缺失。
        """
        # JSAPI 支付需要 trade_type='JSAPI' 和 openid 参数
        order = self.create_order()

        try:
            notify_url = settings.WECHAT_PAY_NOTIFY_URL
            if not notify_url:
                raise WeChatConfigError("微信支付回调地址 WECHAT_PAY_NOTIFY_URL 未配置")
            if not openid:
                 raise ValueError("创建 JSAPI 支付必须提供用户的 OpenID")
            if not spbill_create_ip:
                 raise ValueError("创建 JSAPI 支付必须提供用户的 IP 地址 (spbill_create_ip)")

            logger.info(f"准备调用微信 JSAPI 支付统一下单: 订单={order.order_id}, 用户OpenID={openid[:5]}..., IP={spbill_create_ip}")
            result = self.wechat_pay.order.create(
                trade_type='JSAPI',
                body=f'充值 - {order.order_id}',
                out_trade_no=order.order_id,
                total_fee=int(order.amount * 100),
                notify_url=notify_url,
                openid=openid,
                spbill_create_ip=spbill_create_ip
            )
            logger.debug(f"微信 JSAPI 支付统一下单接口返回: {result}")

            if result.get('return_code') == 'SUCCESS' and result.get('result_code') == 'SUCCESS':
                prepay_id = result.get('prepay_id')
                if not prepay_id:
                    logger.error(f"微信 JSAPI 支付创建成功但未返回 prepay_id: 订单={order.order_id}")
                    raise PaymentError("创建 JSAPI 支付失败: 未获取到 prepay_id")

                # 生成前端调起支付所需的参数 (使用 wechatpy 的辅助方法)
                jsapi_params = self.wechat_pay.jsapi.get_jsapi_params(prepay_id=prepay_id)
                logger.info(f"微信 JSAPI 支付创建成功: 订单={order.order_id}, Prepay ID={prepay_id}")

                # 返回订单信息和前端支付参数
                return {
                    'order_id': order.order_id,
                    'amount': float(order.amount),
                    'jsapi_params': jsapi_params, # 包含 appId, timeStamp, nonceStr, package, signType, paySign
                    'payment_method': 'wechat_jsapi'
                }
            else:
                error_msg = result.get('err_code_des') or result.get('return_msg', '未知错误')
                logger.error(f"创建微信 JSAPI 支付失败: {error_msg} (Return: {result.get('return_code')}, Result: {result.get('result_code')}), 订单={order.order_id}")
                raise PaymentError(f"创建 JSAPI 支付失败: {error_msg}")

        except WeChatPayException as e:
            logger.exception(f"微信 JSAPI 支付 API 调用异常: {e}, 订单={order.order_id}")
            raise PaymentError(f"创建 JSAPI 支付失败: 微信接口异常 ({e})")
        except WeChatConfigError as e:
            logger.error(f"微信支付配置错误: {e}")
            raise e
        except ValueError as e:
             logger.error(f"创建 JSAPI 支付参数错误: {e}")
             raise e
        except Exception as e:
            logger.exception(f"创建微信 JSAPI 支付时发生未知异常: {e}, 订单={order.order_id}")
            raise PaymentError(f"创建微信 JSAPI 支付时发生内部错误: {e}")


    def create_h5_payment(self, spbill_create_ip, wap_url=None, wap_name=None):
        """
        创建微信 H5 支付 (MWEB, 用于微信客户端外的手机浏览器)。

        Args:
            spbill_create_ip (str): 发起支付请求的终端用户 IP 地址。
            wap_url (str, optional): WAP 网站的 URL 地址。如果为 None，则尝试从 settings 读取。
            wap_name (str, optional): WAP 网站的名称。如果为 None，则尝试从 settings 读取。

        Returns:
            dict: 包含订单信息和用于重定向的 mweb_url。
                  {
                      'order_id': str,
                      'amount': float,
                      'mweb_url': str,
                      'payment_method': 'wechat_h5'
                  }
        Raises:
            PaymentError: 创建支付失败或微信接口返回错误。
            WeChatConfigError: 配置缺失或 H5 相关配置不足。
            ValueError: 缺少必要的参数 (spbill_create_ip)。
        """
        order = self.create_order()

        if not spbill_create_ip:
            raise ValueError("创建 H5 支付必须提供用户的 IP 地址 (spbill_create_ip)")

        # 获取 H5 支付所需的 scene_info 配置
        wap_url = wap_url or getattr(settings, 'WECHAT_PAY_H5_WAP_URL', None)
        wap_name = wap_name or getattr(settings, 'WECHAT_PAY_H5_WAP_NAME', None)

        if not wap_url or not wap_name:
            logger.error("微信 H5 支付所需的 WAP URL 或 WAP Name 未配置在 settings 中 (WECHAT_PAY_H5_WAP_URL, WECHAT_PAY_H5_WAP_NAME)")
            raise WeChatConfigError("微信 H5 支付配置不完整：缺少 WAP URL 或 WAP Name")

        scene_info = {
            "h5_info": {
                "type": "Wap",
                "wap_url": wap_url,
                "wap_name": wap_name
            }
        }
        # 将字典转换为 JSON 字符串
        scene_info_str = json.dumps(scene_info)

        try:
            notify_url = settings.WECHAT_PAY_NOTIFY_URL
            if not notify_url:
                raise WeChatConfigError("微信支付回调地址 WECHAT_PAY_NOTIFY_URL 未配置")

            logger.info(f"准备调用微信 H5 支付统一下单: 订单={order.order_id}, 金额={order.amount}, IP={spbill_create_ip}, Scene={scene_info_str}")
            result = self.wechat_pay.order.create(
                trade_type='MWEB',
                body=f'充值 - {order.order_id}',
                out_trade_no=order.order_id,
                total_fee=int(order.amount * 100),
                notify_url=notify_url,
                spbill_create_ip=spbill_create_ip, # 使用传入的用户 IP
                scene_info=scene_info_str
            )
            logger.debug(f"微信 H5 支付统一下单接口返回: {result}")

            if result.get('return_code') == 'SUCCESS' and result.get('result_code') == 'SUCCESS':
                mweb_url = result.get('mweb_url')
                if not mweb_url:
                    logger.error(f"微信 H5 支付创建成功但未返回 mweb_url: 订单={order.order_id}")
                    raise PaymentError("创建 H5 支付失败: 未获取到 mweb_url")

                logger.info(f"微信 H5 支付创建成功: 订单={order.order_id}, Mweb URL 已获取")
                return {
                    'order_id': order.order_id,
                    'amount': float(order.amount),
                    'mweb_url': mweb_url, # 前端重定向到此 URL
                    'payment_method': 'wechat_h5'
                }
            else:
                error_msg = result.get('err_code_des') or result.get('return_msg', '未知错误')
                logger.error(f"创建微信 H5 支付失败: {error_msg} (Return: {result.get('return_code')}, Result: {result.get('result_code')}), 订单={order.order_id}")
                if result.get('err_code') == 'ORDERPAID':
                     logger.warning(f"H5 支付创建失败，订单已支付: {order.order_id}")
                     raise PaymentError("订单已支付，无需重复创建")
                raise PaymentError(f"创建 H5 支付失败: {error_msg}")

        except WeChatPayException as e:
            logger.exception(f"微信 H5 支付 API 调用异常: {e}, 订单={order.order_id}")
            raise PaymentError(f"创建 H5 支付失败: 微信接口异常 ({e})")
        except WeChatConfigError as e:
            logger.error(f"微信支付配置错误: {e}")
            raise e
        except ValueError as e:
             logger.error(f"创建 H5 支付参数错误: {e}")
             raise e
        except Exception as e:
            logger.exception(f"创建微信 H5 支付时发生未知异常: {e}, 订单={order.order_id}")
            raise PaymentError(f"创建微信 H5 支付时发生内部错误: {e}")

    def query_order_status(self, order_id):
        """
        查询微信支付订单状态 (V2)。

        Args:
            order_id (str): 商户订单号。

        Returns:
            dict: 包含订单状态信息。
                  {
                      'order_id': str,
                      'status': str ('paid', 'pending', etc.),
                      'paid': bool,
                      'amount': float,
                      'error': str (optional, if query failed or status issue),
                      'trade_state': str (optional, WeChat's trade state),
                      'trade_state_desc': str (optional, WeChat's state description)
                  }
        Raises:
            PaymentError: 查询过程中发生严重错误或本地订单不存在。
        """
        try:
            order = PaymentOrder.objects.get(order_id=order_id)
            logger.info(f"查询订单状态: 本地状态={order.status}, 订单={order_id}")

            # 如果本地状态已经是 paid，直接返回成功状态
            if order.status == 'paid':
                return {
                    'order_id': order.order_id,
                    'status': order.status,
                    'paid': True,
                    'amount': float(order.amount)
                }

            # 本地未支付，向微信查询
            try:
                logger.info(f"向微信查询订单状态: 订单={order_id}")
                result = self.wechat_pay.order.query(out_trade_no=order_id)
                logger.debug(f"微信订单查询接口返回: {result}")

                if result.get('return_code') == 'SUCCESS' and result.get('result_code') == 'SUCCESS':
                    trade_state = result.get('trade_state')
                    logger.info(f"微信端订单状态: {trade_state}, 订单={order_id}")

                    if trade_state == 'SUCCESS':
                        # 微信端支付成功，核对金额并处理本地订单
                        transaction_id = result.get('transaction_id')
                        total_paid_fen = int(result.get('total_fee', 0))
                        expected_fen = int(order.amount * 100)

                        if expected_fen == total_paid_fen:
                            logger.info(f"微信支付成功且金额匹配: 订单={order_id}，准备更新本地状态...")
                            # 调用支付成功处理逻辑
                            self.process_payment_success(order, transaction_id)
                            return {
                                'order_id': order.order_id,
                                'status': 'paid', # 返回更新后的状态
                                'paid': True,
                                'amount': float(order.amount)
                            }
                        else:
                            logger.error(f"订单 {order_id} 微信支付成功，但金额不匹配: 预期={expected_fen}分, 实际={total_paid_fen}分")
                            # 重要：金额不匹配，不能标记为成功，需要人工介入
                            return {
                                'order_id': order.order_id,
                                'status': order.status, # 保持本地状态
                                'paid': False,
                                'amount': float(order.amount),
                                'error': '支付金额不匹配',
                                'trade_state': trade_state
                            }
                    else:
                        # 微信端未支付成功 (e.g., USERPAYING, NOTPAY, CLOSED, REVOKED, PAYERROR)
                         logger.info(f"微信端订单状态为非 SUCCESS: {trade_state} ({result.get('trade_state_desc')}), 订单={order_id}")
                         return {
                            'order_id': order.order_id,
                            'status': order.status,
                            'paid': False,
                            'amount': float(order.amount),
                            'trade_state': trade_state,
                            'trade_state_desc': result.get('trade_state_desc')
                        }
                else:
                    # 查询接口本身失败 (return_code 或 result_code 不为 SUCCESS)
                    error_msg = result.get('err_code_des') or result.get('return_msg', '未知错误')
                    logger.error(f"查询微信订单状态失败: {error_msg} (Return: {result.get('return_code')}, Result: {result.get('result_code')}), 订单={order_id}")
                    if result.get('err_code') == 'ORDERNOTEXIST':
                         # 微信端订单不存在
                         logger.warning(f"微信端订单不存在: {order_id}")
                         return {
                            'order_id': order.order_id,
                            'status': order.status,
                            'paid': False,
                            'amount': float(order.amount),
                            'error': '微信支付订单不存在'
                         }
                    # 其他查询失败情况
                    return {
                        'order_id': order.order_id,
                        'status': order.status,
                        'paid': False,
                        'amount': float(order.amount),
                        'error': f'查询微信订单失败: {error_msg}'
                    }

            except WeChatPayException as e:
                logger.exception(f"查询微信订单状态 API 调用异常: {e}, 订单={order_id}")
                # API 调用本身失败，返回包含错误信息的未支付状态
                return {
                    'order_id': order.order_id,
                    'status': order.status,
                    'paid': False,
                    'amount': float(order.amount),
                    'error': f'查询微信接口异常: {e}'
                }
            except Exception as e:
                 logger.exception(f"查询微信订单状态时发生未知异常: {e}, 订单={order_id}")
                 # 未知内部错误，也返回包含错误信息的未支付状态
                 return {
                     'order_id': order.order_id,
                     'status': order.status,
                     'paid': False,
                     'amount': float(order.amount),
                     'error': f'查询订单状态时发生内部错误: {e}'
                 }

        except PaymentOrder.DoesNotExist:
            logger.error(f"查询订单状态失败：本地订单不存在: {order_id}")
            raise PaymentError(f"订单 {order_id} 不存在")


def get_payment_service(user, amount, payment_method):
    """
    根据支付方式获取对应的支付服务实例。

    Args:
        user: 用户对象。
        amount: 支付金额。
        payment_method (str): 支付方式标识符 (e.g., 'wechat').

    Returns:
        PaymentBase: 对应支付方式的服务实例。

    Raises:
        PaymentError: 如果是不支持的支付方式。
        ValueError: 如果金额无效。
        WeChatConfigError: 如果微信支付配置有问题。
    """
    logger.debug(f"获取支付服务: 用户={user.username}, 金额={amount}, 方式={payment_method}")
    if payment_method in ['wechat', 'wechat_jsapi', 'wechat_h5']: # 统一使用 WechatPayment 类
        return WechatPayment(user, amount)
    # elif payment_method == 'alipay': # 示例：将来可扩展支付宝
    #     return AlipayPayment(user, amount)
    else:
        logger.error(f"请求了不支持的支付方式: {payment_method}")
        raise PaymentError(f"不支持的支付方式: {payment_method}")


def process_payment_notification(payment_method, data):
    """
    处理支付平台发送的异步回调通知 (V2)。

    **重要:** 调用此函数前，必须已在接收通知的视图中完成签名的验证！
            此函数假定传入的 `data` 是可信的。

    Args:
        payment_method (str): 支付方式标识符 (e.g., 'wechat').
        data (dict): 从支付平台回调请求中解析出的数据字典 (已经过签名验证)。

    Returns:
        bool: 如果处理成功返回 True，否则返回 False。
              注意：返回 False 表示处理失败，支付平台可能会重试通知。
    """
    logger.info(f"开始处理支付回调通知: 方式={payment_method}")
    logger.debug(f"回调数据 (已验证签名): {data}") # 注意不要记录敏感信息

    try:
        if payment_method == 'wechat':
            # 提取微信 V2 回调的核心数据
            return_code = data.get('return_code')
            result_code = data.get('result_code')
            order_id = data.get('out_trade_no')
            transaction_id = data.get('transaction_id') # 微信支付订单号
            total_fee_str = data.get('total_fee') # 金额（分）

            # 1. 检查通信标识和业务结果
            if return_code != 'SUCCESS':
                logger.error(f"微信回调处理失败: 通信标识不为 SUCCESS. Return Msg: {data.get('return_msg')}, 订单={order_id}")
                return False # 通信失败，告知微信无需重试

            if result_code != 'SUCCESS':
                logger.error(f"微信回调处理失败: 业务结果不为 SUCCESS. Err Code: {data.get('err_code')}, Err Desc: {data.get('err_code_des')}, 订单={order_id}")
                # 支付本身失败，但我们收到了通知，应该认为处理成功，告知微信无需重试
                # 可以根据业务需求决定是否更新订单状态为 'failed' 等
                return True # 返回 True，避免微信重试

            # 2. 检查关键数据是否存在
            if not all([order_id, transaction_id, total_fee_str]):
                 logger.error(f"微信回调处理失败: 关键数据缺失 (order_id, transaction_id, total_fee). Data: {data}")
                 return False # 数据不完整，处理失败，让微信重试

            try:
                total_fee = int(total_fee_str)
            except (ValueError, TypeError):
                logger.error(f"微信回调处理失败: total_fee 格式错误 ('{total_fee_str}'). 订单={order_id}")
                return False # 数据格式错误，处理失败

            # 3. 查找本地订单并验证金额
            try:
                order = PaymentOrder.objects.get(order_id=order_id)
                expected_fee = int(order.amount * 100)

                if expected_fee != total_fee:
                     logger.error(f"微信回调处理失败: 订单 {order_id} 金额不匹配. 预期={expected_fee}分, 实际={total_fee}分")
                     # 金额不匹配是严重问题，需要人工介入，但应该告知微信处理成功，避免重试
                     # 可以记录异常状态
                     order.status = 'error_amount_mismatch'
                     order.save(update_fields=['status'])
                     return True # 返回 True

                # 4. 调用核心支付成功处理逻辑
                # 使用 PaymentBase 实例来调用，确保逻辑一致性
                # 注意：此时 payment_method 可能与 order.payment_method 不同（如 wechat_h5 vs wechat），但处理逻辑相同
                payment_service = PaymentBase(order.user, order.amount, order.payment_method)
                recharge_record = payment_service.process_payment_success(order, transaction_id)

                if recharge_record is None and order.status == 'paid':
                    logger.warning(f"微信回调: 订单 {order_id} 已处理过，跳过重复处理。")
                    # 即使是重复通知，也应返回成功，避免微信继续发送
                    return True
                elif recharge_record:
                    logger.info(f"微信支付回调处理成功: 订单={order_id}, 流水号={transaction_id}")
                    return True
                else:
                    # process_payment_success 内部逻辑应该处理了所有情况，理论上不应到达这里
                    logger.error(f"微信回调处理: process_payment_success 未返回有效结果，订单={order_id}")
                    return False # 未知内部错误，让微信重试

            except PaymentOrder.DoesNotExist:
                logger.error(f"微信回调处理失败: 订单不存在 {order_id}")
                # 订单不存在，告知微信处理成功，避免无效重试
                return True # 返回 True

        else:
            logger.error(f"处理回调通知失败: 不支持的支付方式 '{payment_method}'")
            return False # 不支持的方式，处理失败

    except Exception as e:
        # 捕获所有未预料的异常，记录日志，并返回 False 让微信重试
        logger.exception(f"处理支付回调通知时发生未知异常: {e}. Method={payment_method}, Data={data}")
        return False 