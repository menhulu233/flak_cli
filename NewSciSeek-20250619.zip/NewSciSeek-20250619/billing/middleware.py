"""
Token计费中间件
用于拦截Dify API请求，进行Token计数和计费
"""
import json
import uuid
from functools import wraps
from django.contrib.auth.models import AnonymousUser
from utils.logger import get_logger
from utils.exceptions import InsufficientBalanceError
from .services import TokenCounter, BillingService
from utils.dify_api import dify_client

logger = get_logger('billing_middleware')

def token_billing_required(request_type):
    """
    Token计费装饰器
    用于API视图函数的装饰，确保在调用API前后进行Token计费
    
    Args:
        request_type: 请求类型(chat/text/other)
    """
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(request, *args, **kwargs):
            # 匿名用户不进行计费
            if isinstance(request.user, AnonymousUser):
                return view_func(request, *args, **kwargs)
            
            # 生成请求ID
            request_id = str(uuid.uuid4())
            
            # 根据请求类型提取请求内容和预估Token
            request_content = ""
            estimated_tokens = 0
            model_type = request.data.get('model', 'gpt-3.5-turbo')  # 默认模型
            
            if request_type == 'chat':
                messages = request.data.get('messages', [])
                request_content = json.dumps(messages)
                estimated_tokens = TokenCounter.count_tokens_from_messages(messages)
            elif request_type == 'text':
                prompt = request.data.get('prompt', '')
                request_content = prompt
                estimated_tokens = TokenCounter.count_tokens_from_text(prompt)
            
            try:
                # 预检查余额是否充足
                # 这里只是预估，实际Token数可能会有差异
                # 系统会在API调用后根据真实使用的Token数进行计费
                price_per_token = BillingService.get_price_per_token(model_type)
                estimated_cost = estimated_tokens * price_per_token
                
                # 获取用户账户余额
                from .models import AccountBalance
                account_balance, created = AccountBalance.objects.get_or_create(user=request.user)
                
                # 检查余额是否充足
                if not account_balance.is_balance_sufficient(estimated_cost):
                    raise InsufficientBalanceError(
                        f"预估Token数量: {estimated_tokens}, 预估费用: {estimated_cost}, "
                        f"当前余额: {account_balance.balance}, 余额不足!"
                    )
                
                # 调用原始视图函数，获取API响应
                response = view_func(request, *args, **kwargs)
                
                # API调用成功，进行实际计费
                if response.status_code == 200:
                    # 从API响应中获取实际使用的Token数
                    response_data = response.data
                    usage = TokenCounter.count_tokens_from_response(response_data)
                    actual_tokens = usage.get('total_tokens', estimated_tokens)
                    
                    # 记录消费
                    BillingService.record_consumption(
                        user=request.user,
                        tokens_used=actual_tokens,
                        model_type=model_type,
                        request_type=request_type,
                        request_content=request_content,
                        request_id=request_id
                    )
                
                return response
            
            except InsufficientBalanceError as e:
                logger.warning(f"用户 {request.user.username} 余额不足: {str(e)}")
                from rest_framework.response import Response
                from rest_framework import status
                return Response(
                    {'error': '账户余额不足，请充值后再试'},
                    status=status.HTTP_402_PAYMENT_REQUIRED
                )
            
            except Exception as e:
                logger.exception(f"Token计费过程发生错误: {str(e)}")
                # 继续执行原视图函数，确保即使计费错误也不影响正常功能
                return view_func(request, *args, **kwargs)
        
        return _wrapped_view
    
    return decorator

def wrap_dify_api():
    """
    包装Dify API客户端方法，加入Token计费功能
    在应用启动时调用该函数，修改dify_client的方法
    """
    # 保存原始方法引用
    original_chat_completion = dify_client.chat_completion
    original_text_completion = dify_client.text_completion
    
    # 包装聊天补全方法
    @wraps(original_chat_completion)
    def wrapped_chat_completion(messages, parameters=None, user=None):
        if user is None or isinstance(user, AnonymousUser):
            # 匿名用户直接调用原方法
            return original_chat_completion(messages, parameters)
        
        # 生成请求ID
        request_id = str(uuid.uuid4())
        
        # 预估Token用量
        estimated_tokens = TokenCounter.count_tokens_from_messages(messages)
        model_type = parameters.get('model', 'gpt-3.5-turbo') if parameters else 'gpt-3.5-turbo'
        
        try:
            # 预检查余额
            price_per_token = BillingService.get_price_per_token(model_type)
            estimated_cost = estimated_tokens * price_per_token
            
            # 获取用户账户余额
            from .models import AccountBalance
            account_balance, created = AccountBalance.objects.get_or_create(user=user)
            
            # 检查余额是否充足
            if not account_balance.is_balance_sufficient(estimated_cost):
                raise InsufficientBalanceError(
                    f"预估Token数量: {estimated_tokens}, 预估费用: {estimated_cost}, "
                    f"当前余额: {account_balance.balance}, 余额不足!"
                )
            
            # 调用原始API方法
            response = original_chat_completion(messages, parameters)
            
            # 从响应中获取实际Token用量
            usage = TokenCounter.count_tokens_from_response(response)
            actual_tokens = usage.get('total_tokens', estimated_tokens)
            
            # 记录消费
            BillingService.record_consumption(
                user=user,
                tokens_used=actual_tokens,
                model_type=model_type,
                request_type='chat',
                request_content=json.dumps(messages),
                request_id=request_id
            )
            
            return response
            
        except InsufficientBalanceError as e:
            logger.warning(f"用户 {user.username} 余额不足: {str(e)}")
            error_response = {
                'error': {
                    'message': '账户余额不足，请充值后再试',
                    'type': 'insufficient_balance'
                }
            }
            return error_response
            
        except Exception as e:
            logger.exception(f"聊天补全Token计费过程发生错误: {str(e)}")
            # 出错时仍调用原始方法
            return original_chat_completion(messages, parameters)
    
    # 包装文本补全方法
    @wraps(original_text_completion)
    def wrapped_text_completion(prompt, parameters=None, user=None):
        if user is None or isinstance(user, AnonymousUser):
            # 匿名用户直接调用原方法
            return original_text_completion(prompt, parameters)
        
        # 生成请求ID
        request_id = str(uuid.uuid4())
        
        # 预估Token用量
        estimated_tokens = TokenCounter.count_tokens_from_text(prompt)
        model_type = parameters.get('model', 'gpt-3.5-turbo') if parameters else 'gpt-3.5-turbo'
        
        try:
            # 预检查余额
            price_per_token = BillingService.get_price_per_token(model_type)
            estimated_cost = estimated_tokens * price_per_token
            
            # 获取用户账户余额
            from .models import AccountBalance
            account_balance, created = AccountBalance.objects.get_or_create(user=user)
            
            # 检查余额是否充足
            if not account_balance.is_balance_sufficient(estimated_cost):
                raise InsufficientBalanceError(
                    f"预估Token数量: {estimated_tokens}, 预估费用: {estimated_cost}, "
                    f"当前余额: {account_balance.balance}, 余额不足!"
                )
            
            # 调用原始API方法
            response = original_text_completion(prompt, parameters)
            
            # 从响应中获取实际Token用量
            usage = TokenCounter.count_tokens_from_response(response)
            actual_tokens = usage.get('total_tokens', estimated_tokens)
            
            # 记录消费
            BillingService.record_consumption(
                user=user,
                tokens_used=actual_tokens,
                model_type=model_type,
                request_type='text',
                request_content=prompt,
                request_id=request_id
            )
            
            return response
            
        except InsufficientBalanceError as e:
            logger.warning(f"用户 {user.username} 余额不足: {str(e)}")
            error_response = {
                'error': {
                    'message': '账户余额不足，请充值后再试',
                    'type': 'insufficient_balance'
                }
            }
            return error_response
            
        except Exception as e:
            logger.exception(f"文本补全Token计费过程发生错误: {str(e)}")
            # 出错时仍调用原始方法
            return original_text_completion(prompt, parameters)
    
    # 替换原始方法
    dify_client.chat_completion = wrapped_chat_completion
    dify_client.text_completion = wrapped_text_completion 