from django.contrib import admin
from .models import AccountBalance, ConsumptionRecord, TokenUsage, PricingPlan, PaymentOrder, RechargeRecord
from django.utils import timezone
import logging

logger = logging.getLogger(__name__)

@admin.register(PricingPlan)
class PricingPlanAdmin(admin.ModelAdmin):
    list_display = ('name', 'prompt_price_per_million_tokens', 'completion_price_per_million_tokens', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name',)

@admin.register(AccountBalance)
class AccountBalanceAdmin(admin.ModelAdmin):
    list_display = ('user', 'balance', 'warning_threshold', 'last_recharge_at')
    search_fields = ('user__username', 'user__email')
    readonly_fields = ('created_at', 'updated_at')

@admin.register(ConsumptionRecord)
class ConsumptionRecordAdmin(admin.ModelAdmin):
    list_display = ('user', 'type', 'tokens_used', 'amount', 'status', 'created_at')
    list_filter = ('type', 'status', 'created_at')
    search_fields = ('user__username', 'user__email', 'request_id')
    readonly_fields = ('created_at',)

@admin.register(TokenUsage)
class TokenUsageAdmin(admin.ModelAdmin):
    list_display = ('user', 'date', 'prompt_tokens', 'completion_tokens')
    list_filter = ('date',)
    search_fields = ('user__username', 'user__email')
    date_hierarchy = 'date'

@admin.register(PaymentOrder)
class PaymentOrderAdmin(admin.ModelAdmin):
    list_display = ('order_id', 'user', 'amount', 'credits', 'payment_method', 'status', 'created_at', 'payment_time')
    list_filter = ('status', 'payment_method', 'created_at')
    search_fields = ('order_id', 'user__username', 'user__email', 'transaction_id')
    readonly_fields = ('created_at', 'updated_at')
    date_hierarchy = 'created_at'

    def save_model(self, request, obj, form, change):
        """当管理员修改订单状态时，处理余额更新"""
        old_status = None
        if change:
            try:
                old_obj = self.model.objects.get(pk=obj.pk)
                old_status = old_obj.status
            except:
                pass
        
        # 先保存模型
        super().save_model(request, obj, form, change)
        
        # 如果订单状态从非paid变为paid，自动处理余额和充值记录
        if old_status != 'paid' and obj.status == 'paid':
            logger.info(f"管理员操作: 订单 {obj.order_id} 状态从 {old_status} 变更为 paid")
            
            try:
                # 检查是否已存在充值记录
                recharge_record = RechargeRecord.objects.filter(order=obj).first()
                
                # 获取账户余额
                account_balance, created = AccountBalance.objects.get_or_create(user=obj.user)
                initial_balance = account_balance.balance
                
                if not recharge_record:
                    # 创建充值记录
                    recharge_record = RechargeRecord.objects.create(
                        user=obj.user,
                        order=obj,
                        amount=obj.amount,
                        credits=obj.credits
                    )
                    logger.info(f"管理员操作创建充值记录: 订单={obj.order_id}, 用户={obj.user.username}, 积分={obj.credits}")
                    
                    # 更新用户余额
                    account_balance.balance += obj.credits
                    account_balance.last_recharge_at = timezone.now()
                    account_balance.save()
                    
                    logger.info(f"管理员操作触发余额更新: 用户={obj.user.username}, 订单={obj.order_id}, 金额={obj.amount}, 初始余额={initial_balance}, 现余额={account_balance.balance}")
                else:
                    # 即使已有充值记录，也确保用户余额已更新
                    # 检查是否已经计入余额
                    difference = recharge_record.credits
                    logger.info(f"充值记录已存在: 订单={obj.order_id}, 用户={obj.user.username}, 积分={difference}")
                    
                    # 为安全起见，计算当前余额与记录的所有订单金额之和的差异
                    from django.db.models import Sum
                    total_recharge = RechargeRecord.objects.filter(user=obj.user).aggregate(total=Sum('credits'))['total'] or 0
                    total_consumption = ConsumptionRecord.objects.filter(user=obj.user).aggregate(total=Sum('amount'))['total'] or 0
                    
                    # 理论上余额应该是充值减去消费
                    theoretical_balance = total_recharge - total_consumption
                    
                    # 如果实际余额小于理论余额，可能未计入此次充值
                    if account_balance.balance < theoretical_balance:
                        account_balance.balance = theoretical_balance
                        account_balance.last_recharge_at = timezone.now()
                        account_balance.save()
                        logger.info(f"修正用户余额: 从 {initial_balance} 调整到 {account_balance.balance}, 理论余额={theoretical_balance}")
                    else:
                        logger.info(f"余额已正确: 当前={account_balance.balance}, 理论余额={theoretical_balance}")
            except Exception as e:
                logger.error(f"处理管理员操作订单状态变更时出错: {str(e)}")
                # 不让异常阻断管理操作

@admin.register(RechargeRecord)
class RechargeRecordAdmin(admin.ModelAdmin):
    list_display = ('user', 'amount', 'credits', 'created_at', 'order')
    list_filter = ('created_at',)
    search_fields = ('user__username', 'user__email', 'order__order_id')
    readonly_fields = ('created_at',)
    date_hierarchy = 'created_at'
