from django.db import models
from django.conf import settings
from django.utils.translation import gettext_lazy as _

class PricingPlan(models.Model):
    """定价策略模型"""
    name = models.CharField(_('计划名称'), max_length=100)
    description = models.TextField(_('计划描述'), blank=True)
    prompt_price_per_million_tokens = models.DecimalField(_('每百万提示词Token价格'), max_digits=10, decimal_places=6)
    completion_price_per_million_tokens = models.DecimalField(_('每百万响应Token价格'), max_digits=10, decimal_places=6)
    is_active = models.BooleanField(_('是否激活'), default=True)
    created_at = models.DateTimeField(_('创建时间'), auto_now_add=True)
    updated_at = models.DateTimeField(_('更新时间'), auto_now=True)

    class Meta:
        verbose_name = _('定价计划')
        verbose_name_plural = _('定价计划')
    
    def __str__(self):
        return f"{self.name}"

class AccountBalance(models.Model):
    """账户余额模型"""
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='account_balance')
    balance = models.DecimalField(_('余额'), max_digits=12, decimal_places=6, default=0)
    last_recharge_at = models.DateTimeField(_('最后充值时间'), null=True, blank=True)
    warning_threshold = models.DecimalField(_('预警阈值'), max_digits=12, decimal_places=6, default=10.0)
    created_at = models.DateTimeField(_('创建时间'), auto_now_add=True)
    updated_at = models.DateTimeField(_('更新时间'), auto_now=True)

    class Meta:
        verbose_name = _('账户余额')
        verbose_name_plural = _('账户余额')
    
    def __str__(self):
        return f"{self.user.username}的账户余额: {self.balance}"
    
    def is_balance_sufficient(self, amount=0):
        """检查余额是否充足"""
        return self.balance >= amount
    
    def warning_balance(self):
        """检查是否达到预警阈值"""
        return self.balance <= self.warning_threshold

class PaymentOrder(models.Model):
    """支付订单模型"""
    ORDER_STATUS_CHOICES = (
        ('pending', _('待支付')),
        ('paid', _('已支付')),
        ('failed', _('支付失败')),
        ('cancelled', _('已取消')),
        ('expired', _('已过期')),
    )
    
    PAYMENT_METHOD_CHOICES = (
        ('wechat', _('微信支付')),
    )
    
    order_id = models.CharField(_('订单号'), max_length=64, unique=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='payment_orders')
    amount = models.DecimalField(_('支付金额'), max_digits=10, decimal_places=2)
    credits = models.DecimalField(_('充值积分'), max_digits=10, decimal_places=2)
    status = models.CharField(_('订单状态'), max_length=20, choices=ORDER_STATUS_CHOICES, default='pending')
    payment_method = models.CharField(_('支付方式'), max_length=20, choices=PAYMENT_METHOD_CHOICES)
    payment_time = models.DateTimeField(_('支付时间'), null=True, blank=True)
    transaction_id = models.CharField(_('交易流水号'), max_length=128, blank=True, null=True)
    created_at = models.DateTimeField(_('创建时间'), auto_now_add=True)
    updated_at = models.DateTimeField(_('更新时间'), auto_now=True)
    
    class Meta:
        verbose_name = _('支付订单')
        verbose_name_plural = _('支付订单')
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.order_id} - {self.user.username} - {self.amount}"

class RechargeRecord(models.Model):
    """充值记录模型"""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='recharge_records')
    order = models.OneToOneField(PaymentOrder, on_delete=models.CASCADE, related_name='recharge_record')
    amount = models.DecimalField(_('充值金额'), max_digits=10, decimal_places=2)
    credits = models.DecimalField(_('充值积分'), max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(_('充值时间'), auto_now_add=True)
    
    class Meta:
        verbose_name = _('充值记录')
        verbose_name_plural = _('充值记录')
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.amount}元 - {self.credits}积分"

class ConsumptionRecord(models.Model):
    """消费记录模型"""
    TYPE_CHOICES = (
        ('chat', _('聊天')),
        ('text', _('文本生成')),
        ('other', _('其他')),
    )
    
    STATUS_CHOICES = (
        ('success', _('成功')),
        ('failed', _('失败')),
        ('pending', _('处理中')),
    )
    
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='consumption_records')
    tokens_used = models.IntegerField(_('使用的Token数'))
    amount = models.DecimalField(_('消费金额'), max_digits=10, decimal_places=6)
    type = models.CharField(_('消费类型'), max_length=20, choices=TYPE_CHOICES)
    status = models.CharField(_('状态'), max_length=20, choices=STATUS_CHOICES, default='success')
    request_id = models.CharField(_('请求ID'), max_length=100, blank=True, null=True)
    request_content = models.TextField(_('请求内容'), blank=True)
    created_at = models.DateTimeField(_('创建时间'), auto_now_add=True)
    
    class Meta:
        verbose_name = _('消费记录')
        verbose_name_plural = _('消费记录')
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.get_type_display()} - {self.amount}"

class TokenUsage(models.Model):
    """Token使用统计模型"""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='token_usage')
    date = models.DateField(_('日期'))
    prompt_tokens = models.IntegerField(_('提示Token数'), default=0)
    completion_tokens = models.IntegerField(_('补全Token数'), default=0)
    total_tokens = models.IntegerField(_('总Token数'), default=0)
    
    class Meta:
        verbose_name = _('Token使用统计')
        verbose_name_plural = _('Token使用统计')
        unique_together = ('user', 'date')
    
    def __str__(self):
        return f"{self.user.username} - {self.date} - {self.total_tokens}"
