from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.utils.translation import gettext_lazy as _
import uuid # 导入 uuid 用于生成唯一用户名


class UserManager(BaseUserManager):
    """自定义用户管理器，使用username作为主要标识符"""
    def create_user(self, username, password=None, email=None, **extra_fields):
        """创建普通用户"""
        if not username:
            # 如果没有提供username，尝试基于email生成或使用UUID
            if email:
                 username = self.normalize_email(email).split('@')[0]
                 # 检查用户名是否已存在，如果存在则附加UUID
                 if self.model.objects.filter(username=username).exists():
                     username = f"{username}_{uuid.uuid4().hex[:8]}"
            else:
                 username = f"user_{uuid.uuid4().hex[:12]}" # 生成基于UUID的唯一用户名

        # 确保用户名唯一
        while self.model.objects.filter(username=username).exists():
             username = f"{username.split('_')[0]}_{uuid.uuid4().hex[:8]}" # 附加更多随机性

        if email:
            email = self.normalize_email(email)
            # 检查邮箱是否已存在，如果存在则不允许创建（除非我们稍后决定允许多个用户共享非唯一邮箱）
            # 注意：如果 email 字段不再 unique=True，则需要移除或调整此逻辑
            # if self.model.objects.filter(email=email).exists():
            #     raise ValueError(_('该邮箱地址已被注册'))

        user = self.model(username=username, email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, password=None, email=None, **extra_fields):
        """创建超级用户"""
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError(_('超级用户必须设置is_staff=True'))
        if extra_fields.get('is_superuser') is not True:
            raise ValueError(_('超级用户必须设置is_superuser=True'))

        # 超级用户创建时，如果没提供邮箱，则需要提示或设置一个默认值
        if not email:
             raise ValueError(_('创建超级用户必须提供邮箱地址'))
             # 或者可以设置一个默认管理员邮箱，例如：
             # email = 'admin@example.com' # 但这需要确保该邮箱不会与其他用户冲突

        return self.create_user(username, password, email=email, **extra_fields)


class User(AbstractUser):
    """自定义用户模型"""

    # 邮箱改为可选，不再唯一，但添加索引以优化查找
    email = models.EmailField(_('邮箱地址'), blank=True, null=True, db_index=True)
    # 手机号改为可选
    phone = models.CharField(_('手机号'), max_length=11, blank=True, null=True, unique=True) # 保持手机号唯一（如果需要）
    avatar = models.ImageField(_('头像'), upload_to='avatars/', blank=True, null=True)
    bio = models.TextField(_('个人简介'), max_length=500, blank=True)

    # 身份认证信息
    id_card = models.CharField(_('身份证号'), max_length=18, blank=True, null=True)
    real_name = models.CharField(_('真实姓名'), max_length=50, blank=True, null=True)
    is_verified = models.BooleanField(_('身份已验证'), default=False)
    verification_date = models.DateTimeField(_('验证时间'), blank=True, null=True)

    # 扩展信息
    is_email_verified = models.BooleanField(_('邮箱已验证'), default=False)
    create_time = models.DateTimeField(_('创建时间'), auto_now_add=True)
    update_time = models.DateTimeField(_('更新时间'), auto_now=True)
    last_login_ip = models.GenericIPAddressField(_('最后登录IP'), blank=True, null=True)

    # 设置USERNAME_FIELD为username (继承自AbstractUser，默认就是username)
    # USERNAME_FIELD = 'username' # 这行可以省略，因为是默认值
    REQUIRED_FIELDS = ['email'] # 创建超级用户时需要输入 email

    # 使用自定义的管理器
    objects = UserManager()

    class Meta:
        verbose_name = _('用户')
        verbose_name_plural = _('用户')

    def __str__(self):
        return self.username # 改为返回 username

    def get_full_name(self):
        if self.first_name and self.last_name:
            return f"{self.first_name} {self.last_name}"
        return self.username # 如果没有名字，返回 username


class WechatUser(models.Model):
    """微信用户信息模型"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='wechat_user')
    openid = models.CharField(_('微信OpenID'), max_length=100, unique=True)
    unionid = models.CharField(_('微信UnionID'), max_length=100, blank=True, null=True)
    nickname = models.CharField(_('微信昵称'), max_length=100, blank=True)
    headimgurl = models.URLField(_('头像URL'), blank=True)
    created_at = models.DateTimeField(_('创建时间'), auto_now_add=True)
    updated_at = models.DateTimeField(_('更新时间'), auto_now=True)

    class Meta:
        verbose_name = _('微信用户')
        verbose_name_plural = _('微信用户')

    def __str__(self):
        return f"{self.user.username} - {self.nickname or '未设置昵称'}"
