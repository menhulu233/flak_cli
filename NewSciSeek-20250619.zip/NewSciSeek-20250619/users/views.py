from django.shortcuts import render, redirect
from rest_framework import viewsets, status, views, permissions
from rest_framework.decorators import action
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, FormParser
from django.contrib.auth import login, logout, authenticate
from django.utils import timezone
from django.conf import settings
from django.http import JsonResponse, HttpResponse
from django.views.decorators.http import require_http_methods
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils.translation import gettext as _, get_language
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny, IsAuthenticated
from django.core.cache import cache
import logging
import requests
import json
import uuid
import base64
import qrcode
import io
import rest_framework.authentication
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.template.loader import render_to_string
from django.core.mail import send_mail
from django.urls import reverse

from .models import User, WechatUser
from .serializers import (
    UserRegisterSerializer, UserLoginSerializer, 
    UserDetailSerializer, UserUpdateSerializer,
    PasswordChangeSerializer
)
from utils.response import success_response, error_response
from .forms import UserRegistrationForm, UserCreationForm, EmailChangeForm
from utils.email import EmailVerification

logger = logging.getLogger('users')

def home_view(request):
    """网站首页视图"""
    context = {
        'title': '新科探索',
        'show_login_modal': request.GET.get('show_login', False)
    }
    return render(request, 'pages/home.html', context)

class UserViewSet(viewsets.GenericViewSet):
    """用户视图集"""
    queryset = User.objects.all()
    
    def get_serializer_class(self):
        if self.action == 'register':
            return UserRegisterSerializer
        elif self.action == 'login':
            return UserLoginSerializer
        elif self.action in ['update', 'partial_update']:
            return UserUpdateSerializer
        elif self.action == 'change_password':
            return PasswordChangeSerializer
        return UserDetailSerializer
    
    def get_permissions(self):
        if self.action in ['register', 'login']:
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]
    
    @action(detail=False, methods=['post'])
    def register(self, request):
        """用户注册"""
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        
        return success_response(
            data=UserDetailSerializer(user).data,
            msg="注册成功"
        )
    
    @action(detail=False, methods=['post'])
    def login(self, request):
        """用户登录"""
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        
        # 更新最后登录IP
        try:
            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            if x_forwarded_for:
                ip = x_forwarded_for.split(',')[0]
            else:
                ip = request.META.get('REMOTE_ADDR')
            if ip:
                user.last_login_ip = ip
                user.save(update_fields=['last_login_ip', 'update_time']) # 同时更新 update_time
                logger.info(f"用户 {user.username} 的 last_login_ip 更新为 {ip}")
        except Exception as e:
            logger.error(f"更新用户 {user.username} 的 last_login_ip 时出错: {e}")
        
        # 执行登录
        login(request, user)
        
        # 获取或创建Token
        token, _ = Token.objects.get_or_create(user=user)
        
        # --- 新增：确定重定向 URL ---
        # 优先使用请求中可能存在的 'next' 参数，否则默认为首页 '/'
        # 注意：需要确保 'next' 参数是安全的，防止开放重定向漏洞。
        next_url = request.data.get('next') or settings.LOGIN_REDIRECT_URL # 使用 LOGIN_REDIRECT_URL 设置
        # 基本的安全检查：确保是相对路径或同源 (简单的示例)
        # 在实际应用中，建议使用更健壮的 is_safe_url 检查
        if not next_url.startswith('/') and not next_url.startswith(request.build_absolute_uri('/')):
             next_url = settings.LOGIN_REDIRECT_URL # 不安全则回退

        # --- 修改：在返回数据中添加 status 和 redirect_url ---
        # 假设 success_response 只是包装 data 和 msg，我们需要在 data 内部提供前端需要的东西
        response_data = {
            'status': 'success', # 前端需要的 status
            'token': token.key,
            'user': UserDetailSerializer(user, context={'request': request}).data, # 添加 context
            'redirect_url': next_url # 前端需要的跳转 URL
        }
        
        return success_response(
            data=response_data, # 传递包含 status 和 redirect_url 的 data
            msg="登录成功"
        )
    
    @action(detail=False, methods=['post'])
    def logout(self, request):
        """用户退出登录"""
        # 删除Token
        Token.objects.filter(user=request.user).delete()
        # 执行登出
        logout(request)
        return success_response(msg="已退出登录")
    
    @action(detail=False, methods=['get'])
    def info(self, request):
        """获取当前用户信息"""
        return success_response(
            data=UserDetailSerializer(request.user).data
        )
    
    @action(detail=False, methods=['put', 'patch'])
    def update_info(self, request):
        """更新用户信息"""
        serializer = UserUpdateSerializer(request.user, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return success_response(
            data=UserDetailSerializer(request.user).data,
            msg="用户信息已更新"
        )
    
    @action(detail=False, methods=['post'])
    def change_password(self, request):
        """修改密码"""
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        
        # 登出用户，让用户使用新密码重新登录
        logout(request)
        return success_response(msg="密码修改成功，请重新登录")
    
    @action(detail=False, methods=['post'], parser_classes=[MultiPartParser, FormParser])
    def upload_avatar(self, request):
        """上传用户头像"""
        if 'avatar' not in request.FILES:
            return error_response("请选择图片文件", status=status.HTTP_400_BAD_REQUEST)
        
        # 获取上传的头像文件
        avatar_file = request.FILES['avatar']
        
        # 更新用户头像
        request.user.avatar = avatar_file
        request.user.save(update_fields=['avatar'])
        
        return success_response(
            data={
                'avatar': request.user.avatar.url if request.user.avatar else None
            },
            msg="头像上传成功"
        )
    
    def get_client_ip(self, request):
        """获取客户端IP"""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0]
        else:
            ip = request.META.get('REMOTE_ADDR')
        return ip

@require_http_methods(["GET", "POST"])
def login_view(request):
    if request.method == "POST":
        account = request.POST.get('username')  # 表单中仍然使用username作为字段名
        password = request.POST.get('password')
        remember = request.POST.get('remember') == 'true'
        
        user = None
        
        # 尝试直接认证（邮箱认证，因为USERNAME_FIELD='email'）
        user = authenticate(request, username=account, password=password)
        
        # 如果认证失败，尝试使用用户名查找对应用户
        if user is None and not '@' in account:
            try:
                user_obj = User.objects.get(username=account)
                user = authenticate(request, username=user_obj.email, password=password)
            except User.DoesNotExist:
                pass
        
        if user is not None:
            login(request, user)
            
            # -- 添加开始: 更新最后登录IP --
            try:
                x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
                if x_forwarded_for:
                    ip = x_forwarded_for.split(',')[0]
                else:
                    ip = request.META.get('REMOTE_ADDR')
                if ip:
                    user.last_login_ip = ip
                    user.save(update_fields=['last_login_ip', 'update_time']) # 同时更新 update_time
                    logger.info(f"用户 {user.username} 的 last_login_ip 更新为 {ip}")
            except Exception as e:
                 logger.error(f"更新用户 {user.username} 的 last_login_ip 时出错: {e}")
            # -- 添加结束 --

            if not remember:
                request.session.set_expiry(0)  # 浏览器关闭时过期
                
            # 从POST请求中获取next参数，而不是GET请求
            next_url = request.POST.get('next') or request.GET.get('next') or '/'
            logger.info(f"用户 {user.username} 登录成功，将重定向到: {next_url}")
                
            return JsonResponse({
                'status': 'success',
                'redirect_url': next_url
            })
        else:
            return JsonResponse({
                'status': 'error',
                'message': _('账号或密码错误')
            }, status=400)
    
    # 对于GET请求，如果用户已登录，重定向到next参数指定的页面或主页
    if request.user.is_authenticated:
        next_url = request.GET.get('next')
        if next_url:
            return redirect(next_url)
        return redirect('/')
    
    # 如果用户未登录，显示登录页面
    return render(request, 'pages/home.html', {'show_login_modal': True})

@require_http_methods(["GET", "POST"])
def register_view(request):
    if request.method == 'POST':
        try:
            username = request.POST.get('username')
            email = request.POST.get('email')
            password1 = request.POST.get('password1')
            password2 = request.POST.get('password2')
            verification_code = request.POST.get('verification_code')
            
            errors = []
            
            # 验证必填字段
            if not username:
                errors.append(_('请输入用户名'))
            if not email:
                errors.append(_('请输入邮箱地址'))
            if not password1:
                errors.append(_('请输入密码'))
            if not password2:
                errors.append(_('请确认密码'))
            if not verification_code:
                errors.append(_('请输入验证码'))
            
            # 如果有必填字段缺失，直接返回错误
            if errors:
                return JsonResponse({
                    'status': 'error',
                    'message': '<br>'.join(errors)
                }, status=400)
            
            # 验证密码
            if password1 != password2:
                errors.append(_('两次输入的密码不一致'))
            
            # 验证邮箱格式
            if '@' not in email:
                errors.append(_('请输入有效的邮箱地址'))
                
            # 验证邮箱是否已注册
            if User.objects.filter(email=email).exists():
                errors.append(_('该邮箱已被注册'))
                
            # 验证用户名是否已注册
            if User.objects.filter(username=username).exists():
                errors.append(_('该用户名已被使用'))
                
            # 验证验证码
            if not EmailVerification.verify_code(email, verification_code):
                errors.append(_('验证码错误或已过期'))
                
            if errors:
                return JsonResponse({
                    'status': 'error',
                    'message': '<br>'.join(errors)
                }, status=400)
                
            # 创建用户
            try:
                user = User.objects.create_user(
                    email=email,
                    username=username,
                    password=password1
                )
                logger.info(f"用户注册成功 - 用户名: {username}, 邮箱: {email}")
                
                return JsonResponse({
                    'status': 'success',
                    'message': _('注册成功，请登录'),
                    'redirect_url': '/login/'
                })
            except Exception as e:
                logger.error(f"创建用户失败 - 用户名: {username}, 邮箱: {email}, 错误: {str(e)}")
                return JsonResponse({
                    'status': 'error',
                    'message': _('注册失败，请稍后重试')
                }, status=500)
                
        except Exception as e:
            logger.error(f"注册过程发生错误: {str(e)}")
            return JsonResponse({
                'status': 'error',
                'message': _('注册失败，请稍后重试')
            }, status=500)
    
    # 对于GET请求，重定向到主页
    return redirect('/')

@login_required
def profile_view(request):
    """用户个人资料页面，处理GET和POST请求"""
    if request.method == 'POST':
        # 处理表单提交
        new_username = request.POST.get('username', '').strip()
        first_name = request.POST.get('first_name', '').strip()
        last_name = request.POST.get('last_name', '').strip()
        bio = request.POST.get('bio', '').strip()

        user = request.user
        errors = []

        # 验证用户名
        if not new_username:
            errors.append(_('用户名不能为空。'))
        elif new_username != user.username:
            # 检查新用户名是否已被其他用户使用
            if User.objects.filter(username=new_username).exclude(pk=user.pk).exists():
                errors.append(_('该用户名已被使用，请选择其他用户名。'))
            # 移动 user.username 的赋值到保存阶段，避免验证失败时也被修改

        if errors:
            # 返回错误信息给 AJAX 请求
            return JsonResponse({'status': 'error', 'errors': errors}, status=400)
        else:
            # 更新用户信息
            user.username = new_username # 在确认无错误后更新
            user.first_name = first_name
            user.last_name = last_name
            user.bio = bio
            try:
                user.save(update_fields=['username', 'first_name', 'last_name', 'bio', 'update_time'])
                logger.info(f"用户 {user.pk} 更新了个人信息。")
                # 返回成功信息给 AJAX 请求
                return JsonResponse({'status': 'success', 'message': _('个人信息已成功更新。')})
            except Exception as e:
                logger.error(f"更新用户 {user.pk} 信息时出错: {e}")
                # 返回服务器错误信息给 AJAX 请求
                return JsonResponse({'status': 'error', 'message': _('更新个人信息时发生错误，请稍后重试。')}, status=500)

    # 对于GET请求，正常渲染模板
    email_form = EmailChangeForm(user=request.user)
    context = {
        'form': email_form # 将表单添加到上下文中
    }
    return render(request, 'users/profile.html', context)

@login_required
def identity_verification_page(request):
    """身份验证页面"""
    return render(request, 'users/identity_verification.html')

def identity_api_test_page(request):
    """身份验证API测试页面"""
    return render(request, 'users/identity_test.html')

@require_http_methods(["GET", "POST"])
def logout_view(request):
    """用户退出登录视图"""
    logout(request)
    if request.method == "POST":
        return JsonResponse({
            'status': 'success',
            'message': _('已成功退出登录')
        })
    return redirect('/')

class WechatLoginView(APIView):
    """微信扫码登录视图"""
    permission_classes = [AllowAny]
    
    def get(self, request):
        # 生成随机状态码防止CSRF攻击
        state = str(uuid.uuid4())
        cache.set(f"wechat_login_state_{state}", state, timeout=300)  # 设置5分钟过期
        
        # 构建微信登录URL
        redirect_uri = settings.WECHAT_REDIRECT_URI
        logger.info(f"[WechatLoginView] 使用的回调 URI: {redirect_uri}") # 记录回调 URI
        
        login_url = (
            f"{settings.WECHAT_QR_CONNECT_URL}?"
            f"appid={settings.WECHAT_APP_ID}&"
            f"redirect_uri={redirect_uri}&"
            f"response_type=code&"
            f"scope=snsapi_login&"
            f"state={state}#wechat_redirect"
        )
        
        logger.info(f"[WechatLoginView] 生成的微信登录 URL: {login_url}") # 记录生成的 URL
        
        # 不再由后端生成二维码，直接返回 URL 给前端处理 (用于页面跳转)
        # qr = qrcode.QRCode(
        #     version=1,
        #     error_correction=qrcode.constants.ERROR_CORRECT_L,
        #     box_size=10,
        #     border=4,
        # )
        # qr.add_data(login_url)
        # qr.make(fit=True)
        # 
        # img = qr.make_image(fill_color="black", back_color="white")
        # buffer = io.BytesIO()
        # img.save(buffer, format="PNG")
        # qr_code_base64 = base64.b64encode(buffer.getvalue()).decode()
        
        return Response({
            'login_url': login_url, # 只返回 URL
            # 'qr_code': f"data:image/png;base64,{qr_code_base64}",
            'state': state
        })

class WechatCallbackView(APIView):
    """微信回调视图"""
    permission_classes = [AllowAny]
    
    def get(self, request):
        code = request.GET.get('code')
        state = request.GET.get('state')
        
        # 验证状态码
        cached_state = cache.get(f"wechat_login_state_{state}")
        if not cached_state or cached_state != state:
            logger.error(f"微信登录状态验证失败: {state}")
            return JsonResponse({'error': '登录状态验证失败，请重新登录'}, status=400)
        
        # 删除缓存的状态码
        cache.delete(f"wechat_login_state_{state}")
        
        # 获取访问令牌
        try:
            token_response = requests.get(
                f"{settings.WECHAT_ACCESS_TOKEN_URL}?"
                f"appid={settings.WECHAT_APP_ID}&"
                f"secret={settings.WECHAT_APP_SECRET}&"
                f"code={code}&"
                f"grant_type=authorization_code"
            )
            token_data = token_response.json()
            
            if 'errcode' in token_data:
                logger.error(f"微信获取令牌失败: {token_data}")
                return JsonResponse({'error': '微信认证失败，请重试'}, status=400)
            
            access_token = token_data.get('access_token')
            openid = token_data.get('openid')
            unionid = token_data.get('unionid', '')
            
            # 获取用户信息
            user_info_response = requests.get(
                f"{settings.WECHAT_USERINFO_URL}?"
                f"access_token={access_token}&"
                f"openid={openid}"
            )
            user_info = user_info_response.json()
            
            if 'errcode' in user_info:
                logger.error(f"微信获取用户信息失败: {user_info}")
                return JsonResponse({'error': '获取微信用户信息失败，请重试'}, status=400)
            
            # 检查是否有关联的微信用户
            try:
                wechat_user = WechatUser.objects.get(openid=openid)
                user = wechat_user.user
                # 更新微信用户信息
                wechat_user.nickname = user_info.get('nickname', '')
                wechat_user.headimgurl = user_info.get('headimgurl', '')
                wechat_user.save(update_fields=['nickname', 'headimgurl'])
                
            except WechatUser.DoesNotExist:
                # 创建新用户和关联的微信用户
                nickname = user_info.get('nickname', '')
                # 使用 openid 生成唯一的占位邮箱
                placeholder_email = f"{openid}@wechat.placeholder"
                
                # 尝试创建用户，处理可能的用户名冲突（虽然基于openid的邮箱冲突概率极低）
                try:
                    # 1. 创建用户，传入 username=None 触发自动生成逻辑
                    user = User.objects.create_user(
                        username=None, # 显式传递 None
                        email=placeholder_email, 
                        password=uuid.uuid4().hex 
                    )
                    # 2. 不需要在此设置 nickname，它将保存在 WechatUser 模型中
                    # user.nickname = nickname
                    # 3. 不需要在此单独保存 nickname
                    # user.save(update_fields=['nickname'])
                    
                    # 移除日志中的昵称，因为它不在 User 模型上
                    logger.info(f"为 OpenID {openid} 创建了新用户: {user.username}，使用占位邮箱 {placeholder_email}")
                except Exception as e: # 更具体的异常处理可能更好，例如 IntegrityError
                    logger.exception(f"创建用户失败 (邮箱: {placeholder_email})，可能冲突或其他错误: {str(e)}")
                    return JsonResponse({'error': '创建用户账号失败，请稍后重试或联系管理员'}, status=500)

                # 创建关联的 WechatUser 对象，并将 nickname 保存在这里
                wechat_user = WechatUser.objects.create(
                    user=user,
                    openid=openid,
                    unionid=unionid,
                    nickname=nickname,
                    headimgurl=user_info.get('headimgurl', '')
                )
            
            # 执行登录
            login(request, user)

            # -- 添加开始: 更新最后登录IP --
            try:
                x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
                if x_forwarded_for:
                    ip = x_forwarded_for.split(',')[0]
                else:
                    ip = request.META.get('REMOTE_ADDR')
                if ip:
                    user.last_login_ip = ip
                    user.save(update_fields=['last_login_ip', 'update_time']) # 同时更新 update_time
                    logger.info(f"微信登录用户 {user.username} 的 last_login_ip 更新为 {ip}")
            except Exception as e:
                 logger.error(f"更新微信登录用户 {user.username} 的 last_login_ip 时出错: {e}")
            # -- 添加结束 --
            
            # 获取或创建Token
            token, _ = Token.objects.get_or_create(user=user)
            
            # 重定向到前端页面 (修改：直接重定向到首页)
            # redirect_to = f"/login-success?token={token.key}"
            redirect_to = '/' # 直接重定向到首页
            return redirect(redirect_to)
            
        except Exception as e:
            logger.exception(f"微信登录处理异常: {str(e)}")
            return JsonResponse({'error': '登录处理失败，请重试'}, status=500)

class WechatLoginStatusView(APIView):
    """检查微信登录状态"""
    permission_classes = [AllowAny]
    
    def get(self, request):
        state = request.GET.get('state')
        token = cache.get(f"wechat_login_token_{state}")
        
        if token:
            cache.delete(f"wechat_login_token_{state}")
            user = Token.objects.get(key=token).user
            return Response({
                'status': 'success',
                'token': token,
                'user': UserDetailSerializer(user).data
            })
        
        return Response({'status': 'pending'})

class IdentityVerificationView(APIView):
    """身份证二要素验证视图"""
    permission_classes = [permissions.IsAuthenticated]
    authentication_classes = [rest_framework.authentication.TokenAuthentication, 
                             rest_framework.authentication.SessionAuthentication]
    
    def post(self, request, *args, **kwargs):
        # 添加更详细的调试日志
        logger.info(f"身份验证请求 - 用户:{request.user.username}, 路径:{request.path}, 完整URL:{request.build_absolute_uri()}")
        logger.info(f"请求方法: {request.method}")
        logger.info(f"请求头: {dict(request.headers)}")
        
        # 检查请求体的内容和格式
        content_type = request.headers.get('Content-Type', '')
        logger.info(f"Content-Type: {content_type}")
        
        # 尝试获取请求数据，无论什么格式
        request_data = {}
        try:
            if 'application/json' in content_type:
                # 直接使用request.data，不要再尝试读取request.body
                request_data = request.data
                logger.info(f"JSON请求数据: {request_data}")
            else:
                request_data = request.POST
                logger.info(f"表单请求数据: {request_data}")
        except Exception as e:
            logger.error(f"解析请求数据失败: {str(e)}")
            return error_response(msg="无法解析请求数据，请检查格式", status_code=status.HTTP_400_BAD_REQUEST)
            
        # 从请求中获取数据
        real_name = request_data.get('real_name')
        id_card = request_data.get('id_card')
        
        if not real_name or not id_card:
            logger.warning(f"身份验证数据不完整 - 用户:{request.user.username}")
            return error_response(msg="请提供真实姓名和身份证号", status_code=status.HTTP_400_BAD_REQUEST)
            
        # 检查数据库中是否已有相同身份信息的用户
        existing_user = User.objects.filter(id_card=id_card, real_name=real_name, is_verified=True).first()
        if existing_user:
            logger.info(f"数据库中已存在此身份信息 - 身份证号:{id_card[:6]}****{id_card[-4:]}, 姓名:{real_name}")
            
            # 如果是当前用户，直接返回成功
            if existing_user.id == request.user.id:
                logger.info(f"当前用户已完成实名认证 - 用户:{request.user.username}")
                return success_response(msg="您已完成身份验证")
            
            # 如果是其他用户，返回错误
            logger.warning(f"身份信息已被其他用户使用 - 用户:{request.user.username}")
            return error_response(
                msg="此身份信息已被其他账号使用，如有疑问请联系客服", 
                status_code=status.HTTP_400_BAD_REQUEST
            )
            
        # 调用二要素验证API
        try:
            logger.info(f"开始调用身份验证API - 用户:{request.user.username}")
            
            # 检查API Token是否配置
            if not settings.APISPACE_TOKEN:
                logger.error("APISPACE_TOKEN未配置")
                return error_response(msg="身份验证服务未正确配置，请联系管理员", status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)
                
            result = self.verify_identity(real_name, id_card)
            logger.info(f"身份验证API返回结果 - 用户:{request.user.username}, 结果:{result}")
            
            if not result['success']:
                error_msg = result.get('message', '信息不匹配')
                logger.warning(f"身份验证失败 - 用户:{request.user.username}, 原因:{error_msg}")
                return error_response(msg=f"身份验证失败：{error_msg}", status_code=status.HTTP_400_BAD_REQUEST)
                
            # 验证成功，更新用户信息
            user = request.user
            user.real_name = real_name
            user.id_card = id_card
            user.is_verified = True
            user.verification_date = timezone.now()
            user.save(update_fields=['real_name', 'id_card', 'is_verified', 'verification_date'])
            
            # 记录身份验证成功的详细信息，确保敏感信息脱敏
            masked_id_card = id_card[:6] + "****" + id_card[-4:] if len(id_card) >= 10 else "***"
            logger.info(f"身份验证成功，用户信息已更新 - 用户:{request.user.username}, 姓名:{real_name}, 身份证:{masked_id_card}")
            
            # 添加消息通知
            messages.success(request, "身份验证成功，您现在可以使用所有功能")
            
            return success_response(msg="身份验证成功")
            
        except Exception as e:
            logger.exception(f"身份验证处理过程中发生未捕获异常: {str(e)}")
            # 返回更友好的错误消息，避免暴露内部错误细节
            return error_response(msg="身份验证服务暂时不可用，请稍后再试", status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def verify_identity(self, real_name, id_card):
        """调用第三方API进行身份验证"""
        # 敏感信息保护 - 记录身份证号时只保留前6位和后4位
        masked_id_card = id_card[:6] + "****" + id_card[-4:] if len(id_card) >= 10 else "***"
        logger.info(f"进行身份验证 - 姓名:{real_name}, 身份证:{masked_id_card}")
        
        api_url = "https://eolink.o.apispace.com/identity-two/name_number"
        headers = {
            "X-APISpace-Token": settings.APISPACE_TOKEN,
            "Content-Type": "application/x-www-form-urlencoded"
        }
        
        data = {
            "realname": real_name,
            "idcard": id_card
        }
        
        try:
            logger.info(f"开始请求第三方身份验证API，URL: {api_url}")
            logger.info(f"请求头: {headers}")
            
            # 记录请求数据时屏蔽敏感信息
            logger.info(f"请求数据: {{'realname': '{real_name}', 'idcard': '{masked_id_card}'}}")
            
            response = requests.post(api_url, headers=headers, data=data, timeout=10)
            
            logger.info(f"第三方API响应状态码: {response.status_code}")
            logger.info(f"第三方API响应头: {dict(response.headers)}")
            
            # 检查响应状态码
            if response.status_code != 200:
                response_text = response.text
                try:
                    # 尝试解析错误响应
                    error_data = response.json() if response_text else {"message": "空响应"}
                    logger.error(f"第三方API返回错误状态码: {response.status_code}, 响应内容: {error_data}")
                    error_message = error_data.get("message", f"身份验证服务返回错误: {response.status_code}")
                except:
                    logger.error(f"第三方API返回错误状态码: {response.status_code}, 无法解析响应: {response_text}")
                    error_message = f"身份验证服务返回错误: {response.status_code}"
                    
                return {"success": False, "message": error_message}
            
            # 尝试解析JSON响应
            try:
                result = response.json()
                # 记录结果时屏蔽敏感信息
                safe_result = result.copy() if isinstance(result, dict) else result
                if isinstance(safe_result, dict) and "data" in safe_result and isinstance(safe_result["data"], dict):
                    safe_result["data"] = {k: v for k, v in safe_result["data"].items() if k != "idcard"}
                logger.info(f"身份验证结果: {json.dumps(safe_result)}")
            except json.JSONDecodeError as e:
                logger.error(f"解析API响应JSON失败: {str(e)}, 响应内容: {response.text[:200]}...")
                return {"success": False, "message": "身份验证服务返回无效数据格式"}
            
            # 解析结果
            if result.get("code") == 0:
                data = result.get("data", {})
                # 判断身份证和姓名是否匹配
                if data.get("valid") is True and data.get("incorrect") == 100:
                    return {"success": True}
                else:
                    # 提供更详细的错误信息
                    error_code = data.get("incorrect")
                    if error_code == 101:
                        message = "身份信息不匹配"
                    elif error_code == 102:
                        message = "库中无此号"
                    else:
                        message = data.get("message", "身份信息验证失败")
                    return {"success": False, "message": message}
            
            return {"success": False, "message": result.get("message", "验证服务返回未知响应")}
            
        except requests.exceptions.RequestException as e:
            logger.exception(f"请求第三方API异常: {str(e)}")
            return {"success": False, "message": f"身份验证服务连接异常: {str(e)}"}
        except Exception as e:
            logger.exception(f"身份验证过程中发生未预期异常: {str(e)}")
            return {"success": False, "message": "身份验证服务异常，请稍后再试"}

@require_http_methods(["POST"])
def send_verification_code(request):
    """发送邮箱验证码"""
    email = request.POST.get('email')
    
    if not email or '@' not in email:
        return JsonResponse({
            'status': 'error',
            'message': _('请输入有效的邮箱地址')
        }, status=400)
        
    if User.objects.filter(email=email).exists():
        return JsonResponse({
            'status': 'error',
            'message': _('该邮箱已被注册')
        }, status=400)
        
    try:
        if EmailVerification.send_verification_code(email):
            return JsonResponse({
                'status': 'success',
                'message': _('验证码已发送，请查收邮件')
            })
        else:
            logger.error(f"验证码发送失败 - 邮箱: {email}")
            return JsonResponse({
                'status': 'error',
                'message': _('验证码发送失败，请稍后重试')
            }, status=500)
    except Exception as e:
        logger.exception(f"发送验证码时发生错误: {str(e)}")
        return JsonResponse({
            'status': 'error',
            'message': _('验证码发送失败，请稍后重试')
        }, status=500)

class CheckIPView(APIView):
    """检查用户IP是否来自中国大陆"""
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        """检查用户IP"""
        from utils.ip_verify_middleware import ChinaIPVerificationMiddleware
        
        # 获取IP检测中间件的实例
        middleware = ChinaIPVerificationMiddleware(get_response=lambda r: None)
        
        # 获取客户端IP
        client_ip = middleware._get_client_ip(request)
        
        # 检查是否为中国大陆IP
        is_china_ip = middleware._is_china_ip(client_ip)
        
        return Response({
            'is_china_ip': is_china_ip,
            'ip': client_ip,
            'is_verified': request.user.is_verified
        })

@login_required
@require_http_methods(["GET", "POST"])
def request_email_change(request):
    """处理用户请求更改邮箱的视图"""
    if request.method == 'POST':
        form = EmailChangeForm(request.POST, user=request.user)
        if form.is_valid():
            new_email = form.cleaned_data['email']
            
            # 生成令牌和链接
            token = default_token_generator.make_token(request.user)
            uid = urlsafe_base64_encode(force_bytes(request.user.pk))
            # 将新邮箱编码到 URL 中，以便在确认时使用
            encoded_email = urlsafe_base64_encode(force_bytes(new_email))
            
            # 构建验证URL (使用命名空间)
            verification_url = request.build_absolute_uri(
                reverse('users_web:confirm_email_change', kwargs={'uidb64': uid, 'token': token, 'emailb64': encoded_email})
            )
            
            # --- 开始邮件翻译 --- 
            current_language = get_language()
            # Django语言代码通常是 zh-hans, en
            lang_code = 'zh' if 'zh' in current_language else 'en' 

            email_translations = {
                'en': {
                    'subject': 'Please verify your new email address',
                    'greeting': f'Hello {request.user.username},',
                    'request_line': 'You requested to change the email address associated with your account on NewSciSeek.',
                    'link_line': 'Please click the link below to confirm this change:',
                    'ignore_line': 'If you did not request this change, please ignore this email.',
                    'thanks': 'Thanks,',
                    'team': 'The NewSciSeek Team'
                },
                'zh': {
                    'subject': '请验证您的新邮箱地址',
                    'greeting': f'您好 {request.user.username}，',
                    'request_line': '您请求更改与您 NewSciSeek 账户关联的邮箱地址。',
                    'link_line': '请点击以下链接确认此更改：',
                    'ignore_line': '如果您未请求此更改，请忽略此邮件。',
                    'thanks': '谢谢，',
                    'team': 'NewSciSeek 团队'
                }
            }

            translations = email_translations.get(lang_code, email_translations['en']) # 默认为英文
            # --- 结束邮件翻译 ---

            # 准备邮件上下文
            email_context = {
                'user': request.user,
                'verification_url': verification_url,
                'greeting': translations['greeting'],
                'request_line': translations['request_line'],
                'link_line': translations['link_line'],
                'ignore_line': translations['ignore_line'],
                'thanks': translations['thanks'],
                'team': translations['team']
            }

            # 使用翻译后的上下文渲染邮件内容
            message = render_to_string('users/email/email_change_confirmation_email.html', email_context)

            try:
                # 使用翻译后的主题发送邮件
                send_mail(translations['subject'], message, settings.DEFAULT_FROM_EMAIL, [new_email])
                messages.success(request, '验证邮件已发送至您的新邮箱，请查收并点击链接完成更改。')
                logger.info(f"用户 {request.user.username} 请求更改邮箱至 {new_email}，验证邮件已发送。")
                # 重定向到个人资料页 (使用命名空间)
                return redirect('users_web:profile')
            except Exception as e:
                logger.error(f"发送邮箱更改验证邮件失败 - 用户: {request.user.username}, 新邮箱: {new_email}, 错误: {str(e)}")
                messages.error(request, '发送验证邮件失败，请稍后重试或联系管理员。')
                # 渲染带有表单错误的页面
                return render(request, 'users/email_change_form.html', {'form': form})
        else:
            # 表单验证失败，重新显示表单和错误
            messages.error(request, '请修正表单中的错误。')
            # 渲染带有表单错误的页面
            return render(request, 'users/email_change_form.html', {'form': form})
    else:
        # GET 请求，显示空表单
        form = EmailChangeForm(user=request.user)
        # 传递空表单到模板
        return render(request, 'users/email_change_form.html', {'form': form})

@require_http_methods(["GET"])
def confirm_email_change(request, uidb64, token, emailb64):
    """处理邮箱更改确认链接的视图"""
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
        new_email = force_str(urlsafe_base64_decode(emailb64))
    except (TypeError, ValueError, OverflowError, User.DoesNotExist, Exception) as e:
        logger.warning(f"邮箱更改确认链接无效 - uidb64: {uidb64}, token: {token}, emailb64: {emailb64}, 错误: {str(e)}")
        user = None
        new_email = None

    if user is not None and new_email is not None and default_token_generator.check_token(user, token):
        # 令牌有效，进行最后的检查并更新邮箱
        # 再次检查新邮箱是否被其他用户占用（防止在发送邮件和确认之间被占用）
        if User.objects.filter(email__iexact=new_email, is_active=True).exclude(pk=user.pk).exists():
            messages.error(request, _('邮箱更改失败：该邮箱地址已被其他用户使用。'))
            logger.warning(f"用户 {user.username} 确认邮箱更改失败，新邮箱 {new_email} 已被占用。")
            # 重定向到个人资料页 (使用命名空间)
            return redirect('users_web:profile')

        # 更新邮箱
        old_email = user.email
        user.email = new_email
        # 设置邮箱已验证状态 (假设 User 模型有 is_email_verified 字段)
        user.is_email_verified = True
        user.save(update_fields=['email', 'is_email_verified'])
        messages.success(request, _('您的邮箱地址已成功更新。'))
        logger.info(f"用户 {user.username} 成功将邮箱从 {old_email} 更改为 {new_email}。")
        # 可选：登出用户，要求重新登录
        # logout(request)
        # messages.info(request, _('为了安全起见，您已退出登录，请使用新邮箱重新登录。'))
        # 重定向到个人资料页 (使用命名空间)
        return redirect('users_web:profile')
    else:
        # 令牌无效或过期
        messages.error(request, _('邮箱验证链接无效或已过期，请重新请求更改。'))
        logger.warning(f"邮箱更改确认失败 - 用户: {user.username if user else '未知'}, 链接无效或过期。")
        # 重定向到请求更改页面 (使用命名空间)
        return redirect('users_web:request_email_change')
