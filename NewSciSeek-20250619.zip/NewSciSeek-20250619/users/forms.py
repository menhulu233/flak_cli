from django import forms
from django.contrib.auth.forms import UserCreationForm, PasswordChangeForm
from django.utils.translation import gettext_lazy as _
from django.core.exceptions import ValidationError
from .models import User
from utils.email import EmailVerification

class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField(
        max_length=254,
        required=True,
        widget=forms.EmailInput(attrs={'class': 'form-control'})
    )
    verification_code = forms.CharField(
        max_length=6,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control'}),
        label=_('验证码')
    )
    
    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2', 'verification_code')
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update({'class': 'form-control'})
        self.fields['password1'].widget.attrs.update({'class': 'form-control'})
        self.fields['password2'].widget.attrs.update({'class': 'form-control'})
        
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError(_('该邮箱已被注册'))
        return email
        
    def clean_verification_code(self):
        email = self.cleaned_data.get('email')
        code = self.cleaned_data.get('verification_code')
        
        if not EmailVerification.verify_code(email, code):
            raise forms.ValidationError(_('验证码错误或已过期'))
        return code

class EmailChangeForm(forms.Form):
    """用于用户请求更改邮箱的表单"""
    email = forms.EmailField(
        label="New Email Address",
        max_length=254,
        widget=forms.EmailInput(attrs={'autocomplete': 'email', 'class': 'form-control'})
    )

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)

    def clean_email(self):
        new_email = self.cleaned_data.get('email')
        if not self.user:
            # This should not happen if used correctly in the view
            raise ValidationError(_("用户未指定。"))

        # 检查新邮箱是否与当前邮箱相同
        if new_email.lower() == self.user.email.lower():
            raise ValidationError(_("新邮箱地址不能与当前邮箱地址相同。"))

        # 检查新邮箱是否已被其他活跃用户使用
        if User.objects.filter(email__iexact=new_email, is_active=True).exclude(pk=self.user.pk).exists():
            raise ValidationError(_("此邮箱地址已被其他用户使用。"))

        return new_email 