from django.db import migrations

def populate_email_fields(apps, schema_editor):
    """为现有用户填充唯一的邮箱地址"""
    User = apps.get_model('users', 'User')
    # 获取所有邮箱为空的用户
    users_without_email = User.objects.filter(email='') | User.objects.filter(email__isnull=True)
    
    for i, user in enumerate(users_without_email):
        # 使用用户ID和序号创建唯一邮箱
        user.email = f"user_{user.id}_{i}@example.com"
        user.save()
    
    # 检查重复邮箱
    email_counts = {}
    for user in User.objects.all():
        if user.email in email_counts:
            email_counts[user.email] += 1
            # 为重复邮箱的用户创建新的唯一邮箱
            user.email = f"user_{user.id}_{email_counts[user.email]}@example.com"
            user.save()
        else:
            email_counts[user.email] = 1

class Migration(migrations.Migration):
    dependencies = [
        ('users', '0004_user_id_card_user_real_name_alter_user_is_verified_and_more'),
    ]

    operations = [
        migrations.RunPython(populate_email_fields),
    ] 