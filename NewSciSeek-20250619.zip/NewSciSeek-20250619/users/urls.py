from django.urls import path, include, reverse_lazy
from rest_framework.routers import DefaultRouter
from . import views
from .views import WechatLoginView, WechatCallbackView, WechatLoginStatusView, IdentityVerificationView, CheckIPView
from django.contrib.auth import views as auth_views

# API路由
router = DefaultRouter()
router.register(r'users', views.UserViewSet, basename='user')

# 设置通用app_name，用于命名空间
app_name = 'users_common'

# 网站URL模式
urlpatterns = [
    # 包含API路由
    path('', include(router.urls)),
    
    # 认证相关URL
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register_view, name='register'),
    path('profile/', views.profile_view, name='profile'),
    path('identity/', views.identity_verification_page, name='identity_verification_page'),
    path('identity/test/', views.identity_api_test_page, name='identity_api_test_page'),
    path('send-verification-code/', views.send_verification_code, name='send_verification_code'),
    # 邮箱更改
    path('email/change/', views.request_email_change, name='request_email_change'),
    path('email/confirm/<uidb64>/<token>/<emailb64>/', views.confirm_email_change, name='confirm_email_change'),
    
    # 密码重置
    path('password-reset/',
         auth_views.PasswordResetView.as_view(
             template_name='users/password_reset_form.html',
             email_template_name='users/password_reset_email.html',
             subject_template_name='users/password_reset_subject.txt',
             success_url=reverse_lazy('users_web:password_reset_done')
         ),
         name='password_reset'),
    path('password-reset/done/',
         auth_views.PasswordResetDoneView.as_view(
             template_name='users/password_reset_done.html'
         ),
         name='password_reset_done'),
    path('password-reset/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(
             template_name='users/password_reset_confirm.html',
             success_url=reverse_lazy('users_web:password_reset_complete')
         ),
         name='password_reset_confirm'),
    path('password-reset/complete/',
         auth_views.PasswordResetCompleteView.as_view(
             template_name='users/password_reset_complete.html'
         ),
         name='password_reset_complete'),
    
    # 微信登录相关
    path('wx/login/', WechatLoginView.as_view(), name='wechat_login'),
    path('wx/callback/', WechatCallbackView.as_view(), name='wechat_callback'),
    path('wx/status/', WechatLoginStatusView.as_view(), name='wechat_login_status'),
    
    # 身份证二要素验证
    path('identity/verify/', IdentityVerificationView.as_view(), name='identity_verification'),
    
    # IP检查
    path('check_ip/', CheckIPView.as_view(), name='check_ip'),
] 