from rest_framework import serializers
from django.contrib.auth import authenticate
from django.utils.translation import gettext_lazy as _
from .models import User


class UserRegisterSerializer(serializers.ModelSerializer):
    """用户注册序列化器"""
    password2 = serializers.CharField(write_only=True, required=True, style={'input_type': 'password'}, label=_('确认密码'))
    
    class Meta:
        model = User
        fields = ['email', 'password', 'password2']
        extra_kwargs = {
            'password': {'write_only': True, 'style': {'input_type': 'password'}},
            'email': {'required': True, 'help_text': _('邮箱地址')},
        }
    
    def validate(self, attrs):
        # 验证两次密码是否一致
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError({'password2': _('两次密码不一致')})
        
        # 验证邮箱是否已被注册
        email = attrs.get('email')
        if User.objects.filter(email=email).exists():
            raise serializers.ValidationError({'email': _('该邮箱已被注册')})
        
        return attrs
    
    def create(self, validated_data):
        # 移除password2字段
        validated_data.pop('password2', None)
        
        # 创建用户
        user = User.objects.create_user(**validated_data)
        return user


class UserLoginSerializer(serializers.Serializer):
    """用户登录序列化器"""
    account = serializers.CharField(label=_('账号'), required=True)
    password = serializers.CharField(label=_('密码'), style={'input_type': 'password'}, write_only=True)
    
    def validate(self, attrs):
        # 获取认证字段
        account = attrs.get('account')
        password = attrs.get('password')
        
        if not account:
            raise serializers.ValidationError({'account': _('请输入账号')})
        
        user = None
        
        # 如果账号像是邮箱，尝试邮箱登录
        if '@' in account:
            user = authenticate(self.context['request'], username=account, password=password)
        # 尝试用户名登录 (修正 authenticate 调用)
        else:
            # 仍然先检查用户是否存在，避免不必要的 authenticate 调用
            try:
                # 只检查是否存在，不直接用于 authenticate
                User.objects.get(username=account) 
                # 【修正】直接使用输入的 account (用户名) 进行认证
                user = authenticate(self.context['request'], username=account, password=password) 
            except User.DoesNotExist:
                # 用户名不存在，user 保持 None
                pass

        # 验证失败
        if not user:
            raise serializers.ValidationError(_('账号或密码错误'))
        # 检查用户是否激活 (可选但推荐)
        elif not user.is_active:
             raise serializers.ValidationError(_('此账号已被禁用')) # 提供更具体的错误

        # 验证成功
        attrs['user'] = user
        return attrs


class UserDetailSerializer(serializers.ModelSerializer):
    """用户详情序列化器"""
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'phone', 'avatar', 'bio', 'is_verified', 'date_joined', 'last_login']
        read_only_fields = ['id', 'is_verified', 'date_joined', 'last_login']


class UserUpdateSerializer(serializers.ModelSerializer):
    """用户更新序列化器"""
    class Meta:
        model = User
        fields = ['avatar', 'bio']
    
    def update(self, instance, validated_data):
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        return instance


class PasswordChangeSerializer(serializers.Serializer):
    """密码修改序列化器"""
    old_password = serializers.CharField(required=True, style={'input_type': 'password'}, label=_('旧密码'))
    new_password = serializers.CharField(required=True, style={'input_type': 'password'}, label=_('新密码'))
    new_password2 = serializers.CharField(required=True, style={'input_type': 'password'}, label=_('确认新密码'))
    
    def validate_old_password(self, value):
        user = self.context['request'].user
        if not user.check_password(value):
            raise serializers.ValidationError(_('旧密码不正确'))
        return value
    
    def validate(self, data):
        if data['new_password'] != data['new_password2']:
            raise serializers.ValidationError({'new_password2': _('两次密码不一致')})
        return data
    
    def save(self, **kwargs):
        user = self.context['request'].user
        user.set_password(self.validated_data['new_password'])
        user.save()
        return user 