/**
 * 认证相关的工具函数
 */

// 获取 CSRF Token
function getCsrfToken() {
    const name = 'csrftoken';
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    // 如果没有在cookie中找到，从meta标签获取
    if (!cookieValue) {
        const csrfToken = document.querySelector('meta[name="csrf-token"]');
        if (csrfToken) {
            cookieValue = csrfToken.getAttribute('content');
        }
    }
    return cookieValue;
}

// 获取认证令牌
function getAuthToken() {
    return localStorage.getItem('auth_token');
}

// 设置认证令牌
function setAuthToken(token) {
    localStorage.setItem('auth_token', token);
}

// 移除认证令牌
function removeAuthToken() {
    localStorage.removeItem('auth_token');
}

// 检查是否已登录
function isAuthenticated() {
    // 首先检查页面元标记
    const authMeta = document.querySelector('meta[name="user-authenticated"]');
    if (authMeta && authMeta.getAttribute('content') === 'true') {
        // 用户已通过Django认证，将用户信息保存到localStorage
        const userIdMeta = document.querySelector('meta[name="user-id"]');
        const usernameMeta = document.querySelector('meta[name="username"]');
        
        if (userIdMeta && usernameMeta) {
            localStorage.setItem('user_id', userIdMeta.getAttribute('content'));
            localStorage.setItem('username', usernameMeta.getAttribute('content'));
        }
        
        return true;
    }
    
    // 然后检查localStorage中的令牌（API客户端方式）
    if (getAuthToken()) {
        return true;
    }
    
    return false;
}

// 获取认证头
function getAuthHeaders() {
    const token = getAuthToken();
    const headers = {
        'Content-Type': 'application/json',
        'X-CSRFToken': getCsrfToken()
    };
    
    if (token) {
        headers['Authorization'] = `Token ${token}`;
    }
    
    return headers;
}

// 处理认证错误
function handleAuthError(error) {
    if (error.status === 401) {
        // 清除令牌并重定向到登录页面
        removeAuthToken();
        window.location.href = '/login/';
    }
    throw error;
}

// 登录函数
async function login(username, password) {
    try {
        const response = await fetch('/api/users/login/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCsrfToken()
            },
            body: JSON.stringify({
                phone: username,
                password: password
            })
        });
        
        if (!response.ok) {
            const data = await response.json();
            throw new Error(data.error || '登录失败');
        }
        
        const data = await response.json();
        setAuthToken(data.data.token);
        return data;
    } catch (error) {
        console.error('登录失败:', error);
        throw error;
    }
}

// 登出函数
async function logout() {
    try {
        const response = await fetch('/api/users/logout/', {
            method: 'POST',
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            throw new Error('登出失败');
        }
        
        removeAuthToken();
        window.location.href = '/login/';
    } catch (error) {
        console.error('登出失败:', error);
        throw error;
    }
}

// 获取当前用户信息
async function getCurrentUser() {
    try {
        const response = await fetch('/api/users/info/', {
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            return handleAuthError(response);
        }
        
        const data = await response.json();
        return data.data;
    } catch (error) {
        console.error('获取用户信息失败:', error);
        throw error;
    }
}

// 导出函数
export {
    getCsrfToken,
    getAuthToken,
    setAuthToken,
    removeAuthToken,
    isAuthenticated,
    getAuthHeaders,
    handleAuthError,
    login,
    logout,
    getCurrentUser
}; 