// 页面初始化
document.addEventListener('DOMContentLoaded', function() {
    const chatInput = document.getElementById('chatInput');
    const sendButton = document.getElementById('sendButton');
    const chatMessages = document.getElementById('chatMessages');
    const fileInput = document.getElementById('fileInput');
    const filePreview = document.getElementById('filePreview');
    const mobileToggle = document.getElementById('mobileToggle');
    const sidebar = document.getElementById('sidebar');
    const newChatBtn = document.getElementById('newChatBtn');
    const renameDialog = document.getElementById('renameDialog');
    const newTitleInput = document.getElementById('newTitleInput');
    const renameDialogConfirm = document.getElementById('renameDialogConfirm');
    const renameDialogCancel = document.getElementById('renameDialogCancel');
    
    // 绑定模态框关闭按钮事件
    const closeModalBtn = document.getElementById('closeModal');
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', function() {
            const modal = document.getElementById('balanceModal');
            if (modal) {
                modal.style.display = 'none';
            }
        });
    }
    
    let activeConversationId = document.querySelector('.chat-container').dataset.conversationId || null;
    let isStreaming = false;
    let currentTaskId = null;
    let uploadedFiles = [];
    let isFirstMessage = !activeConversationId || document.querySelectorAll('.message.user').length === 0;
    
    // 页面加载完成后自动滚动到对话底部
    if (chatMessages) {
        scrollToBottom();
    }
    
    // 自动调整输入框高度
    chatInput.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
        
        // 启用/禁用发送按钮
        if (this.value.trim() === '' && uploadedFiles.length === 0) {
            sendButton.disabled = true;
        } else {
            sendButton.disabled = false;
        }
    });
    
    // 调整输入框高度函数
    function adjustTextareaHeight() {
        chatInput.style.height = 'auto';
        chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
    }
    
    // 发送消息
    sendButton.addEventListener('click', function() {
        if (isStreaming) {
            // 如果正在流式传输，点击按钮应该停止
            stopStreaming();
        } else {
            // 否则正常发送消息
            sendMessage();
        }
    });
    
    // 按下Enter发送消息 (Shift+Enter换行)
    chatInput.addEventListener('keydown', function(event) {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            sendMessage();
        }
    });
    
    // 移动端侧边栏切换
    mobileToggle.addEventListener('click', function() {
        sidebar.classList.toggle('show');
    });
    
    // 为滚动相关事件添加passive选项
    chatMessages.addEventListener('touchstart', function() {}, { passive: true });
    chatMessages.addEventListener('touchmove', function() {}, { passive: true });
    chatMessages.addEventListener('wheel', function() {}, { passive: true });
    document.addEventListener('touchstart', function() {}, { passive: true });
    document.addEventListener('touchmove', function() {}, { passive: true });
    document.addEventListener('wheel', function() {}, { passive: true });
    
    // 新对话按钮
    newChatBtn.addEventListener('click', function() {
        // 向后端发送创建新会话的请求
        fetch('/api/chat/api/conversation/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCookie('csrftoken')
            },
            body: JSON.stringify({
                title: "新对话"
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // 清空当前会话，设置新的会话ID
                activeConversationId = data.conversation_id;
                isFirstMessage = true;
                clearMessages();
                updateChatTitle("新对话");
                
                // 更新URL以反映新会话
                window.history.pushState({}, '', `?conversation_id=${activeConversationId}`);
                
                // 在会话列表中添加新会话
                const conversationsList = document.getElementById('conversationsList');
                const newConversationItem = document.createElement('a');
                newConversationItem.href = `?conversation_id=${data.conversation_id}`;
                newConversationItem.className = 'conversation-item active';
                newConversationItem.dataset.id = data.conversation_id;
                
                // 当前时间格式化为MM-DD HH:MM
                const now = new Date();
                const month = String(now.getMonth() + 1).padStart(2, '0');
                const day = String(now.getDate()).padStart(2, '0');
                const hours = String(now.getHours()).padStart(2, '0');
                const minutes = String(now.getMinutes()).padStart(2, '0');
                const timeFormatted = `${month}-${day} ${hours}:${minutes}`;
                
                newConversationItem.innerHTML = `
                    <div class="conversation-title">新对话</div>
                    <div class="conversation-time">${timeFormatted}</div>
                    <div class="conversation-menu">
                        <button class="menu-btn rename-conversation" data-id="${data.conversation_id}" title="重命名会话">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="menu-btn delete-conversation" data-id="${data.conversation_id}" title="删除会话">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                `;
                
                // 设置所有会话为非活跃
                document.querySelectorAll('.conversation-item').forEach(item => {
                    item.classList.remove('active');
                });
                
                // 添加新会话到列表顶部
                if (conversationsList.firstChild) {
                    conversationsList.insertBefore(newConversationItem, conversationsList.firstChild);
                } else {
                    conversationsList.appendChild(newConversationItem);
                }
                
                // 移除可能存在的"暂无对话记录"提示
                const emptyMessage = conversationsList.querySelector('.text-muted');
                if (emptyMessage) {
                    emptyMessage.remove();
                }
                
                // 重新绑定删除按钮事件
                bindDeleteButtons();
                
                // 在移动端关闭侧边栏
                if (window.innerWidth <= 768) {
                    sidebar.classList.remove('show');
                }
            } else {
                showToast(data.error || '创建新会话失败', 'error');
            }
        })
        .catch(error => {
            // console.error('创建新会话失败:', error);
            showToast('创建新会话失败: ' + error.message, 'error');
        });
    });
    
    // 文件上传处理
    fileInput.addEventListener('change', function(event) {
        const files = event.target.files;
        if (files.length > 0) {
            handleFileUpload(files);
        }
    });
    
    // 处理文件上传
    function handleFileUpload(files) {
        Array.from(files).forEach(file => {
            if (file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const fileObj = {
                        type: 'image',
                        transfer_method: 'base64',
                        data: e.target.result.split(',')[1],  // 去掉前缀，只保留Base64数据
                        preview: e.target.result,
                        name: file.name
                    };
                    uploadedFiles.push(fileObj);
                    
                    // 创建文件预览
                    const fileItem = document.createElement('div');
                    fileItem.className = 'file-item';
                    fileItem.innerHTML = `
                        <img src="${e.target.result}" alt="${file.name}">
                        <span>${file.name}</span>
                        <button class="remove-file" data-index="${uploadedFiles.length - 1}">
                            <i class="fas fa-times"></i>
                        </button>
                    `;
                    filePreview.appendChild(fileItem);
                    
                    // 启用发送按钮
                    sendButton.disabled = false;
                };
                reader.readAsDataURL(file);
            }
        });
        
        // 清空input，以便再次选择相同文件
        fileInput.value = '';
        
        // 绑定删除文件事件
        setTimeout(() => {
            document.querySelectorAll('.remove-file').forEach(btn => {
                btn.addEventListener('click', function() {
                    const index = parseInt(this.dataset.index);
                    uploadedFiles.splice(index, 1);
                    this.closest('.file-item').remove();
                    
                    // 更新所有按钮的索引
                    document.querySelectorAll('.remove-file').forEach((btn, idx) => {
                        btn.dataset.index = idx;
                    });
                    
                    // 检查是否禁用发送按钮
                    if (chatInput.value.trim() === '' && uploadedFiles.length === 0) {
                        sendButton.disabled = true;
                    }
                });
            });
        }, 100);
    }
    
    // 发送消息功能
    function sendMessage() {
        const message = chatInput.value.trim();
        const files = uploadedFiles;
        uploadedFiles = [];  // 重置待上传文件
        
        // 如果没有消息且没有文件，则不发送
        if (!message && (!files || files.length === 0)) {
            return;
        }
        
        // 清空输入框
        chatInput.value = '';
        
        // 重置输入框高度
        adjustTextareaHeight();
        
        // 检查是否有活跃的会话，如果没有则创建新会话
        if (!activeConversationId) {
            // 标记这是第一条消息，用于自动重命名会话
            isFirstMessage = true;
        }
        
        // 检查是否正在流式传输，如果是则不发送新消息
        if (isStreaming) {
            return;
        }
        
        // 检查用户余额状态
        // console.log('开始检查用户余额');
        fetch('/api/billing/account/check/', {
            method: 'GET',
            headers: {
                'X-CSRFToken': getCookie('csrftoken')
            }
        })
        .then(response => {
            // console.log('余额检查API响应状态:', response.status);
            if (!response.ok) {
                throw new Error(`请求失败: ${response.status}`);
            }
            return response.json().then(data => {
                // console.log('余额检查API响应数据:', data);
                return data;
            });
        })
        .then(data => {
            // 直接调试输出所有响应数据
            // console.log('余额数据:', data);
            
            // 检查字段是否存在
            // console.log('is_sufficient字段:', data.is_sufficient);
            // console.log('balance字段:', data.balance);
            // console.log('min_cost字段:', data.min_cost);
            
            // 检查is_sufficient是否为假
            if (data.is_sufficient === false) {
                // console.log('检测到余额不足');
                
                // 显示Toast通知
                showToast(`账户余额不足，无法发送消息。当前余额: ${data.balance}，最低需要: ${data.min_cost}`, 'error', 5000);
                
                // 添加助手消息
                addMessage('assistant', `<div class="error-message">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-exclamation-circle" viewBox="0 0 16 16">
                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                        <path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z"/>
                    </svg> 
                    <span>账户余额不足，无法发送消息。</span>
                    <a href="/api/billing/account/recharge/" class="recharge-button">立即充值</a>
                </div>`);
                return;
            }
            
            // 余额充足，继续发送消息
            processSendMessage(message, files);
        })
        .catch(error => {
            // console.error('检查余额失败:', error);
            
            // 在发生错误时，为了安全起见，我们先显示一个警告，告知用户
            showToast('检查账户余额失败，但仍会尝试发送消息', 'warning', 3000);
            
            // 依然尝试发送消息，服务器端会再次检查余额
            processSendMessage(message, files);
        });
    }
    
    // 处理发送消息的实际逻辑
    function processSendMessage(message, files) {
        // 添加用户消息到界面
        addMessage('user', message);
        
        // 显示打字指示器
        showTypingIndicator();
        
        // 禁用发送按钮
        sendButton.disabled = true;
        
        // 准备请求数据
        const requestData = {
            message: message,
            conversation_id: activeConversationId || null
        };
        
        // 添加文件如果有
        if (files && files.length > 0) {
            requestData.files = files;
        }
        
        // 记录这是否是新会话的第一条消息
        shouldAutoRename = isFirstMessage;
        
        // 滚动到底部
        scrollToBottom();
        
        // 清空文件预览和上传文件数组
        const filePreviewContainer = document.getElementById('filePreviewContainer');
        if (filePreviewContainer) {
            filePreviewContainer.innerHTML = '';
            filePreviewContainer.style.display = 'none';
        }
        
        // 使用fetch API发起请求，然后逐行处理响应
        fetch('/api/chat/api/stream', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCookie('csrftoken')
            },
            body: JSON.stringify(requestData)
        })
        .then(response => {
            // console.log('API响应状态码:', response.status);
            
            // 特别处理402 Payment Required响应 (余额不足)
            if (response.status === 402) {
                // 停止加载状态
                finishStreaming();
                
                // console.log('收到402余额不足响应');
                
                // 直接显示模态框，不依赖于其他函数
                const modal = document.getElementById('balanceModal');
                if (modal) {
                    // console.log('找到模态框元素，设置display为flex');
                    modal.style.display = 'flex';
                } else {
                    // console.error('找不到balanceModal元素');
                }
                
                // 尝试读取并显示API返回的具体错误信息
                response.text().then(text => {
                    // console.log('402响应内容:', text);
                    let errorMsg = '账户余额不足，无法发送消息。';
                    
                    try {
                        const data = JSON.parse(text);
                        if (data.error) {
                            errorMsg = data.error;
                            // console.log('解析到错误信息:', errorMsg);
                        }
                    } catch (e) {
                        // console.error('解析402响应JSON失败:', e);
                    }
                    
                    // 添加错误消息到聊天界面
                    addMessage('assistant', `<div class="error-message">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-exclamation-circle" viewBox="0 0 16 16">
                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                            <path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z"/>
                        </svg> 
                        <span>${errorMsg}</span>
                        <a href="/api/billing/account/recharge/" class="recharge-button">立即充值</a>
                    </div>`);
                });
                
                // 中断处理链
                throw new Error('账户余额不足');
            }
            
            if (!response.ok) {
                throw new Error(`请求失败: ${response.status}`);
            }
            
            // 创建响应流的reader
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            
            // 处理流式响应
            return processStream(reader, decoder);
        })
        .catch(error => {
            // console.error('Stream error:', error);
            finishStreaming();
            
            // 显示错误消息
            const errorMsg = error.message || '请求失败';
            if (errorMsg.includes('余额不足')) {
                // 余额不足错误已经在前面处理了，这里不需要做额外处理
                // console.log('捕获到余额不足错误');
            } else {
                addMessage('assistant', `错误: ${errorMsg}`);
            }
        });
    }
    
    // 处理流式处理函数
    async function processStream(reader, decoder) {
        // 移除加载指示器
        removeTypingIndicator();
        
        // 设置流式传输状态
        isStreaming = true;
        
        // 更换发送按钮为停止按钮
        sendButton.innerHTML = '<i class="fas fa-stop"></i>';
        sendButton.classList.add('stop-button');
        sendButton.disabled = false;
        
        // 创建初始助手消息（空内容）
        messageElement = createMessageElement('assistant', '');
        chatMessages.appendChild(messageElement);
        
        let buffer = '';
        let currentMessage = ''; // 初始化currentMessage变量
        
        try {
            while (true) {
                const { done, value } = await reader.read();
                
                if (done) {
                    // 处理最后一个可能的消息
                    if (buffer) {
                        processEventData(buffer, currentMessage);
                    }
                    break;
                }
                
                // 解码并添加到缓冲区
                const text = decoder.decode(value, { stream: true });
                // console.log("收到原始数据块:", text);
                buffer += text;
                
                // 处理缓冲区中的完整事件
                let lines = buffer.split('\n');
                
                // 检查是否是纯文本响应而不是SSE格式
                if (lines.length === 1 && !buffer.includes('data: ') && !buffer.includes('event: ')) {
                    // 可能是纯文本响应，但需要确保缓冲区已完整
                    if (buffer.trim()) {
                        try {
                            // 尝试作为JSON解析
                            const data = JSON.parse(buffer);
                            currentMessage = processJsonData(data, currentMessage);
                            buffer = '';
                        } catch (e) {
                            // 不是JSON，可能是部分数据，继续等待更多数据
                            // 但如果数据超过一定长度，则当作纯文本处理
                            if (buffer.length > 1000 || done) {
                                currentMessage += buffer;
                                const contentElement = messageElement.querySelector('.message-content');
                                
                                // 直接使用innerHTML，不通过markdown-it处理，保留完整HTML标签和属性
                                if (buffer.includes('<details') && buffer.includes('style=')) {
                                    contentElement.innerHTML = currentMessage;
                                } else {
                                    try {
                                        contentElement.innerHTML = md.render(currentMessage);
                                        // 应用语法高亮
                                        contentElement.querySelectorAll('pre code').forEach(block => {
                                            hljs.highlightElement(block);
                                        });
                                    } catch (mdError) {
                                        // 如果markdown渲染失败，则使用纯文本
                                        contentElement.textContent = currentMessage;
                                    }
                                }
                                
                                scrollToBottom();
                                buffer = '';
                            }
                        }
                    }
                } else {
                    // 正常SSE格式处理
                    buffer = lines.pop() || ''; // 保留最后一个不完整的行
                    
                    for (const line of lines) {
                        if (line.trim()) {  // 只处理非空行
                            // 传递currentMessage变量并获取更新后的值
                            currentMessage = processEventData(line, currentMessage);
                        }
                    }
                }
            }
        } catch (error) {
            // console.error("流处理错误:", error);
            const contentElement = messageElement.querySelector('.message-content');
            contentElement.textContent += "\n\n[流式处理出错]";
        } finally {
            // 完成流式处理
            finishStreaming();
            
            // 如果是第一条消息，自动重命名会话
            if (shouldAutoRename && activeConversationId) {
                renameConversation(activeConversationId, '', true);
                isFirstMessage = false;
            }
        }
    }
    
    // 处理JSON数据
    function processJsonData(data, currentMessage) {
        // console.log("处理JSON数据:", data);
        
        // 尝试从各种可能的字段中获取内容
        let content = null;
        if (data.answer !== undefined) content = data.answer;
        else if (data.text !== undefined) content = data.text;
        else if (data.content !== undefined) content = data.content;
        else if (data.message !== undefined) content = data.message;
        else if (typeof data === 'string') content = data;
        
        if (content !== null) {
            currentMessage += content;
            const contentElement = messageElement.querySelector('.message-content');
            
            // 检查是否包含details标签和内联样式
            if (content.includes('<details') && content.includes('style=')) {
                contentElement.innerHTML = currentMessage;
            } else {
                try {
                    contentElement.innerHTML = md.render(currentMessage);
                    
                    // 修复markdown-body内边距问题
                    const mdBody = contentElement.querySelector('.markdown-body');
                    if (mdBody) {
                        mdBody.style.padding = '8px';
                        mdBody.style.maxWidth = '100%';
                    }
                    
                    // 特别处理details内的markdown-body
                    contentElement.querySelectorAll('details .markdown-body').forEach(dmb => {
                        dmb.style.padding = '0';
                        dmb.style.margin = '0';
                    });
                } catch (mdError) {
                    // console.warn("Markdown渲染错误:", mdError);
                    contentElement.textContent = currentMessage;
                }
            }
            
            // 应用语法高亮
            try {
                contentElement.querySelectorAll('pre code').forEach(block => {
                    hljs.highlightElement(block);
                });
            } catch (hlError) {
                // console.warn("语法高亮错误:", hlError);
            }
            
            // 激活details标签的交互
            try {
                contentElement.querySelectorAll('details').forEach(detail => {
                    detail.addEventListener('toggle', function() {
                        scrollToBottom();
                    });
                });
            } catch (detailsError) {
                // console.warn("Details交互绑定错误:", detailsError);
            }
            
            scrollToBottom();
        }
        
        // 尝试获取会话ID
        if (data.conversation_id && !activeConversationId) {
            activeConversationId = data.conversation_id;
            window.history.replaceState({}, '', `?conversation_id=${activeConversationId}`);
        }
        
        // 尝试获取任务ID
        if (data.task_id && !currentTaskId) {
            currentTaskId = data.task_id;
        }
        
        return currentMessage;
    }
    
    // 处理SSE格式的事件数据
    function processEventData(line, currentMessage) {
        if (line.startsWith('data: ')) {
            try {
                const jsonStr = line.substring(6);
                // 调试显示原始数据
                // console.log("SSE数据:", jsonStr);
                
                // 检查是否为ping事件，如果是则忽略
                if (line.includes('event: ping')) {
                    // console.log("忽略ping事件:", line);
                    return currentMessage;
                }
                
                // 尝试解析JSON
                try {
                    const data = JSON.parse(jsonStr);
                    return processJsonData(data, currentMessage);
                } catch (jsonError) {
                    // console.log("非JSON数据，作为纯文本处理:", jsonStr);
                    // 不是有效的JSON，作为纯文本处理
                    currentMessage += jsonStr;
                    const contentElement = messageElement.querySelector('.message-content');
                    
                    // 尝试使用markdown渲染，如果失败则使用纯文本
                    try {
                        contentElement.innerHTML = md.render(currentMessage);
                        
                        // 修复markdown-body内边距问题
                        const mdBody = contentElement.querySelector('.markdown-body');
                        if (mdBody) {
                            mdBody.style.padding = '8px';
                            mdBody.style.maxWidth = '100%';
                        }
                        
                        // 特别处理details内的markdown-body
                        contentElement.querySelectorAll('details .markdown-body').forEach(dmb => {
                            dmb.style.padding = '0';
                            dmb.style.margin = '0';
                        });
                        
                        // 应用语法高亮
                        contentElement.querySelectorAll('pre code').forEach(block => {
                            hljs.highlightElement(block);
                        });
                    } catch (mdError) {
                        contentElement.textContent = currentMessage;
                    }
                    
                    scrollToBottom();
                    return currentMessage;
                }
            } catch (e) {
                // console.warn('处理事件数据错误:', e, line);
                return currentMessage;
            }
        } else if (line.startsWith('event:') || line.startsWith('event: ')) {
            // 处理事件行，如event: ping
            // console.log("收到事件行:", line);
            // 忽略纯事件行，不添加到消息中
            return currentMessage;
        } else if (line.trim()) {
            // 可能是普通文本，直接显示
            // console.log("非SSE格式数据:", line);
            currentMessage += line + "\n";
            const contentElement = messageElement.querySelector('.message-content');
            try {
                contentElement.innerHTML = md.render(currentMessage);
                
                // 修复markdown-body内边距问题
                const mdBody = contentElement.querySelector('.markdown-body');
                if (mdBody) {
                    mdBody.style.padding = '8px';
                    mdBody.style.maxWidth = '100%';
                }
                
                // 特别处理details内的markdown-body
                contentElement.querySelectorAll('details .markdown-body').forEach(dmb => {
                    dmb.style.padding = '0';
                    dmb.style.margin = '0';
                });
                
                // 应用语法高亮
                contentElement.querySelectorAll('pre code').forEach(block => {
                    hljs.highlightElement(block);
                });
            } catch (mdError) {
                contentElement.textContent = currentMessage;
            }
            scrollToBottom();
            return currentMessage;
        }
        
        return currentMessage;
    }
    
    // 停止流式生成
    function stopStreaming() {
        if (currentTaskId) {
            fetch(`/api/chat/api/stop/${currentTaskId}`, {
                method: 'POST',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken')
                }
            })
            .then(response => response.json())
            .then(data => {
                // console.log('Stopped streaming', data);
            })
            .catch(error => {
                // console.error('Error stopping stream:', error);
            })
            .finally(() => {
                finishStreaming();
            });
        } else {
            finishStreaming();
        }
    }
    
    // 完成流式处理
    function finishStreaming() {
        isStreaming = false;
        currentTaskId = null;
        
        // 恢复发送按钮
        sendButton.innerHTML = '<i class="fas fa-paper-plane"></i>';
        sendButton.classList.remove('stop-button');
        sendButton.disabled = true;
        
        // 移除加载指示器
        removeTypingIndicator();
    }
    
    // 显示加载指示器
    function showTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.className = 'typing-indicator';
        indicator.innerHTML = '<span></span><span></span><span></span>';
        chatMessages.appendChild(indicator);
        scrollToBottom();
    }
    
    // 移除加载指示器
    function removeTypingIndicator() {
        const indicator = document.querySelector('.typing-indicator');
        if (indicator) {
            indicator.remove();
        }
    }
    
    // 添加消息到UI
    function addMessage(role, content) {
        const messageElement = createMessageElement(role, content);
        chatMessages.appendChild(messageElement);
        scrollToBottom();
    }
    
    // 创建消息元素
    function createMessageElement(role, content) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${role}`;
        
        const avatar = document.createElement('div');
        avatar.className = 'avatar';
        
        if (role === 'user') {
            avatar.innerHTML = '<i class="fas fa-user"></i>';
        } else {
            avatar.innerHTML = '<i class="fas fa-robot"></i>';
        }
        
        const messageContent = document.createElement('div');
        messageContent.className = 'message-content';
        
        // 使用Markdown渲染助手消息
        if (role === 'assistant' && content) {
            // 检查内容是否已经包含details标签
            if (content.includes('<details') && content.includes('style=')) {
                // 已包含HTML标签，直接设置避免再次解析
                messageContent.innerHTML = content;
            } else {
                // 保留<details>等HTML标签
                messageContent.innerHTML = md.render(content);
                
                // 修复markdown-body内边距问题
                const mdBody = messageContent.querySelector('.markdown-body');
                if (mdBody) {
                    mdBody.style.padding = '8px';
                    mdBody.style.maxWidth = '100%';
                }
                
                // 特别处理details内的markdown-body
                messageContent.querySelectorAll('details .markdown-body').forEach(dmb => {
                    dmb.style.padding = '0';
                    dmb.style.margin = '0';
                });
            }
            
            // 应用语法高亮
            messageContent.querySelectorAll('pre code').forEach(block => {
                hljs.highlightElement(block);
            });
            
            // 激活details标签的交互
            messageContent.querySelectorAll('details').forEach(detail => {
                detail.addEventListener('toggle', function() {
                    scrollToBottom();
                });
            });
        } else {
            // 用户消息处理 - 转义特殊SSE格式
            let escapedContent = content;
            // 转义event:前缀，防止被解析为SSE控制命令
            escapedContent = escapedContent.replace(/event:/g, 'event&#58;');
            escapedContent = escapedContent.replace(/data:/g, 'data&#58;');
            
            // 添加换行符
            escapedContent = escapedContent.replace(/\n/g, '<br>');
            
            messageContent.innerHTML = escapedContent;
        }
        
        const messageTime = document.createElement('div');
        messageTime.className = 'message-time';
        
        const now = new Date();
        const timeString = now.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
        messageTime.textContent = timeString;
        
        messageDiv.appendChild(avatar);
        messageDiv.appendChild(messageContent);
        messageDiv.appendChild(messageTime);
        
        return messageDiv;
    }
    
    // 清空消息区域
    function clearMessages() {
        while (chatMessages.firstChild) {
            chatMessages.removeChild(chatMessages.firstChild);
        }
        
        // 添加欢迎消息
        const welcomeDiv = document.createElement('div');
        welcomeDiv.className = 'text-center mt-5 text-muted';
        welcomeDiv.innerHTML = `
            <div class="mb-3">
                <i class="fas fa-robot fa-3x"></i>
            </div>
            <h4>欢迎使用 NewSciSeek 智能助手</h4>
            <p>您可以询问任何问题，我会尽力帮助您</p>
        `;
        chatMessages.appendChild(welcomeDiv);
    }
    
    // 更新聊天标题
    function updateChatTitle(title) {
        document.querySelector('.chat-title').textContent = title;
    }
    
    // 滚动到底部
    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // 获取CSRF Token
    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
    
    // 删除会话
    function deleteConversation(conversationId) {
        fetch(`/api/chat/api/conversation/${conversationId}/delete`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': getCookie('csrftoken')
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 'success') {
                // 删除成功，从UI中移除会话
                const conversationElement = document.querySelector(`.conversation-item[data-id="${conversationId}"]`);
                if (conversationElement) {
                    conversationElement.remove();
                }
                
                // 如果删除的是当前活跃的会话，刷新页面开始新会话
                if (activeConversationId === conversationId) {
                    window.location.href = '/chat/';
                }
                
                // 显示成功消息
                showToast(data.message || '会话已删除');
            } else {
                // 显示错误消息
                showToast(data.error || '删除会话失败', 'error');
            }
        })
        .catch(error => {
            // console.error('删除会话失败:', error);
            showToast('删除会话失败: ' + error.message, 'error');
        });
    }
    
    // 显示确认对话框
    function showConfirmDialog(title, message, confirmCallback) {
        const confirmDialog = document.getElementById('confirmDialog');
        const confirmDialogTitle = document.getElementById('confirmDialogTitle');
        const confirmDialogMessage = document.getElementById('confirmDialogMessage');
        const confirmDialogConfirm = document.getElementById('confirmDialogConfirm');
        const confirmDialogCancel = document.getElementById('confirmDialogCancel');
        
        confirmDialogTitle.textContent = title;
        confirmDialogMessage.textContent = message;
        
        confirmDialog.classList.add('show');
        
        // 绑定确认按钮事件
        const confirmClickHandler = function() {
            confirmCallback();
            confirmDialog.classList.remove('show');
            confirmDialogConfirm.removeEventListener('click', confirmClickHandler);
            confirmDialogCancel.removeEventListener('click', cancelClickHandler);
        };
        
        // 绑定取消按钮事件
        const cancelClickHandler = function() {
            confirmDialog.classList.remove('show');
            confirmDialogConfirm.removeEventListener('click', confirmClickHandler);
            confirmDialogCancel.removeEventListener('click', cancelClickHandler);
        };
        
        confirmDialogConfirm.addEventListener('click', confirmClickHandler);
        confirmDialogCancel.addEventListener('click', cancelClickHandler);
    }
    
    // 添加一个Toast提示函数 - 在合适的位置添加此函数
    function showToast(message, type = 'info', duration = 3000) {
        // 添加控制台日志
        // console.log(`显示Toast: ${message} (类型: ${type})`);
        
        // 移除现有的toast
        const existingToast = document.querySelector('.toast-message');
        if (existingToast) {
            existingToast.remove();
        }
        
        // 创建新的toast
        const toast = document.createElement('div');
        toast.className = `toast-message toast-${type}`;
        toast.textContent = message;
        
        // 添加到页面
        document.body.appendChild(toast);
        
        // 显示toast
        setTimeout(() => {
            toast.classList.add('show');
        }, 10);
        
        // 设置自动消失
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                toast.remove();
            }, 300);
        }, duration);
    }
    
    // 绑定删除按钮事件
    function bindDeleteButtons() {
        document.querySelectorAll('.delete-conversation').forEach(btn => {
            btn.addEventListener('click', function(event) {
                event.preventDefault();
                event.stopPropagation();
                const conversationId = this.dataset.id;
                showConfirmDialog(
                    '删除会话',
                    '确定要删除此会话吗？此操作不可恢复。',
                    function() {
                        deleteConversation(conversationId);
                    }
                );
            });
        });
    }
    
    // 初始化绑定现有的删除按钮
    bindDeleteButtons();
    
    // 初始化绑定重命名操作
    bindRenameEvents();
    
    // 绑定重命名相关事件
    function bindRenameEvents() {
        // 为每个会话项添加右键菜单支持
        document.querySelectorAll('.conversation-item').forEach(item => {
            item.addEventListener('contextmenu', function(event) {
                event.preventDefault();
                const conversationId = this.dataset.id;
                showRenameDialog(conversationId);
            });
            
            // 添加重命名按钮到会话菜单（如果不存在）
            const menu = item.querySelector('.conversation-menu');
            if (menu && !menu.querySelector('.rename-conversation')) {
                const renameBtn = document.createElement('button');
                renameBtn.className = 'menu-btn rename-conversation';
                renameBtn.title = '重命名会话';
                renameBtn.dataset.id = item.dataset.id;
                renameBtn.innerHTML = '<i class="fas fa-edit"></i>';
                
                // 在删除按钮前插入
                const deleteBtn = menu.querySelector('.delete-conversation');
                if (deleteBtn) {
                    menu.insertBefore(renameBtn, deleteBtn);
                } else {
                    menu.appendChild(renameBtn);
                }
            }
        });
        
        // 绑定重命名按钮事件
        document.querySelectorAll('.rename-conversation').forEach(btn => {
            btn.addEventListener('click', function(event) {
                event.preventDefault();
                event.stopPropagation();
                const conversationId = this.dataset.id;
                showRenameDialog(conversationId);
            });
        });
        
        // 绑定重命名对话框按钮事件
        if (renameDialogConfirm) {
            renameDialogConfirm.addEventListener('click', function() {
                const conversationId = renameDialog.dataset.conversationId;
                const newTitle = newTitleInput.value.trim();
                if (conversationId && newTitle) {
                    renameConversation(conversationId, newTitle);
                    hideRenameDialog();
                }
            });
        }
        
        if (renameDialogCancel) {
            renameDialogCancel.addEventListener('click', hideRenameDialog);
        }
        
        // 按Esc键关闭对话框
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && renameDialog.classList.contains('show')) {
                hideRenameDialog();
            }
        });
    }
    
    // 显示重命名对话框
    function showRenameDialog(conversationId) {
        // 设置当前会话ID
        renameDialog.dataset.conversationId = conversationId;
        
        // 获取当前会话标题作为默认值
        const conversationItem = document.querySelector(`.conversation-item[data-id="${conversationId}"]`);
        let currentTitle = '';
        if (conversationItem) {
            const titleElement = conversationItem.querySelector('.conversation-title');
            if (titleElement) {
                currentTitle = titleElement.textContent.trim();
            }
        }
        
        // 设置输入框默认值
        newTitleInput.value = currentTitle;
        
        // 显示对话框
        renameDialog.classList.add('show');
        
        // 聚焦输入框并选中所有文本
        setTimeout(() => {
            newTitleInput.focus();
            newTitleInput.select();
        }, 100);
    }
    
    // 隐藏重命名对话框
    function hideRenameDialog() {
        renameDialog.classList.remove('show');
        newTitleInput.value = '';
        delete renameDialog.dataset.conversationId;
    }
    
    // Markdown渲染器
    const md = {
        render: function(text) {
            // 使用页面中已定义的simpleMd函数
            return window.simpleMd ? window.simpleMd(text) : text;
        }
    };

    // 重命名会话功能
    function renameConversation(conversationId, newTitle, autoRename = false) {
        // 如果是自动重命名且没有提供新标题，则使用第一条用户消息作为标题
        if (autoRename && !newTitle) {
            const userMessages = document.querySelectorAll('.message.user .message-content');
            if (userMessages.length > 0) {
                // 获取第一条用户消息的内容
                let firstMessage = userMessages[0].textContent.trim();
                // 限制标题长度，最多取前20个字符
                newTitle = firstMessage.length > 20 ? firstMessage.substring(0, 20) + '...' : firstMessage;
            } else {
                return; // 没有用户消息，不执行重命名
            }
        }

        // 如果没有新标题，则不执行重命名
        if (!newTitle) return;

        // 发送重命名请求到后端
        fetch(`/api/chat/api/conversation/${conversationId}/rename`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCookie('csrftoken')
            },
            body: JSON.stringify({
                title: newTitle
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 'success') {
                // 更新UI中的会话标题
                updateChatTitle(newTitle);
                
                // 更新侧边栏中的会话标题
                const conversationItem = document.querySelector(`.conversation-item[data-id="${conversationId}"]`);
                if (conversationItem) {
                    const titleElement = conversationItem.querySelector('.conversation-title');
                    if (titleElement) {
                        titleElement.textContent = newTitle;
                    }
                }
                
                if (!autoRename) {
                    // 显示成功消息（仅手动重命名时）
                    showToast(data.message || '会话已重命名');
                }
            } else {
                // 显示错误消息
                showToast(data.error || '重命名会话失败', 'error');
            }
        })
        .catch(error => {
            // console.error('重命名会话失败:', error);
            showToast('重命名会话失败: ' + error.message, 'error');
        });
    }
});