/**
 * 登录页面功能
 */

import { login } from './auth.js';

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
    // 获取表单元素
    const loginForm = document.querySelector('form');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const rememberCheckbox = document.getElementById('remember');
    const togglePasswordBtn = document.querySelector('.toggle-password');
    
    // 切换密码显示/隐藏
    togglePasswordBtn.addEventListener('click', () => {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        togglePasswordBtn.querySelector('i').classList.toggle('fa-eye');
        togglePasswordBtn.querySelector('i').classList.toggle('fa-eye-slash');
    });
    
    // 表单提交处理
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // 获取表单数据
        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();
        
        // 表单验证
        if (!username || !password) {
            showError('请填写用户名和密码');
            return;
        }
        
        try {
            // 显示加载状态
            const submitBtn = loginForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> 登录中...';
            
            // 调用登录 API
            const response = await login(username, password);
            
            // 登录成功
            if (response.code === 200) {
                // 如果选择了"记住我"，将用户名保存到 localStorage
                if (rememberCheckbox.checked) {
                    localStorage.setItem('remembered_username', username);
                } else {
                    localStorage.removeItem('remembered_username');
                }
                
                // 跳转到首页
                window.location.href = '/';
            } else {
                showError(response.msg || '登录失败');
            }
        } catch (error) {
            showError(error.message || '登录失败，请重试');
        } finally {
            // 恢复按钮状态
            const submitBtn = loginForm.querySelector('button[type="submit"]');
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        }
    });
    
    // 检查是否有保存的用户名
    const rememberedUsername = localStorage.getItem('remembered_username');
    if (rememberedUsername) {
        usernameInput.value = rememberedUsername;
        rememberCheckbox.checked = true;
    }
});

// 显示错误信息
function showError(message) {
    const messagesContainer = document.querySelector('.messages');
    if (!messagesContainer) {
        // 如果消息容器不存在，创建一个
        const container = document.createElement('div');
        container.className = 'messages mt-3';
        document.querySelector('.login-form').appendChild(container);
        messagesContainer = container;
    }
    
    // 创建错误消息元素
    const alert = document.createElement('div');
    alert.className = 'alert alert-danger alert-dismissible fade show';
    alert.role = 'alert';
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // 添加到消息容器
    messagesContainer.appendChild(alert);
    
    // 3秒后自动移除
    setTimeout(() => {
        alert.remove();
    }, 3000);
} 