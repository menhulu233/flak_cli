/**
 * 国际化工具类
 */
class I18n {
    constructor() {
        this.translations = {};
        this.currentLang = localStorage.getItem('prefLang') || 'zh';
        this.supportedLangs = ['zh', 'en'];
        
        // 初始化语言，优先顺序：localStorage > URL参数 > 浏览器首选语言
        this.initLanguage();
    }

    /**
     * 初始化语言设置
     */
    async initLanguage() {
        // 检查URL参数
        const urlParams = new URLSearchParams(window.location.search);
        const langParam = urlParams.get('lang');
        
        if (langParam && this.supportedLangs.includes(langParam)) {
            this.currentLang = langParam;
            localStorage.setItem('prefLang', langParam);
        } else if (!localStorage.getItem('prefLang')) {
            // 检查浏览器首选语言
            const browserLang = navigator.language.split('-')[0];
            if (this.supportedLangs.includes(browserLang)) {
                this.currentLang = browserLang;
                localStorage.setItem('prefLang', browserLang);
            }
        }
        
        // 加载当前语言包
        await this.loadLanguage(this.currentLang);
        
        // 更新语言切换按钮文本
        this.updateToggleButton();
        
        // 应用当前语言
        this.updatePageLanguage();
    }

    /**
     * 加载指定语言的翻译文件
     * @param {string} lang - 语言代码
     * @returns {Promise} - 加载完成的Promise
     */
    async loadLanguage(lang) {
        try {
            const response = await fetch(`/static/js/i18n/${lang}.json`);
            if (!response.ok) {
                throw new Error(`Failed to load language file: ${lang}.json`);
            }
            this.translations[lang] = await response.json();
            return true;
        } catch (error) {
            console.error('Error loading language file:', error);
            return false;
        }
    }

    /**
     * 获取翻译文本
     * @param {string} key - 翻译键，支持嵌套格式 'common.back'
     * @param {Object} params - 替换参数对象 {name: 'John'}
     * @returns {string} - 翻译后的文本
     */
    t(key, params = {}) {
        const keys = key.split('.');
        let value = this.translations[this.currentLang];
        
        // 获取嵌套值
        for (const k of keys) {
            if (value && value[k] !== undefined) {
                value = value[k];
            } else {
                console.warn(`Translation key not found: ${key}`);
                return key; // 返回键名作为后备
            }
        }
        
        // 替换参数
        if (params && typeof value === 'string') {
            Object.keys(params).forEach(paramKey => {
                value = value.replace(new RegExp(`{{${paramKey}}}`, 'g'), params[paramKey]);
            });
        }
        
        return value;
    }

    /**
     * 切换语言
     * @returns {Promise} - 完成切换的Promise
     */
    async toggleLanguage() {
        // 切换语言
        this.currentLang = this.currentLang === 'zh' ? 'en' : 'zh';
        
        // 保存到localStorage
        localStorage.setItem('prefLang', this.currentLang);
        
        // 如果尚未加载当前语言包，则加载
        if (!this.translations[this.currentLang]) {
            await this.loadLanguage(this.currentLang);
        }
        
        // 更新URL参数但不刷新页面
        const url = new URL(window.location);
        url.searchParams.set('lang', this.currentLang);
        window.history.pushState({}, '', url);
        
        // 更新语言切换按钮
        this.updateToggleButton();
        
        // 更新页面文本
        this.updatePageLanguage();
    }

    /**
     * 更新语言切换按钮文本
     */
    updateToggleButton() {
        const langToggle = document.getElementById('lang-toggle');
        if (langToggle && this.translations[this.currentLang]) {
            langToggle.textContent = this.translations[this.currentLang]['lang-toggle'];
        }
    }

    /**
     * 更新页面上所有需要翻译的元素
     */
    updatePageLanguage() {
        if (!this.translations[this.currentLang]) return;
        
        // 更新所有带有data-i18n属性的元素
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            const text = this.t(key);
            if (text) {
                element.innerHTML = text;
            }
        });
        
        // 为了兼容现有实现，也更新所有id匹配的元素
        for (const [key, value] of Object.entries(this.translations[this.currentLang])) {
            // 跳过嵌套对象
            if (typeof value !== 'string') continue;
            
            const element = document.getElementById(key);
            if (element) {
                element.innerHTML = value;
            }
        }
        
        // 触发自定义事件，通知其他脚本语言已更改
        document.dispatchEvent(new CustomEvent('languageChanged', {
            detail: { language: this.currentLang }
        }));
    }
}

// 创建全局i18n实例
window.i18n = new I18n();

// 暴露全局函数以便在HTML内直接使用
window.toggleLanguage = function() {
    window.i18n.toggleLanguage();
};

// 文档加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    // 初始化已在构造函数中完成
});

// 简便的翻译函数 
window.t = function(key, params) {
    return window.i18n.t(key, params);
}; 