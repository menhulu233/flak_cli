/**
 * API 请求工具函数
 */

import { getAuthHeaders, handleAuthError, getCsrfToken } from './auth.js';

// 通用 GET 请求
async function get(url, params = {}) {
    try {
        // 构建查询字符串
        const queryString = new URLSearchParams(params).toString();
        const fullUrl = queryString ? `${url}?${queryString}` : url;
        
        const response = await fetch(fullUrl, {
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            return handleAuthError(response);
        }
        
        return await response.json();
    } catch (error) {
        console.error('GET 请求失败:', error);
        throw error;
    }
}

// 通用 POST 请求
async function post(url, data = {}) {
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify(data)
        });
        
        if (!response.ok) {
            return handleAuthError(response);
        }
        
        return await response.json();
    } catch (error) {
        console.error('POST 请求失败:', error);
        throw error;
    }
}

// 通用 PUT 请求
async function put(url, data = {}) {
    try {
        const response = await fetch(url, {
            method: 'PUT',
            headers: getAuthHeaders(),
            body: JSON.stringify(data)
        });
        
        if (!response.ok) {
            return handleAuthError(response);
        }
        
        return await response.json();
    } catch (error) {
        console.error('PUT 请求失败:', error);
        throw error;
    }
}

// 通用 DELETE 请求
async function del(url) {
    try {
        const response = await fetch(url, {
            method: 'DELETE',
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            return handleAuthError(response);
        }
        
        return await response.json();
    } catch (error) {
        console.error('DELETE 请求失败:', error);
        throw error;
    }
}

// 通用 PATCH 请求
async function patch(url, data = {}) {
    try {
        const response = await fetch(url, {
            method: 'PATCH',
            headers: getAuthHeaders(),
            body: JSON.stringify(data)
        });
        
        if (!response.ok) {
            return handleAuthError(response);
        }
        
        return await response.json();
    } catch (error) {
        console.error('PATCH 请求失败:', error);
        throw error;
    }
}

// 通用 POST 请求（流式响应）
async function postWithStream(url, data = {}, onChunk = null) {
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify(data)
        });
        
        if (!response.ok) {
            return handleAuthError(response);
        }
        
        // 处理流式响应
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        
        let done = false;
        let result = "";
        
        // 读取流数据
        while (!done) {
            const { value, done: doneReading } = await reader.read();
            done = doneReading;
            
            if (done) break;
            
            // 解码当前数据块
            const chunk = decoder.decode(value, { stream: true });
            
            // 如果提供了回调函数，则调用它
            if (onChunk) {
                onChunk(chunk);
            }
            
            result += chunk;
        }
        
        // 尝试解析完整的JSON数据
        try {
            return JSON.parse(result);
        } catch {
            return { raw: result };
        }
    } catch (error) {
        console.error('流式POST请求失败:', error);
        throw error;
    }
}

// 导出函数
export {
    get,
    post,
    put,
    del,
    patch,
    postWithStream
}; 