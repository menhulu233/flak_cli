from django.contrib import admin
from .models import Conversation, Message, MajorQuestion, ChatTokenUsage, PreprocessedContent
import requests
import logging
import json
import re
from django.urls import path
from django.shortcuts import redirect
from django.template.response import TemplateResponse
from django.utils.html import format_html
from django.urls import reverse
from django.conf import settings
from django.db import transaction
from django.http import HttpResponseRedirect
from django.contrib import messages

# 获取日志记录器
logger = logging.getLogger(__name__)

class MessageInline(admin.TabularInline):
    model = Message
    extra = 0
    readonly_fields = ('role', 'content', 'created_at', 'tokens', 'dify_message_id')
    can_delete = False
    
    def has_add_permission(self, request, obj=None):
        return False

class TokenUsageInline(admin.TabularInline):
    model = ChatTokenUsage
    extra = 0
    readonly_fields = ('prompt_tokens', 'completion_tokens', 'total_tokens', 'cost', 'currency', 'created_at')
    can_delete = False
    
    def has_add_permission(self, request, obj=None):
        return False

@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'title', 'created_at', 'updated_at', 'get_message_count')
    list_filter = ('user', 'created_at')
    search_fields = ('title', 'user__username')
    readonly_fields = ('created_at', 'updated_at')

    def get_message_count(self, obj):
        return obj.messages.count()
    get_message_count.short_description = 'Messages'

@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ('id', 'conversation', 'role', 'truncated_content', 'created_at')
    list_filter = ('role', 'created_at', 'conversation__user')
    search_fields = ('content', 'conversation__title')
    readonly_fields = ('created_at',)

    def truncated_content(self, obj):
        return (obj.content[:75] + '...') if len(obj.content) > 75 else obj.content
    truncated_content.short_description = 'Content'

@admin.register(ChatTokenUsage)
class TokenUsageAdmin(admin.ModelAdmin):
    list_display = ('user', 'get_conversation_title', 'prompt_tokens', 'completion_tokens', 'total_tokens', 'cost', 'created_at')
    list_filter = ('user', 'created_at', 'currency')
    search_fields = ('user__username', 'conversation__title')
    readonly_fields = ('prompt_tokens', 'completion_tokens', 'total_tokens', 'cost', 'currency', 'created_at')
    
    def get_conversation_title(self, obj):
        return obj.conversation.title
    get_conversation_title.short_description = '会话'

@admin.register(MajorQuestion)
class MajorQuestionAdmin(admin.ModelAdmin):
    list_display = ('question_preview', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('question',)
    
    def question_preview(self, obj):
        return obj.question[:50] + '...' if len(obj.question) > 50 else obj.question
    question_preview.short_description = '问题预览'

@admin.register(PreprocessedContent)
class PreprocessedContentAdmin(admin.ModelAdmin):
    list_display = ('id', 'truncated_content', 'created_at')
    search_fields = ('content',)
    readonly_fields = ('created_at',)

    def truncated_content(self, obj):
        limit = 100
        if obj.content:
            return (obj.content[:limit] + '...') if len(obj.content) > limit else obj.content
        return "(No content)"
    truncated_content.short_description = 'Content Preview'

    def get_urls(self):
        """添加自定义 URL"""
        urls = super().get_urls()
        custom_urls = [
            path('trigger-dify-call/', self.admin_site.admin_view(self.trigger_dify_call_view), name='chat_preprocessedcontent_trigger_dify'),
        ]
        return custom_urls + urls

    def trigger_dify_call_view(self, request):
        """处理触发 Dify API 调用的视图"""
        if request.method == 'POST':
            repetitions_str = request.POST.get('repetitions', '1')
            try:
                repetitions = int(repetitions_str)
                if repetitions <= 0:
                    raise ValueError("Repetitions must be a positive integer.")
            except ValueError as e:
                messages.error(request, f"Invalid input for repetitions: {e}")
                # 重定向回列表页
                changelist_url = reverse('admin:chat_preprocessedcontent_changelist')
                return HttpResponseRedirect(changelist_url)

            # --- 从 tasks.py 移植并修改的逻辑 ---
            api_key = settings.DIFY_API_KEY_SECONDARY
            base_url = settings.DIFY_API_BASE_URL_SECONDARY

            if not api_key or not base_url:
                messages.error(request, "Secondary Dify API Key or Base URL not configured.")
                changelist_url = reverse('admin:chat_preprocessedcontent_changelist')
                return HttpResponseRedirect(changelist_url)

            endpoint = f"{base_url.rstrip('/')}/chat-messages"
            headers = {
                'Authorization': f'Bearer {api_key}',
                'Content-Type': 'application/json'
            }
            # 保持与 task 中相同的 payload query
            payload = {
                "inputs": {},
                "query": """结合一下下面的理论，将物理学进行概念和参数重塑：
宇宙万物都是正能量E⁺，但相对活泼的物质或能量是相对稳定物质或能量的反能量E⁻，宇宙万物有自己的反馈强度，反馈强度γ的定义是系统维持有序的能力，当物质发生变化时（如生物或星球内部结构发生变化），反馈强度也发生变化，外界的不平衡作用（非平衡状态）高于物质的反馈强度时，使物质的一部分正能量E⁺变化为反能量E⁻，反能量E⁻与正能量E⁺产生反应使熵增变大但同时产生出一部分有序状态。不平衡作用（非平衡状态）越大，产生的反能量越极端，产生的有序状态越有序，产生的熵增更多，但复杂系统不能承受过大的不平衡作用（非平衡状态），否则会产生崩溃，如：生命无法承受过大的物理或精神压力，否则会造成身体或精神崩溃，另外，开放系统可以通过补充外部的正能量而使自身壮大，不至于因为上述反应同时变成有序和熵增而使自身体积逐渐减小，例如人体通过进食，当进食量大于不平衡作用消耗的能量时，体重增加。空间由熵的增加产生。""",
                "user": "admin-trigger", # 标识调用方
                "response_mode": "streaming",
                "conversation_id": "",
            }

            success_count = 0
            errors = []

            for i in range(repetitions):
                logger.info(f"Admin Trigger: Calling Dify API (Repetition {i+1}/{repetitions})")
                try:
                    # 设置稍长的超时时间，因为这是同步请求
                    response = requests.post(endpoint, headers=headers, json=payload, stream=True, timeout=600)
                    response.raise_for_status()

                    extracted_text = ""
                    for chunk in response.iter_lines():
                        if chunk:
                            try:
                                decoded_chunk = chunk.decode('utf-8')
                                if decoded_chunk.startswith('data: '):
                                    try:
                                        json_data = json.loads(decoded_chunk[len('data: '):])
                                        # 在同步模式下，可能需要调整事件处理逻辑，
                                        # 这里我们仍然只关注最终的输出
                                        if json_data.get('event') == 'node_finished':
                                            outputs = json_data.get('data', {}).get('outputs', {})
                                            if outputs and 'text' in outputs:
                                                extracted_text += outputs['text']
                                        # 如果需要累加 'message' 事件的 'answer'，可以在这里添加逻辑
                                        # elif json_data.get('event') == 'message':
                                        #     answer = json_data.get('answer')
                                        #     if answer:
                                        #         extracted_text += answer

                                    except json.JSONDecodeError:
                                        logger.warning(f"Admin Trigger: JSONDecodeError for chunk: {decoded_chunk}")
                                        errors.append(f"Rep {i+1}: JSON decode error.")
                            except UnicodeDecodeError:
                                logger.warning("Admin Trigger: UnicodeDecodeError.")
                                errors.append(f"Rep {i+1}: Decode error.")

                    # 清理并保存
                    cleaned_text = extracted_text.strip()
                    if cleaned_text:
                        # 使用与 tasks.py 中相同的清理逻辑 (确保 re 被导入)
                        # 移除 <details> 块但保留其内容
                        # cleaned_text = re.sub(r'<details.*?<summary>.*?</summary>(.*?)<\\/details>', r'\\1', cleaned_text, flags=re.DOTALL | re.IGNORECASE).strip()
                        # 或者，如果只想简单移除整个块而不保留任何内容：
                        # cleaned_text = re.sub(r'<details.*?</details>', '', cleaned_text, flags=re.DOTALL | re.IGNORECASE).strip()
                        # 清理 <think> 块 (完全移除)
                        cleaned_text = re.sub(r'<think>.*?</think>', '', cleaned_text, flags=re.DOTALL | re.IGNORECASE).strip()


                    if cleaned_text:
                        try:
                            # 获取原始查询
                            original_query = payload.get('query', '')
                            # 格式化保存的内容
                            content_to_save = f"问题：\n{original_query}\n\n回复：\n{cleaned_text}"
                            with transaction.atomic():
                                PreprocessedContent.objects.create(content=content_to_save)
                            success_count += 1
                            logger.info(f"Admin Trigger: Saved question and response for repetition {i+1}.")
                        except Exception as db_error:
                            logger.error(f"Admin Trigger: DB save error for repetition {i+1}: {db_error}")
                            errors.append(f"Rep {i+1}: DB save error - {db_error}")
                    else:
                        logger.info(f"Admin Trigger: Empty content after cleaning for repetition {i+1}.")
                        # 将空内容也视为一种错误或警告
                        errors.append(f"Rep {i+1}: Empty content after processing.")

                except requests.exceptions.RequestException as e:
                    logger.error(f"Admin Trigger: API Call RequestException for repetition {i+1}: {e}")
                    errors.append(f"Rep {i+1}: API Request error - {e}")
                except Exception as e:
                    logger.error(f"Admin Trigger: Unexpected error for repetition {i+1}: {e}", exc_info=True)
                    errors.append(f"Rep {i+1}: Unexpected error - {e}")

            # 循环结束后添加消息
            if success_count > 0:
                messages.success(request, f"Successfully executed {success_count}/{repetitions} calls and saved results.")
            if errors:
                # 显示更详细的错误信息
                error_summary = '; '.join(errors[:5]) # 显示前5个错误
                if len(errors) > 5:
                    error_summary += '...'
                messages.warning(request, f"Finished with {len(errors)} errors out of {repetitions} calls. Errors: {error_summary}. Check logs for more details.")
            if success_count == 0 and not errors:
                 messages.warning(request, f"Executed {repetitions} calls, but no content was saved (likely empty or invalid responses).")
            elif success_count == 0 and errors:
                 messages.error(request, f"All {repetitions} calls failed.")

            # 重定向回列表页
            changelist_url = reverse('admin:chat_preprocessedcontent_changelist')
            return HttpResponseRedirect(changelist_url)
        else:
            # 对 GET 请求直接重定向，不允许通过 GET 触发
            changelist_url = reverse('admin:chat_preprocessedcontent_changelist')
            return HttpResponseRedirect(changelist_url)
