from django.db import models
from django.conf import settings
from django.utils.translation import gettext_lazy as _
import uuid
from decimal import Decimal

class Conversation(models.Model):
    """聊天会话模型"""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='conversations')
    conversation_id = models.UUIDField(_('会话ID'), default=uuid.uuid4, unique=True, editable=False)
    title = models.CharField(_('标题'), max_length=200)
    created_at = models.DateTimeField(_('创建时间'), auto_now_add=True)
    updated_at = models.DateTimeField(_('更新时间'), auto_now=True)
    is_archived = models.BooleanField(_('是否归档'), default=False)
    model_type = models.CharField(_('模型类型'), max_length=50, default='gpt-3.5-turbo')
    
    # --- 新增字段记录思考模式 ---
    THINKING_MODE_CHOICES = (
        ('simple', _('简单思考')),
        ('deep', _('深度思考')),
        ('heavy', _('重度思考')),
    )
    thinking_mode = models.CharField(
        _('思考模式'), 
        max_length=10, 
        choices=THINKING_MODE_CHOICES, 
        default='simple', 
        null=True,  # 允许在旧会话中为空
        blank=True  # 允许在旧会话中为空
    )
    # --- 结束新增字段 ---
    
    # Token统计跟踪字段 - 用于计算每次对话的token差值
    last_prompt_tokens = models.IntegerField(_('上次提示词token数'), default=0)
    last_completion_tokens = models.IntegerField(_('上次回复token数'), default=0)
    last_total_tokens = models.IntegerField(_('上次总token数'), default=0)
    
    # Dify相关字段
    dify_conversation_id = models.CharField(_('Dify会话ID'), max_length=100, null=True, blank=True)
    dify_app_id = models.CharField(_('Dify应用ID'), max_length=100, null=True, blank=True)
    dify_status = models.CharField(_('Dify状态'), max_length=20, default='normal')
    dify_metadata = models.JSONField(_('Dify元数据'), null=True, blank=True)
    
    class Meta:
        verbose_name = _('聊天会话')
        verbose_name_plural = _('聊天会话')
        ordering = ['-updated_at']
        indexes = [
            models.Index(fields=['dify_conversation_id']),
            models.Index(fields=['dify_app_id']),
            models.Index(fields=['user', '-updated_at'], name='idx_user_updated_at'),
        ]
    
    def __str__(self):
        return f"{self.title} ({self.user.username})"
    
    def save(self, *args, **kwargs):
        """重写save方法，处理Dify会话ID"""
        # 首先执行保存，确保实例有主键
        super().save(*args, **kwargs)
        
        # 保存后检查关系字段
        if not self.dify_conversation_id and self.pk:  # 确保有主键
            # 如果有消息但没有Dify会话ID，尝试从第一条消息中获取
            if self.messages.exists():
                first_message = self.messages.first()
                if hasattr(first_message, 'dify_message_id') and first_message.dify_message_id:
                    self.dify_conversation_id = first_message.dify_message_id.split('_')[0]
                    # 再次保存以更新dify_conversation_id
                    super().save(update_fields=['dify_conversation_id'])

class Message(models.Model):
    """聊天消息模型"""
    ROLE_CHOICES = (
        ('user', _('用户')),
        ('assistant', _('助手')),
        ('system', _('系统')),
    )
    
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name='messages')
    role = models.CharField(_('角色'), max_length=20, choices=ROLE_CHOICES)
    content = models.TextField(_('内容'))
    created_at = models.DateTimeField(_('创建时间'), auto_now_add=True)
    tokens = models.IntegerField(_('Token数'), default=0)
    
    # Dify相关字段
    dify_message_id = models.CharField(_('Dify消息ID'), max_length=100, null=True, blank=True)
    dify_metadata = models.JSONField(_('Dify元数据'), null=True, blank=True)
    
    class Meta:
        verbose_name = _('聊天消息')
        verbose_name_plural = _('聊天消息')
        ordering = ['created_at']
        indexes = [
            models.Index(fields=['dify_message_id']),
        ]
    
    def __str__(self):
        return f"{self.get_role_display()}: {self.content[:50]}..."


class ChatTokenUsage(models.Model):
    """单次对话Token使用记录模型
    
    此模型记录每次对话的token使用情况，而非整个会话的累计使用量。
    每次新消息产生时，通过计算与前一次对话的token差值，记录本次对话实际使用的token数量。
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='chat_token_usages', verbose_name=_('用户'))
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name='token_usages', verbose_name=_('会话'))
    message = models.ForeignKey(Message, on_delete=models.CASCADE, related_name='token_usage', verbose_name=_('消息'), null=True, blank=True)
    
    # Token使用数据 - 记录的是与上次对话的差值，而非累计值
    prompt_tokens = models.IntegerField(_('提示词token数'), default=0)
    completion_tokens = models.IntegerField(_('回复token数'), default=0)
    total_tokens = models.IntegerField(_('总token数'), default=0)
    
    # 成本信息 - 对应当前对话的成本，按差值计算
    cost = models.DecimalField(_('花费'), max_digits=10, decimal_places=7, default=0)
    currency = models.CharField(_('货币'), max_length=10, default='USD')
    prompt_price = models.DecimalField(_('提示词价格'), max_digits=10, decimal_places=7, default=0)
    completion_price = models.DecimalField(_('回复价格'), max_digits=10, decimal_places=7, default=0)
    prompt_unit_price = models.DecimalField(_('提示词单价'), max_digits=10, decimal_places=7, default=0)
    completion_unit_price = models.DecimalField(_('回复单价'), max_digits=10, decimal_places=7, default=0)
    
    # API性能信息
    latency = models.FloatField(_('延迟(秒)'), null=True, blank=True)
    
    # 时间信息
    created_at = models.DateTimeField(_('创建时间'), auto_now_add=True)
    
    class Meta:
        verbose_name = _('对话Token使用记录')
        verbose_name_plural = _('对话Token使用记录')
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user']),
            models.Index(fields=['conversation']),
            models.Index(fields=['created_at']),
            models.Index(fields=['user', 'created_at'], name='idx_chattoken_user_created'),
        ]
    
    def __str__(self):
        return f"{self.user.username} - {self.total_tokens}tokens - {self.created_at.strftime('%Y-%m-%d %H:%M')}"
    
    def save(self, *args, **kwargs):
        """保存前自动计算费用"""
        # 如果费用为0，且已有token数据，则自动计算费用
        if self.cost == 0 and self.total_tokens > 0 and not self.prompt_price and not self.completion_price:
            self.calculate_cost()
        
        super().save(*args, **kwargs)
        
        # 保存后更新用户账户余额和消费记录
        self.update_user_balance()
    
    def calculate_cost(self):
        """根据定价策略计算费用"""
        from billing.models import PricingPlan
        
        try:
            # 获取当前激活的定价策略
            pricing_plan = PricingPlan.objects.filter(is_active=True).first()
            
            if pricing_plan:
                # 分别计算提示词和补全的费用
                prompt_million_tokens = Decimal(self.prompt_tokens) / Decimal('1000000')
                completion_million_tokens = Decimal(self.completion_tokens) / Decimal('1000000')
                
                # 使用新的字段分别计算提示词和补全的费用
                prompt_cost = prompt_million_tokens * pricing_plan.prompt_price_per_million_tokens
                completion_cost = completion_million_tokens * pricing_plan.completion_price_per_million_tokens
                
                # 总费用为两者之和
                self.cost = prompt_cost + completion_cost
                self.prompt_price = prompt_cost
                self.completion_price = completion_cost
                self.currency = 'USD'  # 假设使用美元，可根据需要修改
            else:
                # 如果没有找到定价策略，使用默认价格
                prompt_million_tokens = Decimal(self.prompt_tokens) / Decimal('1000000')
                completion_million_tokens = Decimal(self.completion_tokens) / Decimal('1000000')
                
                # 默认价格：提示词每百万token 1美元，补全每百万token 2美元
                prompt_cost = prompt_million_tokens * Decimal('1.0')
                completion_cost = completion_million_tokens * Decimal('2.0')
                
                self.cost = prompt_cost + completion_cost
                self.prompt_price = prompt_cost
                self.completion_price = completion_cost
                self.currency = 'USD'
        except Exception as e:
            # 计算失败时记录错误但不中断流程
            print(f"计算费用失败: {str(e)}")
    
    def update_user_balance(self):
        """更新用户账户余额并创建消费记录"""
        from billing.models import AccountBalance, ConsumptionRecord
        
        try:
            # 获取用户账户余额
            account_balance, created = AccountBalance.objects.get_or_create(
                user=self.user,
                defaults={'balance': Decimal('0.0')}
            )
            
            # 扣除余额
            account_balance.balance -= self.cost
            account_balance.save()
            
            # 创建消费记录
            ConsumptionRecord.objects.create(
                user=self.user,
                tokens_used=self.total_tokens,
                amount=self.cost,
                type='chat',
                status='success',
                request_id=self.message.dify_message_id if self.message else None,
                request_content=self.message.content if self.message else ''
            )
        except Exception as e:
            # 更新余额失败时记录错误但不中断流程
            print(f"更新用户余额失败: {str(e)}")

class MajorQuestion(models.Model):
    """重大问题模型"""
    question = models.TextField(_('问题'))
    created_at = models.DateTimeField(_('创建时间'), auto_now_add=True, db_index=True)
    
    class Meta:
        verbose_name = _('重大问题')
        verbose_name_plural = _('重大问题')
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.question[:50]}..."

class PreprocessedContent(models.Model):
    """预处理内容模型 (仅保留内容和创建时间)"""
    # 字段 source_description, preprocessing_type, updated_at 已被移除
    # source_description = models.CharField(_('来源描述'), max_length=200, null=True, blank=True, help_text=_('描述内容的来源，例如 \'periodic_dify_task\''))
    content = models.TextField(_('预处理后内容'))
    # preprocessing_type = models.CharField(_('预处理类型'), max_length=50, default='cleaned', help_text=_('例如: cleaned, summarized, translated'))
    created_at = models.DateTimeField(_('创建时间'), auto_now_add=True)
    # updated_at = models.DateTimeField(_('更新时间'), auto_now=True)

    class Meta:
        verbose_name = _('预处理内容')
        verbose_name_plural = _('预处理内容')
        ordering = ['-created_at'] # 按创建时间排序
        indexes = [
            models.Index(fields=['created_at']),
            # 其他索引已根据移除的字段清理
        ]

    def __str__(self):
        # 更新 __str__ 方法以反映剩余字段
        return f"Preprocessed Content created at {self.created_at.strftime('%Y-%m-%d %H:%M')}"
