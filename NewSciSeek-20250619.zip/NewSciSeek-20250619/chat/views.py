from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, StreamingHttpResponse
from django.conf import settings
import json
import uuid
import random
from django.views.decorators.http import require_POST
from decimal import Decimal
from django.db.models import Sum, Avg, Count, F
from django.utils import timezone
import datetime
import logging
import requests
from functools import lru_cache
from .models import Conversation, Message, ChatTokenUsage, MajorQuestion, PreprocessedContent # 假设的模型名
from utils.dify_client import ChatClient # 确保导入 ChatClient
from billing.services import BillingService, InsufficientBalanceError # 确保导入 InsufficientBalanceError
from django.core.cache import cache # 导入 Django 缓存
from django.db.models.functions import Random, TruncDate # 导入 Random 函数和 TruncDate

# 初始化日志记录器
logger = logging.getLogger('django')

# 初始化Dify客户端
def get_dify_client():
    """获取Dify客户端实例"""
    api_key = settings.DIFY_API_KEY
    base_url = getattr(settings, 'DIFY_API_BASE_URL', 'https://api.dify.ai/v1')
    return ChatClient(api_key=api_key, base_url=base_url)

# 修改余额检查缓存逻辑
# @lru_cache(maxsize=128) # 移除 lru_cache
def check_user_balance_cached(user_id):
    """
    缓存用户余额检查结果，使用 Django Cache API。
    缓存键包含 user_id，缓存时间为 10 秒。
    """
    cache_key = f'user_{user_id}_balance_check'
    cached_result = cache.get(cache_key)

    if cached_result is not None:
        logger.debug(f"User balance cache hit for user {user_id}")
        return cached_result

    logger.info(f"User balance cache miss for user {user_id}. Checking DB.")
    from django.contrib.auth import get_user_model
    User = get_user_model()
    try:
        user = User.objects.get(id=user_id)
        result = BillingService.check_balance(user)
        # 将结果存入缓存，设置 10 秒过期
        cache.set(cache_key, result, timeout=10)
        return result
    except User.DoesNotExist:
         logger.error(f"Attempted to check balance for non-existent user_id: {user_id}")
         # 对于不存在的用户，可以返回一个表示余额不足的默认值或抛出异常
         # 这里返回余额不足，避免后续逻辑出错
         return (False, Decimal('0'), Decimal('0.01')) # is_sufficient, balance, min_cost
    except Exception as e:
         logger.error(f"Error checking balance for user_id {user_id}: {e}", exc_info=True)
         # 发生错误时也返回余额不足
         return (False, Decimal('0'), Decimal('0.01'))

@login_required
def chat_view(request):
    """
    聊天页面视图
    """
    try:
        # 获取用户的会话列表 (已确认在 models.py 中添加了索引)
        conversations = Conversation.objects.filter(user=request.user).order_by('-updated_at')
        
        # 获取当前活跃的会话 (逻辑保持不变)
        active_conversation = None
        conversation_id = request.GET.get('conversation_id')
        
        if conversation_id:
            try:
                active_conversation = Conversation.objects.get(
                    conversation_id=conversation_id,
                    user=request.user
                )
            except Conversation.DoesNotExist:
                pass 
        
        if not active_conversation and conversations.exists():
            pass 
        
        messages = []
        if active_conversation:
            messages = Message.objects.filter(conversation=active_conversation).order_by('created_at')
        
        # --- 获取所有重大问题 (添加缓存逻辑) ---
        major_questions_cache_key = 'major_questions_list'
        major_questions = cache.get(major_questions_cache_key)
        cache_hit = major_questions is not None # 检查是否命中缓存

        if not cache_hit:
            logger.info("Major questions cache miss. Fetching from DB.")
            # 缓存未命中，从数据库查询 (已确认在 models.py 中添加了索引)
            major_questions = list(MajorQuestion.objects.all().order_by('-created_at')) # 物化查询结果
            # 将结果存入缓存，设置过期时间 (例如 1 小时 = 3600 秒)
            # 注意：对于 LocMemCache，过期时间可能不是严格精确的
            cache.set(major_questions_cache_key, major_questions, timeout=3600) 
        else:
             logger.debug("Major questions cache hit.")
        # --- 结束缓存逻辑 ---

        context = {
            'conversations': conversations,
            'active_conversation': active_conversation,
            'messages': messages,
            'major_questions': major_questions,
            'major_questions_cache_hit': cache_hit, # (可选) 传递缓存命中信息到模板，用于调试
        }
        
        response = render(request, 'chat/chat.html', context)
        return response
    except Exception as e:
        logger.error(f"聊天页面加载错误: {str(e)}", exc_info=True) # 添加 exc_info=True 获取更详细的回溯信息
        return render(request, 'chat/chat.html', {'error': str(e)})

@login_required
def stream_message(request):
    """接收用户消息并流式返回AI回复"""
    if request.method != 'POST':
        return JsonResponse({'error': '只支持POST请求'}, status=405)
    
    # 检查用户余额是否充足 (调用修改后的缓存函数)
    # 不再需要传递时间戳
    is_sufficient, balance, min_cost = check_user_balance_cached(request.user.id)
    
    if not is_sufficient:
        logger.warning(f"用户 {request.user.username} 余额不足: 当前余额 {balance}, 最低需要 {min_cost}")
        return JsonResponse({
            'error': f'账户余额不足，无法发送消息。当前余额: {balance}，最低需要: {min_cost}',
            'code': 'insufficient_balance'
        }, status=402)  # 402 Payment Required
    
    try:
        data = json.loads(request.body)
        conversation_id = data.get('conversation_id')
        user_message = data.get('message', '').strip()
        files = data.get('files', [])
        thinking_mode_from_request = data.get('thinking_mode') 
        
        if not user_message and not files:
            return JsonResponse({'error': '消息内容不能为空'}, status=400)
        
        # 获取或创建会话，并确定最终使用的思考模式
        conversation = None
        user_message_obj = None
        is_new_conversation_local = False 
        final_thinking_mode = 'simple' 
        
        if conversation_id:
            try:
                conversation = Conversation.objects.get(
                    conversation_id=conversation_id,
                    user=request.user
                )
                final_thinking_mode = conversation.thinking_mode or 'simple' 
                if not conversation.thinking_mode and thinking_mode_from_request:
                     conversation.thinking_mode = thinking_mode_from_request

            except Conversation.DoesNotExist:
                logger.error(f"尝试访问不存在的会话: ID={conversation_id}, 用户={request.user.id}")
                return JsonResponse({'error': '会话不存在'}, status=404)
        else:
            final_thinking_mode = thinking_mode_from_request or 'simple'
            conversation = Conversation.objects.create(
                user=request.user,
                title=user_message[:50] + ('... ' if len(user_message) > 50 else ''),
                thinking_mode=final_thinking_mode
            )
            is_new_conversation_local = True
            logger.info(f"为用户 {request.user.id} 创建了新会话: 本地ID={conversation.conversation_id}, 思考模式={final_thinking_mode}")
        
        thinking_mode_map = {
            'simple': 'Simple Thinking',
            'deep': 'Deep Thinking',
            'heavy': 'Heavy Thinking'
        }
        dify_thinking_mode = thinking_mode_map.get(final_thinking_mode, 'Simple Thinking')

        dify_inputs = {
            'chat_type': dify_thinking_mode
        }

        # 如果是 Deep Thinking 模式，添加 base_content (优化加载方式)
        if final_thinking_mode == 'deep':
            try:
                # --- 修改：使用 order_by('?').first() 高效获取随机记录 --- 
                random_content_obj = PreprocessedContent.objects.order_by('?').first()
                # --- 结束修改 ---
                
                if random_content_obj:
                    dify_inputs['base_content'] = random_content_obj.content
                    logger.info(f"为 Deep Thinking 模式加载了 base_content: ID={random_content_obj.id}")
                else:
                    logger.warning("尝试为 Deep Thinking 模式加载 base_content，但 PreprocessedContent 表为空。")
            except Exception as e:
                # 注意: order_by('?') 可能在某些数据库后端 (如 SQLite 的旧版本) 或特定情况下性能不佳或不支持。
                # 如果遇到问题，可以考虑备选方案，如随机取 ID。
                logger.error(f"为 Deep Thinking 模式加载 base_content 时出错 (使用 order_by('?')): {e}", exc_info=True)

        # 如果需要根据APP定义添加其他变量，可以在这里添加
        # dify_inputs['another_variable'] = 'some_value'

        # 保存用户消息
        try:
            user_message_obj = Message.objects.create(
                conversation=conversation,
                role='user',
                content=user_message
            )
            logger.info(f"用户消息已保存: 消息ID={user_message_obj.id}, 会话ID={conversation.id}")
        except Exception as e:
            logger.error(f"保存用户消息时出错: {e}", exc_info=True)
            return JsonResponse({'error': '无法保存用户消息'}, status=500)
        
        update_fields = ['updated_at']
        conversation.updated_at = timezone.now()
        if not is_new_conversation_local and not conversation.thinking_mode and thinking_mode_from_request:
            conversation.thinking_mode = thinking_mode_from_request
            update_fields.append('thinking_mode')
        conversation.save(update_fields=update_fields)
        
        dify_files = []
        if files:
            for file_info in files:
                if file_info.get('transfer_method') == 'remote_url':
                    dify_files.append({
                        'type': file_info.get('type', 'image'),
                        'transfer_method': 'remote_url',
                        'url': file_info.get('url')
                    })
                elif file_info.get('transfer_method') == 'base64':
                    dify_files.append({
                        'type': file_info.get('type', 'image'),
                        'transfer_method': 'base64',
                        'data': file_info.get('data')
                    })
        
        # 调用Dify API获取流式响应 (使用确定的 dify_inputs)
        client = get_dify_client()
        # --- 添加日志记录使用的 API Key (masked) ---
        api_key_used = settings.DIFY_API_KEY
        masked_api_key = f"{api_key_used[:5]}...{api_key_used[-4:]}" if api_key_used and len(api_key_used) > 9 else "无效或过短的API Key"
        logger.info(f"准备调用 Dify create_chat_message API: user={request.user.id}, query='{user_message[:50]}...', conversation_id={conversation.dify_conversation_id}, inputs={dify_inputs}, files_provided={bool(dify_files)}, api_key_used={masked_api_key}")
        # --- 结束添加日志 ---
        
        try:
            dify_response = client.create_chat_message(
                inputs=dify_inputs, 
                query=user_message,
                user=str(request.user.id),
                conversation_id=conversation.dify_conversation_id,
                response_mode='streaming', 
                files=dify_files if dify_files else None 
            )
            logger.info(f"Dify API 调用返回状态码: {dify_response.status_code}")
        except Exception as e:
            logger.error(f"调用 Dify API 时发生异常: {e}", exc_info=True)
            return JsonResponse({'error': f'与AI服务通信时出错: {e}'}, status=502)

        if dify_response.status_code != 200:
            error_content = dify_response.text
            logger.error(f"Dify API 响应错误: 状态码={dify_response.status_code}, 内容={error_content}")
            return JsonResponse({'error': f'AI服务返回错误 (代码: {dify_response.status_code}). 请稍后再试或联系支持.'}, status=500)
        
        def event_stream():
            complete_answer = ""
            message_id = None
            token_usage_data = None
            is_new_conversation = not conversation.dify_conversation_id 
            local_conversation_id_sent = False

            logger.info(f"[Stream {conversation.conversation_id}] Waiting for first chunk from Dify...")

            if is_new_conversation:
                initial_data = json.dumps({
                    'event': 'conversation_created',
                    'local_conversation_id': str(conversation.conversation_id) 
                })
                yield f"data: {initial_data}\n\n".encode('utf-8')
                local_conversation_id_sent = True

            for chunk in dify_response.iter_lines():
                # logger.info(f"[Stream {conversation.conversation_id}] Received chunk from Dify.") # Reduce log verbosity
                if chunk:
                    chunk_str = chunk.decode('utf-8')
                    # logger.debug(f"[Stream {conversation.conversation_id}] Chunk content: {chunk_str}") # Reduce log verbosity
                    
                    if chunk_str.startswith('data: '):
                        try:
                            json_str = chunk_str[6:]
                            chunk_data = json.loads(json_str)
                            
                            if not conversation.dify_conversation_id and 'conversation_id' in chunk_data:
                                conversation.dify_conversation_id = chunk_data['conversation_id']
                                # Defer save until the end if possible, or save immediately if needed
                                conversation.save(update_fields=['dify_conversation_id'])
                                logger.info(f"Updated dify_conversation_id for local conversation {conversation.id}")
                            
                            if not local_conversation_id_sent:
                                chunk_data['local_conversation_id'] = str(conversation.conversation_id)
                                json_str = json.dumps(chunk_data)
                                local_conversation_id_sent = True

                            if 'id' in chunk_data and not message_id:
                                message_id = chunk_data['id']
                            
                            if 'answer' in chunk_data:
                                complete_answer += chunk_data.get('answer', '')
                            
                            if chunk_data.get('event') == 'message_end' and 'metadata' in chunk_data and 'usage' in chunk_data['metadata']:
                                usage = chunk_data['metadata']['usage']
                                token_usage_data = {
                                    'prompt_tokens': usage.get('prompt_tokens', 0),
                                    'completion_tokens': usage.get('completion_tokens', 0),
                                    'total_tokens': usage.get('total_tokens', 0),
                                    'total_price': Decimal(str(usage.get('total_price', '0'))),
                                    'currency': usage.get('currency', 'USD'),
                                    'prompt_price': Decimal(str(usage.get('prompt_price', '0'))),
                                    'completion_price': Decimal(str(usage.get('completion_price', '0'))),
                                    'prompt_unit_price': Decimal(str(usage.get('prompt_unit_price', '0'))),
                                    'completion_unit_price': Decimal(str(usage.get('completion_unit_price', '0'))),
                                    'latency': usage.get('latency')
                                }
                                logger.info(f"用户 {request.user.id} 的消息计费信息: ...") # Log summary
                        except json.JSONDecodeError:
                             logger.warning(f"Failed to decode JSON from Dify stream chunk: {chunk_str}")
                    
                    yield f"{chunk_str}\n".encode('utf-8')
            
            # 保存 AI 回复和处理计费 (逻辑保持不变)
            if complete_answer:
                ai_message = Message.objects.create(
                    conversation=conversation,
                    role='assistant',
                    content=complete_answer,
                    dify_message_id=message_id
                )
                if token_usage_data:
                    prev_prompt_tokens = conversation.last_prompt_tokens
                    prev_completion_tokens = conversation.last_completion_tokens
                    current_prompt_tokens = token_usage_data['prompt_tokens']
                    current_completion_tokens = token_usage_data['completion_tokens']
                    current_total_tokens = token_usage_data['total_tokens']
                    prompt_tokens_diff = max(current_prompt_tokens - prev_prompt_tokens, 0)
                    completion_tokens_diff = max(current_completion_tokens - prev_completion_tokens, 0)
                    total_tokens_diff = prompt_tokens_diff + completion_tokens_diff
                    
                    if total_tokens_diff > 0:
                        try:
                            billing_service = BillingService()
                            consumption_record = billing_service.record_consumption(
                                user=request.user,
                                tokens_used=total_tokens_diff, 
                                prompt_tokens=prompt_tokens_diff,
                                completion_tokens=completion_tokens_diff,
                                request_type='chat', 
                                request_content=user_message, 
                                request_id=ai_message.dify_message_id if ai_message else message_id 
                            )
                            logger.info(f"消费记录成功: 用户={request.user.id}, ...")
                        except InsufficientBalanceError as e:
                            logger.warning(f"用户 {request.user.username} 余额不足，无法记录消费: {e}")
                            pass 
                        except Exception as e:
                            logger.error(f"记录消费时发生错误: {e}", exc_info=True)
                            pass
                    
                    conversation.last_prompt_tokens = current_prompt_tokens
                    conversation.last_completion_tokens = current_completion_tokens
                    conversation.last_total_tokens = current_total_tokens 
                    conversation.save(update_fields=['last_prompt_tokens', 'last_completion_tokens', 'last_total_tokens'])
                    
                    ai_message.tokens = completion_tokens_diff
                    ai_message.save(update_fields=['tokens'])
                    
                    if user_message_obj:
                        user_message_obj.tokens = prompt_tokens_diff
                        user_message_obj.save(update_fields=['tokens'])
        
        return StreamingHttpResponse(
            event_stream(),
            content_type='text/event-stream'
        )
        
    except Exception as e:
        logger.error(f"stream_message 视图发生意外错误: {e}", exc_info=True)
        return JsonResponse({'error': str(e)}, status=500)

@login_required
def stop_generation(request, task_id):
    """停止指定的流式生成任务 (通过调用 Dify API)"""
    if request.method != 'POST':
        return JsonResponse({'error': '只支持POST请求'}, status=405)

    logger.info(f"用户 {request.user.username} 请求停止 Dify 任务: {task_id}")

    try:
        client = get_dify_client() # 获取 Dify 客户端实例
        # --- 添加日志记录使用的 API Key (masked) ---
        api_key_used = settings.DIFY_API_KEY
        masked_api_key = f"{api_key_used[:5]}...{api_key_used[-4:]}" if api_key_used and len(api_key_used) > 9 else "无效或过短的API Key"
        logger.info(f"准备调用 Dify stop_message API: task_id={task_id}, user={request.user.id}, api_key_used={masked_api_key}")
        # --- 结束添加日志 ---
        # 调用 Dify 客户端的 stop_message 方法
        response = client.stop_message(task_id, str(request.user.id))

        logger.info(f"调用 Dify stop_message API 响应状态码: {response.status_code}")

        if response.status_code == 200:
            # Dify API 确认已停止
            try:
                response_data = response.json() # 尝试解析 JSON 响应
                logger.info(f"Dify stop_message 响应内容: {response_data}")
                return JsonResponse(response_data)
            except json.JSONDecodeError:
                # 如果 Dify 返回非 JSON 或空响应，也视为成功
                logger.info(f"Dify stop_message 成功但无 JSON 响应内容 (Task ID: {task_id})")
                return JsonResponse({'status': 'stopped', 'task_id': task_id})
        else:
            # Dify API 返回错误
            error_content = response.text
            logger.error(f"调用 Dify stop_message API 失败 (Task ID: {task_id}): 状态码={response.status_code}, 内容={error_content}")
            return JsonResponse({'error': f'无法停止任务 (状态码: {response.status_code}) - {error_content}', 'task_id': task_id}, status=response.status_code if response.status_code >= 400 else 500)

    except Exception as e:
        # 其他意外错误 (例如获取客户端失败)
        logger.error(f"尝试停止 Dify 任务 {task_id} 时发生意外错误: {e}", exc_info=True)
        return JsonResponse({'error': f'停止任务时发生意外错误: {e}', 'task_id': task_id}, status=500)

@login_required
def delete_conversation(request, conversation_id):
    """删除会话"""
    if request.method != 'POST':
        return JsonResponse({'error': '只支持POST请求'}, status=405)
    
    try:
        # 获取会话
        try:
            conversation = Conversation.objects.get(
                conversation_id=conversation_id,
                user=request.user
            )
        except Conversation.DoesNotExist:
            logger.warning(f"尝试删除不存在的会话: ID={conversation_id}, 用户={request.user.id}")
            return JsonResponse({'error': '会话不存在'}, status=404)
        
        # 如果有Dify会话ID，则同步删除Dify中的会话
        dify_deleted = False
        if conversation.dify_conversation_id:
            try:
                client = get_dify_client()
                # --- 添加日志记录使用的 API Key (masked) ---
                api_key_used = settings.DIFY_API_KEY
                masked_api_key = f"{api_key_used[:5]}...{api_key_used[-4:]}" if api_key_used and len(api_key_used) > 9 else "无效或过短的API Key"
                logger.info(f"准备调用 Dify delete_conversation API: dify_conversation_id={conversation.dify_conversation_id}, user={request.user.id}, api_key_used={masked_api_key}")
                # --- 结束添加日志 ---
                dify_response = client.delete_conversation(
                    conversation.dify_conversation_id,
                    str(request.user.id)
                )
                dify_deleted = dify_response.status_code == 204 or dify_response.status_code == 200
                if not dify_deleted:
                     logger.warning(f"删除Dify会话失败 (用户: {request.user.id}, Dify ID: {conversation.dify_conversation_id}): 状态码={dify_response.status_code}, 内容={dify_response.text}")

            except requests.exceptions.RequestException as e: # Catch specific network errors
                logger.error(f"调用Dify删除API时网络错误 (用户: {request.user.id}, Dify ID: {conversation.dify_conversation_id}): {str(e)}", exc_info=True)
                # Still continue to delete locally, dify_deleted remains False
            except Exception as e:
                # 记录删除Dify会话时发生意外错误，但仍继续删除本地会话
                logger.error(f"删除Dify会话时发生意外错误 (用户: {request.user.id}, Dify ID: {conversation.dify_conversation_id}): {str(e)}", exc_info=True)
                # Still continue to delete locally, dify_deleted remains False

        # 删除本地会话及其所有消息
        conversation_title = conversation.title
        conversation.delete()
        logger.info(f"本地会话已删除: ID={conversation_id}, 标题='{conversation_title}', 用户={request.user.id}")

        return JsonResponse({
            'status': 'success',
            'message': f'会话 "{conversation_title}" 已删除',
            'dify_deleted': dify_deleted
        })
        
    except Exception as e:
        # Log the error with traceback before returning JSON
        logger.error(f"删除会话视图发生意外错误 (ID: {conversation_id}, 用户: {request.user.id}): {str(e)}", exc_info=True)
        # Return a more informative JSON error, although Django might still override with HTML in DEBUG mode
        return JsonResponse({'error': f'删除会话时发生内部错误。请检查服务器日志获取详细信息。'}, status=500)

@login_required
def rename_conversation(request, conversation_id):
    """重命名会话"""
    if request.method != 'POST':
        return JsonResponse({'error': '只支持POST请求'}, status=405)
    
    try:
        data = json.loads(request.body)
        new_title = data.get('title', '').strip()
        auto_generate = data.get('auto_generate', False)
        
        if not new_title and not auto_generate:
            return JsonResponse({'error': '标题不能为空'}, status=400)
        
        # 获取会话
        try:
            conversation = Conversation.objects.get(
                conversation_id=conversation_id,
                user=request.user
            )
        except Conversation.DoesNotExist:
            return JsonResponse({'error': '会话不存在'}, status=404)
        
        # 如果是自动生成标题，使用第一条用户消息作为标题
        if auto_generate:
            first_message = Message.objects.filter(
                conversation=conversation,
                role='user'
            ).order_by('created_at').first()
            
            if first_message:
                new_title = first_message.content[:50] + ('...' if len(first_message.content) > 50 else '')
            else:
                new_title = "新对话"
        
        # 更新标题
        old_title = conversation.title
        conversation.title = new_title
        conversation.save()
        
        # 如果有Dify会话ID，则尝试同步更新Dify中的会话标题
        dify_updated = False
        if conversation.dify_conversation_id:
            try:
                # 将 get_dify_client() 移入 try 块
                client = get_dify_client() 
                # --- 添加日志记录使用的 API Key (masked) ---
                api_key_used = settings.DIFY_API_KEY
                masked_api_key = f"{api_key_used[:5]}...{api_key_used[-4:]}" if api_key_used and len(api_key_used) > 9 else "无效或过短的API Key"
                logger.info(f"准备调用 Dify update_conversation API: dify_conversation_id={conversation.dify_conversation_id}, user={request.user.id}, new_name='{new_title}', api_key_used={masked_api_key}")
                # --- 结束添加日志 ---

                dify_response = client.update_conversation(
                    conversation.dify_conversation_id,
                    str(request.user.id),
                    name=new_title
                )
                dify_updated = dify_response.status_code == 200
            except Exception as e:
                # 记录更新Dify会话失败，但仍继续更新本地会话
                logger.error(f"更新Dify会话标题失败 (dify_id={conversation.dify_conversation_id}, user={request.user.id}): {str(e)}", exc_info=True) # 使用 logger.error 并添加 exc_info
                # print(f"更新Dify会话标题失败: {str(e)}") # 移除或注释掉 print
        
        return JsonResponse({
            'status': 'success',
            'message': f'会话标题已从 "{old_title}" 更改为 "{new_title}"',
            'title': new_title,
            'dify_updated': dify_updated
        })
        
    except Exception as e:
        # 添加详细错误日志记录
        logger.error(f"重命名会话时发生意外错误 (conv_id={conversation_id}, user={request.user.id}): {e}", exc_info=True)
        return JsonResponse({'error': str(e)}, status=500)

@require_POST
@login_required
def create_conversation(request):
    """创建新的会话"""
    try:
        data = json.loads(request.body)
        title = data.get('title', '新对话')
        
        # 创建新会话
        conversation = Conversation.objects.create(
            user=request.user,
            title=title
        )
        
        return JsonResponse({
            'status': 'success',
            'message': '会话已创建',
            'conversation_id': str(conversation.conversation_id)
        })
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'error': f'创建会话失败: {str(e)}'
        }, status=500)

@login_required
def token_usage_stats(request):
    """获取用户token使用统计 (优化每日统计查询)"""
    try:
        # 总计使用情况
        total_usage = ChatTokenUsage.objects.filter(user=request.user).aggregate(
            total_prompt_tokens=Sum('prompt_tokens'),
            total_completion_tokens=Sum('completion_tokens'),
            total_tokens=Sum('total_tokens'),
            total_cost=Sum('cost'),
            count=Count('id')
        )
        
        # 最近30天总使用情况
        thirty_days_ago = timezone.now() - datetime.timedelta(days=30)
        recent_usage = ChatTokenUsage.objects.filter(
            user=request.user, 
            created_at__gte=thirty_days_ago
        ).aggregate(
            recent_prompt_tokens=Sum('prompt_tokens'),
            recent_completion_tokens=Sum('completion_tokens'),
            recent_tokens=Sum('total_tokens'),
            recent_cost=Sum('cost'),
            recent_count=Count('id')
        )
        
        # --- 按日统计最近30天使用情况 (优化为单次查询) ---
        daily_usage_query = ChatTokenUsage.objects.filter(
            user=request.user,
            created_at__gte=thirty_days_ago
        ).annotate(
            date=TruncDate('created_at') # 按天截断日期
        ).values(
            'date' # 按日期分组
        ).annotate(
            tokens=Sum('total_tokens'),
            cost=Sum('cost'),
            count=Count('id')
        ).order_by('-date') # 按日期降序排序

        # 将查询结果转换为所需的格式
        daily_usage = [
            {
                'date': item['date'].strftime('%Y-%m-%d'),
                'tokens': item['tokens'] or 0,
                'cost': float(item['cost'] or 0),
                'count': item['count'] or 0
            }
            for item in daily_usage_query
        ]
        # --- 结束优化查询 ---
        
        # 最近的token使用记录
        recent_records = ChatTokenUsage.objects.filter(
            user=request.user
        ).order_by('-created_at')[:10].values(
            'conversation__title', 
            'prompt_tokens', 
            'completion_tokens', 
            'total_tokens', 
            'cost', 
            'created_at'
        )
        
        recent_records_list = []
        for record in recent_records:
            recent_records_list.append({
                'conversation_title': record['conversation__title'],
                'prompt_tokens': record['prompt_tokens'],
                'completion_tokens': record['completion_tokens'],
                'total_tokens': record['total_tokens'],
                'cost': float(record['cost']),
                'created_at': record['created_at'].strftime('%Y-%m-%d %H:%M:%S')
            })
        
        return JsonResponse({
            'status': 'success',
            'data': {
                'total': {
                    'prompt_tokens': total_usage['total_prompt_tokens'] or 0,
                    'completion_tokens': total_usage['total_completion_tokens'] or 0,
                    'total_tokens': total_usage['total_tokens'] or 0,
                    'cost': float(total_usage['total_cost'] or 0),
                    'count': total_usage['count'] or 0
                },
                'recent_30_days': {
                    'prompt_tokens': recent_usage['recent_prompt_tokens'] or 0,
                    'completion_tokens': recent_usage['recent_completion_tokens'] or 0,
                    'total_tokens': recent_usage['recent_tokens'] or 0,
                    'cost': float(recent_usage['recent_cost'] or 0),
                    'count': recent_usage['recent_count'] or 0
                },
                'daily_usage': daily_usage,
                'recent_records': recent_records_list,
                'currency': 'USD'  # 假设所有记录使用相同货币
            }
        })
    except Exception as e:
        logger.error(f"获取 Token 使用统计时出错: {e}", exc_info=True) # 添加 exc_info
        return JsonResponse({
            'status': 'error',
            'error': str(e)
        }, status=500)

@login_required
def conversation_token_usage(request, conversation_id):
    """获取特定会话的token使用统计"""
    try:
        # 检查会话是否存在且属于当前用户
        try:
            conversation = Conversation.objects.get(
                conversation_id=conversation_id,
                user=request.user
            )
        except Conversation.DoesNotExist:
            return JsonResponse({'error': '会话不存在或无权访问'}, status=404)
        
        # 获取会话的token使用统计
        usage_stats = ChatTokenUsage.objects.filter(
            conversation=conversation
        ).aggregate(
            prompt_tokens=Sum('prompt_tokens'),
            completion_tokens=Sum('completion_tokens'),
            total_tokens=Sum('total_tokens'),
            total_cost=Sum('cost'),
            count=Count('id'),
            avg_tokens=Avg('total_tokens')
        )
        
        # 获取会话的每条消息token使用情况
        message_usage = ChatTokenUsage.objects.filter(
            conversation=conversation
        ).order_by('created_at').values(
            'message__content',
            'prompt_tokens',
            'completion_tokens',
            'total_tokens',
            'cost',
            'created_at'
        )
        
        message_usage_list = []
        for usage in message_usage:
            if usage['message__content']:  # 确保消息内容存在
                content_preview = usage['message__content'][:100] + ('...' if len(usage['message__content']) > 100 else '')
                message_usage_list.append({
                    'content_preview': content_preview,
                    'prompt_tokens': usage['prompt_tokens'],
                    'completion_tokens': usage['completion_tokens'],
                    'total_tokens': usage['total_tokens'],
                    'cost': float(usage['cost']),
                    'created_at': usage['created_at'].strftime('%Y-%m-%d %H:%M:%S')
                })
        
        return JsonResponse({
            'status': 'success',
            'data': {
                'conversation_title': conversation.title,
                'stats': {
                    'prompt_tokens': usage_stats['prompt_tokens'] or 0,
                    'completion_tokens': usage_stats['completion_tokens'] or 0,
                    'total_tokens': usage_stats['total_tokens'] or 0,
                    'total_cost': float(usage_stats['total_cost'] or 0),
                    'count': usage_stats['count'] or 0,
                    'avg_tokens': float(usage_stats['avg_tokens'] or 0)
                },
                'message_usage': message_usage_list,
                'currency': 'USD'  # 假设所有记录使用相同货币
            }
        })
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'error': str(e)
        }, status=500) 