import re
from django import template
from django.utils.safestring import mark_safe

register = template.Library()

# 正则表达式用于移除两种格式的思考块
# 移除了开头的 ^ 锚点，添加了 re.MULTILINE 以防万一，保持 IGNORECASE
DETAILS_THINKING_REGEX = re.compile(
    r'<details[\s\S]*?>\s*<summary[\s\S]*?>[\s\S]*?Thinking\.*[\s\S]*?<\/summary>[\s\S]*?<\/details>',
    re.IGNORECASE | re.MULTILINE
)
SIMPLE_THINK_REGEX = re.compile(
    r'<think>[\s\S]*?<\/think>',
    re.IGNORECASE | re.MULTILINE
)

@register.filter(name='remove_thinking_details')
def remove_thinking_details(value):
    """
    从字符串中移除 <details> thinking 和 <think> thinking 块。
    """
    if isinstance(value, str):
        # 依次移除两种格式的块
        cleaned_value = DETAILS_THINKING_REGEX.sub('', value)
        cleaned_value = SIMPLE_THINK_REGEX.sub('', cleaned_value).strip()
        # 假设清理后的内容可能仍然包含安全的 HTML（例如 Markdown 转换结果）
        # 使用 mark_safe 告诉 Django 这是安全的，不需要再次转义
        return mark_safe(cleaned_value)
    # 如果输入不是字符串，原样返回
    return value
