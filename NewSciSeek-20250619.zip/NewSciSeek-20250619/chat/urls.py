from django.urls import path
from . import views

app_name = 'chat' # Define app_name for namespacing if needed, matching include in main urls.py

urlpatterns = [
    # API接口 (根路径 '' 已被移除，路径不含 'api/' 前缀)
    path('stream', views.stream_message, name='stream_message'),
    path('stop/<str:task_id>', views.stop_generation, name='stop_generation'),
    path('conversation/<str:conversation_id>/delete/', views.delete_conversation, name='delete_conversation'),
    path('conversation/<str:conversation_id>/rename/', views.rename_conversation, name='rename_conversation'),
    path('conversation/create', views.create_conversation, name='create_conversation'),
    
    # Token统计接口
    path('token-usage/stats', views.token_usage_stats, name='token_usage_stats'),
    path('token-usage/conversation/<str:conversation_id>', views.conversation_token_usage, name='conversation_token_usage'),
] 