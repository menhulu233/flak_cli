from django.http import HttpResponse


def response_as_json(data):
    # json_str = json.dumps(data)
    response = HttpResponse(
        data,
        content_type="application/json",
    )
    response["Access-Control-Allow-Origin"] = "*"
    return response


def getRet(request):
    with open('data/SandPlugEvalApp/jsons/flag_list/flag_test_400_2.json') as f:
        data = f.read()
    return response_as_json(data)


import requests
from django.http import JsonResponse


def external_url_view(request):
    if request.method == 'POST':
        url = request.POST.get('remote_url')  # 获取前端传递的URL参数
        try:
            response = requests.get(url)  # 发送GET请求到外部URL
            response.raise_for_status()  # 检查请求是否成功
            data = response.json()  # 获取JSON数据（假设返回的是JSON格式）
            return JsonResponse(data)  # 将JSON数据作为响应返回给前端
        except requests.exceptions.RequestException as e:
            # 处理请求异常
            return JsonResponse({'error': str(e)})
    else:
        return JsonResponse({'error': 'Invalid request method'})
