"""
URL configuration for Hydrofracturing project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from Hydrofracturing import views
from Home.views import index1  # 导入 Home 应用中的 index1 视图

urlpatterns = [
    path('',index1,name='index1'),
    path('admin/', admin.site.urls),
    path('home/', include('Home.urls')),
    # 跨域访问url代理函数
    path('external-url/', views.external_url_view, name='external-url'),
    path('perforationNum/',include('PerforationNum.urls')),
    path('Gfunction/',include('GFunction.urls')),
    path('sandplug/',include('SandPlug.urls')),
    path('PRAnalysis/', include('PRAnalysis.urls')),
    path('proppant/', include('Proppant.urls')),
    path('rock/',include('rock.urls'))

]
