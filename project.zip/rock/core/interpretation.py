from rock.core.completion_well import get_len_table_num
import pandas as pd


def get_interpretation_excel(interpretation_table,table_name):
    interpretation_data = []
    interpretation_table_start_num = get_len_table_num(interpretation_table)
    for cell in interpretation_table.rows[0].cells:
        if "顶深" in cell.text.replace("\n", "").strip():
            cell.text = "顶深(m)"
        elif '底深' in cell.text.replace("\n", "").strip():
            cell.text = "底深(m)"
        elif "杨氏模量" in cell.text.replace("\n", "").strip():
            cell.text = "杨氏模量"
    for row in interpretation_table.rows[interpretation_table_start_num - 1:]:
        row_data = [cell.text.replace("\n", "").strip() for cell in row.cells]
        interpretation_data.append(row_data)
    # 转换为 DataFrame
    df = pd.DataFrame(interpretation_data)
    # 保存为 Excel 文件
    df.to_excel(f'{table_name}interpretation.xlsx', index=False, header=False)
