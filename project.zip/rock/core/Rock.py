import re
import numpy as np
from PySide2.QtWidgets import QApplication, QFileDialog, QTextBrowser, QVBoxLayout, QDialog, QWidget
from matplotlib import pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas, \
    NavigationToolbar2QT as NavigationToolbar
from PySide2.QtCore import QFile, Signal, QObject
from PySide2.QtUiTools import QUiLoader
from PySide2.QtGui import QIcon
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.figure import Figure

from extract import start

from threading import Thread
from matplot import get_parameters


class MySignals(QObject):
    text_print = Signal(QTextBrowser, str)
    update_table = Signal(str)


def create_ellipsoid(a, b, c, location, theta):
    t = np.linspace(0, 2 * np.pi, 40)
    phi = np.linspace(0, np.pi, 20)

    # 参数方程描述椭球上的点
    t, phi = np.meshgrid(t, phi)
    x = a * np.sin(phi) * np.cos(t)
    y = c * np.sin(phi) * np.sin(t)
    z = b * np.cos(phi)
    x += location[0]
    y += location[1]
    # 旋转椭球
    x_rot = (x - location[0]) * np.cos(theta) - (y - location[1]) * np.sin(theta) + location[0]
    y_rot = (x - location[0]) * np.sin(theta) + (y - location[1]) * np.cos(theta) + location[1]
    z_rot = z + location[2]
    # 计算椭球上每个点的厚度
    thickness = np.sqrt((x_rot - x_rot.mean()) ** 2 + (y_rot - y_rot.mean()) ** 2 + (z_rot - z_rot.mean()) ** 2)

    return x_rot, y_rot, z_rot, thickness


class MyDialog(QDialog):
    def __init__(self, well, para_lists, parent=None):
        super().__init__(parent)

        self.layout = QVBoxLayout(self)

        # 创建 Matplotlib 图形
        self.fig = Figure(figsize=(20, 16))
        self.fig.subplots_adjust(left=0.03, right=1, bottom=0, top=1)
        self.ax = self.fig.add_subplot(111, projection='3d')
        self.canvas = FigureCanvas(self.fig)
        self.layout.addWidget(NavigationToolbar(self.canvas, self))
        self.layout.addWidget(self.canvas)
        self.well = well
        self.para_lists = para_lists
        # 绘制井轨迹
        x = well[0]
        y = well[1]
        z = -well[2]
        self.ax.plot(x, y, z, color="black", linewidth=1, alpha=1)
        # 设置坐标
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('Y')
        self.ax.set_zlabel('Z')
        self.canvas.mpl_connect('scroll_event', self.call_scroll)
        # 设置x、y、z轴范围一样
        max_range = np.array([x.max() - x.min(), y.max() - y.min(), z.max() - z.min()]).max() / 2.0
        mid_x = (x.max() + x.min()) * 0.5
        mid_y = (y.max() + y.min()) * 0.5
        mid_z = (z.max() + z.min()) * 0.5
        self.ax.set_xlim(mid_x - max_range, mid_x + max_range)
        self.ax.set_ylim(mid_y - max_range, mid_y + max_range)
        self.ax.set_zlim(mid_z - max_range, mid_z + max_range)
        self.ax.grid(True)

        # 创建一个定时器，用于更新动画
        self.timer = self.fig.canvas.new_timer()
        self.timer.add_callback(self.update_animation)
        self.frame_count = 0  # 添加帧计数器
        self.timer.start(50)  # 每100毫秒更新一次动画

    def update_animation(self):
        for collection in self.ax.collections:
            collection.remove()
        for para in self.para_lists:
            a = 0.01 + para[0] * (self.frame_count * 60) ** (2 / 3)
            b = (0.005 + para[1] * (self.frame_count * 60) ** (2 / 3)) / 2
            c = (1e-9 + para[10] * (self.frame_count * 60) ** (1 / 3)) / 2
            location = [para[6], para[7], -para[8]]
            theta = np.radians(-para[9])
            x_rot, y_rot, z_rot, thickness = create_ellipsoid(a, b, c, location, theta)
            # 自定义颜色映射，红色对应较大的厚度，蓝色对应较小的厚度
            cmap = LinearSegmentedColormap.from_list('coolwarm',
                                                     ['#FF0000', '#FFFF00', '#00FF00', '#00FFFF', '#0000FF'], N=256)
            norm = plt.Normalize(thickness.min(), thickness.max())
            colors = cmap(norm(thickness))
            # 绘制椭球表面，设置颜色
            self.ax.plot_surface(x_rot, y_rot, z_rot, facecolors=colors, rstride=1, cstride=1, alpha=0.6)
        self.canvas.draw()
        if self.frame_count < self.para_lists[0][2]:
            self.frame_count += 1
        else:
            self.timer.stop()

    def call_scroll(self, event):
        if event.inaxes is not None:
            # 获取当前坐标轴的范围
            x_min, x_max = self.ax.get_xlim()
            y_min, y_max = self.ax.get_ylim()
            z_min, z_max = self.ax.get_zlim()
            w = x_max - x_min
            h = y_max - y_min
            d = z_max - z_min

            # 使用ax.format_coord获取鼠标在3D坐标系中的坐标
            mouse_position = self.ax.format_coord(event.xdata, event.ydata)

            # 从鼠标位置字符串中提取X、Y、Z坐标
            # 提取数值部分的正则表达式，包含负号
            coordinates = re.findall(r'[-+]?\d*\.\d+|[-+]?\d+', mouse_position.replace("−", "-"))
            cur_x, cur_y, cur_z = map(float, coordinates[-3:])
            # 根据滚轮滚动方向确定放大或缩小
            if event.button == 'up':
                factor = 0.9
            elif event.button == 'down':
                factor = 1.1
            else:
                return
            curXposition = (cur_x - x_min) / w
            curYposition = (cur_y - y_min) / h
            curZposition = (cur_z - z_min) / d  # 注意这里使用深度d
            # 计算新的范围
            w = w * factor
            h = h * factor
            d = d * factor

            # 计算新的坐标轴范围的起始点
            newx = cur_x - w * curXposition
            newy = cur_y - h * curYposition
            newz = cur_z - d * curZposition

            # 更新坐标轴范围
            self.ax.set_xlim(newx, newx + w)
            self.ax.set_ylim(newy, newy + h)
            self.ax.set_zlim(newz, newz + d)

            # 绘制更新
            self.fig.canvas.draw_idle()


class Main(QWidget):
    def __init__(self):
        super().__init__()
        # 从文件中加载UI定义
        qfile_interface = QFile("UI/second.ui")
        qfile_interface.open(QFile.ReadOnly)
        qfile_interface.close()

        # 从 UI 定义中动态创建一个相应的窗口对象
        self.ui = QUiLoader().load(qfile_interface)
        # 点击radio_button
        self.ui.radioButton_2.setChecked(True)
        # 点击按钮调用提取程序
        self.ui.Button.clicked.connect(self.handleExtract)
        # 点击清楚按钮，清空massage内容
        self.ui.pushButton_2.clicked.connect(self.clearMassage)
        self.ms = MySignals()
        self.ms.text_print.connect(self.printToGui)
        # 点击toolButton,选择文件
        self.ui.toolButton_4.clicked.connect(self.find_path_fracture)
        self.ui.toolButton.clicked.connect(self.find_path_interpretation)
        self.ui.toolButton_2.clicked.connect(self.find_path_perforation)
        self.ui.toolButton_3.clicked.connect(self.find_path_pump)
        self.ui.toolButton_5.clicked.connect(self.find_path_well)
        # 设置spinBox默认值
        self.ui.spinBox.setValue(1)
        # 绘图按钮
        self.ui.pushButton.setEnabled(False)
        self.ui.lineEdit_2.textChanged.connect(self.update_button_state)
        self.ui.lineEdit_3.textChanged.connect(self.update_button_state)
        self.ui.lineEdit_4.textChanged.connect(self.update_button_state)
        # 绘图
        self.ui.pushButton.clicked.connect(self.crack_propagation)

    def crack_propagation(self):
        # 获取completion数据
        completion_file_path = self.ui.lineEdit_3.text()
        # 获取测井解释数据
        interpretation_path = self.ui.lineEdit_2.text()
        # 获取泵注程序
        pump_file_path = self.ui.lineEdit_4.text()
        well_trajectory_path = self.ui.lineEdit_5.text()
        input_a = int(self.ui.spinBox.value())
        self.ui.textBrowser.clear()
        # 尝试绘图
        try:
            if get_parameters(completion_file_path, interpretation_path, pump_file_path, well_trajectory_path,
                              stage_num=input_a):
                well_para, ellipses_para = get_parameters(completion_file_path, interpretation_path, pump_file_path,
                                                          well_trajectory_path, stage_num=input_a)
                dialog = MyDialog(well_para, ellipses_para, self)
                dialog.setGeometry(400, 110, 1200, 880)
                dialog.setWindowTitle("Rock")
                dialog.exec_()
                for para in ellipses_para:
                    self.ms.text_print.emit(self.ui.textBrowser,
                                            f"测量深度{para[3]}m的裂缝,压裂用时{para[2]}min,裂缝半长{round(para[4], 2)}m,缝高{round(para[5], 2)}m,最大缝宽{round(para[-1] * 1e3, 2)}mm")
                self.ms.text_print.emit(self.ui.textBrowser, "裂缝扩展绘制成功！")

            else:
                self.ms.text_print.emit(self.ui.textBrowser, "数据不全,裂缝扩展绘制失败！")
        except Exception as e:
            self.ms.text_print.emit(self.ui.textBrowser, f"{e}\n裂缝扩展绘制失败！")

    def update_button_state(self):
        # 当两个编辑框都不为空时启用按钮，否则禁用按钮
        if self.ui.lineEdit_2.text() and self.ui.lineEdit_3.text() and self.ui.lineEdit_4.text():
            self.ui.pushButton.setEnabled(True)
        else:
            self.ui.pushButton.setEnabled(False)

    def find_path_fracture(self):
        file_dialog = QFileDialog()
        file_path, _ = file_dialog.getOpenFileName(self.ui, "选择文件", "", "Word 文档 (*.doc *.docx)")

        if file_path:
            # 用户选择了文件，将文件路径显示在 QLineEdit 中
            self.ui.lineEdit.setText(file_path)

    def find_path_interpretation(self):
        file_dialog = QFileDialog()
        file_path, _ = file_dialog.getOpenFileName(self.ui, "选择文件", "", "Excel 文件 (*.xls *.xlsx);")

        if file_path:
            # 用户选择了文件，将文件路径显示在 QLineEdit 中
            self.ui.lineEdit_2.setText(file_path)

    def find_path_perforation(self):
        file_dialog = QFileDialog()
        file_path, _ = file_dialog.getOpenFileName(self.ui, "选择文件", "", "Excel 文件 (*.xls *.xlsx)")

        if file_path:
            # 用户选择了文件，将文件路径显示在 QLineEdit中
            self.ui.lineEdit_3.setText(file_path)

    def find_path_pump(self):
        file_dialog = QFileDialog()
        file_path, _ = file_dialog.getOpenFileName(self.ui, "选择文件", "", "Excel 文件 (*.xls *.xlsx)")

        if file_path:
            # 用户选择了文件，将文件路径显示在 QLineEdit 中
            self.ui.lineEdit_4.setText(file_path)

    def find_path_well(self):
        file_dialog = QFileDialog()
        file_path, _ = file_dialog.getOpenFileName(self.ui, "选择文件", "", "Excel 文件 (*.xls *.xlsx);")

        if file_path:
            # 用户选择了文件，将文件路径显示在 QLineEdit 中
            self.ui.lineEdit_5.setText(file_path)

    def printToGui(self, fb, text):
        fb.append(str(text))
        fb.ensureCursorVisible()

    def handleExtract(self):

        #  清空massage内容
        conversion = False
        self.ui.textBrowser_2.clear()
        # 是否转换单位
        if self.ui.radioButton_2.isChecked():
            conversion = False
        elif self.ui.radioButton.isChecked():
            conversion = True
        # 获取用户输入的字符串
        input_file_path = self.ui.lineEdit.text()

        def run():
            self.ui.Button.setEnabled(False)
            self.ms.text_print.emit(self.ui.textBrowser_2, "输入的压裂文件地址是:" + input_file_path)
            # 调用 start 函数并显示提取完成信息
            result = start(input_file_path, self.ms.text_print, conversion, self.ui.textBrowser_2)
            if result:
                self.ms.text_print.emit(self.ui.textBrowser_2,
                                        "\n压裂数据提取完成！\n生成的文件路径与你输入文件路径相同。")
            else:
                self.ms.text_print.emit(self.ui.textBrowser_2, "\n压裂数据提取失败！")
            self.ui.Button.setEnabled(True)

        t = Thread(target=run)
        t.start()

    def clearMassage(self):
        self.ui.textBrowser_2.clear()


app = QApplication()
app.setWindowIcon(QIcon("pictures/logo.png"))
main = Main()
main.ui.show()
app.exec_()
