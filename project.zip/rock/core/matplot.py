import os
import random
import time
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.animation import FuncAnimation
from matplotlib.colors import LinearSegmentedColormap
import re


def plot_lines_and_ellipses(well, para_lists):
    def call_scroll(event):
        if event.inaxes is not None:
            # 获取当前坐标轴的范围
            x_min, x_max = ax.get_xlim()
            y_min, y_max = ax.get_ylim()
            z_min, z_max = ax.get_zlim()
            w = x_max - x_min
            h = y_max - y_min
            d = z_max - z_min

            # 使用ax.format_coord获取鼠标在3D坐标系中的坐标
            mouse_position = ax.format_coord(event.xdata, event.ydata)

            # 从鼠标位置字符串中提取X、Y、Z坐标
            # 提取数值部分的正则表达式，包含负号
            coordinates = re.findall(r'[-+]?\d*\.\d+|[-+]?\d+', mouse_position.replace("−", "-"))
            cur_x, cur_y, cur_z = map(float, coordinates[-3:])
            # 根据滚轮滚动方向确定放大或缩小
            if event.button == 'up':
                factor = 0.9
            elif event.button == 'down':
                factor = 1.1
            else:
                return
            curXposition = (cur_x - x_min) / w
            curYposition = (cur_y - y_min) / h
            curZposition = (cur_z - z_min) / d  # 注意这里使用深度d
            # 计算新的范围
            w = w * factor
            h = h * factor
            d = d * factor

            # 计算新的坐标轴范围的起始点
            newx = cur_x - w * curXposition
            newy = cur_y - h * curYposition
            newz = cur_z - d * curZposition

            # 更新坐标轴范围
            ax.set_xlim(newx, newx + w)
            ax.set_ylim(newy, newy + h)
            ax.set_zlim(newz, newz + d)

            # 绘制更新
            fig.canvas.draw_idle()

    def create_ellipsoid(a, b, c, location, theta):
        t = np.linspace(0, 2 * np.pi, 40)
        phi = np.linspace(0, np.pi, 20)

        # 参数方程描述椭球上的点
        t, phi = np.meshgrid(t, phi)
        x = a * np.sin(phi) * np.cos(t)
        y = c * np.sin(phi) * np.sin(t)
        z = b * np.cos(phi)
        x += location[0]
        y += location[1]
        # 旋转椭球
        x_rot = (x - location[0]) * np.cos(theta) - (y - location[1]) * np.sin(theta) + location[0]
        y_rot = (x - location[0]) * np.sin(theta) + (y - location[1]) * np.cos(theta) + location[1]
        z_rot = z + location[2]
        # 计算椭球上每个点的厚度
        thickness = np.sqrt((x_rot - x_rot.mean()) ** 2 + (y_rot - y_rot.mean()) ** 2 + (z_rot - z_rot.mean()) ** 2)

        return x_rot, y_rot, z_rot, thickness

    def update(frame):
        for collection in ax.collections:
            collection.remove()
        for para in para_lists:
            a = 0.01 + para[0] * (frame * 60) ** (2 / 3)
            b = (0.005 + para[1] * (frame * 60) ** (2 / 3)) / 2
            c = (1e-9 + para[10] * (frame * 60) ** (1 / 3)) / 2
            location = [para[6], para[7], -para[8]]
            theta = np.radians(-para[9])
            x_rot, y_rot, z_rot, thickness = create_ellipsoid(a, b, c, location, theta)
            # 自定义颜色映射，红色对应较大的厚度，蓝色对应较小的厚度
            cmap = LinearSegmentedColormap.from_list('coolwarm',
                                                     ['#FF0000', '#FFFF00', '#00FF00', '#00FFFF', '#0000FF'], N=256)
            norm = plt.Normalize(thickness.min(), thickness.max())
            colors = cmap(norm(thickness))
            # 绘制椭球表面，设置颜色
            ax.plot_surface(x_rot, y_rot, z_rot, facecolors=colors, rstride=1, cstride=1, alpha=0.6)

    # 创建图形并调整子图位置
    fig = plt.figure(figsize=(10, 8))
    # 调整子图位置以增大 3D 图的大小
    fig.subplots_adjust(left=0.03, right=1, bottom=0, top=1)
    ax = fig.add_subplot(111, projection='3d', aspect="equal")
    # 绘制井轨迹
    x = well[0]
    y = well[1]
    z = -well[2]
    ax.plot(x, y, z, color="black", label='Water Well', linewidth=1)
    # 设置坐标
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    fig.canvas.mpl_connect('scroll_event', call_scroll)
    # 设置x、y、z轴范围一样
    max_range = np.array([x.max() - x.min(), y.max() - y.min(), z.max() - z.min()]).max() / 2.0
    mid_x = (x.max() + x.min()) * 0.5
    mid_y = (y.max() + y.min()) * 0.5
    mid_z = (z.max() + z.min()) * 0.5
    ax.set_xlim(mid_x - max_range, mid_x + max_range)
    ax.set_ylim(mid_y - max_range, mid_y + max_range)
    ax.set_zlim(mid_z - max_range, mid_z + max_range)
    ax.grid(True)

    # 创建动画
    frames = int(para_lists[0][2])
    anim = FuncAnimation(fig, update, frames=frames, interval=100)

    # 手动更新并绘制最后一帧
    update(frames - 1)

    # 保存图像到指定路径
    save_path = os.path.join(os.path.dirname(__file__), '..', '..', 'static', 'rock', 'data', 'plot_image.png')
    plt.savefig(save_path)

    # 关闭图形对象以释放内存
    plt.close(fig)
    # # 创建动画
    # frames = int(para_lists[0][2])
    # anim = FuncAnimation(fig, update, frames=frames, interval=100)
    #
    # # 等待动画完成
    # time.sleep(frames * 0.1)  # 假设每帧间隔100毫秒，等待动画完成
    #
    # # 保存图像到指定路径
    # save_path = os.path.join(os.path.dirname(__file__),"..","..",'static', 'rock', 'data', 'plot_image.png')
    # anim.save(save_path)
    # plt.close(fig)  # 关闭图形对象以释放内存

    return save_path  # 返回图像保存的路径

def KGD_model(local, Yang, Song, time, pump_rate, measured_depth, east, north, depth, theta):
    # 计算裂缝长度与宽度
    viscosity = 5 * 0.001
    pump_rate = (pump_rate * 0.9) / (60 * 2)
    t = time * 60
    E = Yang * 1e9 / (1 - Song ** 2)
    KGD_height = random.uniform(100, 120)
    KGD_length = 0.539 * (((E * pump_rate ** 3) / (viscosity * KGD_height ** 3)) ** (1 / 5)) * (t ** (2 / 3))
    KGD_width = 2.360 * ((viscosity * pump_rate ** 3 / (E * KGD_height ** 3)) ** (1 / 6)) * (t ** (1 / 3))
    para_1 = 0.539 * (((E * pump_rate ** 3) / (viscosity * KGD_height ** 3)) ** (1 / 5))
    para_2 = KGD_height / t ** (2 / 3)
    para_3 = 2.360 * ((viscosity * pump_rate ** 3 / (E * KGD_height ** 3)) ** (1 / 6))
    # 计算裂缝位置与偏角
    target_x = np.interp(local, measured_depth, east)
    target_y = np.interp(local, measured_depth, north)
    target_z = np.interp(local, measured_depth, depth)
    target_theta = np.interp(local, measured_depth, theta)
    para_list = [para_1, para_2, time, local, KGD_length, KGD_height, target_x, target_y, target_z, target_theta,
                 para_3, KGD_width]
    return para_list


def get_parameters(completion_file_path, interpretation_path, pump_file_path, well_trajectory_path, stage_num):
    # 读取射孔数据
    df_completion = pd.read_excel(completion_file_path)
    # 按照 "Stage number" 分组
    grouped_data = df_completion.groupby('Stage number')['Perf bottom MD(m)'].apply(list).reset_index(
        name='Perf bottom MD(m) List')
    # 选择 Stage number
    stage_perf_bottom_list = grouped_data[grouped_data['Stage number'] == stage_num]['Perf bottom MD(m) List'].iloc[0]
    piece_num = len(stage_perf_bottom_list)

    # 读取泵注程序
    df_pump = pd.read_excel(pump_file_path)
    pump_rate_data = df_pump['Pump rate(m3/min)']
    pump_volume_data = df_pump["Fluid volume(m³)"]
    time_data = np.divide(np.array(pump_volume_data), np.array(pump_rate_data))
    time = round(sum(time_data))
    # 计算泵注速率的平均值
    average_pump_rate = round(sum(pump_volume_data) / time, 2)

    # 读取测井解释数据
    df_interpretation = pd.read_excel(interpretation_path)
    # 保留的列名列表
    desired_columns = ['顶深(m)', '底深(m)', '杨氏模量', '泊松比']
    # 删除除了指定列之外的所有列
    df_interpretation = df_interpretation[desired_columns]
    # 对删除后的数据框进行均值填充，采用默认值填充空列
    df_interpretation = df_interpretation.apply(pd.to_numeric, errors='coerce')  # 转换为数值类型，非数值的值将被转换为NaN
    df_interpretation = df_interpretation.fillna(round(df_interpretation.mean(), 2))  # 使用均值填充缺失值
    # 如果泊松比仍有缺失，使用默认值0.2填充
    df_interpretation['泊松比'].fillna(0.2, inplace=True)
    # 如果杨氏模量仍有缺失，使用默认值40填充
    df_interpretation['杨氏模量'].fillna(40, inplace=True)

    # 读取进轨迹
    df_well = pd.read_excel(well_trajectory_path)
    # 井的数据
    measured_depth = np.array(df_well["井深(m)"])
    depth = np.array(df_well["垂深(m)"])
    theta = np.array(df_well["方位(°)"])
    east = np.array(df_well['E(m)'])
    north = np.array(df_well["N(m)"])

    # 计算绘图所需要的点
    ellipses = []
    for a in stage_perf_bottom_list:
        filtered_data = df_interpretation[(df_interpretation['顶深(m)'] <= a) & (df_interpretation['底深(m)'] >= a)]
        if not filtered_data.empty:
            corresponding_values = {
                '杨氏模量': filtered_data['杨氏模量'].iloc[0],
                '泊松比': filtered_data['泊松比'].iloc[0]
            }
            para_list = KGD_model(a, corresponding_values['杨氏模量'], corresponding_values['泊松比'], time,
                                  average_pump_rate / piece_num, measured_depth, east, north, depth, theta)
            ellipses.append(para_list)
        else:
            return False
    well_trajectory = [east, north, depth]
    return well_trajectory, ellipses


if __name__ == "__main__":
    # 构建文件路径
    base_dir = os.path.dirname(__file__)
    print('11111',base_dir)
    completion_file_path = os.path.join(base_dir,"..","..", "static", "rock", "data", "宁216H11-5井压裂设计completion9.xlsx")
    interpretation_path = os.path.join(base_dir,"..","..", "static", "rock", "data", "宁216H11-5井压裂设计interpretation.xlsx")
    pump_file_path = os.path.join(base_dir,"..","..", "static", "rock", "data", "宁216H11-5井压裂设计pump13.xlsx")
    well_trajectory_path = os.path.join(base_dir,"..","..", "static", "rock", "data", "宁216H11-5井压裂设计well_trajectory.xlsx")
    stage_num = 1
    well_trajectory, ellipses = get_parameters(completion_file_path, interpretation_path, pump_file_path,
                                               well_trajectory_path, stage_num)
    image_path = plot_lines_and_ellipses(well_trajectory, ellipses)
    # print("图像保存路径:", image_path)