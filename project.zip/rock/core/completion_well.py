# -*- coding:utf-8 -*-
import pandas as pd
import re


def is_chinese(word):
    """
    判断是否为汉字
    """
    for ch in word:
        if '\u4e00' <= ch <= '\u9fff':
            return True
    return False


def check_table(table, num):
    check_list = []
    for cell in table.rows[0].cells:
        check_list.append(cell.text.replace("\n", "").strip())
    # text_edit.emit(textBrowser_2, f"表{num}的表头为:" + str(check_list))


def get_len_table_num(table):
    """
    获取表头长度
    """
    same_num = 0
    same = table.cell(0, 0).text
    column = table.columns[0]
    for cell in column.cells[0:10]:
        if cell.text == same:
            same_num += 1
    if same_num == 0:
        num = 1
    else:
        num = same_num
    # text_edit.emit(textBrowser_2, f"表头占用表格列数：{num}")
    return num


def get_density_data(table, density_table_num):
    """
    获取射空密度数据
    """
    density_dict = {}
    num = None
    for i in range(len(table.rows[0].cells)):
        if "孔密" in table.rows[0].cells[i].text.replace("\n", "").strip():
            num = i
            break
    column_len = int(table.cell(-2, 0).text)
    try:
        for j in range(1, column_len + 1):
            density_dict[j] = table.cell(density_table_num, num).text.replace("\n", "").strip()
            density_table_num += 1
    except Exception as e:
        pass
        # text_edit.emit(textBrowser_2, f"获取射孔密度时发生错误！except{e}:")
    return density_dict


def modify_table_headers(table, conversion):
    """
    修改表格头部为英文
    """
    headers_mapping = {
        "段次": 'Stage number',
        "射孔底界(m)": 'Perf bottom MD(m)',
        "射孔底界m": 'Perf bottom MD(m)',
        "射孔底界": 'Perf bottom MD(m)',
        "射孔顶界(m)": 'Perf top MD(m)',
        "射孔顶界m": 'Perf top MD(m)',
        "射孔顶界": 'Perf top MD(m)',
        "射孔长度(m)": "射孔长度(m)",
        "射孔长度m": "射孔长度(m)",
        "射孔长度": "射孔长度(m)",
        "净液量（m³）": "Fluid volume(m³)",
        "净液量m³": "Fluid volume(m³)",
        "净液量m3": "Fluid volume(m³)",
        "净液量": "Fluid volume(m³)",
        "净液量（m3）": "Fluid volume(m³)",
        "排量（m3/min）": "Pump rate(m3/min)",
        "排量m3/min": "Pump rate(m3/min)",
        "排量": "Pump rate(m3/min)",
        "砂浓度（kg/m3）": "Prop.concentration(kgPA)",
        "砂浓度kg/m3": "Prop.concentration(kgPA)",
        "砂浓度": "Prop.concentration(kgPA)",
        "备注": "Step type"
    }
    en_headers_mapping = {
        "段次": 'Stage number',
        "射孔底界(m)": 'Perf bottom MD(ft)',
        "射孔底界m": 'Perf bottom MD(ft)',
        "射孔底界": 'Perf bottom MD(ft)',
        "射孔顶界(m)": 'Perf top MD(ft)',
        "射孔顶界m": 'Perf top MD(ft)',
        "射孔顶界": 'Perf top MD(ft)',
        "射孔长度(m)": "射孔长度(m)",
        "射孔长度m": "射孔长度(m)",
        "射孔长度": "射孔长度(m)",
        "净液量（m³）": "Fluid volume(gal)",
        "净液量m³": "Fluid volume(gal)",
        "净液量m3": "Fluid volume(gal)",
        "净液量": "Fluid volume(gal)",
        "净液量（m3）": "Fluid volume(gal)",
        "排量（m3/min）": "Pump rate(bbl/min)",
        "排量m3/min": "Pump rate(bbl/min)",
        "排量": "Pump rate(bbl/min)",
        "砂浓度（kg/m3）": "Prop.concentration(PPA)",
        "砂浓度kg/m3": "Prop.concentration(PPA)",
        "砂浓度": "Prop.concentration(PPA)",
        "备注": "Step type"
    }
    for cell in table.rows[0].cells:
        cell.text = cell.text.replace("\n", "").strip()
        if conversion:
            if cell.text in en_headers_mapping:
                cell.text = en_headers_mapping[cell.text]
        else:
            if cell.text in headers_mapping:
                cell.text = headers_mapping[cell.text]


def convert_to_dirc(well_completion_table, density_dict, table_num, conversion):
    """
    将射孔数据转换为字典数据
    """
    completion_dict = {}
    well_completion_j = 1
    for row in well_completion_table.rows[table_num:]:
        completion_dict_a = {}
        i = 0
        for cell in row.cells:
            well_a = cell.text.replace("\n", "").strip()
            completion_dict_a[well_completion_table.cell(0, i).text] = well_a
            i += 1
        if not completion_dict_a["Stage number"].isdigit():
            # 获取数字
            match_num = re.search(r'\d+', completion_dict_a["Stage number"])
            completion_dict_a["Stage number"] = str(match_num.group())

        try:
            perforation_density = int(density_dict[int(completion_dict_a["Stage number"])])
        except Exception as e:
            # text_edit.emit(textBrowser_2, f"射孔密度匹配失败！将采用默认射孔密度。错误原因：{e}")
            perforation_density = 8
        if conversion:
            completion_dict_a['Perf bottom MD(ft)'] = str(
                round(float(completion_dict_a['Perf bottom MD(ft)']) * 3.28, 2))
            completion_dict_a['Perf top MD(ft)'] = str(
                round(float(completion_dict_a['Perf top MD(ft)']) * 3.28, 2))

        try:
            completion_dict_a["No of shots"] = str(
                perforation_density * float(completion_dict_a['射孔长度(m)'].replace("\n", "").strip()))
        except Exception as e:
            # text_edit.emit(textBrowser_2, f"射孔长度获取失败{e}，采用默认射孔长度")
            completion_dict_a["No of shots"] = str(perforation_density * 0.5)
        completion_dict["Perforation" + str(well_completion_j)] = completion_dict_a
        well_completion_j += 1
    return completion_dict


def remove_chinese_keys(data_dict):
    """
    删除字典中的中文键
    """
    for value in data_dict.values():
        if type(value) is dict:
            for nk in list(value.keys()):
                if is_chinese(nk):
                    value.pop(nk, None)


def get_completion_excel(well_perforation_table, density_num, well_completion_table, comp_num, table_name,
                         conversion):
    # 查看表头
    check_table(well_perforation_table, density_num)
    # 获取射孔密度字典
    density_table_num = get_len_table_num(well_perforation_table)
    density_dict = get_density_data(well_perforation_table, density_table_num)

    # 匹配射孔段表
    check_table(well_completion_table, comp_num)

    # 获取表头长度
    well_completion_table_num = get_len_table_num(well_completion_table)

    # 修改表头为英文
    modify_table_headers(well_completion_table, conversion)

    # 将射孔数据转换为字典数据
    completion_dict = convert_to_dirc(well_completion_table, density_dict, well_completion_table_num,
                                      conversion)

    # 删除不必要的数据
    remove_chinese_keys(completion_dict)

    # 转换为DataFrame
    df = pd.DataFrame.from_dict(completion_dict, orient='index')
    # 重新排列顺序
    try:
        if conversion:
            df = df[["Perf top MD(ft)", "Perf bottom MD(ft)", "Stage number", "No of shots"]]
        else:
            df = df[["Perf top MD(m)", "Perf bottom MD(m)", "Stage number", "No of shots"]]
    except Exception as e:
        # text_edit.emit(textBrowser_2, f"pump表格中缺少数据，或者文件头格式不对！生成的数据将有缺失！\n{e}")
        pass
    # 反转DataFrame的行顺序
    df = df[::-1]

    # 写入Excel文件
    try:
        if conversion:
            df.to_excel(f'{table_name}completion{comp_num}英制.xlsx', index=True)
        else:
            df.to_excel(f'{table_name}completion{comp_num}.xlsx', index=True)
    except Exception as e:
        pass
        # text_edit.emit(textBrowser_2, f"请关闭已经生成的excel文件！{e}")

