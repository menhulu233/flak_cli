import re
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def KGD_model(local, Yang, Song, time, pump_rate, measured_depth, east, north, depth, theta, Height, viscosity):
    # 计算裂缝长度与宽度
    t = time
    E = Yang * 1e9 / (1 - Song ** 2)
    KGD_height = Height
    KGD_length = 0.539 * (((E * pump_rate ** 3) / (viscosity * KGD_height ** 3)) ** (1 / 6)) * (t ** (2 / 3))
    KGD_width = 2.360 * (((viscosity * pump_rate ** 3) / (E * KGD_height ** 3)) ** (1 / 6)) * (t ** (1 / 3))
    # 计算裂缝位置与偏角
    target_x = np.interp(local, measured_depth, east)
    target_y = np.interp(local, measured_depth, north)
    target_z = np.interp(local, measured_depth, depth)
    target_theta = np.interp(local, measured_depth, theta)
    para_list = [time, local, KGD_length, KGD_height, target_x, target_y, target_z, target_theta, KGD_width]
    return para_list


def PKN_model(local, Yang, Song, time, pump_rate, measured_depth, east, north, depth, theta, Height, viscosity):
    # 计算裂缝长度与宽度
    t = time
    E = Yang * 1e9 / (1 - Song ** 2)
    PKN_height = Height
    PKN_length = 0.524 * (((E * pump_rate ** 3) / (viscosity * PKN_height ** 4)) ** (1 / 5)) * (t ** (4 / 5))
    PKN_width = 3.04 * (((viscosity * pump_rate ** 2) / (E * PKN_height)) ** (1 / 5)) * (t ** (1 / 5))
    # 计算裂缝位置与偏角
    target_x = np.interp(local, measured_depth, east)
    target_y = np.interp(local, measured_depth, north)
    target_z = np.interp(local, measured_depth, depth)
    target_theta = np.interp(local, measured_depth, theta)
    para_list = [time, local, PKN_length, PKN_height, target_x, target_y, target_z, target_theta, PKN_width]
    return para_list


def get_parameters(ModelType, stage_perf_bottom_list, Yang, Song, Height, viscosity, Time, pump_rate, east, north,
                   depth, theta):
    # 读取泵注程序
    time = Time * 60
    # 计算泵注速率的平均值
    average_pump_rate = pump_rate / (60 * 2 * piece_num * 4)
    # 计算绘图所需要的点
    ellipses = []
    for a in stage_perf_bottom_list:
        if ModelType == "PKN":
            para_list = PKN_model(a, Yang, Song, time, average_pump_rate, measured_depth, east, north, depth, theta,
                                  Height,
                                  viscosity)
        else:
            para_list = KGD_model(a, Yang, Song, time, average_pump_rate, measured_depth, east, north, depth, theta,
                                  Height,
                                  viscosity)
        ellipses.append(para_list)
    return ellipses


# 定义一个更新图形的函数，用于实时绘制裂缝扩展
def call_scroll(event):
    if event.inaxes is not None:
        # 获取当前坐标轴的范围
        x_min, x_max = ax.get_xlim()
        y_min, y_max = ax.get_ylim()
        z_min, z_max = ax.get_zlim()
        w = x_max - x_min
        h = y_max - y_min
        d = z_max - z_min

        # 使用ax.format_coord获取鼠标在3D坐标系中的坐标
        mouse_position = ax.format_coord(event.xdata, event.ydata)

        # 从鼠标位置字符串中提取X、Y、Z坐标
        # 提取数值部分的正则表达式，包含负号
        coordinates = re.findall(r'[-+]?\d*\.\d+|[-+]?\d+', mouse_position.replace("−", "-"))
        cur_x, cur_y, cur_z = map(float, coordinates[-3:])
        # 根据滚轮滚动方向确定放大或缩小
        if event.button == 'up':
            factor = 0.9
        elif event.button == 'down':
            factor = 1.1
        else:
            return
        curXposition = (cur_x - x_min) / w
        curYposition = (cur_y - y_min) / h
        curZposition = (cur_z - z_min) / d  # 注意这里使用深度d
        # 计算新的范围
        w = w * factor
        h = h * factor
        d = d * factor

        # 计算新的坐标轴范围的起始点
        newx = cur_x - w * curXposition
        newy = cur_y - h * curYposition
        newz = cur_z - d * curZposition

        # 更新坐标轴范围
        ax.set_xlim(newx, newx + w)
        ax.set_ylim(newy, newy + h)
        ax.set_zlim(newz, newz + d)

        # 绘制更新
        fig.canvas.draw_idle()


def create_ellipsoid(a, b, c, location, theta):
    t = np.linspace(0, 2 * np.pi, 40)
    phi = np.linspace(0, np.pi, 20)

    # 参数方程描述椭球上的点
    t, phi = np.meshgrid(t, phi)
    x = a * np.sin(phi) * np.cos(t)
    y = c * np.sin(phi) * np.sin(t)
    z = b * np.cos(phi)
    x += location[0]
    y += location[1]
    # 旋转椭球
    x_rot = (x - location[0]) * np.cos(theta) - (y - location[1]) * np.sin(theta) + location[0]
    y_rot = (x - location[0]) * np.sin(theta) + (y - location[1]) * np.cos(theta) + location[1]
    z_rot = z + location[2]
    # 计算椭球上每个点的厚度
    thickness = np.sqrt((x_rot - x_rot.mean()) ** 2 + (y_rot - y_rot.mean()) ** 2 + (z_rot - z_rot.mean()) ** 2)

    return x_rot, y_rot, z_rot, thickness


def update_plot(ax, ellipses):
    for collection in ax.collections:
        collection.remove()

    for index, para in enumerate(ellipses):
        a = para[2]
        b = para[3] / 2
        c = para[8] / 2
        location = [para[4], para[5], -para[6]]
        theta = np.radians(-para[7])
        x_rot, y_rot, z_rot, thickness = create_ellipsoid(a, b, c, location, theta)
        # 自定义颜色映射，红色对应较大的厚度，蓝色对应较小的厚度
        cmap = LinearSegmentedColormap.from_list('coolwarm',
                                                 ['#FF0000', '#FFFF00', '#00FF00', '#00FFFF', '#0000FF'], N=256)
        norm = plt.Normalize(thickness.min(), thickness.max())
        colors = cmap(norm(thickness))
        # 绘制椭球表面，设置颜色
        ax.plot_surface(x_rot, y_rot, z_rot, facecolors=colors, rstride=1, cstride=1, alpha=0.5)
        # if index == 0:
        #     # 绘制新的长方形边框并将其添加到 rectangle_lines 列表中
        #     lines = add_rectangle_border(ax, a, b, location, theta)
        #     rectangle_lines.extend(lines)
    plt.pause(0.1)


if __name__ == "__main__":
    # 全局变量用于存储边框线条
    rectangle_lines = []
    # 需要界面输入的参数
    stage_num = 30
    Yang = 40
    Song = 0.2
    Height = 50
    viscosity = 0.005
    ModelType = "KGD"
    # 需要文件输入的参数
    completion_file_path = "E:\Desktop\实时裂缝扩展8.26\实时裂缝扩展8.26\阳101H29-2井压裂设计completion7.xlsx"
    well_trajectory_path = "E:\Desktop\实时裂缝扩展8.26\实时裂缝扩展8.26\阳101H29-2井压裂设计well_trajectory.xlsx"

    # 读取射孔数据
    df_completion = pd.read_excel(completion_file_path)
    # 按照 "Stage number" 分组
    grouped_data = df_completion.groupby('Stage number')['Perf bottom MD(m)'].apply(list).reset_index(
        name='Perf bottom MD(m) List')
    # 选择 Stage number
    stage_perf_bottom_list = grouped_data[grouped_data['Stage number'] == stage_num]['Perf bottom MD(m) List'].iloc[0]
    piece_num = len(stage_perf_bottom_list)

    # 读取进轨迹
    df_well = pd.read_excel(well_trajectory_path)
    measured_depth = np.array(df_well["井深(m)"])
    depth = np.array(df_well["垂深(m)"])
    theta = np.array(df_well["方位(°)"])
    east = np.array(df_well['E(m)'])
    north = np.array(df_well["N(m)"])
    well = [east, north, depth]
    # 创建图形并调整子图位置
    fig = plt.figure(figsize=(10, 8))
    # 调整子图位置以增大 3D 图的大小
    fig.subplots_adjust(left=0.05, right=1, bottom=0.05, top=1)
    ax = fig.add_subplot(111, projection='3d', aspect="auto")
    # 绘制井轨迹
    x = well[0]
    y = well[1]
    z = -well[2]
    x_range = (-150, 500)
    y_range = (-150, 500)
    z_range = (z.min(), -3400)
    ax.set_xlim(x_range)
    ax.set_ylim(y_range)
    ax.set_zlim(z_range)
    mask = (
            (x >= x_range[0]) & (x <= x_range[1]) &
            (y >= y_range[0]) & (y <= y_range[1]) &
            (z >= z_range[0]) & (z <= z_range[1])
    )
    x = x[mask]
    y = y[mask]
    z = z[mask]
    ax.plot(x, y, z, color="black", label='Well', linewidth=3)
    # 设置坐标
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    fig.canvas.mpl_connect('scroll_event', call_scroll)
    # 设置背景透明
    ax.xaxis.pane.set_facecolor((1.0, 1.0, 1.0, 0.0))  # 设置x轴背景颜色透明
    ax.yaxis.pane.set_facecolor((1.0, 1.0, 1.0, 0.0))  # 设置y轴背景颜色透明
    ax.zaxis.pane.set_facecolor((1.0, 1.0, 1.0, 0.0))  # 设置z轴背景颜色透明
    ax.grid(True)
    # 设置视角
    elev = 26  # 仰角
    azim = -14  # 方位角
    ax.view_init(elev=elev, azim=azim)

    # 实时传入的施工数据
    Time = 5
    pump_rate = 14
    ellipses = get_parameters(ModelType, stage_perf_bottom_list, Yang, Song, Height, viscosity, Time,
                              pump_rate, east,
                              north, depth, theta)
    # 更新图形以显示新的裂缝扩展
    update_plot(ax, ellipses)
    # 保持图形窗口打开
    plt.show()
