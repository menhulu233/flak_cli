import pandas as pd

from rock.core.completion_well import get_len_table_num


def get_well_trajectory_excel(well_table, table_name):
    well_table_start_num = get_len_table_num(well_table)
    # 防止表头有问题
    for cell in well_table.rows[0].cells:
        if "井深" in cell.text.replace("\n", "").strip():
            cell.text = "井深(m)"
        elif "方位" in cell.text.replace("\n", "").strip():
            cell.text = "方位(°)"
        elif "垂深" in cell.text.replace("\n", "").strip():
            cell.text = "垂深(m)"
        elif "N" in cell.text.replace("\n", "").strip():
            cell.text = "N(m)"
        elif "E" in cell.text.replace("\n", "").strip():
            cell.text = "E(m)"
    well_trajectory = []
    # 写入文件
    for row in well_table.rows[well_table_start_num - 1:]:
        row_data = [cell.text.replace("\n", "").strip() for cell in row.cells]
        well_trajectory.append(row_data)
    # 转换为 DataFrame
    df = pd.DataFrame(well_trajectory)
    # 保存为 Excel 文件
    df.to_excel(f'{table_name}well_trajectory.xlsx', index=False, header=False)
