from docx import Document
import win32com.client
import os

from completion_well import get_completion_excel
from interpretation import get_interpretation_excel
from pump import get_bump_excel
from well_trajectory import get_well_trajectory_excel


def get_table_num(tables):
    """
    获取表格位置
    """
    num_dir = {}
    pump_num_list = []
    for i in range(len(tables)):
        table = tables[i]
        for cell in table.rows[0].cells:
            if "射孔底界" in cell.text.replace("\n", "").strip():
                num_dir["completion"] = i
                break
            elif "孔密" in cell.text.replace("\n", "").strip():
                num_dir["density"] = i
                break
            elif "杨氏模量" in cell.text.replace("\n", "").strip():
                num_dir["interpretation"] = i
            elif "砂浓度" in cell.text.replace("\n", "").strip():
                pump_num_list.append(i)
                break
            elif "狗腿度" in cell.text.replace("\n", "").strip():
                num_dir["well_trajectory"] = i
                break
    num_dir["pump"] = pump_num_list
    return num_dir


def check_table(table, num):
    check_list = []
    for cell in table.rows[0].cells:
        check_list.append(cell.text.replace("\n", "").strip())
    # text_edit.emit(textBrowser_2, f"表{num}的表头为:" + str(check_list))


def extract_table_name(file_path):
    table_name = os.path.splitext(file_path)[0]

    return table_name


def convert_doc_to_docx(doc_file_path, docx_file_path):
    # 创建Word应用程序对象
    word_app = win32com.client.Dispatch("Word.Application")

    # 打开旧版的.doc文件
    doc = word_app.Documents.Open(os.path.abspath(doc_file_path))

    # 将文件保存为新版的.docx文件
    doc.SaveAs2(os.path.abspath(docx_file_path), FileFormat=16)  # 16 表示.docx格式

    # 关闭Word应用程序
    word_app.Quit()


def check_file(file_path):
    file_name, file_extension = os.path.splitext(file_path)
    if file_extension == ".docx":
        return file_path
    elif file_extension == ".doc":
        # text_edit.emit(textBrowser_2, f"你输入的word文件类型是doc,需要转换为docx。")
        doc_file_path = file_path
        docx_file_path = os.path.splitext(file_path)[0] + ".docx"
        try:
            convert_doc_to_docx(doc_file_path, docx_file_path)
        except Exception as e:
            pass
            # text_edit.emit(textBrowser_2, f"{e}")
        file_path = docx_file_path
    else:
        # text_edit.emit(textBrowser_2, "输入文件格式不对！请输入正确的文件路径。")
        return None
    return file_path


def start(file_path, conversion):
    # 判断文件是否为doc文件
    file_path = check_file(file_path)
    if file_path:
        # 提取表头，观察是否有问题
        table_name = extract_table_name(file_path)
        try:
            doc = Document(file_path)
        except Exception as e:
            # text_edit.emit(textBrowser_2, f"未找到你输入的文件,请检查你输入的路径！{e}")
            return False
        # 获取表格位置
        tables = doc.tables
        num_dir = get_table_num(tables)
        # 获取射孔数据excel
        try:
            density_num = num_dir["density"]
            comp_num = num_dir["completion"]
            well_perforation_table = doc.tables[density_num]
            well_completion_table = doc.tables[comp_num]
            get_completion_excel(well_perforation_table, density_num, well_completion_table, comp_num, table_name,
                                  conversion)
        except Exception as e:
            # text_edit.emit(textBrowser_2, f"发生错误！射孔数据提取失败！文件中缺少{e}。")
            pass
        # 获取泵注程序excel
        pump_num_list = num_dir["pump"]
        if len(pump_num_list) != 0:
            for num in pump_num_list:
                pump_table = doc.tables[num]
                check_table(pump_table, num)
                try:
                    get_bump_excel(pump_table, num, table_name, conversion)
                except Exception as e:
                    # text_edit.emit(textBrowser_2, f"泵注程序提取失败{e}")
                    return False
        else:
            # text_edit.emit(textBrowser_2, f"文件中缺少泵注程序！")
            return False
        # 获取解释表格
        try:
            interpretation_table = doc.tables[num_dir["interpretation"]]
            check_table(interpretation_table, num_dir["interpretation"])
            get_interpretation_excel(interpretation_table,table_name)
        except Exception as e:
            # text_edit.emit(textBrowser_2, f"测井解释数据提取失败！数据缺失{e}")
            return False
        # 提取井斜数据
        try:
            well_trajectory_table = doc.tables[num_dir["well_trajectory"]]
            check_table(well_trajectory_table, num_dir["well_trajectory"])
            get_well_trajectory_excel(well_trajectory_table, table_name)
        except Exception as e:
            # text_edit.emit(textBrowser_2, f"井斜数据提取失败！数据缺失{e}")
            return False
        # 返回True
        return True

    else:
        return False
