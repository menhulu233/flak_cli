import pandas as pd
from rock.core.completion_well import modify_table_headers, remove_chinese_keys, get_len_table_num
import re


def is_chinese(word):
    """
    判断是否为汉字
    """
    for ch in word:
        if '\u4e00' <= ch <= '\u9fff':
            return True
    return False


def pump_convert_to_dirc(pump_table, num, conversion):
    """
    表格转换为字典
    num:表头长度
    """
    pump_dirc = {}
    step_name = 1
    # 定义正则表达式
    pattern = r'\d+/\d+'

    for row in pump_table.rows[num:]:
        pump_dirc_cell = {}
        i = 0
        # 获取表格数据
        for cell in row.cells:
            cell_value = cell.text.replace("\n", "").strip()
            pump_dirc_cell[pump_table.cell(0, i).text] = cell_value
            i += 1
        # 设置Treatment type
        pump_dirc_cell["Treatment type"] = "Propped Fracture"
        # 获取压裂液
        if "滑溜水" in pump_dirc_cell["阶段"]:
            pump_dirc_cell["Fluid name"] = "Slickwater"
        elif "盐酸" in pump_dirc_cell["阶段"]:
            pump_dirc_cell["Fluid name"] = "HCl"
        elif "线性胶" in pump_dirc_cell["阶段"]:
            pump_dirc_cell["Fluid name"] = "WF"
        else:
            pump_dirc_cell["Fluid name"] = "Slickwater"

        # 使用re模块进行匹配,获取支撑剂
        match = re.search(pattern, str(pump_dirc_cell["Step type"]))
        # 是否转换单位
        if conversion:
            # 修改排量中的异常值规数值
            if not pump_dirc_cell["Pump rate(bbl/min)"].isdigit():
                # 获取两个数字并计算平均值
                match_num = re.findall(r'\d+', pump_dirc_cell["Pump rate(bbl/min)"])
                # 将字符串形式的数字转换为整数或浮点数
                numeric_values = [float(num) for num in match_num]
                average = sum(numeric_values) / len(match_num)
                pump_dirc_cell["Pump rate(bbl/min)"] = str(round(average * 6.29, 2))
            # 转换液体体积
            pump_dirc_cell["Fluid volume(gal)"] = str(round(float(pump_dirc_cell["Fluid volume(gal)"]) * 264.17, 2))
            # 转换砂浓度
            pump_dirc_cell["Prop.concentration(PPA)"] = str(
                round(float(pump_dirc_cell["Prop.concentration(PPA)"]) / 120, 2))
            if float(pump_dirc_cell["Prop.concentration(PPA)"]) == 0:
                pump_dirc_cell["Proppant"] = "None"
            elif match and "石英砂" in pump_dirc_cell["Step type"]:
                pump_dirc_cell["Proppant"] = "Sand " + match.group()
            elif match and "陶粒" in pump_dirc_cell["Step type"]:
                pump_dirc_cell["Proppant"] = "Ceramic " + match.group()
            else:
                pump_dirc_cell["Proppant"] = "Sand 70/140"
            # 更改step type
            if pump_dirc_cell["Step type"] == "前置":
                pump_dirc_cell["Step type"] = "Pad"
            elif pump_dirc_cell["Step type"] == "顶替" or "顶替" in pump_dirc_cell["阶段"]:
                pump_dirc_cell["Step type"] = "Flush"
            elif float(pump_dirc_cell["Prop.concentration(PPA)"]) == 0:
                pump_dirc_cell["Step type"] = "Pad"
            else:
                pump_dirc_cell["Step type"] = "Slurry"
        else:
            # 修改排量中的异常值规数值
            if not pump_dirc_cell["Pump rate(m3/min)"].isdigit():
                # 获取两个数字并计算平均值
                match_num = re.findall(r'\d+', pump_dirc_cell["Pump rate(m3/min)"])
                # 将字符串形式的数字转换为整数或浮点数
                numeric_values = [float(num) for num in match_num]
                average = sum(numeric_values) / len(match_num)
                pump_dirc_cell["Pump rate(m3/min)"] = str(average)
            if pump_dirc_cell["Prop.concentration(kgPA)"] == "0":
                pump_dirc_cell["Proppant"] = "None"
            elif match and "石英砂" in pump_dirc_cell["Step type"]:
                pump_dirc_cell["Proppant"] = "Sand " + match.group()
            elif match and "陶粒" in pump_dirc_cell["Step type"]:
                pump_dirc_cell["Proppant"] = "Ceramic " + match.group()
            else:
                pump_dirc_cell["Proppant"] = "Sand 70/140"
            # 更改step type
            if pump_dirc_cell["Step type"] == "前置":
                pump_dirc_cell["Step type"] = "Pad"
            elif pump_dirc_cell["Step type"] == "顶替" or "顶替" in pump_dirc_cell["阶段"]:
                pump_dirc_cell["Step type"] = "Flush"
            elif pump_dirc_cell["Prop.concentration(kgPA)"] == "0":
                pump_dirc_cell["Step type"] = "Pad"
            else:
                pump_dirc_cell["Step type"] = "Slurry"

        pump_dirc[str(step_name)] = pump_dirc_cell
        step_name += 1
    return pump_dirc


def get_bump_excel(pump_table, local_num, table_name,conversion):
    """
    local_num:表格所在位置
    """

    # 获取表头长度
    table_num = get_len_table_num(pump_table)

    # 修改表头为英文
    modify_table_headers(pump_table, conversion)

    # 将泵注程序数据转换为字典数据
    pump_dict = pump_convert_to_dirc(pump_table, table_num, conversion)

    # 删除不必要的数据
    remove_chinese_keys(pump_dict)

    # 转换为DataFrame
    df = pd.DataFrame.from_dict(pump_dict, orient='index')

    # 重新排列列的顺序
    try:
        if conversion:
            df = df[["Treatment type", "Pump rate(bbl/min)", "Fluid name", "Fluid volume(gal)",
                     "Proppant", "Prop.concentration(PPA)", "Step type"]]
        else:
            df = df[["Treatment type", "Pump rate(m3/min)", "Fluid name", "Fluid volume(m³)",
                     "Proppant", "Prop.concentration(kgPA)", "Step type"]]
    except Exception as e:
        # text_edit.emit(textBrowser_2, f"pump表格中缺少数据，或者文件头格式不对！生成的数据将有缺失！\n{e}")
        pass
    # 写入Excel文件
    try:
        if conversion:
            df.to_excel(f'{table_name}pump{local_num}英制.xlsx', index=True)
        else:
            df.to_excel(f'{table_name}pump{local_num}.xlsx', index=True)
    except Exception as e:
        pass
        # text_edit.emit(textBrowser_2, f"请关闭{table_name}pump{local_num}文件！{e}")
