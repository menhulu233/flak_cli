from django.urls import path
from . import views11
urlpatterns = [
    path('uploadrockdata', views11.upload_rockdata,name='uploadrockdata'),
    path('cal',views11.rockCal,name="rockCal")
]