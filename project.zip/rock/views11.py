import base64
import datetime
import math
import os
import time
import traceback

from django.shortcuts import render
import re
from matplotlib.colors import LinearSegmentedColormap

from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse, JsonResponse
import matplotlib
matplotlib.use('Agg')  # 使用 Agg 后端以避免 GUI
import matplotlib.pyplot as plt

import io
import pandas as pd
import numpy as np


from scipy.optimize import minimize

def KGD_model(local, Yang, Song, time, pump_rate, measured_depth, east, north, depth, theta, Height, viscosity):
    # 计算裂缝长度与宽度
    t = time
    E = Yang * 1e9 / (1 - Song ** 2)
    KGD_height = Height
    KGD_length = 0.539 * (((E * pump_rate ** 3) / (viscosity * KGD_height ** 3)) ** (1 / 6)) * (t ** (2 / 3))
    KGD_width = 2.360 * (((viscosity * pump_rate ** 3) / (E * KGD_height ** 3)) ** (1 / 6)) * (t ** (1 / 3))
    # 计算裂缝位置与偏角
    target_x = np.interp(local, measured_depth, east)
    target_y = np.interp(local, measured_depth, north)
    target_z = np.interp(local, measured_depth, depth)
    target_theta = theta
    para_list = [time, local, KGD_length, KGD_height, target_x, target_y, target_z, target_theta, KGD_width]
    return para_list

def PKN_model(local, Yang, Song, time, pump_rate, measured_depth, east, north, depth, theta, Height, viscosity):
    # 计算裂缝长度与宽度
    t = time
    E = Yang * 1e9 / (1 - Song ** 2)
    PKN_height = Height
    PKN_length = 0.39054 * (((E * pump_rate ** 3) / (viscosity * PKN_height ** 4)) ** (1 / 5)) * (t ** (4 / 5))
    PKN_width = 2.174 * (((viscosity * pump_rate ** 2) / (E * PKN_height)) ** (1 / 5)) * (t ** (1 / 5))
    # 计算裂缝位置与偏角
    target_x = np.interp(local, measured_depth, east)
    target_y = np.interp(local, measured_depth, north)
    target_z = np.interp(local, measured_depth, depth)
    target_theta = theta
    para_list = [time, local, PKN_length, PKN_height, target_x, target_y, target_z, target_theta, PKN_width]
    return para_list

def get_parameters(ModelType, stage_perf_bottom_list, Yang, Song, Height, viscosity, Time, pump_rate, east, north,
                   depth, theta, filtration, shodow_filtration):
    # 读取泵注程序
    time = Time
    E = Yang * 1e9 / (1 - Song ** 2)
    # 计算绘图所需要的点
    ellipses = []
    # 计算泵注速率的平均值
    if pump_rate <= 0:
        for i, local in enumerate(stage_perf_bottom_list):
            para_list = [time, local, 0, 0, np.interp(local, measured_depth, east),
                         np.interp(local, measured_depth, north), np.interp(local, measured_depth, depth), theta, 0]
            ellipses.append(para_list)
        return ellipses

    average_pump_rate = pump_rate / (60 * len(stage_perf_bottom_list) * 2 * filtration)
    average_p = 1.08819 * (
            math.pow(
                (math.pow(E, 4) * math.pow(average_pump_rate, 2) * viscosity) / math.pow(Height, 6),
                1 / 5
            ) * math.pow(time, 1 / 5)
    )
    frac_space = np.zeros((len(stage_perf_bottom_list), len(stage_perf_bottom_list)))
    shadow = np.zeros((len(stage_perf_bottom_list), len(stage_perf_bottom_list)))
    space = abs(stage_perf_bottom_list[-1] - stage_perf_bottom_list[0]) / (len(stage_perf_bottom_list) - 1)
    for k in range(len(stage_perf_bottom_list)):
        for h in range(len(stage_perf_bottom_list)):
            frac_space[k][h] = abs(h - k) * space
    for k in range(len(stage_perf_bottom_list)):
        for h in range(len(stage_perf_bottom_list)):
            if k != h:
                shadow[k][h] = average_p * (
                        1 - frac_space[k][h] / np.sqrt(frac_space[k][h] ** 2 + (Height / 2) ** 2) + (
                        frac_space[k][h] / (Height / 2)) / np.power(
                    (frac_space[k][h] / (Height / 2)) * (
                            np.sqrt(frac_space[k][h] ** 2 + (Height / 2) ** 2) / (Height / 2)), 3 / 2))
    frac_shadow = [sum(raw) for raw in shadow]
    frac_Pnet = [max((average_p - 0.1 * shodow_filtration * a) * 10 ** -6, 1e-9) for a in frac_shadow]
    n_components = len(frac_shadow)  # 分量的数量
    # 设定变量的范围
    bounds = [(0, None)] * n_components
    # 初始猜测值
    initial_guesses = [1] * n_components

    def objective(variables):
        variables = np.array(variables)
        total_sum = np.sum(variables) - average_pump_rate * len(stage_perf_bottom_list)
        target_ratios = np.array([x ** (2 / 5) for x in variables])
        # 改进约束定义
        ratio_constraints = (target_ratios / np.array(frac_Pnet)) - (target_ratios[0] / frac_Pnet[0])
        # 返回的总和包含平方和
        return total_sum ** 2 + np.sum(ratio_constraints ** 2)

    # 使用 trust-constr 求解，设置选项以提高精度
    options = {'xtol': 1e-7, 'gtol': 1e-10, 'maxiter': 500, 'disp': False}
    result = minimize(objective, initial_guesses, bounds=bounds, method='trust-constr', options=options)
    frac_single = result.x
    print("frac_single",frac_single)

    for i, local in enumerate(stage_perf_bottom_list):
        if ModelType == "PKN":
            para_list = PKN_model(local, Yang, Song, time, frac_single[i], measured_depth, east, north, depth,
                                  theta,
                                  Height,
                                  viscosity)
        else:
            para_list = KGD_model(local, Yang, Song, time, frac_single[i], measured_depth, east, north, depth,
                                  theta,
                                  Height,
                                  viscosity)
        ellipses.append(para_list)
    return ellipses

# 定义一个更新图形的函数，用于实时绘制裂缝扩展
def call_scroll(event):
    if event.inaxes is not None:
        # 获取当前坐标轴的范围
        x_min, x_max = ax.get_xlim()
        y_min, y_max = ax.get_ylim()
        z_min, z_max = ax.get_zlim()
        w = x_max - x_min
        h = y_max - y_min
        d = z_max - z_min

        # 使用ax.format_coord获取鼠标在3D坐标系中的坐标
        mouse_position = ax.format_coord(event.xdata, event.ydata)

        # 从鼠标位置字符串中提取X、Y、Z坐标
        # 提取数值部分的正则表达式，包含负号
        coordinates = re.findall(r'[-+]?\d*\.\d+|[-+]?\d+', mouse_position.replace("−", "-"))
        cur_x, cur_y, cur_z = map(float, coordinates[-3:])
        # 根据滚轮滚动方向确定放大或缩小
        if event.button == 'up':
            factor = 0.9
        elif event.button == 'down':
            factor = 1.1
        else:
            return
        curXposition = (cur_x - x_min) / w
        curYposition = (cur_y - y_min) / h
        curZposition = (cur_z - z_min) / d  # 注意这里使用深度d
        # 计算新的范围
        w = w * factor
        h = h * factor
        d = d * factor

        # 计算新的坐标轴范围的起始点
        newx = cur_x - w * curXposition
        newy = cur_y - h * curYposition
        newz = cur_z - d * curZposition

        # 更新坐标轴范围
        ax.set_xlim(newx, newx + w)
        ax.set_ylim(newy, newy + h)
        ax.set_zlim(newz, newz + d)

        # 绘制更新
        fig.canvas.draw_idle()
def create_ellipsoid(a, b, c, location, theta):
    t = np.linspace(0, 2 * np.pi, 40)
    phi = np.linspace(0, np.pi, 20)

    # 参数方程描述椭球上的点
    t, phi = np.meshgrid(t, phi)
    x = a * np.sin(phi) * np.cos(t)
    y = c * np.sin(phi) * np.sin(t)
    z = b * np.cos(phi)
    x += location[0]
    y += location[1]
    # 旋转椭球
    x_rot = (x - location[0]) * np.cos(theta) - (y - location[1]) * np.sin(theta) + location[0]
    y_rot = (x - location[0]) * np.sin(theta) + (y - location[1]) * np.cos(theta) + location[1]
    z_rot = z + location[2]
    # 计算椭球上每个点的厚度
    thickness = np.sqrt((x_rot - x_rot.mean()) ** 2 + (y_rot - y_rot.mean()) ** 2 + (z_rot - z_rot.mean()) ** 2)

    return x_rot, y_rot, z_rot, thickness

def update_plot(ax, ellipses):
    for collection in ax.collections:
        collection.remove()
    for index, para in enumerate(ellipses):
        a = para[2]
        b = para[3] / 2
        c = para[8] / 2
        location = [para[4], para[5], -para[6]]
        theta = np.radians(-para[7])
        x_rot, y_rot, z_rot, thickness = create_ellipsoid(a, b, c, location, theta)
        # 自定义颜色映射，红色对应较大的厚度，蓝色对应较小的厚度
        cmap = LinearSegmentedColormap.from_list('coolwarm',
                                                 ['#FF0000', '#FFFF00', '#00FF00', '#00FFFF', '#0000FF'], N=256)
        norm = plt.Normalize(thickness.min(), thickness.max())
        colors = cmap(norm(thickness))
        # 绘制椭球表面，设置颜色
        ax.plot_surface(x_rot, y_rot, z_rot, facecolors=colors, rstride=1, cstride=1, alpha=0.5)
        # if index == 0:
        #     # 绘制新的长方形边框并将其添加到 rectangle_lines 列表中
        #     lines = add_rectangle_border(ax, a, b, location, theta)
        #     rectangle_lines.extend(lines)


def upload_rockdata(request):
    if request.method == 'POST':
        uploaded_file1 = request.FILES.get('file1')
        uploaded_file2 = request.FILES.get('file2')

        if uploaded_file1 and uploaded_file2:
            file_name1 = "completion.xlsx"
            file_name2 = "well_trajectory.xlsx"

            save_path1 = os.path.join('static/rock/data', file_name1)
            save_path2 = os.path.join('static/rock/data', file_name2)

            # 保存上传的文件
            with open(save_path1, 'wb') as destination1, open(save_path2, 'wb') as destination2:
                for chunk in uploaded_file1.chunks():
                    destination1.write(chunk)
                for chunk in uploaded_file2.chunks():
                    destination2.write(chunk)

            # 调用后台任务处理上传的文档
            if os.path.exists(save_path1) and os.path.exists(save_path2):
                return JsonResponse({'status': 'success'})  # 处理成功的响应
            else:
                return JsonResponse({'status': 'failure'})  # 处理失败的响应
        else:
            return JsonResponse({'status': 'failure', 'message': '必须上传两个文件'})  # 如果文件缺失

    return render(request, 'index1.html')


def rockCal(request):
    if request.method == 'POST':
        try:
            global rectangle_lines
            # 全局变量用于存储边框线条
            rectangle_lines = []
            # 获取前端传递的参数
            fracStage = int(request.POST.get("fracStage", 1))
            yang = float(request.POST.get("yang", 0.0))
            song = float(request.POST.get("song", 0.0))
            modelType = request.POST.get("modelType", "PKN")
            viscosity1 = float(request.POST.get("viscosity", 1.0))
            height = float(request.POST.get("rock_height", 1.0))
            count = int(request.POST.get('count', 0))
            pl = float(request.POST.get("pl", 0.0))

            #新增加
            filtration = 4
            theta = 27
            shodow_filtration = 0.8
            # 文件路径
            completion_file_path = "static/rock/data/completion.xlsx"
            well_trajectory_path = "static/rock/data/well_trajectory.xlsx"

            # 读取射孔数据
            df_completion = pd.read_excel(completion_file_path)
            grouped_data = df_completion.groupby('Stage number')['Perf bottom MD(m)'].apply(list).reset_index(
                name='Perf bottom MD(m) List')

            # 获取指定阶段的射孔深度列表
            try:
                stage_perf_bottom_list = grouped_data[grouped_data['Stage number'] == fracStage]['Perf bottom MD(m) List'].iloc[0]
            except IndexError:
                return JsonResponse({'error': '无效的 fracStage 值。'}, status=400)

            global measured_depth
            # 读取井轨迹数据
            df_well = pd.read_excel(well_trajectory_path)
            measured_depth = np.array(df_well["井深(m)"])
            depth = np.array(df_well["垂深(m)"])
            # theta = np.array(df_well["方位(°)"])
            east = np.array(df_well['E(m)'])
            north = np.array(df_well["N(m)"])
            well = [east, north, depth]

            global fig,ax
            # 创建图形并调整子图位置
            fig = plt.figure(figsize=(10, 8))
            # 调整子图位置以增大 3D 图的大小
            fig.subplots_adjust(left=0.05, right=1, bottom=0.05, top=1)
            ax = fig.add_subplot(111, projection='3d', aspect="equal")

            # 绘制井轨迹
            x = well[0]
            y = well[1]
            z = -well[2]
            x_range = (-150, 500)
            y_range = (-150, 500)
            z_range = (z.min(), -3400)
            ax.set_xlim(x_range)
            ax.set_ylim(y_range)
            ax.set_zlim(z_range)
            mask = (
                    (x >= x_range[0]) & (x <= x_range[1]) &
                    (y >= y_range[0]) & (y <= y_range[1]) &
                    (z >= z_range[0]) & (z <= z_range[1])
            )
            x = x[mask]
            y = y[mask]
            z = z[mask]
            ax.plot(x, y, z, color="black", label='Well', linewidth=3)

            # 设置坐标轴标签
            ax.set_xlabel('X')
            ax.set_ylabel('Y')
            ax.set_zlabel('Z')
            fig.canvas.mpl_connect('scroll_event', call_scroll)
            # 设置背景透明
            ax.xaxis.pane.set_facecolor((1.0, 1.0, 1.0, 0.0))
            ax.yaxis.pane.set_facecolor((1.0, 1.0, 1.0, 0.0))
            ax.zaxis.pane.set_facecolor((1.0, 1.0, 1.0, 0.0))
            ax.grid(True)

            # 设置视角
            elev = 26
            azim = -14
            ax.view_init(elev=elev, azim=azim)

            # 实时传入的施工数据
            Time = count
            pump_rate = pl
            ellipses = get_parameters(modelType, stage_perf_bottom_list, yang, song, height, viscosity1, Time,
                                      pump_rate, east,
                                      north, depth, theta, filtration,shodow_filtration)
            print("pump_rate",pump_rate)
            # 更新图形并获取图像数据
            update_plot(ax, ellipses)

            # 保存图像到内存
            buf = io.BytesIO()
            plt.savefig(buf, format='png')
            # 生成带有时间戳的文件名
            # timestamp = time.strftime('%Y%m%d_%H%M%S')
            file_path = f'static/rock/data/plot_rock.png'
            # 保存图像到本地文件
            plt.savefig(file_path)

            buf.seek(0)
            encoded_string = base64.b64encode(buf.read()).decode('utf-8')
            buf.close()
            plt.close(fig)
            # 生成响应
            return JsonResponse({'new_plot': encoded_string})
            # 添加对异常的详细处理
        except Exception as e:
            # 捕获完整的堆栈信息
            error_trace = traceback.format_exc()
            # 返回错误信息及堆栈跟踪
            return JsonResponse({'error': str(e), 'traceback': error_trace}, status=500)


    else:
        return JsonResponse({'error': '无效的请求方法。'}, status=405)


