from django.http import HttpResponse
from django.shortcuts import render
import json
from PerforationNum.core.calNum import calNum
# Create your views here.
def response_as_json(data):
    json_str = json.dumps(data)
    response = HttpResponse(
        json_str,
        content_type="application/json",
    )
    response["Access-Control-Allow-Origin"] = "*"
    return response


def json_response(data, code=200):
    data = {
        "code": code,
        "msg": "success",
        "data": data,
    }
    return response_as_json(data)

def cal(request):
    if request.method == 'POST':
        d = request.POST.get("d")
        D = request.POST.get("D")
        L1 = request.POST.get("L1")
        L2 = request.POST.get("L2")
        Cd = request.POST.get("Cd")
        density = request.POST.get("density")
        ISIP = request.POST.get("ISIP")
        a1 = request.POST.get("a1")
        a2 = request.POST.get("a2")
        x = request.POST.get("x")
        jobData = request.POST.get("jobData")
        # ret=调用函数
        nums = calNum(d,D,L1,L2,Cd,density,ISIP,a1,a2,x,jobData)
        ret = json.dumps({"num": nums})
        # 图片保存在static/CalPerforationNum/retImgs/ret.svg
        # ret = 4
        return json_response(ret)
