import base64
from io import BytesIO

import pandas as pd
import numpy as np
import pywt
import matplotlib.pyplot as plt

def calPR(startTime,endTime,sgyl_list,pl_list):
    class WaveletAnalysis:
        def __init__(self, signal, wavelet='db12'):
            self.signal = signal
            self.wavelet = wavelet
            if len(signal) > 0:
                self.level = int(np.floor(np.log2(len(signal))))
            else:
                # 如果信号长度为零，你可以设置一个默认值，例如 0
                self.level = 0
            self.decomposed, self.approx = self.perform_wavelet_decomposition()

        def perform_wavelet_decomposition(self):
            coeffs = pywt.wavedec(self.signal, self.wavelet, level=self.level)
            A = pywt.waverec([coeffs[0]] + [np.zeros_like(c) for c in coeffs[1:]], self.wavelet)[:len(self.signal)]
            D = np.zeros((self.level, len(self.signal)))
            for i in range(self.level):
                detail_coeffs = [np.zeros_like(c) for c in coeffs]
                detail_coeffs[-(i + 1)] = coeffs[-(i + 1)]
                detail_signal = pywt.waverec(detail_coeffs, self.wavelet)[:len(self.signal)]
                D[i, :] = detail_signal
            return D, A

        def calculate_energy(self):
            cd = np.abs(self.decomposed) ** 2
            E_total = np.sum(np.abs(self.signal) ** 2)
            E_cD = np.sum(cd, axis=1)
            return cd, E_cD / E_total

    def plot_dual_axis(x, y1, y2, labels, colors, title, y1_ticks, y2_ticks):
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()

        ax1.plot(x, y1, color=colors[0], linewidth=1, label=labels[0])
        ax2.plot(x, y2, color=colors[1], linewidth=1, label=labels[1])

        ax1.set_xlabel('Time (min)')
        ax1.set_ylabel(labels[0], color=colors[0])
        ax2.set_ylabel(labels[1], color=colors[1])
        ax1.tick_params('y', colors=colors[0], direction='in')
        ax2.tick_params('y', colors=colors[1], direction='in')
        ax1.set_yticks(y1_ticks)
        ax2.set_yticks(y2_ticks)

        plt.title(title)
        plt.legend([ax1.get_lines()[0], ax2.get_lines()[0]], labels)

        # 保存图像并递增计数器
        plot_counter = plot_dual_axis.counter
        plot_counter += 1
        save_path_full = f'static/PRAnalysis/img/{plot_counter:03d}_{title}.png'
        plot_dual_axis.counter = plot_counter

        # 使用BytesIO保存图像到内存
        buf = BytesIO()
        plt.savefig(buf, format='png', bbox_inches='tight')
        buf.seek(0)

        # 将图像转换为base64编码
        img_base64 = base64.b64encode(buf.read()).decode('utf-8')
        buf.close()

        plt.close(fig)  # 关闭图像

        return img_base64
    # def plot_dual_axis(x, y1, y2, labels, colors, title, y1_ticks, y2_ticks):
    #     fig, ax1 = plt.subplots()
    #     ax2 = ax1.twinx()
    #
    #     ax1.plot(x, y1, color=colors[0], linewidth=1, label=labels[0])
    #     ax2.plot(x, y2, color=colors[1], linewidth=1, label=labels[1])
    #
    #     ax1.set_xlabel('Time (min)')
    #     ax1.set_ylabel(labels[0], color=colors[0])
    #     ax2.set_ylabel(labels[1], color=colors[1])
    #     ax1.tick_params('y', colors=colors[0], direction='in')
    #     ax2.tick_params('y', colors=colors[1], direction='in')
    #     ax1.set_yticks(y1_ticks)
    #     ax2.set_yticks(y2_ticks)
    #
    #     plt.title(title)
    #     plt.legend([ax1.get_lines()[0], ax2.get_lines()[0]], labels)
    #     save_path_full ='static/PRAnalysis/img/'+title+'.png'
    #     # 递增编号
    #     plot_counter = plot_dual_axis.counter
    #     plot_counter += 1
    #     save_path_full = f'static/PRAnalysis/img/{plot_counter:03d}_{title}.png'
    #     plot_dual_axis.counter = plot_counter
    #
    #     plt.savefig(save_path_full, bbox_inches='tight')
        # plt.show()

    # 初始化计数器
    plot_dual_axis.counter = 0

    sgyl= sgyl_list.split(sep=",")
    pl = pl_list.split(sep=",")
    P = np.array(sgyl).astype(float)
    Rate = np.array(pl).astype(float)
    print(P)

    # filename = '1.csv'
    # data = pd.read_csv(filename, encoding='gbk', skiprows=2, header=None, usecols=[1, 2, 3, 4, 5, 6, 7, 8, 9])
    # P = data.iloc[:, 0].values
    # Rate = data.iloc[:, 1].values

    # 绘制原始数据图
    t_full = np.arange(0, len(P)) / 60.0
    plot_dual_axis(t_full, P, Rate, ['Treating Pressure(MPa)', 'Slurry Rate(m³/min)'], ['b', 'r'],
                   'Fracturing construction site record data - Full Data', np.arange(0, 101, 10), np.arange(0, 31, 3))

    # 手动输入 starttime 和 endtime（假设单位为分钟）
    # starttime = float(input("请输入开始时间（分钟）: "))
    # endtime = float(input("请输入结束时间（分钟）: "))
    starttime = float(startTime)
    endtime = float(endTime)
    # 数据切片
    fs = 1  # 假设采样频率为1Hz
    P = P[int(starttime * 60 * fs):int(endtime * 60 * fs)]
    Rate = Rate[int(starttime * 60 * fs):int(endtime * 60 * fs)]
    t = np.arange(0, len(P)) / 60.0 / fs

    # 绘制切片后的数据图
    plot_dual_axis(t, P, Rate, ['Treating Pressure(MPa)', 'Slurry Rate(m³/min)'], ['b', 'r'],
                   'Fracturing construction site record data - Selected Interval', np.arange(0, 101, 10), np.arange(0, 31, 3))

    # 执行小波分解和能量计算
    wavelet_analysis_P = WaveletAnalysis(P)
    wavelet_analysis_Rate = WaveletAnalysis(Rate)
    cdpressure, Energyfraction_pressure = wavelet_analysis_P.calculate_energy()
    cdrate, Energyfraction_Rate = wavelet_analysis_Rate.calculate_energy()

    imgcodes=[]
    # 绘制小波分解能量分布图
    for i in range(wavelet_analysis_P.level):
        showlevel = wavelet_analysis_P.level - i
        normalized_cdpressure = cdpressure[showlevel - 1, :] / np.max(cdpressure[showlevel - 1, :])
        normalized_cdrate = cdrate[showlevel - 1, :] / np.max(cdrate[showlevel - 1, :])
        imgcode=plot_dual_axis(t, normalized_cdpressure, normalized_cdrate,
                       ['Normalized Signal Energy, Pressure', 'Normalized Signal Energy, Rate'],
                       ['b', 'r'], f'Distribution of the signal energy at level {showlevel} for both BHP and slurry rate',
                       np.arange(0, 1.1, 0.1), np.arange(0, 1.1, 0.1))
        imgcodes.append(imgcode)

    return imgcodes