import os
from django.conf import settings
from django.http import HttpResponse
from django.shortcuts import render
import json
from PRAnalysis.core.PRanalysisEnhanceInput import calPR
# Create your views here.
def response_as_json(data):
    json_str = json.dumps(data)
    response = HttpResponse(
        json_str,
        content_type="application/json",
    )
    response["Access-Control-Allow-Origin"] = "*"
    return response


def json_response(data, code=200):
    data = {
        "code": code,
        "msg": "success",
        "data": data,
    }
    return response_as_json(data)

def cal(request):
    if request.method == 'POST':
        startTime = request.POST.get("startTime")
        endTime = request.POST.get("endTime")
        sgyl_list = request.POST.get("sgyl_list")
        pl_list = request.POST.get("pl_list")

        imgcodes=calPR(startTime,endTime,sgyl_list,pl_list)
        image_folder = 'static/PRAnalysis/img/'
        images = sorted([os.path.join(image_folder, img) for img in os.listdir(image_folder) if img.endswith(".png")])
        print(images)
        # 图片保存在static/CalPerforationNum/retImgs/ret.svg
        # ret = 4
        return json_response({'images': imgcodes})
