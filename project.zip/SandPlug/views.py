import json

from django.http import HttpResponse
from django.shortcuts import render
from SandPlug.core.core import getSeqDfFromFront, run
# Create your views here.

# 实时预警函数run调用，返回预警结果
def getFlags4Chart(request):
    sgyl_list = list(json.loads(request.POST.get('sgyl')))
    pl_list = list(json.loads(request.POST.get('pl')))
    snd_list = list(json.loads(request.POST.get('snd')))
    live_time_list = list(json.loads(request.POST.get('live_time')))  # 升序
    # print(yy_list)
    # print(pl_list)
    # print(snd_list)
    # print(live_date_list)

    flag_list = run(
        getSeqDfFromFront(live_date_list=live_time_list, yy_list=sgyl_list, pl_list=pl_list, snd_list=snd_list)
    )  # 返回list
    ret_list = []

    for i in range(len(live_time_list)):
        # t = datetime.datetime.strftime(live_date_list[i], "%Y-%m-%d %H:%M:%S")
        t = live_time_list[i]
        f = flag_list[i]
        ret_list.append([t, f])
    datastr = json.dumps(ret_list).replace("None", "null")

    return response_as_json(datastr)

def response_as_json(data):
    # json_str = json.dumps(data)
    response = HttpResponse(
        data,
        content_type="application/json",
    )
    response["Access-Control-Allow-Origin"] = "*"
    return response