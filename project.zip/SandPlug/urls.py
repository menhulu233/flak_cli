from django.urls import path
from . import views
urlpatterns = [
    path('getFlags4Chart', views.getFlags4Chart),
]