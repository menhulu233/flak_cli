# !/usr/bin/python3
# -*-encoding=utf-8-*-
# @author   : WangTianyu
# @File     : core.py.py
import time

import numpy as np
from scipy.optimize import leastsq

from SandPlug.core.utils.myLeastsq import *
# 返回砂浓度不为0时，对应油压的最左和最右索引值
# 油压 x[start]=0  x[end]!=0
import pandas as pd
from sklearn import cluster
from sympy import Symbol, solve


def getIndex(x):
    s = 0
    for i in range(0, len(x)):
        if x[i] == 0:
            s += 1
        else:
            break

    e = len(x) - 1
    for i in range(len(x) - 1, 0, -1):
        if x[i] == 0:
            e -= 1
        else:
            break
    # print(s, e)
    return s, e


def getData(Slice=-1,
            SliceFrom=1560,
            p=r'..\..\data\SandPlugEvalApp\excels\section.csv'):
    with open(p, encoding='gbk') as f:
        data = np.loadtxt(f, delimiter=",", skiprows=2, usecols={1, 4})
        start, end = getIndex(data[:, 1])  # 砂浓度（尚未用到排量数据）
        X = data[start:end, :]

        # 以下一行代码，
        # 若注释掉即取全部约5000个数据，
        # 不注释则表示取油压数据 倒数第320 ~ 倒数第200 之间的120个数据
        if Slice != -1:
            X = X[SliceFrom:SliceFrom + Slice, :]  # 有1 的砂堵片段 SliceFrom=1560

        X = np.c_[X, np.arange(1, len(X[:, 1]) + 1).reshape(-1, 1)]  # 第[2]列T

        column_names = ['P', 'D', 'T', 'flag']
        X = np.c_[X, np.zeros(len(X[:, 1])).reshape(-1, 1)]  # 第[3]列风险等级，默认为0
        df = pd.DataFrame(X, columns=column_names, index=None)
        save_path = r'df_4.csv'
        # df.to_csv(save_path)
        # P D T flag
        return df


def getSeqDF(df, start, length=300):
    df = pd.DataFrame(df.values[start - length:start, :], columns=df.columns)
    plt.figure()
    plt.plot(df.values[:, 0])  # p
    plt.show()
    return df


index_P = 0
index_D = 1
index_T = 2
index_flag = 3
indexAP = [index_P, index_T]
indexClass = ['P', 'T']

Seq_flag = []


def run(df):
    X = df.values
    t0 = time.time()
    affinity_propagation = cluster.AffinityPropagation(
        damping=.8, preference=-200, random_state=0).fit(X[:, indexAP])
    t = time.time() - t0
    print("time cost: %f s" % t)
    cluster_centers_indices = affinity_propagation.cluster_centers_indices_  # 预测出的中心点的索引，如[123,23,34]
    labels = affinity_propagation.labels_  # 预测出的每个数据的类别标签,labels是一个NumPy数组
    n_clusters_ = len(cluster_centers_indices)
    flag_list = []
    for k in range(n_clusters_):
        class_members = labels == k

        # 采用（左闭右开）的方式处理数据分段
        for i in range(1, len(class_members) - 1):
            if class_members[i] == True and class_members[i - 1] == False:
                class_members[i - 1] = True

        # slice_seq = X[class_members]
        slice_seq_x = X[class_members, indexAP[1]]
        slice_seq_y = X[class_members, indexAP[0]]

        global Seq_flag, Seq_Offset
        Seq_flag = [0 for _ in range(len(slice_seq_x))]  # 初始化为0
        Seq_Offset = 0
        getFlags(slice_seq_x, slice_seq_y)
        # if len(Seq_flag) != len(slice_seq_x):
        #     print("no", k)
        #     print(slice_seq_x)
        #     print(Seq_flag)
        # else:
        #     print("yes", k)
        flag_list.append(Seq_flag)
    flag_list_ret = [b for a in flag_list for b in a[1:]]  # 删去每一段左闭右开的“闭”点
    flag_list_ret.insert(0, flag_list[0][0])  # 第一段是多删的加回来
    # print(flag_list_ret)
    # print(len(flag_list_ret))
    return flag_list_ret


def checKin(rmse, k):
    level = 0
    if k >= KI_Threshold:
        level = 1
    elif k >= KII_Threshold:
        level = 2
    elif rmse >= RMSE_Threshold:
        if k > 0:
            level = 3
        else:
            level = 4
    else:
        level = 4
    return level


RMSE_total = 0
RMSE_cnt = 0
RMSE_avg = 0.2
# Rmse_Array = []

RMSE_Threshold = 3 * RMSE_avg
KII_Threshold = 0.3
KI_Threshold = 0.8
Seq_Offset = 0


def getFlags(seq_x, seq_y):
    global RMSE_avg, RMSE_Threshold, RMSE_total, RMSE_cnt
    global Seq_flag, Seq_Offset
    # X_flag = [0 for _ in range(len(seq_x))]
    p1 = [0, 1000]  # 最小二乘法一次线性

    para1 = leastsq(error1, np.array(p1), args=(seq_x, seq_y))  # para1[0][0]是斜率k，para1[0][1]是b偏置值
    y_fitted = Fun1(para1[0], seq_x)
    cur_RMSE = getRMSE(seq_y, y_fitted)
    level = checKin(cur_RMSE, para1[0][0])  # 返回分段等级
    if Seq_Offset < len(Seq_flag):  # 越界处理
        if Seq_Offset + math.floor(seq_x.max()) - math.ceil(seq_x.min()) + 1 <= len(Seq_flag):
            # print((Seq_Offset, Seq_Offset + math.floor(seq_x.max()) - math.ceil(seq_x.min())+1))  # 更新/修改flag的区间
            for i in range(Seq_Offset, Seq_Offset + math.floor(seq_x.max()) - math.ceil(seq_x.min()) + 1):
                Seq_flag[i] = level
    else:
        return

    if cur_RMSE <= RMSE_Threshold:
        # Seq_flag = [?????????]  # 返回当前分段对应的flag，todo:注意start和end位置情况
        RMSE_total += cur_RMSE
        RMSE_cnt += 1
        RMSE_avg = (RMSE_total + RMSE_total) / RMSE_cnt * 0.5 + RMSE_avg * 0.5
        RMSE_Threshold = 3 * RMSE_avg
        Seq_Offset += math.floor(seq_x.max()) - math.ceil(seq_x.min()) + 1
    else:
        RMSE_total += cur_RMSE
        RMSE_cnt += 1
        RMSE_avg = (RMSE_total + RMSE_total) / RMSE_cnt * 0.5 + RMSE_avg * 0.5
        RMSE_Threshold = 3 * RMSE_avg
        p2 = [0, 0.01, 1000]  # 拟合的初始参数设置
        para2 = leastsq(error2, np.array(p2), args=(seq_x, seq_y))  # 进行拟合 (para2[0][0], para2[0][1], para2[0][2]))
        # y_fitted = Fun2(para2[0], seq_x)  # 画出拟合后的曲线
        # plt.plot(lsqX, y_fitted, c='g', label='2次拟合')

        # 分左右段线性拟合
        x = Symbol('x')
        ret = solve([para2[0][0] * 2 * x + para2[0][1]], x)  # 导函数等于0的点
        ret[x] = np.float32(ret[x])
        # retx = numpy.array([sympy.N(i) for i in ret])
        rety = para2[0][0] * ret[x] ** 2 + para2[0][1] * ret[x] + para2[0][2]

        seq_x_l = list(seq_x[seq_x < ret[x]])
        seq_y_l = list(seq_y[seq_x < ret[x]])

        seq_x_r = list(seq_x[seq_x > ret[x]])
        seq_y_r = list(seq_y[seq_x > ret[x]])

        if math.ceil(seq_x.min()) < ret[x] < math.floor(seq_x.max()):  # 限制一个时间间隔1s里，只能插入一个点
            seq_x_l.append(ret[x])
            seq_y_l.append(rety)
            seq_x_r = [ret[x], ] + seq_x_r
            seq_y_r = [rety, ] + seq_y_r
        else:
            Seq_Offset += math.floor(seq_x.max()) - math.ceil(seq_x.min()) + 1
            return

        seq_x_l = np.array(seq_x_l)
        seq_y_l = np.array(seq_y_l)
        seq_x_r = np.array(seq_x_r)
        seq_y_r = np.array(seq_y_r)
        # # 分段信息
        # print(seq_x)
        # print(seq_y)
        # print(seq_x_l)
        # print(seq_y_l)
        # print(seq_x_r)
        # print(seq_y_r)

        getFlags(seq_x_l, seq_y_l)
        # print("左结束")
        # print(Seq_Offset)
        getFlags(seq_x_r, seq_y_r)


def getSeqDfFromFront(live_date_list, yy_list, pl_list, snd_list):
    # P D T flag
    df = pd.DataFrame(list(yy_list), columns=['P'])
    df = pd.concat([df, pd.DataFrame(list(snd_list), columns=['D'])], axis=1)
    df = pd.concat([df, pd.DataFrame(np.array(range(len(live_date_list))).reshape(-1, 1), columns=['T'])], axis=1)
    df = pd.concat([df, pd.DataFrame(np.zeros(len(live_date_list)).reshape(-1, 1), columns=['flag'])], axis=1)
    return df


if __name__ == '__main__':
    import matplotlib.pyplot as plt
    plt.figure()
    plt.plot(run(getSeqDF(getData(), 1659)))
    plt.show()
