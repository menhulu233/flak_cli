import base64
import io
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
import json
from Proppant.core.draw import draw
from threading import RLock
import math
import scipy
from scipy import linalg
import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # 使用 Agg 后端以避免 GUI
####内置参数
from scipy.optimize import minimize
import plotly.graph_objects as go
import plotly.io as pio
# Create your views here.
def response_as_json(data):
    json_str = json.dumps(data)
    response = HttpResponse(
        json_str,
        content_type="application/json",
    )
    response["Access-Control-Allow-Origin"] = "*"
    return response
def json_response(data, code=200):
    data = {
        "code": code,
        "msg": "success",
        "data": data,
    }
    return response_as_json(data)
# g = 9.8
# saturation_concern = 0.63
# dx = 0.5
# t_total = 60
# dt = 0.5
# width = 0.002
# height = 40
# pressure_bound = 1000000
# proppant_density = 2650
# fluid_density = 1000
# proppant_diameter = 0.0006
# viscosity_0 = 0.001
# K_fitting = 0.8
# beta = -2
# vertical_height = 3973.17
# number_perforation = 8
# perforation_diamater = 0.875 * 0.0254
# casing_diameter = 3 * 0.0254
g = 9.8
saturation_concern = 0.63
dx = 0.5
t_total = 60
dt = 0.5
width = 0.002
height = 40
K_fitting = 0.8
beta = -2

# number_perforation = 8
# vertical_height = 3973.17

proppant_density = 2650 # 支撑剂密度
fluid_density = 1000 # 压裂液密度
proppant_diameter = 0.0006 #支撑剂颗粒平均直径
viscosity_0 = 0.001 # 压裂液粘度
perforation_diamater = 0.375 * 0.0254 # 射孔直径
casing_diameter = 3 * 0.0254 # 套管直径
####
def KGD_model(local, Yang, Song, time, pump_rate, measured_depth, east, north, depth, theta, Height, viscosity):
  # 计算裂缝长度与宽度
  t = time
  E = Yang * 1e9 / (1 - Song ** 2)
  KGD_height = Height
  KGD_length = 0.539 * (((E * pump_rate ** 3) / (viscosity * KGD_height ** 3)) ** (1 / 6)) * (t ** (2 / 3))
  para_list = KGD_length
  return para_list

def PKN_model(local, Yang, Song, time, pump_rate, measured_depth, east, north, depth, theta, Height, viscosity):
  # 计算裂缝长度与宽度
  t = time
  E = Yang * 1e9 / (1 - Song ** 2)
  PKN_height = Height
  PKN_length = 0.39054 * (((E * pump_rate ** 3) / (viscosity * PKN_height ** 4)) ** (1 / 5)) * (t ** (4 / 5))
  para_list = PKN_length
  return para_list

def get_parameters(ModelType, stage_perf_bottom_list, Yang, Song, Height, viscosity, Time, pump_rate, east, north,
                   depth, theta, filtration,shodow_filtration):
  # 读取泵注程序
  time = Time
  E = Yang * 1e9 / (1 - Song ** 2)
  # 计算绘图所需要的点
  ellipses = []
  frac_Pnet=[]
  frac_single=[]
  # 计算泵注速率的平均值
  if pump_rate <= 0:
      for i, local in enumerate(stage_perf_bottom_list):
          para_list = 0
          ellipses.append(para_list)
          frac_Pnet.append(0)
          frac_single.append(0)
      return ellipses,frac_Pnet,frac_single

  average_pump_rate = pump_rate / (60 * len(stage_perf_bottom_list) * 2 * filtration)
  length = 0.3905 * (((E * average_pump_rate ** 3) / (viscosity * Height ** 4)) ** (1 / 5)) * (time ** (4 / 5))
  average_p = 1.08819 * (
          math.pow(
              (math.pow(E, 4) * math.pow(average_pump_rate, 2) * viscosity) / math.pow(Height, 6),
              1 / 5
          ) * math.pow(time, 1 / 5)
  )
  frac_space = np.zeros((len(stage_perf_bottom_list), len(stage_perf_bottom_list)))
  shadow = np.zeros((len(stage_perf_bottom_list), len(stage_perf_bottom_list)))
  space = abs(stage_perf_bottom_list[-1] - stage_perf_bottom_list[0]) / (len(stage_perf_bottom_list) - 1)
  for k in range(len(stage_perf_bottom_list)):
      for h in range(len(stage_perf_bottom_list)):
          frac_space[k][h] = abs(h - k) * space
  for k in range(len(stage_perf_bottom_list)):
      for h in range(len(stage_perf_bottom_list)):
          if k != h:
              shadow[k][h] = average_p * (
                      1 - frac_space[k][h] / np.sqrt(frac_space[k][h] ** 2 + (length / 2) ** 2) + (
                      frac_space[k][h] / (length / 2)) / np.power(
                  (frac_space[k][h] / (length / 2)) * (
                          np.sqrt(frac_space[k][h] ** 2 + (length / 2) ** 2) / (length / 2)), 3 / 2))
  frac_shadow = [sum(raw) for raw in shadow]
  frac_Pnet = [max((average_p - 0.1 * shodow_filtration * a) * 10 ** -6, 1e-9) for a in frac_shadow]
  n_components = len(frac_shadow)
  bounds = [(0, None)] * n_components
  initial_guesses = [1] * n_components

  def objective(variables):
      variables = np.array(variables)
      total_sum = np.sum(variables) - average_pump_rate * len(stage_perf_bottom_list)

      # 计算目标比率并与 frac_Pnet 比较
      target_ratios = np.array([x ** (2 / 5) for x in variables])
      ratio_constraints = (target_ratios / np.array(frac_Pnet)) - (target_ratios[0] / frac_Pnet[0])
      # 目标函数为总和约束和比率约束的平方和
      return total_sum ** 2 + np.sum(ratio_constraints ** 2)

  # 使用 trust-constr 求解，设置选项以提高精度
  options = {'xtol': 1e-7, 'gtol': 1e-10, 'maxiter': 500, 'disp': False}
  result = minimize(objective, initial_guesses, bounds=bounds, method='trust-constr', options=options)
  frac_single = result.x
  print("q4",frac_single)
  for i, local in enumerate(stage_perf_bottom_list):
    if ModelType == "PKN":
      len1 = PKN_model(local, Yang, Song, time, frac_single[i], measured_depth, east, north, depth,
                            theta,
                            Height,
                            viscosity)
    else:
      len1 = KGD_model(local, Yang, Song, time, frac_single[i], measured_depth, east, north, depth,
                            theta,
                            Height,
                            viscosity)
    ellipses.append(len1)
  return ellipses,frac_Pnet,frac_single

def interpolation(data):
  # Parameters

  length = data.shape[0]
  array = []
  for i in range(length - 1):
    a = data[i]
    b = data[i + 1]
    c = 0.5 * a + 0.5 * b
    array.extend([a, c])
  array.append(data[length - 1])
  number = 2 * (length - 1) + 1
  array = np.array(array)
  return array

# def draw(concern, hbed,j):
#   ### 输入的是array格式即可
#   ### 内置参数
#   height = 40
#   Y_factor = 2000
#   max_concern = 0.63
#   dx = 0.275
#   Y_one = height / Y_factor
#   ###
#   num=j
#   concern = interpolation(concern)
#   hbed = interpolation(hbed)
#
#   concern = interpolation(concern)
#   hbed = interpolation(hbed)
#
#   length = hbed.shape[0]
#
#   # Initialize arrays
#   concen_2d = np.zeros((length, Y_factor))
#   X1 = np.zeros((length + 1, Y_factor + 1))
#   Y1 = np.zeros((length + 1, Y_factor + 1))
#   ppp = np.zeros((length + 1, Y_factor + 1))
#
#   # Loop for branch_hbed
#   for i in range(length):
#     y_number = round(hbed[i] / Y_one)
#     for j in range(y_number):
#       concen_2d[i, j] = max_concern
#     for j in range(y_number, Y_factor):
#       concen_2d[i, j] = concern[i]
#
#   # Populate X1, Y1, and ppp arrays
#   for i in range(length):
#     for j in range(Y_factor):
#       X1[i, j] = i * dx
#       Y1[i, j] = j * Y_one
#       ppp[i, j] = concen_2d[i, j]
#
#   i = length
#   for j in range(Y_factor):
#     X1[i, j] = i * dx
#     Y1[i, j] = j * Y_one
#     ppp[i, j] = concen_2d[i-1, j]
#
#   j = Y_factor
#   for i in range(length):
#     X1[i, j] = i * dx
#     Y1[i, j] = j * Y_one
#     ppp[i, j] = concen_2d[i, j-1]
#
#   i = length
#   j = Y_factor
#   X1[i, j] = i * dx
#   Y1[i, j] = j * Y_one
#   ppp[i, j] = concen_2d[i - 1, j - 1]
#   # 打印形状
#   print("Shape of X1:", X1.shape)
#   print("Shape of Y1:", Y1.shape)
#   # 打印 x 和 y 的内容
#   print("X1 contents:")
#   print(X1)
#
#   print("\nY1 contents:")
#   print(Y1)
#   fig, axs = plt.subplots()
#   axs.clear()
#   # 第一个子图
#   im1 = axs.pcolormesh(X1, Y1, ppp, cmap='jet', vmin=0, vmax=0.7, antialiased=True,linewidth=1)
#   #axs.set_xlim([0, len_hbed * dx])
#   axs.set_xlim([0, 100])
#   axs.set_ylim([0, height])
#   axs.spines['top'].set_visible(False)
#   axs.spines['right'].set_visible(False)
#   axs.set_xlabel('x(m)')
#   axs.set_ylabel('z(m)')
#   axs.set_aspect('equal')
#   cbar = fig.colorbar(im1, ax=axs, orientation='vertical')
#   ###########c的位置在侧向，不好看，放到color bar正上方比较合适
#   cbar.set_label('c',position = "top")
#   # 保存图像到内存
#   buf = io.BytesIO()
#   plt.savefig(buf, format='png')
#   # 生成带有时间戳的文件名
#   # timestamp = time.strftime('%Y%m%d_%H%M%S')
#   file_path = f'static/Proppant/img/plot_{num}.png'
#   # 保存图像到本地文件
#   plt.savefig(file_path)
#
#   buf.seek(0)
#   encoded_string = base64.b64encode(buf.read()).decode('utf-8')
#   buf.close()
#   plt.close(fig)
#   # plt.show()
#   # 生成响应
#   return encoded_string

def draw(concern, hbed, number):
    ### 输入的是array格式即可
    ### 内置参数
    height = 40
    Y_factor = 2000
    max_concern = 0.63
    dx = 0.275
    Y_one = height / Y_factor
    ###
    num = number
    concern = interpolation(concern)
    hbed = interpolation(hbed)

    length = hbed.shape[0]

    # Initialize arrays
    concen_2d = np.zeros((length, Y_factor))
    X1 = np.zeros((length + 1, Y_factor + 1))
    Y1 = np.zeros((length + 1, Y_factor + 1))
    ppp = np.zeros((length + 1, Y_factor + 1))

    # Loop for branch_hbed
    for i in range(length):
        y_number = round(hbed[i] / Y_one)
        for j in range(y_number):
            concen_2d[i, j] = max_concern
        for j in range(y_number, Y_factor):
            concen_2d[i, j] = concern[i]

    # Populate X1, Y1, and ppp arrays
    for i in range(length):
        for j in range(Y_factor):
            X1[i, j] = i * dx
            Y1[i, j] = j * Y_one
            ppp[i, j] = concen_2d[i, j]

    i = length
    for j in range(Y_factor):
        X1[i, j] = i * dx
        Y1[i, j] = j * Y_one
        ppp[i, j] = concen_2d[i - 1, j]

    j = Y_factor
    for i in range(length):
        X1[i, j] = i * dx
        Y1[i, j] = j * Y_one
        ppp[i, j] = concen_2d[i, j - 1]

    i = length
    j = Y_factor
    X1[i, j] = i * dx
    Y1[i, j] = j * Y_one
    ppp[i, j] = concen_2d[i - 1, j - 1]
    # # 打印形状
    # print("Shape of X1:", X1.shape)
    # print("Shape of Y1:", Y1.shape)
    # print("shape of ppp:",ppp.shape)
    # # 打印 x 和 y 的内容
    # print("X1 contents:")
    # print(X1)
    #
    # print("\nY1 contents:")
    # print(Y1)
    # print("ppp:")
    # print(ppp)
    # 使用Plotly创建图形
    print("x1",X1[:,0])
    print("y1",Y1[0,:])
    print("x1_shape",X1[:,0].shape)
    print("y1_shape",Y1[0,:].shape)
    print("shape of ppp:", ppp.shape)
    x1=X1[:,0]
    y1=Y1[0,:]
    # 创建等高线图
    fig = go.Figure(data=go.Heatmap(
        z=ppp.T,  # 热图的值
        x=x1,  # 只取 x 坐标的一部分，x 是一维的
        y=y1,  # y 是一维的
        dx=0.275,  # x1 的步长
        dy=0.02,   # y1 的步长
        colorscale='Jet',
        zmin=0,
        zmax=0.7,
        colorbar=dict(
            title='c',
            ticklabelposition='outside'  # 仅保留这个属性
        ),
    ))
    # 更新布局
    fig.update_layout(
        xaxis_title='x(m)',
        yaxis_title='z(m)',
        # xaxis_range=[0, 1000],
        # yaxis_range=[0, height],
        xaxis=dict(range=[0, 100]),
        yaxis=dict(range=[0, height]),
        height=500,
        width=800,
        # title='Heatmap of Concentration'
    )

    # 保存图像到内存并进行编码
    buf = io.BytesIO()
    fig.write_image(buf, format='png')
    file_path = f'static/Proppant/img/plot_{num}.png'
    with open(file_path, 'wb') as f:
        f.write(buf.getvalue())

    buf.seek(0)
    encoded_string = base64.b64encode(buf.read()).decode('utf-8')
    buf.close()

    return encoded_string

def pad_array(array_old, array_new):
    # 该函数的意义在于，如果先前传输的裂缝长度比当前时刻裂缝长度小，则需要对上一个时刻的变量进行补零操作
    # 传输的格式是array，输出也必须是array
    len_old = array_old.shape[0]
    len_new = array_new.shape[0]

    # 计算补零长度
    padding_length = len_new - len_old

    # 如果新数组长度大于旧数组长度，进行补零
    if padding_length > 0:
        padding = np.zeros((padding_length,))
        padded_array = np.concatenate((array_old, padding))
    else:
        # 如果新数组长度小于或等于旧数组长度，直接返回旧数组
        padded_array = array_old[:len_new]  # 可以选择截断旧数组

    return padded_array
"""
#####测试文件，在正式使用时需要删除，只需要在每个时间步接受浓度，入口流体流速以及裂缝尺寸长度即可
test_file = pd.read_excel("test.xlsx",header=0,index_col=0)
test_data = np.array(test_file)
#####
"""
def save_to_excel(len_list, pressure_perforation_list, C_Mi, pressure_wellhead, Q_total):
    # 创建数据字典
    data = {
        "len_list": [len_list],
        "pressure_perforation_list": [pressure_perforation_list],
        "C_Mi": [C_Mi],
        "pressure_wellhead": [pressure_wellhead],
        "Q_total": [Q_total],
    }

    # 转换为 DataFrame
    df = pd.DataFrame(data)

    # 定义 Excel 文件路径
    excel_file = 'output.xlsx'

    # 如果文件存在，读取并追加数据
    if os.path.exists(excel_file):
        # 读取现有数据
        existing_data = pd.read_excel(excel_file)
        # 将新数据追加到现有数据
        df = pd.concat([existing_data, df], ignore_index=True)

    # 保存到 Excel
    df.to_excel(excel_file, index=False)

concern_old = np.zeros([0,])
hbed_old = np.zeros([0,])
concern_new=np.zeros([0,])
hbed_new=np.zeros([0,])
#####本部分实现的是单簇裂缝内的支撑剂运移实时过程，各簇独立考虑，暂时尚未考虑第一簇计算流量后总流量损失对第二簇的影响
#####也认为井筒压力处处相等，没有考虑沿程摩阻
def cal(request):
  # 声明全局变量
  global concern_old, hbed_old
  encoded_string = []
  ####外部输入模型参数（需要耦合的部分，需要读取当前t时刻的参数）
  if request.method == 'POST':
      fracStage = int(request.POST.get("fracStage", 1))
      yang = float(request.POST.get("yang", 0.0))
      song = float(request.POST.get("song", 0.0))
      modelType = request.POST.get("modelType", "PKN")
      viscosity1 = float(request.POST.get("viscosity", 1.0))
      height = float(request.POST.get("rock_height", 1.0))
      count = int(request.POST.get('count', 0))
      pl = float(request.POST.get("pl", 0.0))
      # 新增加
      filtration = 4
      theta = 27
      shodow_filtration =0.8 #应力阴影系数，范围(0，1)
      # 文件路径
      completion_file_path = "static/rock/data/completion.xlsx"
      well_trajectory_path = "static/rock/data/well_trajectory.xlsx"
      # 读取射孔数据
      df_completion = pd.read_excel(completion_file_path)
      grouped_data = df_completion.groupby('Stage number')['Perf bottom MD(m)'].apply(list).reset_index(
          name='Perf bottom MD(m) List')

      # 获取指定阶段的射孔深度列表
      try:
          stage_perf_bottom_list = \
          grouped_data[grouped_data['Stage number'] == fracStage]['Perf bottom MD(m) List'].iloc[0]
      except IndexError:
          return JsonResponse({'error': '无效的 fracStage 值。'}, status=400)

      global measured_depth
      # 读取井轨迹数据
      df_well = pd.read_excel(well_trajectory_path)
      measured_depth = np.array(df_well["井深(m)"])
      depth = np.array(df_well["垂深(m)"])
      east = np.array(df_well['E(m)'])
      north = np.array(df_well["N(m)"])

      Time = count
      pump_rate = pl

      len_list,pressure_perforation_list,frac_single = get_parameters(modelType, stage_perf_bottom_list, yang, song, height, viscosity1, Time,
                                pump_rate, east,
                                north, depth, theta, filtration,shodow_filtration)
      print(len_list,pressure_perforation_list,frac_single)
      if(len_list[0]!=0):
          ####读取井口支撑剂的浓度（体积浓度）
          C_Mi = float(request.POST.get("snd", 0.0))
          ####读取裂缝长度（单位m）
          # len = int(ellipses[0][2])
          ####读取井口压力（单位pa）
          pressure_wellhead = float(request.POST.get("sgyl", 0.0))
          ####读取裂缝入口压力（单位pa）
          # pressure_perforation_list = ellipses[1]
          ####读取井口排量（单位立方米每秒）
          Q_total = float(request.POST.get("pl", 0.0))
          Q_perforation1 = frac_single[0]
          Q_perforation2 = frac_single[1]
          Q_perforation3 = frac_single[2]
          Q_perforation4 = frac_single[3]

          for j,pressure_perforation in enumerate(pressure_perforation_list):
              length=int(len_list[j])
              # print("i",i)
              ####计算套管内流速
              v_casing = 4 * Q_total / ((casing_diameter ** 2) * 3.14)
              Stokes_number = proppant_density * (proppant_diameter ** 2) * v_casing / (18 * viscosity_0 * perforation_diamater)
              # pressure_wellbottom = pressure_wellhead + fluid_density * g * vertical_height
              # delta_pressure = pressure_wellbottom - pressure_perforation
              #
              # ####射孔摩阻求流量
              # Q_initial = np.sqrt((delta_pressure * number_perforation ** 2 * perforation_diamater ** 4 * 0.56) / (0.807 * fluid_density))
              ####求解缝口浓度
              if Q_total == 0:
                  PFR = 0  # 或者设置为合适的默认值
              else:
                  if j == 0:
                      PFR = Q_perforation1 / (Q_total * 2)
                  elif j == 1:
                      PFR = Q_perforation2 / ((Q_total - Q_perforation1) * 2)
                  elif j == 2:
                      PFR = Q_perforation3 / (Q_total - Q_perforation1)
                  else:
                      PFR = Q_perforation4 / (Q_total - Q_perforation1 - Q_perforation2)

              if C_Mi == 0:
                  # 如果 C_Mi 为零，可以返回一个特定的结果，比如 None 或其他有意义的值
                  PTE = 0  # 或者其他有意义的结果
              else:
                  PTE = 0.59 * PFR * (Stokes_number ** (-0.05)) * ((0.7 * 0.045 / C_Mi) ** 0.356)

              if PFR==0:
                  concern_0 = 0
              else:
                  concern_0 = PTE * C_Mi / PFR

              ####初始化变量

              A = np.zeros([2 * length, 2 * length])
              b = np.zeros([2 * length, 1])
              A1 = np.zeros([length, length])
              b1 = np.zeros([length, 1])

              miu = np.ones([length,]) * viscosity_0
              vx = np.zeros([length,])
              ######
              concern_new = np.zeros([length,])
              hbed_new = np.zeros([length,])
              ######

              Ini_rouup = concern_0 * proppant_density + (1 - concern_0) * fluid_density
              Ini_hydrD1 = 2 * width * height / (width + height)
              fa = 2/np.power(4.06 * math.log(Ini_hydrD1 / proppant_diameter) + 3.36, 2);
              Inicial_X = 2 * fa

              #####浓度和高度与当前时刻的几何模型相比来补齐，不足的位置补0
              concern_old = pad_array(concern_old, concern_new)
              hbed_old = pad_array(hbed_old, hbed_new)

              for i in range(1, length):
                A[i, i - 1] = 1 * (height - hbed_old[i]) * np.power(width, 3) / (12 * miu[i] * dx)
                A[i, i] = -1 * (height - hbed_old[i]) * np.power(width, 3) / (12 * miu[i] * dx)
                A[i, length + i - 1] = -1

              A[0, 0] = 1
              b[0, 0] = pressure_perforation

              A[length, length] = 1
              print("Shape of b:", b.shape)
              # print("frac_sfrac_single[i]",frac_single[i])
              if(Q_perforation1):
                  b[length, 0] = Q_perforation1
              elif(Q_perforation2):
                  b[length, 0] = Q_perforation2
              elif(Q_perforation3):
                  b[length, 0] = Q_perforation3
              elif(Q_perforation4):
                  b[length, 0] = Q_perforation4

              for i in range(length + 1, 2 * length):
                A[i, i - 1] = -1
                A[i, i] = 1

              pressure_flowrate = linalg.solve(A, b)
              flowrate = pressure_flowrate[length:, :]
              for i in range(length):
                vx[i] = flowrate[i, 0]/((height-hbed_old[i]) * width)

              A1[0, 0] = 1
              b1[0, 0] = concern_0
              for i in range(1, length):
                A1[i, i] = 1 + vx[i] * dt / dx
                A1[i, i - 1] = - vx[i] * dt / dx
                b1[i,0] = concern_old[i]

              concern1 = linalg.solve(A1, b1)
              concern_new = concern1[:, 0]

              # **************************************************************************#
              for i in range(0, length):
                # 计算 粘度 沉降速率 和悬浮液浓度
                miu = viscosity_0 * np.power((1 - concern_new[i] / saturation_concern), beta)
                vs = g * (proppant_density - fluid_density) * proppant_diameter * proppant_diameter * (1 - concern_new[i]) / (18 * miu * np.power(10, 1.82 * concern_new[i]))
                upper_density = concern_new[i] * proppant_density + (1 - concern_new[i]) * fluid_density
                # *********************************************************************#
                # 计算build_up高度 水力直径 雷诺数
                # 当前格子

                hbed_new[i] = hbed_old[i] + concern_new[i] * vs * dt / saturation_concern
                hydr_diameter = 2 * width * abs(height - hbed_new[i]) / (width + abs(height - hbed_new[i]))
                Re = upper_density * (vx[i] * hydr_diameter / miu)
                # *********************************************************************#
                # 计算摩擦系数
                inta=1;
                f_n1=Inicial_X;
                while (inta > 0.001):
                  f_n = f_n1;
                  F_x = 1/np.power(2*f_n,1/2)+0.86*np.log(proppant_diameter/(hydr_diameter*3.7)+2.51/(Re*np.power(2*f_n,1/2)))
                  F_dx = -np.power(2*f_n,-1.5)-(2.1586/Re)*np.power(2*f_n,-3/2)/(proppant_diameter/(hydr_diameter*3.7)+2.51/(Re*np.power(2*f_n,1/2)))
                  f_n1 = f_n-F_x/F_dx
                  inta = abs((f_n1-f_n)/f_n)
                # 计算wash_out高度

                ####
                H_move = K_fitting * dt * 0.5 * f_n1 * upper_density * vx[i] / (proppant_density)
                if H_move > hbed_new[i]:
                  H_move = hbed_new[i]

                tem_bed = concern_new[i] * vs * dt / saturation_concern - H_move
                if tem_bed < 0:
                  tem_bed = 0
                  H_move = concern_new[i] * vs * dt / saturation_concern
                hbed_new[i] = hbed_new[i] - H_move
                #####由于支撑剂高度变化，需要更新每个单元的浓度
                c_reduce = saturation_concern * tem_bed/(height-hbed_new[i])
                c_upper = concern_new[i] * (height - hbed_old[i]) / (height - hbed_new[i]) - c_reduce
                if c_upper<0:
                  c_reduce = 0
                  c_reduce = concern_new[i]
                  tem_bed = concern_new[i] * (height - hbed_new[i])/saturation_concern
                  hbed_new[i] = hbed_new[i] + tem_bed

                concern_new[i] = c_upper
              #######这段代码只是测试时的时间戳
              # t = t + 1
              #####
              print("j",j)
              encoded_string1=draw(concern_new.copy(),hbed_new.copy(),j)
              encoded_string.append(encoded_string1)
          ####
          concern_old = concern_new
          hbed_old = hbed_new

      else:
          return JsonResponse({'error': '裂缝长度为0'})

  return JsonResponse({
      'new_plot2': encoded_string[0],
      'new_plot3': encoded_string[1],
      'new_plot4': encoded_string[2],
      'new_plot5': encoded_string[3]
  })

