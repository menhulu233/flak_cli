import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
def draw():
    def interpolation(data, num):
        # Parameters
        len_data = len(data)
        if len_data == num:
            array = []
            for i in range(len_data - 1):
                a = data[i]
                b = data[i + 1]
                c = 0.5 * a + 0.5 * b
                array.extend([a, c])
            array.append(data[len_data - 1])
            number = 2 * (num - 1) + 1
        elif len_data > num:
            data1 = data[:num]
            data2 = data[num:len_data]
            array = []
            for i in range(num - 1):
                a = data1[i]
                b = data1[i + 1]
                c = 0.5 * a + 0.5 * b
                array.extend([a, c])
            array.append(data1[num - 1])
            for i in range(num - 1):
                a = data2[i]
                b = data2[i + 1]
                c = 0.5 * a + 0.5 * b
                array.extend([a, c])
            array.append(data2[num - 1])
            number = 2 * (num - 1) + 1
        array = np.array(array)
        return array, number

    height = 40
    length_main = 100
    num = 50
    Y_factor = 2000
    max_concen = 0.63
    dx = 0.275
    Y_one = height / Y_factor

    branch_concern = pd.read_excel("static/Proppant/data/viscosity_2_1500_branch_concentration.xlsx", header=None).to_numpy()
    branch_hbed = pd.read_excel("static/Proppant/data/viscosity_2_1500_branch_hbed.xlsx", header=None).to_numpy()
    main_concern = pd.read_excel("static/Proppant/data/viscosity_2_1500_main_concentration.xlsx", header=None).to_numpy()
    main_hbed = pd.read_excel("static/Proppant/data/viscosity_2_1500_main_hbed.xlsx", header=None).to_numpy()

    branch_concern = branch_concern.flatten()
    branch_hbed = branch_hbed.flatten()
    main_concern = main_concern.flatten()
    main_hbed = main_hbed.flatten()

    [branch_concern, len_branch_concern] = interpolation(branch_concern, num)
    [branch_hbed, len_branch_hbed] = interpolation(branch_hbed, num)
    [main_concern, len_main_concern] = interpolation(main_concern, num)
    [main_hbed, len_main_hbed] = interpolation(main_hbed, num)

    [branch_concern, len_branch_concern] = interpolation(branch_concern, len_branch_concern)
    [branch_hbed, len_branch_hbed] = interpolation(branch_hbed, len_branch_hbed)
    [main_concern, len_main_concern] = interpolation(main_concern, len_main_concern)
    [main_hbed, len_main_hbed] = interpolation(main_hbed, len_main_hbed)

    branch_concern = branch_concern.T
    branch_hbed = branch_hbed.T
    main_concern = main_concern.T
    main_hbed = main_hbed.T

    print("branch_hbed shape:", branch_hbed.shape)
    print("main_hbed shape:", main_hbed.shape)


    # Assuming you have the values for len_branch_hbed, branch_hbed, Y_one, max_concen, Y_factor, branch_concern, dx
    # and similarly for len_main_hbed, main_hbed, main_concern

    # Initialize arrays
    concen_2d_branch = np.zeros((len_branch_hbed, Y_factor))
    X1 = np.zeros((len_branch_hbed + 1, Y_factor + 1))
    Y1 = np.zeros((len_branch_hbed + 1, Y_factor + 1))
    ppp = np.zeros((len_branch_hbed + 1, Y_factor + 1))

    # Loop for branch_hbed
    for i in range(len_branch_hbed):
        y_number = round(branch_hbed[i] / Y_one)
        for j in range(y_number):
            concen_2d_branch[i, j] = max_concen
        for j in range(y_number, Y_factor):
            concen_2d_branch[i, j] = branch_concern[i]

    # Populate X1, Y1, and ppp arrays
    for i in range(len_branch_hbed):
        for j in range(Y_factor):
            X1[i, j] = i * dx
            Y1[i, j] = j * Y_one
            ppp[i, j] = concen_2d_branch[i, j]

    i = len_branch_hbed
    for j in range(Y_factor):
        X1[i, j] = i * dx
        Y1[i, j] = j * Y_one
        ppp[i, j] = concen_2d_branch[i-1, j]

    j = Y_factor
    for i in range(len_branch_hbed):
        X1[i, j] = i * dx
        Y1[i, j] = j * Y_one
        ppp[i, j] = concen_2d_branch[i, j-1]

    i = len_branch_hbed
    j = Y_factor
    X1[i, j] = i * dx
    Y1[i, j] = j * Y_one
    ppp[i, j] = concen_2d_branch[i - 1, j - 1]

    # Repeat the same process for main_hbed
    concen_2d_main = np.zeros((2 * len_main_hbed, Y_factor))
    X2 = np.zeros((2 * len_main_hbed + 1, Y_factor + 1))
    Y2 = np.zeros((2 * len_main_hbed + 1, Y_factor + 1))
    ppp2 = np.zeros((2 * len_main_hbed + 1, Y_factor + 1))

    for i in range(2 * len_main_hbed):
        y_number2 = round(main_hbed[i] / Y_one)
        for j in range(y_number2):
            concen_2d_main[i, j] = max_concen
        for j in range(y_number2, Y_factor):
            concen_2d_main[i, j] = main_concern[i]

    for i in range(2 * len_main_hbed):
        for j in range(Y_factor):
            X2[i, j] = i * dx
            Y2[i, j] = j * Y_one
            ppp2[i, j] = concen_2d_main[i, j]

    i = 2 * len_main_hbed
    for j in range(Y_factor):
        X2[i, j] = i * dx
        Y2[i, j] = j * Y_one
        ppp2[i, j] = concen_2d_main[i-1, j]

    j = Y_factor
    for i in range(2 * len_main_hbed):
        X2[i, j] = i * dx
        Y2[i, j] = j * Y_one
        ppp2[i, j] = concen_2d_main[i, j-1]

    i = 2 * len_main_hbed
    j = Y_factor
    X2[i, j] = i * dx
    Y2[i, j] = j * Y_one
    ppp2[i, j] = concen_2d_main[i - 1, j - 1]

    print("Min and max of ppp:", np.min(ppp), np.max(ppp))
    print("Min and max of ppp2:", np.min(ppp2), np.max(ppp2))

    import matplotlib.pyplot as plt

    # 创建一个图形对象和平铺布局
    fig, axs = plt.subplots(1, 2, figsize=(20, 16))


    # 第一个子图
    im1 = axs[0].pcolormesh(X1, Y1, ppp, cmap='jet', vmin=0, vmax=0.7, antialiased=True,linewidth=1)
    axs[0].set_xlim([0, len_branch_hbed * dx])
    axs[0].set_ylim([0, height])
    axs[0].set_xlabel('branch x (m)', fontname='Times New Roman', fontsize=20, fontweight='bold')
    axs[0].set_ylabel('z (m)', fontname='Times New Roman', fontsize=20, fontweight='bold')
    axs[0].set_aspect('equal')
    fig.colorbar(im1, ax=axs[0], orientation='vertical')

    # 绘制 main 的图形
    im2 = axs[1].pcolormesh(X2, Y2, ppp2, cmap='jet', vmin=0, vmax=0.7, antialiased=True,linewidth=1)
    axs[1].set_xlim([0, 2 * len_main_hbed * dx])
    axs[1].set_ylim([0, height])
    axs[1].set_xlabel('main x (m)', fontname='Times New Roman', fontsize=20, fontweight='bold')
    axs[1].set_aspect('equal'),
    fig.colorbar(im2, ax=axs[1], orientation='vertical')
    # im2.set_clim(0, 0.7)
    plt.savefig('static/Proppant/img/res.png', dpi=300, bbox_inches='tight')
    plt.show()
