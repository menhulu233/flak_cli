import math
import scipy
from scipy import linalg
import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt

####内置参数
from scipy.optimize import minimize

g = 9.8
saturation_concern = 0.63
dx = 0.5
t_total = 60
dt = 0.5
width = 0.002
height = 40
pressure_bound = 1000000
proppant_density = 2650
fluid_density = 1000
proppant_diameter = 0.0006
viscosity_0 = 0.001
K_fitting = 0.8
beta = -2
vertical_height = 3973.17
number_perforation = 8
perforation_diamater = 0.875 * 0.0254
casing_diameter = 3 * 0.0254
####
def KGD_model(local, Yang, Song, time, pump_rate, measured_depth, east, north, depth, theta, Height, viscosity):
  # 计算裂缝长度与宽度
  t = time
  E = Yang * 1e9 / (1 - Song ** 2)
  KGD_height = Height
  KGD_length = 0.539 * (((E * pump_rate ** 3) / (viscosity * KGD_height ** 3)) ** (1 / 6)) * (t ** (2 / 3))
  KGD_width = 2.360 * (((viscosity * pump_rate ** 3) / (E * KGD_height ** 3)) ** (1 / 6)) * (t ** (1 / 3))
  # 计算裂缝位置与偏角
  target_x = np.interp(local, measured_depth, east)
  target_y = np.interp(local, measured_depth, north)
  target_z = np.interp(local, measured_depth, depth)
  target_theta = theta
  para_list = [time, local, KGD_length, KGD_height, target_x, target_y, target_z, target_theta, KGD_width]
  return para_list


def PKN_model(local, Yang, Song, time, pump_rate, measured_depth, east, north, depth, theta, Height, viscosity):
  # 计算裂缝长度与宽度
  t = time
  E = Yang * 1e9 / (1 - Song ** 2)
  PKN_height = Height
  PKN_length = 0.39054 * (((E * pump_rate ** 3) / (viscosity * PKN_height ** 4)) ** (1 / 5)) * (t ** (4 / 5))
  PKN_width = 2.174 * (((viscosity * pump_rate ** 2) / (E * PKN_height)) ** (1 / 5)) * (t ** (1 / 5))
  # 计算裂缝位置与偏角
  target_x = np.interp(local, measured_depth, east)
  target_y = np.interp(local, measured_depth, north)
  target_z = np.interp(local, measured_depth, depth)
  target_theta = theta
  para_list = [time, local, PKN_length, PKN_height, target_x, target_y, target_z, target_theta, PKN_width]
  return para_list


def get_parameters(ModelType, stage_perf_bottom_list, Yang, Song, Height, viscosity, Time, pump_rate, east, north,
                   depth, theta, filtration):
  # 读取泵注程序
  time = Time
  E = Yang * 1e9 / (1 - Song ** 2)
  # 计算泵注速率的平均值
  average_pump_rate = pump_rate / (60 * len(stage_perf_bottom_list) * 2 * filtration)
  average_p = 1.08819 * (
          math.pow(
            (math.pow(E, 4) * math.pow(average_pump_rate, 2) * viscosity) / math.pow(Height, 6),
            1 / 5
          ) * math.pow(time, 1 / 5)
  )
  frac_space = np.zeros((len(stage_perf_bottom_list), len(stage_perf_bottom_list)))
  shadow = np.zeros((len(stage_perf_bottom_list), len(stage_perf_bottom_list)))
  space = abs(stage_perf_bottom_list[-1] - stage_perf_bottom_list[0]) / (len(stage_perf_bottom_list) - 1)
  for k in range(len(stage_perf_bottom_list)):
    for h in range(len(stage_perf_bottom_list)):
      frac_space[k][h] = abs(h - k) * space
  for k in range(len(stage_perf_bottom_list)):
    for h in range(len(stage_perf_bottom_list)):
      if k != h:
        shadow[k][h] = average_p * (
                1 - frac_space[k][h] / np.sqrt(frac_space[k][h] ** 2 + (Height / 2) ** 2) + (
                frac_space[k][h] / (Height / 2)) / np.power(
          (frac_space[k][h] / (Height / 2)) * (
                  np.sqrt(frac_space[k][h] ** 2 + (Height / 2) ** 2) / (Height / 2)), 3 / 2))
  frac_shadow = [sum(raw) for raw in shadow]
  frac_Pnet = [(average_p - 0.17 * a) * (10 ** (1 - len(str(abs(int(average_p - 0.2 * a)))))) for a in frac_shadow]
  n_components = len(frac_shadow)  # 分量的数量
  # 设定变量的范围
  bounds = [(0, None)] * n_components
  # 初始猜测值
  initial_guesses = [1] * n_components

  def objective(variables):
    variables = np.array(variables)
    total_sum = np.sum(variables) - average_pump_rate * len(stage_perf_bottom_list)
    target_ratios = np.array([x ** (2 / 5) for x in variables])
    # 改进约束定义
    ratio_constraints = (target_ratios / np.array(frac_Pnet)) - (target_ratios[0] / frac_Pnet[0])
    # 返回的总和包含平方和
    return total_sum ** 2 + np.sum(ratio_constraints ** 2)

  # 使用 minimize 方法求解
  result = minimize(objective, initial_guesses, bounds=bounds)
  frac_single = result.x
  # 计算绘图所需要的点
  ellipses = []
  for i, local in enumerate(stage_perf_bottom_list):
    if ModelType == "PKN":
      para_list = PKN_model(local, Yang, Song, time, frac_single[i], measured_depth, east, north, depth,
                            theta,
                            Height,
                            viscosity)
    else:
      para_list = KGD_model(local, Yang, Song, time, frac_single[i], measured_depth, east, north, depth,
                            theta,
                            Height,
                            viscosity)
    ellipses.append(para_list)
  return ellipses


def interpolation(data):
  # Parameters

  length = data.shape[0]
  array = []
  for i in range(length - 1):
    a = data[i]
    b = data[i + 1]
    c = 0.5 * a + 0.5 * b
    array.extend([a, c])
  array.append(data[length - 1])
  number = 2 * (length - 1) + 1
  array = np.array(array)
  return array


def draw(concern, hbed):
  ### 输入的是array格式即可
  ### 内置参数
  height = 10
  Y_factor = 2000
  max_concern = 0.63
  dx = 0.275
  Y_one = height / Y_factor
  ###

  concern = interpolation(concern)
  hbed = interpolation(hbed)

  concern = interpolation(concern)
  hbed = interpolation(hbed)

  length = hbed.shape[0]

  # Initialize arrays
  concen_2d = np.zeros((length, Y_factor))
  X1 = np.zeros((length + 1, Y_factor + 1))
  Y1 = np.zeros((length + 1, Y_factor + 1))
  ppp = np.zeros((length + 1, Y_factor + 1))

  # Loop for branch_hbed
  for i in range(length):
    y_number = round(hbed[i] / Y_one)
    for j in range(y_number):
      concen_2d[i, j] = max_concern
    for j in range(y_number, Y_factor):
      concen_2d[i, j] = concern[i]

  # Populate X1, Y1, and ppp arrays
  for i in range(length):
    for j in range(Y_factor):
      X1[i, j] = i * dx
      Y1[i, j] = j * Y_one
      ppp[i, j] = concen_2d[i, j]

  i = length
  for j in range(Y_factor):
    X1[i, j] = i * dx
    Y1[i, j] = j * Y_one
    ppp[i, j] = concen_2d[i-1, j]

  j = Y_factor
  for i in range(length):
    X1[i, j] = i * dx
    Y1[i, j] = j * Y_one
    ppp[i, j] = concen_2d[i, j-1]

  i = length
  j = Y_factor
  X1[i, j] = i * dx
  Y1[i, j] = j * Y_one
  ppp[i, j] = concen_2d[i - 1, j - 1]
  fig, axs = plt.subplots()
  axs.clear()
  # 第一个子图
  im1 = axs.pcolormesh(X1, Y1, ppp, cmap='jet', vmin=0, vmax=0.7, antialiased=True,linewidth=1)
  #axs.set_xlim([0, len_hbed * dx])
  axs.set_xlim([0, 100])
  axs.set_ylim([0, height])
  axs.spines['top'].set_visible(False)
  axs.spines['right'].set_visible(False)
  axs.set_xlabel('x(m)')
  axs.set_ylabel('z(m)')
  axs.set_aspect('equal')
  cbar = fig.colorbar(im1, ax=axs, orientation='vertical')
  ###########c的位置在侧向，不好看，放到color bar正上方比较合适
  cbar.set_label('c',position = "top")

  plt.show()

def pad_array(array_old, array_new):
  ####该函数的意义在于，如果先前传输的裂缝长度比当前时刻裂缝长度小，则需要对上一个时刻的变量进行补零操作
  ####传输的格式是array，输出也必须是array
  len_old = array_old.shape[0]
  len_new = array_new.shape[0]
  padding_length = len_new - len_old
  padding = np.zeros([padding_length,])

  padded_array = np.concatenate((array_old, padding))
  return padded_array
"""
#####测试文件，在正式使用时需要删除，只需要在每个时间步接受浓度，入口流体流速以及裂缝尺寸长度即可
test_file = pd.read_excel("test.xlsx",header=0,index_col=0)
test_data = np.array(test_file)
#####
"""
concern_old = np.zeros([5,])
hbed_old = np.zeros([5,])
t = 0

#####本部分实现的是单簇裂缝内的支撑剂运移实时过程，各簇独立考虑，暂时尚未考虑第一簇计算流量后总流量损失对第二簇的影响
#####也认为井筒压力处处相等，没有考虑沿程摩阻
def cal():
  ####外部输入模型参数（需要耦合的部分，需要读取当前t时刻的参数）

  ####读取井口支撑剂的浓度（体积浓度）
  C_Mi = test_data[t, 1]
  ####读取裂缝长度（单位m）
  len = int(test_data[t, 2])
  ####读取井口压力（单位pa）
  pressure_wellhead = test_data[t, 3]
  ####读取裂缝入口压力（单位pa）
  pressure_perforation = test_data[t, 4]
  ####读取井口排量（单位立方米每秒）
  Q_total = test_data[t, 5]

  ####计算套管内流速
  v_casing = 4 * Q_total / ((casing_diameter ** 2) * 3.14)
  Stokes_number = proppant_density * (proppant_diameter ** 2) * v_casing / (18 * viscosity_0 * perforation_diamater)
  pressure_wellbottom = pressure_wellhead + fluid_density * g * vertical_height
  delta_pressure = pressure_wellbottom - pressure_perforation
  ####射孔摩阻求流量
  Q_initial = np.sqrt((delta_pressure * number_perforation ** 2 * perforation_diamater ** 4 * 0.56) / (0.807 * fluid_density))
  ####求解缝口浓度
  PFR = Q_initial / Q_total
  PTE = 0.59 * PFR * (Stokes_number ** (-0.05)) * ((0.7 * 0.045 / C_Mi) ** 0.356)
  concern_0 = PTE * C_Mi / PFR

  ####初始化变量

  A = np.zeros([2 * len, 2 * len])
  b = np.zeros([2 * len, 1])
  A1 = np.zeros([len, len])
  b1 = np.zeros([len, 1])

  miu = np.ones([len,]) * viscosity_0
  vx = np.zeros([len,])
  ######
  concern_new = np.zeros([len,])
  hbed_new = np.zeros([len,])
  ######

  Ini_rouup = concern_0 * proppant_density + (1 - concern_0) * fluid_density
  Ini_hydrD1 = 2 * width * height / (width + height)
  fa = 2/np.power(4.06 * math.log(Ini_hydrD1 / proppant_diameter) + 3.36, 2);
  Inicial_X = 2 * fa

  #####浓度和高度与当前时刻的几何模型相比来补齐，不足的位置补0
  concern_old = pad_array(concern_old, concern_new)
  hbed_old = pad_array(hbed_old, hbed_new)

  for i in range(1, len):
    A[i, i - 1] = 1 * (height - hbed_old[i]) * np.power(width, 3) / (12 * miu[i] * dx)
    A[i, i] = -1 * (height - hbed_old[i]) * np.power(width, 3) / (12 * miu[i] * dx)
    A[i, len + i - 1] = -1

  A[0, 0] = 1
  b[0, 0] = pressure_perforation

  A[len, len] = 1
  b[len, 0] = Q_initial

  for i in range(len + 1, 2 * len):
    A[i, i - 1] = -1
    A[i, i] = 1

  pressure_flowrate = linalg.solve(A, b)
  flowrate = pressure_flowrate[len:, :]
  for i in range(len):
    vx[i] = flowrate[i, 0]/((height-hbed_old[i]) * width)


  A1[0, 0] = 1
  b1[0, 0] = concern_0
  for i in range(1, len):
    A1[i, i] = 1 + vx[i] * dt / dx
    A1[i, i - 1] = - vx[i] * dt / dx
    b1[i,0] = concern_old[i]

  concern1 = linalg.solve(A1, b1)
  concern_new = concern1[:, 0]


  # **************************************************************************#
  for i in range(0, len):
    # 计算 粘度 沉降速率 和悬浮液浓度
    miu = viscosity_0 * np.power((1 - concern_new[i] / saturation_concern), beta)
    vs = g * (proppant_density - fluid_density) * proppant_diameter * proppant_diameter * (1 - concern_new[i]) / (18 * miu * np.power(10, 1.82 * concern_new[i]))
    upper_density = concern_new[i] * proppant_density + (1 - concern_new[i]) * fluid_density
    # *********************************************************************#
    # 计算build_up高度 水力直径 雷诺数
    # 当前格子

    hbed_new[i] = hbed_old[i] + concern_new[i] * vs * dt / saturation_concern
    hydr_diameter = 2 * width * abs(height - hbed_new[i]) / (width + abs(height - hbed_new[i]))
    Re = upper_density * (vx[i] * hydr_diameter / miu)
    # *********************************************************************#
    # 计算摩擦系数
    inta=1;
    f_n1=Inicial_X;
    while (inta > 0.001):
      f_n = f_n1;
      F_x = 1/np.power(2*f_n,1/2)+0.86*np.log(proppant_diameter/(hydr_diameter*3.7)+2.51/(Re*np.power(2*f_n,1/2)))
      F_dx = -np.power(2*f_n,-1.5)-(2.1586/Re)*np.power(2*f_n,-3/2)/(proppant_diameter/(hydr_diameter*3.7)+2.51/(Re*np.power(2*f_n,1/2)))
      f_n1 = f_n-F_x/F_dx
      inta = abs((f_n1-f_n)/f_n)
    # 计算wash_out高度

    ####
    H_move = K_fitting * dt * 0.5 * f_n1 * upper_density * vx[i] / (proppant_density)
    if H_move > hbed_new[i]:
      H_move = hbed_new[i]

    tem_bed = concern_new[i] * vs * dt / saturation_concern - H_move
    if tem_bed < 0:
      tem_bed = 0
      H_move = concern_new[i] * vs * dt / saturation_concern
    hbed_new[i] = hbed_new[i] - H_move
    #####由于支撑剂高度变化，需要更新每个单元的浓度
    c_reduce = saturation_concern * tem_bed/(height-hbed_new[i])
    c_upper = concern_new[i] * (height - hbed_old[i]) / (height - hbed_new[i]) - c_reduce
    if c_upper<0:
      c_reduce = 0
      c_reduce = concern_new[i]
      tem_bed = concern_new[i] * (height - hbed_new[i])/saturation_concern
      hbed_new[i] = hbed_new[i] + tem_bed

    concern_new[i] = c_upper
  #######这段代码只是测试时的时间戳
  # t = t + 1
  #####
  if t%100 == 1:
    draw(concern_new,hbed_new)
  ####
  concern_old = concern_new
  hbed_old = hbed_new



