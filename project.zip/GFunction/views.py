from django.http import HttpResponse
from django.shortcuts import render
import json
from GFunction.core.core import calGFunction
# Create your views here.
def response_as_json(data):
    json_str = json.dumps(data)
    response = HttpResponse(
        json_str,
        content_type="application/json",
    )
    response["Access-Control-Allow-Origin"] = "*"
    return response


def json_response(data, code=200):
    data = {
        "code": code,
        "msg": "success",
        "data": data,
    }
    return response_as_json(data)

def cal(request):
    if request.method == 'POST':
        S1 = request.POST.get("S1")
        nn = request.POST.get("nn")
        nl = request.POST.get("nl")
        frac_num = request.POST.get("frac_num")
        frac_spac = request.POST.get("frac_spac")
        Hw = request.POST.get("Hw")
        Hp = request.POST.get("Hp")
        Q = request.POST.get("Q")
        tp = request.POST.get("tp")
        E = request.POST.get("E")
        v = request.POST.get("v")
        ISIP1 = request.POST.get("ISIP1")
        P_i = request.POST.get("P_i")
        t_i = request.POST.get("t_i")
        P_j = request.POST.get("P_j")
        t_j = request.POST.get("t_j")
        mm = request.POST.get("mm")
        frac_type = request.POST.get("frac_type")
        # ret=调用函数
        res = calGFunction(S1,nn,nl,frac_num,frac_spac,Hw,Hp,Q,tp,E,v,ISIP1,P_i,t_i,P_j,t_j,mm,frac_type)
        ret = json.dumps({"缝长": res[0],"泵注过程的总滤失体积":res[1],"停泵过程的总滤失体积/改造体积":res[2],"总泵入体积":res[3],"压裂液效率":res[4],"最大缝宽":res[5],"滤失系数":res[6]})
        # 图片保存在static/CalPerforationNum/retImgs/ret.svg
        # ret = 4
        return json_response(ret)
