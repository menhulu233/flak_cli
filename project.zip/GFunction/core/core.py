import datetime
import matplotlib.pyplot as plt
from matplotlib import cm, rcParams
from mpl_toolkits.mplot3d import Axes3D
from numpy.core.function_base import linspace
import numpy as np
from scipy import linalg
import math

def calGFunction(S1,nn,nl,frac_num,frac_spac,Hw,Hp,Q,tp,E,v,ISIP,P_i,t_i,P_j,t_j,m,frac_type):
    """输入参数"""
    S1 = float(S1)  # 最小水平主应力（MPa, 参考值：10）
    n = float(nn)  # 幂律系数（无因次，参考值：2）
    nl = float(nl)  # 缝长比例系数, nl = 2 * n / (2 + n)
    frac_num = int(frac_num)  # 裂缝条数（参考：2，3，4，5）
    frac_spac = float(frac_spac)  # 相邻簇间距（m，参考值：20）
    Hw = float(Hw)  # 缝高（m，参考值：20）
    Hp = float(Hp)  # 滤失高度（m，参考值：20）
    Q = float(Q)  # 排量（方/s，参考值：0.2）
    tp = float(tp)  # 泵注时间（s，参考值：20）
    E = float(E)  # 杨氏模量（MPa，参考值：30000）
    v = float(v)  # 泊松比（无因次，参考值：0.25）
    ISIP = float(ISIP)  # 瞬时停泵压力（MPa，参考值：15）
    P_i = float(P_i)  # 滤失过程i点压力（MPa，参考值：大于等于最小水平主应力,10.1228）
    t_i = float(t_i)  # 滤失过程i点闭合时间（s，参考值：小于等于裂缝完全闭合时间,11236.1）
    P_j = float(P_j)  # 滤失过程j点压力（MPa，参考值：大于等于最小水平主应力,11.7964）
    t_j = float(t_j)  # 滤失过程j点闭合时间（s，参考值：小于等于裂缝完全闭合时间,3016.13）
    m = float(m)  # 裂缝延伸系数（无因次，参考值：1.5）
    frac_type = str(frac_type)  # 裂缝模型（PKN/KGD）
    # eff = 25.450  # 压裂液效率
    eff_c = 1  # 泵注效率控制系数

    """模型计算"""
    if frac_type == "PKN":
        beta = math.pi / 4.0
    else:
        beta = 1

    # 确定簇间距和诱导应力系数矩阵
    d = np.zeros((frac_num, frac_num))  # 簇间距
    phi = np.zeros((frac_num, frac_num))  # 诱导应力系数矩阵
    for i in range(frac_num):
        for j in range(frac_num):
            if i != j:
                d[i][j] = frac_spac * abs(i - j)
                phi[i][j] = 1 - math.pow(1 + math.pow(Hw / 2 / d[i][j], 2), -1.5)

    for i in range(frac_num):
        tmp = 0
        for j in range(frac_num):
            tmp += phi[i][j]
        # console.print(tmp, style="green")
        if tmp >= 1:
            for k in range(frac_num):
                phi[k][i] = 0.0000001
                phi[i][k] = 0.0000001
                phi[i][i] = 0.999999
    a = np.zeros((frac_num))  # 缝长系数矩阵
    Pnet = np.zeros((frac_num))  # 停泵时刻各缝净压力矩阵
    for i in range(frac_num):
        tmp = 0
        for j in range(frac_num):
            tmp += phi[i][j]
        a[i] = 1 - tmp
        if a[i] < 0:
            a[i] = 0
        Pnet[i] = a[i] * (ISIP - S1)

    E1 = E / (2 * (1.0 - pow(v, 2)))  # 平面弹性模量
    ti = (t_i - tp) * 1.0 / tp  # 无因次时间
    gi = (4.0 / math.pi) * (
            (1.0 + ti) * math.asin(math.pow((1.0 + ti), -0.5))
            + math.pow(ti, 0.5)
            - math.pi / 2
    )
    tj = (t_j - tp) * 1.0 / tp  # 无因次时间
    gj = (4.0 / math.pi) * (
            (1.0 + tj) * math.asin(math.pow((1.0 + tj), -0.5))
            + math.pow(tj, 0.5)
            - math.pi / 2
    )
    b = (16 * beta * math.pow(Hw, 2) / (5 * E1)) * (
            (ISIP - S1)
            - (P_j - P_i)
            / (gj - gi)
            * (np.sqrt(math.pi) * m * math.gamma(m))
            / ((m + 0.5) * math.gamma(m + 0.5)) * eff_c
    )  # 常数分母项
    c = Q * tp  # 常数分子项

    # 联立线性方程组
    # 联立后的缝长系数矩阵
    a_sum = np.zeros((frac_num, frac_num))  # 联立后的缝长系数矩阵
    for i in range(frac_num - 1):
        a_sum[i][i] = 1
        if (a[i] > 0) and (a[i + 1] > 0):
            a_sum[i][i + 1] = 0 - math.pow(a[i] / a[i + 1], nl)

    for i in range(frac_num):
        a_sum[frac_num - 1][i] = a[i]

    b_sum = np.zeros((frac_num))  # 联立后的常数项矩阵
    for i in range(frac_num - 1):
        b_sum[i] = 0
    b_sum[frac_num - 1] = c / b

    Lp = linalg.solve(a_sum, b_sum)
    L = Lp * 2

    Wmax = 1.5 * Hw * Pnet / E1
    C = 0 - 4 * beta * math.pow(Hw, 2) * a / (5 * E1 * Hp * np.sqrt(tp)) * (
            P_j - P_i
    ) / (gj - gi)

    leak_pump = 0  # 泵注过程的总滤失体积
    for i in range(frac_num):
        leak_pump += (
                             -16
                             * beta
                             * math.pow(Hw, 2)
                             * (L[i] / 2)
                             / (5 * E1)
                             * a[i]
                             * (P_j - P_i)
                             / (gj - gi)
                             * np.sqrt(math.pi)
                             * m
                             * math.gamma(m)
                             / ((m + 0.5) * math.gamma(m + 0.5))
                     ) * eff_c
        # (4 * np.sqrt(math.pi) * m * math.gamma(m) * C[i] * Hp * L[i] * np.sqrt(tp))/ ((m + 0.5) * math.gamma(m + 0.5))
    leak_shut = 0  # 停泵过程的总滤失体积
    for i in range(frac_num):
        leak_shut += 16 * beta * math.pow(Hw, 2) * (L[i] / 2) / (5 * E1) * Pnet[i]
    V_frac = 0  # 停泵时刻裂缝总体积
    for i in range(frac_num):
        V_frac += 16 * beta * math.pow(Hw, 2) * (L[i] / 2) / (5 * E1) * Pnet[i]
    eff = (Q * tp - leak_pump) / (Q * tp) * 100

    # 计算滤失面积
    # s = L * 2 * Hw
    # console.print('滤失面积:\n', s, style="green")
    data = [
        ["缝长", str(L)],
        ["泵注过程的总滤失体积", str(leak_pump)],
        ["停泵过程的总滤失体积/改造体积", str(leak_shut)],
        ["总泵入体积", str(Q * tp)],
        ["压裂液效率", str(eff)],
        ["最大缝宽", str(Wmax)],
        ["滤失系数", str(C)],
    ]

    """可视化"""
    fig = plt.figure()
    ax = Axes3D(fig, auto_add_to_figure=False)
    fig.add_axes(ax)
    for i in range(frac_num):
        Y = np.arange(0, int(L[i] / 2) + 1, 1)
        Z = np.arange(-Hw, Hw + 1, 1)
        Y, Z = np.meshgrid(Y, Z)
        w = Wmax[i] * np.sqrt(np.sqrt(1 - Y / int(L[i] / 2)))
        X = w * np.sqrt(1 - Z * Z / (Hw * Hw))
        ax.plot_surface(
            X + i * max(Wmax) * 3, Y, Z, rstride=1, cstride=1, cmap=cm.viridis
        )
        ax.plot_surface(
            X + i * max(Wmax) * 3, -Y, Z, rstride=1, cstride=1, cmap=cm.viridis
        )
        ax.plot_surface(
            -X + i * max(Wmax) * 3, Y, Z, rstride=1, cstride=1, cmap=cm.viridis
        )
        ax.plot_surface(
            -X + i * max(Wmax) * 3, -Y, Z, rstride=1, cstride=1, cmap=cm.viridis
        )
        ax.plot_surface(
            X + i * max(Wmax) * 3, Y, -Z, rstride=1, cstride=1, cmap=cm.viridis
        )
        ax.plot_surface(
            X + i * max(Wmax) * 3, -Y, -Z, rstride=1, cstride=1, cmap=cm.viridis
        )
        ax.plot_surface(
            -X + i * max(Wmax) * 3, Y, -Z, rstride=1, cstride=1, cmap=cm.viridis
        )
        ax.plot_surface(
            -X + i * max(Wmax) * 3, -Y, -Z, rstride=1, cstride=1, cmap=cm.viridis
        )
    ax.set_xlabel("Fracture Width", rotation=-15)
    ax.set_ylabel("Fracture Length", rotation=50)
    ax.set_zlabel("Fracture Height", rotation=90)

    curr_time = datetime.datetime.now()
    time_str = datetime.datetime.strftime(curr_time, "%Y-%m-%d-%H-%M-%S")
    plt.savefig(r"static\GfunctionResult\img\3D.png")

    fig, ax = plt.subplots()
    for i in range(frac_num):
        Y = np.arange(0, int(L[i] / 2) + 1, 0.001)
        w = Wmax[i] * np.sqrt(np.sqrt(np.maximum(1 - Y / int(L[i] / 2), 0)))

        X = np.full((len(Y)), i * frac_spac)

        pos = ax.scatter(X, Y, marker=",", c=w, cmap="RdYlGn_r")
        pos = ax.scatter(X, -Y, marker=",", c=w, cmap="RdYlGn_r")

    fig.colorbar(pos, ax=ax)
    # 设置坐标轴范围
    plt.xticks(linspace(-frac_spac / 2, (frac_num - 1) * frac_spac + frac_spac / 2, 5))
    plt.yticks(linspace(-max(Y) - frac_spac / 2, max(Y) + frac_spac / 2, 7))
    plt.xlabel("x")
    plt.ylabel("y")
    plt.savefig(r"static\GfunctionResult\img\2D.png")

    res=[str(L),str(leak_pump),str(leak_shut),str(Q*tp),str(eff),str(Wmax),str(C)]
    return res