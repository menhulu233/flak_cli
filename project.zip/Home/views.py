import os
from django.shortcuts import render

# Create your views here.
def index1(request):
    # image_folder = 'static/PRAnalysis/img/'
    # images = sorted([os.path.join(image_folder, img) for img in os.listdir(image_folder) if img.endswith(".png")])
    # print(images)
    return render(request,'index1.html')

def index2(request):
    return render(request,'index2.html')