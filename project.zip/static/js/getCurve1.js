var isAnalyzing = false;
var fetchInterval;
function dateDataSort(property, bol) { //property是你需要排序传入的key,bol为true时是升序，false为降序
    return function (a, b) {
        var value1 = a[property];
        var value2 = b[property];
        if (bol) {
            // 升序
            return Date.parse(value1) - Date.parse(value2);
        } else {
            // 降序
            return Date.parse(value2) - Date.parse(value1)
        }
    }
}
function queryWell() {
    // 阻止默认事件，防止页面刷新
    event.preventDefault();
    var selectedUrl = $('#id_origin').val();

    // 发送POST请求
    $.ajax({
        url: '/external-url/',
        type: 'POST',
    // /api_app/data/pub/going_job?user_token=frac_app_client
    //     /api_app/data/pub/getwelldata?user_token=frac_app_client
    //     data: { remote_url: selectedUrl + '/api_app/data/pub/going_job?user_token=frac_app_client' },
        data: { remote_url: selectedUrl + '/api_app/data/pub/getwelldata?user_token=frac_app_client' },
        headers: {
            "X-CSRFToken": getCookie("csrftoken")
        },
        success: function (data) {
            if (data.meta && data.meta.success === 1) {
                $('#id_combobox').empty(); // 清空下拉框选项

                // 添加一个默认选项
                $('#id_combobox').append('<option value="">选择并加载施工井</option>');

                data.data.forEach(function (well) {
                    // 为每口井添加一个选项
                    $('#id_combobox').append('<option value="' + well.job_id + '">' + well.wellname + '</option>');
                });

                // // 刷新下拉框
                // $('#id_combobox').select('refresh');

                // 显示查询结果
                // $('#queryResult').html('11111111111');
                $('#queryResult').html('共查询到<span style="color: #0000FF;">' + data.data.length + '</span>口井');


            }
        }
    });
}
var job_id_list;
var live_time_list  //日期
var data_time_list;  //时间
var sgyl_list; // 施工压力
var hkyl_list; // 环空压力
var pl_list;  // 排量
var jdyl_list;  // 阶段液量
var zyl_list;  // 总液量
var snd_list;  // 砂浓度
var sllj_list; // 砂量累计
var slljlj_list; // 砂量阶段累计
function loadCurveHistory() {
    event.preventDefault()
    if ($('#id_combobox').val() === "") {
        // 使用 Bootstrap 的警告框显示错误信息
        $('#errorAlert').text('查询失败，请确认井号信息');
        $('#errorAlert').show();
        // 使用 Bootstrap 的滚动效果自动隐藏警告框
        setTimeout(function () {
            $('#errorAlert').hide();
        }, 3000);
    } else {
        var selectedUrl = $('#id_origin').val();
        $.ajax({
            url: '/external-url/',
            type: 'POST',
            data: { remote_url: selectedUrl + '/api_app/data/pub/getwellhistory?user_token=frac_app_client&job_id=' + $('#id_combobox').val() },
            dataType: "json",
            success: function (data) {
                var data_list;
                if (data.meta.success === 1) {
                    data_list = data.data;
                    data_list.sort(dateDataSort("live_date", true));
                    job_id_list = [];
                    live_time_list=[]
                    data_time_list = [];  //时间
                    sgyl_list = []; // 施工压力
                    hkyl_list = []; // 环空压力
                    pl_list = [];  // 排量
                    jdyl_list = [];  // 阶段液量
                    zyl_list = [];  // 总液量
                    snd_list = [];  // 砂浓度
                    sllj_list = []; // 砂量累计
                    slljlj_list = []; // 砂量阶段累计
                    data_list.forEach((curve_his) => {
                        job_id_list.push(curve_his['job_id'].toString())
                        live_time_list.push(curve_his['live_time'])
                        data_time_list.push(curve_his['data_time'])
                        sgyl_list.push(parseFloat(curve_his['sgyl']))
                        hkyl_list.push(parseFloat(curve_his['hkyl']))
                        pl_list.push(parseFloat(curve_his['pl']))
                        jdyl_list.push(parseFloat(curve_his['jdyl']))
                        zyl_list.push(parseFloat(curve_his['zyl']))
                        snd_list.push(parseFloat(curve_his['snd']))
                        sllj_list.push(parseFloat(curve_his['slij']))
                        slljlj_list.push(parseFloat(curve_his['slijlj']))
                    })
                    // 使用 Bootstrap 的成功警告框显示成功信息
                    $('#successAlert').text('历史数据更新成功');
                    $('#successAlert').show();

                    // 使用 Bootstrap 的滚动效果自动隐藏成功警告框
                    setTimeout(function () {
                        $('#successAlert').hide();
                    }, 3000);
                    reFreshChart();
                } else {
                    // 使用 Bootstrap 的警告框显示查询失败信息
                    $('#errorAlert').text('查询失败，请确认信息，或更换其他井尝试');
                    $('#errorAlert').show();
                    // 使用 Bootstrap 的滚动效果自动隐藏警告框
                    setTimeout(function () {
                        $('#errorAlert').hide();
                    }, 3000);
                }
            },
        });
    }
}
function reFreshChart(){
    // data_time_list.sort()
    console.log(pl_list)
    option = {
        title: {
            text: '施工数据曲线',
            left: '1%'
        },
        xAxis: {
            data: live_time_list,
            axisLabel: {
                show:true,
                showMaxLabel:true
            },
        },
        series: [
            {
                name: '油压MPa',
                type: 'line',
                yAxisIndex: 0,
                showSymbol: false,
                data: sgyl_list
            },
            {
                name: '排出流量m^3',
                type: 'line',
                showSymbol: false,
                yAxisIndex: 1,
                data: pl_list
            },
            {
                name: '砂浓度',
                type: 'line',
                yAxisIndex: 2,
                showSymbol: false,
                data: snd_list
            },
        ]
    }

     option && myChart.setOption(option);
}
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

const csrftoken = getCookie('csrftoken');
