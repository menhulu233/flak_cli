// 基于准备好的dom，初始化echarts实例
var myChart2 = echarts.init(document.getElementById('chart'), 'white', {renderer: 'canvas'});
const colors = ['#EE6666', '#5470C6', '#91CC75'];


// 指定图表的配置项和数据
var option = {
    color: colors,
    title: {
        text: '施工数据曲线(Demo数据)',
        left: '1%'
    },
    toolbox: {
        feature: {
            dataZoom: {

            },
            // restore: {},
            saveAsImage: {}
        }
    },
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'cross'
        },
        formatter: function (params) {
            var result = params[0].name + '<br>';  // 时间
            result += '编号: ' + (params[0].dataIndex + 1) + '<br>';  // 编号行
            for (var i = 0; i < params.length; i++) {
                var seriesName = params[i].seriesName; // 系列名称
                var value = params[i].value;           // 对应系列的值
                // 添加带颜色的圆点
                var colorDot = '<span style="display:inline-block;margin-right:5px;width:10px;height:10px;border-radius:50%;background-color:' + params[i].color + '"></span>';
                result += colorDot + seriesName + ': ' + value + '<br>';
            }
            return result;
        }
    },
    legend: {
        data: ["油压MPa", "排出流量m^3", "砂浓度"],
        top: 40
    },
    xAxis: {
        type: 'category',
        // type: 'time',
        splitLine: {
            show: true,
            lineStyle: {
                type: 'dashed',
                color: '#55b9b4'
            }
        },
        xAxisTicks: {
            interval: 60
        },
        axisLabel: {
            show:false,
            showMaxLabel:true
        },
        // data: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    },
    yAxis: [
        {
            name: '油压MPa',
            showSymbol: false,
            position: 'left',
            splitLine: {
                show: true,
                lineStyle: {
                    type: 'dashed',
                    color: '#55b9b4'
                }
            },
            max: 100,
            min: 0,
            boundaryGap: ['20%', '30%'],
            axisTick: {
                show: true,
            },
            lineStyle:{
                color: 'green',
                lineWidth: 40
            },
            alignTicks: false,
            axisLine: {
                show: true,
                symbol: ['none', 'arrow'],
                symbolSize: [6, 12],
                lineStyle: {
                    color: colors[0]
                }
            },
            axisLabel: {
                formatter:function (value, index) {
                     return value.toFixed(1);
                }
            },

            // data: [1, 2, 3, 4, 5, 6]
    },
        {
            name: '排出流量m^3',
            showSymbol: false,
            position: 'right',
            offset: 10,
            splitLine: {
              show: false
            },
            axisTick: {
                show: true
            },
            alignTicks: false,
            // boundaryGap: ['30%', '30%'],
            max: 50,
            min: 0,
            axisLine: {
                show: true,
                lineStyle: {
                    color: colors[1]
                }
            },
            axisLabel: {
                formatter:function (value, index) {
                     return value.toFixed(2);
                }

            },
            // data: [2, 3, 4, 5, 6, 7]
        },
        {
            name: '砂浓度',
            showSymbol: false,
            position: 'right',
            splitLine: {
              show: false
            },
            offset: 55,
            min: 0,
            axisTick: {
                show: true
            },
            alignTicks: false,
            boundaryGap: ['50%', '200%'],
            axisLine: {
                show: true,
                symbol: ['none', 'arrow'],
                symbolSize: [6, 12],
                lineStyle: {
                    color: colors[2]
                }
            },
            axisLabel: {
                formatter:function (value, index) {
                     return value.toFixed(2);
                }
            },
            // data: [3, 4, 5, 6, 7, 8]
        }

    ],
    grid: {
        right: '16%',
        left: '5%',
        containLabel: true
    },
    dataZoom: [
        {
            xAxisIndex: [0],
            type: "slider",
            show: true,
            realtime: true,
            start: 0,
            end: 100,
        },
        {
            xAxisIndex: [0],
            type: "inside",
            show: true,
            realtime: true,
            start: 0,
            end: 100,
        },
        {
            type: 'slider',
            yAxisIndex: 0,  // 油压
            show: true,
            realtime: true,
            start: 0,
            end: 80,
            zoomOnMouseWheel: true,
            left: 3,
            width: 20,
            backgroundColor: 'rgba(243,243,243,0.4)',
            // 选中范围的填充颜色
            fillerColor: 'rgba(234,89,89,0.8)',
            // 边框颜色
            borderColor: 'rgba(255,128,128,0.4)',
        },
        {
            type: 'inside',
            yAxisIndex: 0,
            show: true,
            realtime: true,
            start: 20,
            end: 100,
        },
        {
            type: 'slider',
            yAxisIndex: 1,  // 排量
            show: true,
            realtime: true,
            start: 0,
            end: 100,
            zoomOnMouseWheel: false,
            right: 43,
            width: 20,
            backgroundColor: 'rgba(243,243,243,0.4)',
            // 选中范围的填充颜色
            fillerColor: 'rgba(136,206,243,0.64)',
            // 边框颜色
            borderColor: '#39abe8',
        },
        {
            type: 'slider',
            yAxisIndex: 2, // 砂浓度
            show: true,
            realtime: true,
            start: 0,
            end: 60,
            zoomOnMouseWheel: false,
            right: 10,
            width:20,
            backgroundColor: 'rgba(243,243,243,0.4)',
            // 选中范围的填充颜色
            fillerColor: 'rgba(170,248,183,0.58)',
            // 边框颜色
            borderColor: '#39abe8',
        },

    ],
    series: [
        {
            name: '油压MPa',
            type: 'line',
            yAxisIndex: 0,
            showSymbol: false,
            // alignTicks: true,
            data: [30, 30, 0, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            // data: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 10, 12]
        },
        {
            name: '排出流量m^3',
            type: 'line',
            yAxisIndex: 1,
            showSymbol: false,
            // data: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
            data: [10, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        },
        {
            name: '砂浓度',
            type: 'line',
            yAxisIndex: 2,
            showSymbol: false,
            data: [20, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            // data: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 10, 15]
        }
    ]
};

// 使用刚指定的配置项和数据显示图表。
option && myChart2.setOption(option);
