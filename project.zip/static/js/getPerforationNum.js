var jobData=[]
var jobData_length
function queryJob() {
    event.preventDefault()
    var selectedUrl = $('#id_originPerf').val();
    var jobId = $('#id_jobInput').val()
        // 检查输入是否为空
    if (jobId.trim() === '') {
          $('#errorAlert').text('请先输入历史压裂任务的ID');
            $('#errorAlert').show();
            // 使用 Bootstrap 的滚动效果自动隐藏警告框
            setTimeout(function () {
                $('#errorAlert').hide();
            }, 3000);
    } else {
            // 发送POST请求
            $.ajax({
            url: '/external-url/',
            type: 'POST',
            data: { remote_url: selectedUrl + '/api_app/data/pub/getwellhistory?user_token=frac_app_client&job_id=' + jobId },
            headers: {
                "X-CSRFToken": getCookie("csrftoken")
            },
            success: function (data) {
                 $('#id_jobInput').empty();
                if (data && data.meta && data.meta.success === 1) {
                    // 显示查询结果
                    $('#queryResultPerf').html('共查询到<span style="color: #0000FF;">' + data.data.length + '</span>条数据');
                     // 从响应中获取数据
                   jobData =JSON.stringify(data.data);
                   jobData_length=data.data.length
                } else {
                    $('#queryResultPerf').html('<span style="color: red;">' + '查询失败或不存在' + '</span>');
                }
            }
        });
    }


}
function calclick(){
    if(jobData.length!=0){
        // 获取输入字段
        var a2 = document.getElementById('a2').value;
        if (a2 > jobData_length-1) {
            $('#errorAlert').text('分析终点位置必须小于或等于查询结果的数据条数 (' + jobData_length + ')');
            $('#errorAlert').show();
            // 使用 Bootstrap 的滚动效果自动隐藏警告框
            setTimeout(function () {
                $('#errorAlert').hide();
            }, 3000);
            return
        }
        startEvalFun(jobData)
    }else{
            $('#errorAlert').text('请先查询再计算');
            $('#errorAlert').show();
            // 使用 Bootstrap 的滚动效果自动隐藏警告框
            setTimeout(function () {
                $('#errorAlert').hide();
            }, 3000);
    }
}
function startEvalFun(jobData){

    var d = parseFloat(document.getElementById("d").value)
    var D = parseFloat(document.getElementById("D").value)
    var L1 = parseFloat(document.getElementById("L1").value)
    var L2 = parseFloat(document.getElementById("L2").value)
    var Cd = parseFloat(document.getElementById("Cd").value)
    var density = parseFloat(document.getElementById("density").value)
    var ISIP = parseFloat(document.getElementById("ISIP").value)
    var a1 = parseInt(document.getElementById("a1").value)
    var a2 = parseInt(document.getElementById("a2").value)
    var x = parseInt(document.getElementById("x").value)
    sendReq(d,D,L1,L2,Cd,density,ISIP,a1,a2,x,jobData)
}
function sendReq(d,D,L1,L2,Cd,density,ISIP,a1,a2,x,jobData){
    $.ajax({
    type: "post",
    url: "/perforationNum/cal",
    data:{
        d:d,
        D:D,
        L1: L1,
        L2: L2,
        Cd: Cd,
        density:density,
        ISIP:ISIP,
        a1:a1,
        a2:a2,
        x:x,
        jobData:jobData
    },
    dataType: 'json',
        traditional:true,//防止深度序列化
    success: function (result) {
        var json = JSON.parse(result.data)
        // 在计算完成后，显示元素
        var perfNum = document.getElementById('perfNum');
        var perfImg = document.getElementById('retImg');
        perfNum.style.display = 'block'; // 或 'block', 具体取决于你的布局需求
        retImg.style.display = 'block';
        $("#numSpan").html(json.num+'&nbsp;个');
        var timestamp = new Date().getTime();
        $("#retImg").attr('src', '/static/PerforationNum/img/ret.png?'+timestamp)


    }
});
}
