function getProppantImg(){
    event.preventDefault()
    var width1 = parseFloat(document.getElementById("width1").value)
    var width2 = parseFloat(document.getElementById("width2").value)
    var height1 = parseFloat(document.getElementById("height1").value)
    var pressure_bound = parseFloat(document.getElementById("pressure_bound").value)
    var proppant_density = parseFloat(document.getElementById("proppant_density").value)
    var fluid_density = parseFloat(document.getElementById("fluid_density").value)
    var proppant_diameter = parseFloat(document.getElementById("proppant_diameter").value)
    var V_initial = parseFloat(document.getElementById("V_initial").value)
    var viscosity_0 = parseFloat(document.getElementById("viscosity_0").value)
    var concern_0 = parseFloat(document.getElementById("concern_0").value)

    $.ajax({
    type: "post",
    url: "/proppant/cal",
    data:{
        width1:width1,
        width2:width2,
        height1: height1,
        pressure_bound: pressure_bound,
        proppant_density: proppant_density,
        fluid_density:fluid_density,
        proppant_diameter:proppant_diameter,
        V_initial:V_initial,
        viscosity_0:viscosity_0,
        concern_0:concern_0
    },
    dataType: 'json',
        traditional:true,//防止深度序列化
    success: function (result) {
        var json = JSON.parse(result.data)
        // 在计算完成后，显示元素
        var perfNum = document.getElementById('drawProppant');
        drawProppant.style.display = 'block'; // 或 'block', 具体取决于你的布局需求

    }
});
}
function drawProppantImg(){
    event.preventDefault()
    $.ajax({
        type: "post",
        url: "/proppant/draw",
        success: function (result) {
            var json = JSON.parse(result.data)
            // 在计算完成后，显示元素
            var proppantImg = document.getElementById('proppantImg');
            proppantImg.style.display = 'block'; // 或 'block', 具体取决于你的布局需求

        }
    });
}
