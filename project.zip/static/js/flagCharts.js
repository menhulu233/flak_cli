/**
 * done:绘制预警结果的echart
 *
 * */

var flagChart = echarts.init(document.getElementById('flagChart'));

var flagChartOption = {
      title: {
        text: '实时预警结果(Demo数据)',
        left: '1%'
      },
      tooltip: {
        trigger: 'axis',
        formatter:function(params)
        {
　　　　    var res = params[0].name;
　　　　    for (var i = 0; i < params.length; i++) {
　　　　　　      res += "<br>"+params[i].marker+params[i].seriesName+"："+(5 - params[i].data);
　　　　    }
　　　　    return res;
　　      },
      },
      grid: {
        left: '5%',
        right: '22%',
        bottom: '20%'
      },
      xAxis: {
          data: ["16:54:48", "16:54:49", "16:54:50", "16:54:51", "16:54:52"],  // 测试数据
        // data: data.map(function (item) {
        //   return item[0];
        // })
      },
      yAxis: {
          name: '风险指数',
          axisLabel: {
            show:true,
            formatter:function (value, index) {
                if(5-value <= 4 && 5-value>=1)
                    return (5 - value).toFixed(0);
            },
            showMaxLabel:true
        },
          min: 0.8,
          max: 4.2,
      },
      toolbox: {
        right: 10,
        feature: {
          dataZoom: {
            yAxisIndex: 'none'
          },
          // restore: {},
          saveAsImage: {}
        }
      },
      dataZoom: [
          {
            xAxisIndex: [0],
            type: "slider",
            show: true,
            realtime: true,
            start: 0,
            end: 100,
          },
        {
            xAxisIndex: [0],
            type: "inside",
            show: true,
            realtime: true,
            start: 0,
            end: 100,
        },
      ],
      visualMap: {
        top: 40,
        right: 5,
        pieces: [
          {
            gt: 0.5,
            lte: 1.5,
            color: 'rgba(17,102,231,0.78)'
          },
          {
            gt: 1.5,
            lte: 2.5,
            color: '#93CE07'
          },
          {
            gt: 2.5,
            lte: 3.5,
            color: '#fb910f'
          },
          {
            gt: 3.5 ,
            // lte: 4,
            color: '#FD0100'
          },
          // {
          //   gt: 200,
          //   lte: 300,
          //   color: '#AA069F'
          // },
          // {
          //   gt: 300,
          //   color: '#AC3B2A'
          // }
        ],
        outOfRange: {
          color: '#999'
        },
        formatter: function (name) {
            return 4.5 - name;
        }
      },
      series: {
        name: '风险指数',
        type: 'line',
        step: 'middle',
        data: [1,2,4,1,3], // 测试数据
        // data: data.map(function (item) {
        //   return item[1];
        // }),
        axisTick: {
            show: true
        },

        // position: 'left',
        markLine: {
            silent: true,
            symbol: 'none',
            lineStyle: {
                color: 'rgba(145,174,234,0.83)'
            },
            data: [
                {
                yAxis: 1,
                    label:{
                        formatter:'四级风险',
                        position: 'end'
                    },
                },
                {
                yAxis: 2,
                    label:{
                        formatter:'三级风险',
                        position: 'end'
                    },
                },
                {
                yAxis: 3,
                    label:{
                        formatter:'二级风险',
                        position: 'end',
                        color: '#fb910f',
                        fontSize: 16
                    },
                },
                {
                yAxis: 4,
                label:{
                    formatter:'一级风险',
                    position: 'end',
                    color: 'red',
                    fontSize: 17
                },
            }
            ]
        }
      }
    }
flagChart.setOption(flagChartOption)

// evalNext()
function evalNext(){
    $.get('/api_sandplug/getFlags4Charts_test?t', function (data) {
        flagChart.setOption(
            (flagChartOption = {
                title: {
                    text: '实时预警结果(Demo数据)',
                    left: '1%'
                },
                xAxis: {
                    data: data.map(function (item) {
                      return item[0];
                    })
                },
                series: {
                    name: '风险指数',
                    type: 'line',
                    step: 'middle',
                    data: data.map(function (item) {
                        return 5 - item[1];
                    }),
                    axisTick: {
                        show: true
                    },
                }
            })
            // (flagChartOption = {
            //     title: {
            //         text: '实时预警结果(Demo数据)',
            //         left: '1%'
            //     },
            //     xAxis: {
            //         data: data.map(function (item) {
            //           return item[0];
            //         })
            //     },
            //     series: {
            //         name: '风险指数',
            //         type: 'line',
            //         step: 'middle',
            //         data: data.map(function (item) {
            //             return 5 - item[1];
            //         }),
            //         axisTick: {
            //             show: true
            //         },
            //     }
            // })
        );
    });
}
