function showLoadingState2() {
    // 获取loading容器
    var loadingContainer = document.getElementById('loadingSpinnerContainer2');

    // 显示loading容器
    loadingContainer.style.display = 'block';

    // 创建并启动 Spinner
    var spinner = new Spinner().spin();
    loadingContainer.appendChild(spinner.el);
}
function hideLoadingState2() {
    // 获取loading容器
    var loadingContainer = document.getElementById('loadingSpinnerContainer2');

    // 隐藏loading容器
    loadingContainer.style.display = 'none';

    // 停止 Spinner
    var spinner = loadingContainer.querySelector('.spinner');
    if (spinner) {
        spinner.parentNode.removeChild(spinner);
    }
}
function Gclick() {
        event.preventDefault()
        showLoadingState2()
        var S1 = parseFloat(document.getElementById("min_stress").value)
        var nn = parseFloat(document.getElementById("power_law").value)
        var nl = parseFloat(document.getElementById("crack_length_coeff").value)
        var frac_num = parseFloat(document.getElementById("num_cracks").value)
        var frac_spac = parseFloat(document.getElementById("cluster_spacing").value)
        var Hw = parseFloat(document.getElementById("crack_height").value)
        var Hp = parseFloat(document.getElementById("loss_height").value)
        var Q = parseFloat(document.getElementById("displacement").value)
        var tp = parseFloat(document.getElementById("pump_time").value)
        var E = parseFloat(document.getElementById("youngs_modulus").value)
        var v = parseFloat(document.getElementById("poissons_ratio").value)
        var ISIP1 = parseFloat(document.getElementById("stop_pump_pressure").value)
        var P_i = parseFloat(document.getElementById("loss_point_pressure").value)
        var t_i = parseFloat(document.getElementById("loss_point_closure_time").value)
        var P_j = parseFloat(document.getElementById("j_point_pressure").value)
        var t_j = parseFloat(document.getElementById("j_point_closure_time").value)
        var mm = parseFloat(document.getElementById("crack_extension_coeff").value)
        var frac_type = parseFloat(document.getElementById("crack_model").value)
          $.ajax({
            type: "post",
            url: "/Gfunction/cal",
            data:{
                S1:S1,
                nn:nn,
                nl:nl,
                frac_num:frac_num,
                frac_spac: frac_spac,
                Hw:Hw,
                Hp:Hp,
                Q:Q,
                tp:tp,
                E:E,
                v:v,
                ISIP1:ISIP1,
                P_i:P_i,
                t_i:t_i,
                P_j:P_j,
                t_j:t_j,
                mm:mm,
                frac_type:frac_type
            },
            success: function (result) {
                 // 隐藏loading状态
                hideLoadingState2();
                var json = JSON.parse(result.data)
                console.log(json)
                // 在计算完成后，显示元素
                var outputData = {
                            '缝长': json['缝长'],
                            '泵注过程的总滤失体积': json['泵注过程的总滤失体积'],
                            '停泵过程的总滤失体积/改造体积': json['停泵过程的总滤失体积/改造体积'],
                            '总泵入体积': json['总泵入体积'],
                            '压裂液效率': json['压裂液效率'],
                            '最大缝宽': json['最大缝宽'],
                            '滤失系数':json['滤失系数']
                };
                // Create a table to display the output parameters
                var tableHTML = '<h3>计算结果：</h3><table class="table table-bordered"><thead><tr><th>输出参数</th><th>数值</th></tr></thead><tbody>';
                for (var key in outputData) {
                    tableHTML += '<tr><td>' + key + '</td><td>' + outputData[key] + '</td></tr>';
                }
                tableHTML += '</tbody></table>';
                // Display the table below the form
                $('#output-table').html(tableHTML);
                var GfunctionImg=document.getElementById('GfunctionImg')
                GfunctionImg.style.display='block'
               }
            });


}