var isAnalyzing = false;
var fetchInterval;
function dateDataSort(property, bol) { //property是你需要排序传入的key,bol为true时是升序，false为降序
    return function (a, b) {
        var value1 = a[property];
        var value2 = b[property];
        if (bol) {
            // 升序
            return Date.parse(value1) - Date.parse(value2);
        } else {
            // 降序
            return Date.parse(value2) - Date.parse(value1)
        }
    }
}
function queryWell() {
    // 阻止默认事件，防止页面刷新
    event.preventDefault();
    var selectedUrl = $('#id_origin').val();

    // 发送POST请求
    $.ajax({
        url: '/external-url/',
        type: 'POST',
        data: { remote_url: selectedUrl + '/api_app/data/pub/going_job?user_token=frac_app_client' },
        headers: {
            "X-CSRFToken": getCookie("csrftoken")
        },
        success: function (data) {
            if (data.meta.success === 1) {
                $('#id_combobox').empty(); // 清空下拉框选项

                // 添加一个默认选项
                $('#id_combobox').append('<option value="">选择并加载施工井</option>');

                data.data.forEach(function (well) {
                    // 为每口井添加一个选项
                    $('#id_combobox').append('<option value="' + well.job_id + '">' + well.wellname + '</option>');
                });
                // 刷新下拉框
                $('#id_combobox').select('refresh');
                // 显示查询结果
                $('#queryResult').html('共查询到<span style="color: #0000FF;">' + data.data.length + '</span>口井');
            }
        }
    });
}
var job_id_list;
var live_date_list;  // 时间
var data_time_list;  //
var yy_list; // 油压
var ty_list; // 套压
var pczl_list;  // 排出总量
var pcsd_list;  // 排除速度
var xrsd_list;  // 吸入速度
var snd_list;  // 砂浓度
var flag_list; // 预警结果

function loadCurveHistory() {
    event.preventDefault()
    if ($('#id_combobox').val() === "") {
        // 使用 Bootstrap 的警告框显示错误信息
        $('#errorAlert').text('查询失败，请确认井号信息');
        $('#errorAlert').show();
        // 使用 Bootstrap 的滚动效果自动隐藏警告框
        setTimeout(function () {
            $('#errorAlert').hide();
        }, 3000);
    } else {
        var selectedUrl = $('#id_origin').val();
        $.ajax({
            url: '/external-url/',
            type: 'POST',
            data: { remote_url: selectedUrl + '/api_app/data/pub/curve_history?user_token=frac_app_client&job_id=' + $('#id_combobox').val() },
            dataType: "json",
            success: function (data) {
                var data_list;
                if (data.meta.success === 1) {
                    data_list = data.data;
                    data_list.sort(dateDataSort("live_date", true));
                    job_id_list = []
                    live_date_list = []
                    data_time_list = []
                    yy_list = []
                    ty_list = []
                    pczl_list = []
                    pcsd_list = []
                    xrsd_list = []
                    snd_list = []

                    data_list.forEach((curve_his) => {
                        job_id_list.push(curve_his['job_id'].toString())
                        live_date_list.push(curve_his['live_date'])
                        data_time_list.push(curve_his['data_time'])  // 时间
                        yy_list.push(parseFloat(curve_his['yy']))  // 油压
                        ty_list.push(parseFloat(curve_his['ty']))
                        pczl_list.push(parseFloat(curve_his['pczl']))
                        pcsd_list.push(parseFloat(curve_his['pcsd']))
                        xrsd_list.push(parseFloat(curve_his['xrsd'])) // 吸入速度（排量）
                        snd_list.push(parseFloat(curve_his['snd']))   // 砂浓度
                    })
                    // 使用 Bootstrap 的成功警告框显示成功信息
                    $('#successAlert').text('历史数据更新成功');
                    $('#successAlert').show();

                    // 使用 Bootstrap 的滚动效果自动隐藏成功警告框
                    setTimeout(function () {
                        $('#successAlert').hide();
                    }, 3000);

                    reFreshChart();
                } else {
                    // 使用 Bootstrap 的警告框显示查询失败信息
                    $('#errorAlert').text('查询失败，请确认信息，或更换其他井尝试');
                    $('#errorAlert').show();

                    // 使用 Bootstrap 的滚动效果自动隐藏警告框
                    setTimeout(function () {
                        $('#errorAlert').hide();
                    }, 3000);
                }
            },
        });
    }
}

function reFreshChart(){
    // data_time_list.sort()
    option = {
        title: {
            text: '施工数据曲线',
            left: '1%'
        },
        xAxis: {
            data: data_time_list,
            axisLabel: {
                show:true,
                showMaxLabel:true
            },
        },
        series: [
            {
                name: '油压MPa',
                type: 'line',
                yAxisIndex: 0,
                showSymbol: false,
                data: yy_list
            },
            {
                name: '排出流量m^3',
                type: 'line',
                showSymbol: false,
                yAxisIndex: 1,
                data: pcsd_list
            },
            {
                name: '砂浓度',
                type: 'line',
                yAxisIndex: 2,
                showSymbol: false,
                data: snd_list
            },
        ]
    }


    /*
    option['series']=[
        {
            name: '油压MPa',
            type: 'line',
            yAxisIndex: 0,
            showSymbol: false,
            data: yy_list
        },
        {
            name: '排出流量m^3',
            type: 'line',
            showSymbol: false,
            yAxisIndex: 1,
            data: pcsd_list
        },
        {
            name: '砂浓度',
            type: 'line',
            yAxisIndex: 2,
            showSymbol: false,
            data: snd_list
        },
    ]
    option['xAxis']= {
        data: data_time_list
    };
    option['toolbox']={
        feature: {
            dataZoom: {},
            restore: {},
            saveAsImage: {}
        }
    },

    option && myChart.setOption(option, true);
    // restore重置会ajax之前的默认数据了
     */
     option && myChart.setOption(option);
}
/**
 * formatDate：转换为相应格式的日期字符串
 * @param dateinit 13位的时间戳或是日期格式的字符串。必填。
 * @param format 日期格式。默认'yyyy-mm-dd hh:ii:ss'
 * @returns {string} 返回format格式的字符串
 */
const formatDate = function (dateinit, format = 'yyyy-mm-dd hh:ii:ss') {
    let format_str = format
    if (dateinit === null || dateinit === 0 || dateinit === '' || dateinit === undefined) {
        return ''
    }
    let date = new Date(dateinit)
    //若改为let date = new Date(dateinit / 1000);则dateinit参数仅支持10位的时间戳
    let date_str = {
        'y+': date.getFullYear(),//年
        'm+': date.getMonth() + 1, //月份
        'd+': date.getDate(), //日
        'h+': date.getHours(), //小时
        'i+': date.getMinutes(), //分
        's+': date.getSeconds() //秒
    }
    for (let item in date_str) {
        if (new RegExp('(' + item + ')', 'i').test(format_str)) {
            format_str = format_str.replace(
                RegExp.$1,
                date_str[item].toString().length < 2 ? '0' + date_str[item] : date_str[item]
            )
        }
    }
    // alert(format_str)
    return format_str
}


// 比较时间大小
function compareDate(date1,date2){
    var oDate1 = new Date(date1);
    var oDate2 = new Date(date2);
    if(oDate1.getTime() > oDate2.getTime()){
        return true; //第一个大
    } else {
        return false; //第二个大
    }
}

// function analyseRealtimeData(){
//     if(isAnalyzing){
//         isAnalyzing = false
//         $('#IdRedDot').css({'background':'#535353'});
//         $('#span_info').text('已停止');
//         // remove 定时器
//         window.clearInterval(fetchInterval);
//         $('#errorAlert').text('停止分析');
//         $('#errorAlert').show();
//         // 使用 Bootstrap 的滚动效果自动隐藏警告框
//         setTimeout(function () {
//             $('#errorAlert').hide();
//         }, 3000);
//     }
//     else if($('#id_combobox').val().toString().length===0){
//         $('#errorAlert').text('错误，未选择施工井号');
//         $('#errorAlert').show();
//         // 使用 Bootstrap 的滚动效果自动隐藏警告框
//         setTimeout(function () {
//             $('#errorAlert').hide();
//         }, 3000);
//
//     }
//     else {
//         isAnalyzing = true;
//         $('#IdRedDot').css({'background': '#2dc242'});
//         $('#span_info').text('运行中...');
//
//         loadCurveHistory();  // 运行前先更新一次表格的历史数据，之后再动态更新realtime的数据
//
//         /**
//          * not todo:重置预警结果的echart
//          *  function resetFlagChart()
//          * */
//         flag_list = []
//
//         $('#successAlert').text('错误，未选择施工井号');
//         $('#successAlert').show();
//         // 使用 Bootstrap 的滚动效果自动隐藏警告框
//         setTimeout(function () {
//             $('#successAlert').hide();
//         })
//
//         var selectedUrl = $('#id_origin').val();
//         // 设置定时任务请求数据，
//         window.clearInterval(fetchInterval);
//         fetchInterval = setInterval(fetchAfter, 1000);
//         // 定时执行函数获取realtime数据
//         function fetchAfter(){
//             $.ajax({
//                 url:'/external-url/',
//                 type:'POST',
//                 data:{remote_url: selectedUrl+'/api_app/data/pub/curve_realtime?user_token=frac_app_client&job_id='+
//                         $('#id_combobox').val().toString()+
//                         '&live_date='+live_date_list[live_date_list.length-1]},
//                 dataType: "json",
//                 success: function (data){
//                     var data_list_realtime;
//                     var yy_list_piece;
//                     var pcsd_list_piece;
//                     var snd_list_piece;
//                     var live_date_list_piece;
//                     if (parseInt(data.meta['success']) === 1) {
//                         data_list_realtime = data.data
//                         if (data_list_realtime.length !== 0) {
//                             data_list_realtime.sort(dateDataSort("live_date", true))  // 升序
//
//                             data_list_realtime.forEach((item) => {
//                                 // 判断当前时间的数据是不是已经存在，去除返回的重复数据
//                                 if(compareDate(item['live_date'], live_date_list[live_date_list.length-1])) {
//                                     // todo 去除重复值 BUG
//                                     yy_list.push(parseFloat(item['yy']))  // 油压
//                                     pcsd_list.push(parseFloat(item['pcsd'])) // 排出速度
//                                     snd_list.push(parseFloat(item['snd']))   // 砂浓度
//                                     data_time_list.push(formatDate(item['live_date'], 'hh:ii:ss'))
//                                     live_date_list.push(formatDate(item['live_date'], 'yyyy-mm-dd hh:ii:ss'))
//                                 }
//                             })
//                             // 更新图表：data append
//                             reFreshChart()
//                             reFreshFlagChart()
//
//
//                             /**
//                              * done:后端函数修改
//                              * 收到后300s的live_data_list, yy_list, pcsd_list, snd_list
//                              * 格式化
//                              * 调用函数
//                              * 返回值
//                              * */
//
//                         }
//                     }
//                 },
//
//             })
//         }
//     }
// }

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

const csrftoken = getCookie('csrftoken');