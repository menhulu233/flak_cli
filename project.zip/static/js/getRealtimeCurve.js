/**
 * formatDate：转换为相应格式的日期字符串
 * @param dateinit 13位的时间戳或是日期格式的字符串。必填。
 * @param format 日期格式。默认'yyyy-mm-dd hh:ii:ss'
 * @returns {string} 返回format格式的字符串
 */
var job_id_list;
var live_time_list  //日期
var data_time_list;  //时间
var sgyl_list; // 施工压力
var hkyl_list; // 环空压力
var pl_list;  // 排量
var jdyl_list;  // 阶段液量
var zyl_list;  // 总液量
var snd_list;  // 砂浓度
var sllj_list; // 砂量累计
var slljlj_list; // 砂量阶段累计
var requestCount;
const formatDate = function (dateinit, format = 'yyyy-mm-dd hh:ii:ss') {
    let format_str = format
    if (dateinit === null || dateinit === 0 || dateinit === '' || dateinit === undefined) {
        return ''
    }
    let date = new Date(dateinit)
    //若改为let date = new Date(dateinit / 1000);则dateinit参数仅支持10位的时间戳
    let date_str = {
        'y+': date.getFullYear(),//年
        'm+': date.getMonth() + 1, //月份
        'd+': date.getDate(), //日
        'h+': date.getHours(), //小时
        'i+': date.getMinutes(), //分
        's+': date.getSeconds() //秒
    }
    for (let item in date_str) {
        if (new RegExp('(' + item + ')', 'i').test(format_str)) {
            format_str = format_str.replace(
                RegExp.$1,
                date_str[item].toString().length < 2 ? '0' + date_str[item] : date_str[item]
            )
        }
    }
    // alert(format_str)
    return format_str
}

var isFirstClick = true;
// 比较时间大小
function compareDate(date1,date2){
    var oDate1 = new Date(date1);
    var oDate2 = new Date(date2);
    if(oDate1.getTime() > oDate2.getTime()){
        return true; //第一个大
    } else {
        return false; //第二个大
    }
}

var requestCount = 960;
function analyseRealtimeData(){
    event.preventDefault()
    if(isAnalyzing){
        isAnalyzing = false
        $('#IdRedDot').css({'background':'#535353'});
        $('#span_info').text('已停止');
        // remove 定时器
        window.clearInterval(fetchInterval);
        // 隐藏并清空成功提示
        $('#successAlert').hide().text('');

        $('#errorAlert').text('停止分析');
        $('#errorAlert').show();
        // 使用 Bootstrap 的滚动效果自动隐藏警告框
        setTimeout(function () {
            $('#errorAlert').hide();
        }, 3000);
    }
    else if($('#id_combobox').val().toString().length===0){
        // 隐藏并清空错误提示
        $('#errorAlert').hide().text('');

        $('#errorAlert').text('错误，未选择施工井号');
        $('#errorAlert').show();
        // 使用 Bootstrap 的滚动效果自动隐藏警告框
        setTimeout(function () {
            $('#errorAlert').hide();
        }, 3000);

    }
    else {
        isAnalyzing = true;
        $('#IdRedDot').css({'background': '#2dc242'});
        $('#span_info').text('运行中...');
        // 隐藏并清空错误提示
        $('#errorAlert').hide().text('');

        $('#successAlert').text('开始分析');
        $('#successAlert').show();
        // 使用 Bootstrap 的滚动效果自动隐藏警告框
        setTimeout(function () {
            $('#successAlert').hide();
        },3000)
        // loadCurveHistory();  // 运行前先更新一次表格的历史数据，之后再动态更新realtime的数据

        /**
         * not todo:重置预警结果的echart
         *  function resetFlagChart()
         * */
        if (isFirstClick) {
            // 如果是第一次点击，清空列表
            flag_list = [];
            sgyl_list = [];
            pl_list = [];
            snd_list = [];
            data_time_list = [];
            live_time_list = [];
            isFirstClick = false;  // 设置为 false，表示不是第一次点击
        }
        var selectedUrl = $('#id_origin').val();
        // 设置定时任务请求数据，
        window.clearInterval(fetchInterval);
          //960
        fetchInterval = setInterval(function () {
            fetchAfter(requestCount);
            // 每次请求后增加请求次数
            requestCount++;
        }, 1000); // 设置间隔时间，单位为毫秒
        function fetchAfter(count){ // 定时执行函数获取realtime数据
            $.ajax({
                url:'/external-url/',
                type:'POST',
                // data:{remote_url: selectedUrl+'/api_app/data/pub/curve_realtime?user_token=frac_app_client&job_id=888acd67-6ed2-4a18-b04c-9ef2f8095da6&live_date=2022-08-22 17:00:00'
                data:{remote_url: selectedUrl+'/api_app/data/pub/curve_realtime?user_token=frac_app_client&job_id='+
                        $('#id_combobox').val().toString()+'&count='+count
                },
                dataType: "json",
                success: function (data){
                    var data_list_realtime;
                    if (parseInt(data.meta['success']) === 1) {
                        data_list_realtime = data.data
                        if (data_list_realtime.length !== 0) {
                            data_list_realtime.sort(dateDataSort("live_time", true))  // 升序
                                // 插入新数据
                                // 判断当前时间的数据是不是已经存在，去除返回的重复数据
                                sgyl_list.push(parseFloat(data_list_realtime[data_list_realtime.length-1]['sgyl']));  // 油压
                                pl_list.push(parseFloat(data_list_realtime[data_list_realtime.length-1]['pl']));      // 排出速度
                                snd_list.push(parseFloat(data_list_realtime[data_list_realtime.length-1]['snd']));    // 砂浓度
                                data_time_list.push(formatDate(data_list_realtime[data_list_realtime.length-1]['data_time'], 'hh:ii:ss'));
                                live_time_list.push(formatDate(data_list_realtime[data_list_realtime.length-1]['live_time'], 'yyyy-mm-dd hh:ii:ss'));
                            reFreshChart()
                            reFreshFlagChart()
                            if (requestCount % 60 === 0) {
                                getRockImg(); // 首先调用 getRockImg()
                            } else if (requestCount % 59===0) {
                                getProppantImg();
                            }

                        }
                    }
                },

            })
        }
    }
}

function reFreshChart(){
    // data_time_list.sort()
    // console.log(live_time_list)
    // console.log(pl_list)
    option = {
        title: {
            text: '施工数据曲线',
            left: '1%'
        },
        xAxis: {
            data: live_time_list,
            axisLabel: {
                show:true,
                showMaxLabel:true
            },
        },
        series: [
            {
                name: '油压MPa',
                type: 'line',
                yAxisIndex: 0,
                showSymbol: false,
                data: sgyl_list
            },
            {
                name: '排出流量m^3',
                type: 'line',
                showSymbol: false,
                yAxisIndex: 1,
                data: pl_list
            },
            {
                name: '砂浓度',
                type: 'line',
                yAxisIndex: 2,
                showSymbol: false,
                data: snd_list
            },
        ]
    }

     option && myChart2.setOption(option);
}

function reFreshFlagChart(){
    /**
     * done:数据切片
     * 取后300s的live_data_list, yy_list, pcsd_list, snd_list
     * 判断snd[]是否全不为0（是否是加砂阶段）
     * 如果全为0：无风险
     * 否则：截取数据，格式化数据，发送后端
    * */
    // var yy_list_piece;
    // var pcsd_list_piece;
    // var snd_list_piece;
    // var live_date_list_piece;
    // if (live_date_list.length >= 300 && yy_list.length >= 300
    //     && pcsd_list.length >= 300 && snd_list.length >= 300) {
    //     yy_list_piece = yy_list.slice(-300,)
    //     pcsd_list_piece = pcsd_list.slice(-300,)
    //     snd_list_piece = snd_list.slice(-300,)
    //     live_date_list_piece = live_date_list.slice(-300,)
    // }

    function equal0(value, index, ar) {
        return value === 0
    }

    if (snd_list.every(equal0)) {
        // 如果砂浓度全为0
        // 返回无风险
        flag_list = []
        for (var i = 0; i < live_time_list.length; i++) {
            flag_list.push(1); // 四级风险 todo
        }
        flagChart.setOption(
            (flagChartOption = {
                title: {
                    text: '实时预警结果',
                    left: '1%'
                },
                xAxis: {
                    data: live_time_list,
                    axisLabel: {
                        showMaxLabel: true
                    }
                },
                series: {
                    name: '风险指数',
                    type: 'line',
                    step: 'middle',
                    data: flag_list,

                    axisTick: {
                        show: true
                    },
                }
            })
        );
    } else {  // 几个list数据，JSON.stringfy()后发送后端
        $.ajax({
            url: '/sandplug/getFlags4Chart',
            type: 'POST',
            //headers: {"X-CSRFToken": csrftoken},
            data: {
                'sgyl': JSON.stringify(sgyl_list),
                'pl': JSON.stringify(pl_list),
                'snd': JSON.stringify(snd_list),
                'live_time': JSON.stringify(live_time_list)
            },
            dataType: "json",
            success: function (data0) {
                data = JSON.parse(JSON.stringify(data0))

                // {#console.log(data.data)#}
                flagChart.setOption(
                    (flagChartOption = {
                        title: {
                            text: '实时预警结果',
                            left: '1%'
                        },
                        xAxis: {
                            data: data.map(function (item) {
                              return item[0];
                            }),
                            axisLabel: {
                                showMaxLabel: true
                            }
                        },
                        series: {
                            name: '风险指数',
                            type: 'line',
                            step: 'middle',
                            data: data.map(function (item) {
                                return 5 - item[1];
                            }),
                            axisTick: {
                                show: true
                            },
                        }
                    })
                );
            },
        })
    }
}

// async function makeAjaxCall(url, data) {
//     return new Promise((resolve, reject) => {
//         $.ajax({
//             type: "post",
//             url: url,
//             data: data,
//             dataType: 'json',
//             traditional: true,
//             success: function (result) {
//                 resolve(result); // 请求成功时解析结果
//             },
//             error: function (err) {
//                 reject(err); // 请求错误时处理
//             }
//         });
//     });
// }
//
// async function getRockImg() {
//     event.preventDefault();
//     var fracStage = parseInt(document.getElementById("fracStage").value);
//     var yang = parseFloat(document.getElementById("yang").value);
//     var song = parseFloat(document.getElementById("song").value);
//     var modelType = document.getElementById('modelType').value;
//     var rock_height = parseFloat(document.getElementById("rock_height").value);
//     var viscosity = parseFloat(document.getElementById("viscosity").value);
//
//     try {
//         const result = await makeAjaxCall("/rock/cal", {
//             fracStage: fracStage,
//             yang: yang,
//             song: song,
//             modelType: modelType,
//             viscosity: viscosity,
//             rock_height: rock_height,
//             count: requestCount,
//             pl: pl_list[pl_list.length - 1]
//         });
//         // 更新图像
//         var newSrc = "data:image/png;base64," + result.new_plot;
//         $("#plot-container").attr("src", newSrc);
//     } catch (error) {
//         console.error("Error fetching rock image:", error);
//     }
// }
//
// async function getProppantImg() {
//     event.preventDefault();
//     console.log("getProppantImg");
//     var fracStage = parseInt(document.getElementById("fracStage").value);
//     var yang = parseFloat(document.getElementById("yang").value);
//     var song = parseFloat(document.getElementById("song").value);
//     var modelType = document.getElementById('modelType').value;
//     var rock_height = parseFloat(document.getElementById("rock_height").value);
//     var viscosity = parseFloat(document.getElementById("viscosity").value);
//
//     try {
//         const result = await makeAjaxCall("/proppant/cal", {
//             fracStage: fracStage,
//             yang: yang,
//             song: song,
//             modelType: modelType,
//             viscosity: viscosity,
//             rock_height: rock_height,
//             count: requestCount,
//             pl: pl_list[pl_list.length - 1],
//             snd: snd_list[snd_list.length - 1],
//             sgyl: sgyl_list[sgyl_list.length - 1]
//         });
//         // 更新图像
//         $("#plot-container2").attr("src", "data:image/png;base64," + result.new_plot2);
//         $("#plot-container3").attr("src", "data:image/png;base64," + result.new_plot3);
//         $("#plot-container5").attr("src", "data:image/png;base64," + result.new_plot5);
//         $("#plot-container4").attr("src", "data:image/png;base64," + result.new_plot4);
//     } catch (error) {
//         console.error("Error fetching proppant image:", error);
//     }
// }
//
function getRockImg(){
    event.preventDefault()
    var fracStage = parseInt(document.getElementById("fracStage").value)
    var yang = parseFloat(document.getElementById("yang").value)
    var song = parseFloat(document.getElementById("song").value)
    var modelType = document.getElementById('modelType').value;
    var rock_height = parseFloat(document.getElementById("rock_height").value)
    var viscosity = parseFloat(document.getElementById("viscosity").value)
    $.ajax({
    type: "post",
    url: "/rock/cal",
    data:{
        fracStage:fracStage,
        yang:yang,
        song: song,
        modelType: modelType,
        viscosity : viscosity ,
        rock_height:rock_height,
        count:requestCount,
        pl:pl_list[pl_list.length-1]
    },
    dataType: 'json',
        traditional:true,//防止深度序列化
    success: function (result) {
        // 更新图像
        // console.log(result)
    var newSrc = "data:image/png;base64," + result.new_plot;
        // console.log(newSrc);  // 检查生成的URL
    $("#plot-container").attr("src", newSrc);

    }
    });
}
function getProppantImg(){
    event.preventDefault()
    console.log("getProppantImg")
    var fracStage = parseInt(document.getElementById("fracStage").value)
    var yang = parseFloat(document.getElementById("yang").value)
    var song = parseFloat(document.getElementById("song").value)
    var modelType = document.getElementById('modelType').value;
    var rock_height = parseFloat(document.getElementById("rock_height").value)
    var viscosity = parseFloat(document.getElementById("viscosity").value)
    $.ajax({
    type: "post",
    url: "/proppant/cal",
    data:{
        fracStage:fracStage,
        yang:yang,
        song: song,
        modelType: modelType,
        viscosity : viscosity ,
        rock_height:rock_height,
        count:requestCount,
        pl:pl_list[pl_list.length-1],
        snd:snd_list[snd_list.length-1],
        sgyl:sgyl_list[sgyl_list.length-1]
    },
    dataType: 'json',
        traditional:true,//防止深度序列化
    success: function (result) {
        // 更新图像
        console.log(result)
        var newSrc2 = "data:image/png;base64," + result.new_plot2;
        var newSrc3 = "data:image/png;base64," + result.new_plot3;
        var newSrc5 = "data:image/png;base64," + result.new_plot5;
        var newSrc4 = "data:image/png;base64," + result.new_plot4;
        $("#plot-container2").attr("src", newSrc2);
        $("#plot-container3").attr("src",newSrc3);
        $("#plot-container5").attr("src",newSrc5);
        $("#plot-container4").attr("src",newSrc4)
        }
    });
}
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// const csrftoken = getCookie('csrftoken');