- # Learning Tower (学塔) 🎓

  Learning Tower 是一个基于大语言模型的智能学习助手系统，提供智能问答、文本摘要、笔记管理和学习规划等功能，为用户打造个性化的学习体验。本项目采用现代化的技术栈，并集成了 Intel IPEX-LLM 加速技术，在 Intel 平台上提供卓越的性能表现。

  ## ✨ 核心功能

  ### 1. 智能对话 💬

  - 基于 Ollama API 的实时对话系统

  - IPEX-LLM 加速的流式响应，实现流畅打字机效果

  - 智能上下文理解，提供准确的学习指导

  - 支持多轮对话，实现连贯的交互体验

  - 支持文件上传和内容分析

    ![智能问答](images/智能问答.png)

  ### 2. 笔记管理 📝

  - 智能笔记分类和标签管理

  - 支持多种文件格式上传和处理

  - Markdown 格式支持

  - 笔记实时保存和同步

  - 笔记搜索和筛选功能

    ![笔记管理](./images/笔记管理.png)

  ### 3. 学习规划 📅

  - 个性化学习计划生成

  - 任务进度追踪和可视化

  - 阶段性目标设定

  - 学习任务管理和提醒

    ![学习规划](./images/学习规划.png)

  ### 4. 智能翻译 🌐

  - IPEX-LLM 加速的实时翻译
    - 低延迟响应（<100ms）
    - 高吞吐量并行处理
    - 智能内存管理
  - 多语言支持
    - 中英日韩等主流语言
    - 专业术语库集成
    - 自动语言检测
  - 场景优化
    - 学术论文翻译
    - 技术文档翻译
    - 教育资料翻译
  - 高级特性

    - 上下文感知翻译
    - 术语一致性维护
    - 多格式文件支持（PDF/Word/TXT）
    - 批量处理能力

    ![文本翻译](./images/文本翻译.png)

    ![文件翻译](./images/文件翻译.png)

  ### 6. 设置 ⚙️

  - 偏好设置

    - AI 模型切换
    - 使用 CPU 还是 GPU 推理

    - 主题切换

    ![偏好设置](./images/偏好设置.png)

  ### 6. 用户管理 👤

  - 个性化用户配置
    - 自定义界面主题（明/暗模式）
    - 语言偏好设置
    - AI 模型选择
  - 用户数据管理

    - 个人资料维护

    - 数据导入导出

    - 隐私设置控制

      ![登录](./images/登录.png)

      ![注册](./images/注册.png)

      ![个人资料](./images/个人资料.png)

      ![安全设置](./images/安全设置.png)

  ## 🛠 技术架构

  ### 后端技术栈

  这是目前的技术架构，后期会使用更先进完善的框架和数据库，以及 AI 服务，详情请见项目技术报告

  - **Web 框架**: Django 5.0+
  - **AI 引擎**:
    - Ollama API 基础功能
    - IPEX-LLM 加速引擎
  - **开发语言**: Python 3.11
  - **数据存储**: Mysql（后期项目会使用更高级的数据库，包括向量数据库等）
  - **硬件加速**:
    - Intel IPEX (Intel Platform Optimizations)
    - Intel oneAPI Deep Neural Network Library (oneDNN)

  ### IPEX-LLM 优化特性

  - **硬件感知优化**:
    - 自动检测并利用 Intel CPU 特性
    - AMX/AVX-512 指令集优化
    - 智能线程调度和负载均衡
  - **内存管理优化**:
    - 智能内存复用
    - 动态内存分配
    - 缓存优化策略
  - **推理性能优化**:

    - 计算图优化
    - 算子融合
    - 量化加速
    - 批处理自动调优

  - **动态适配**:
    - 自动适配处理器特性
    - 动态调整线程数
    - 实时性能监控

  ### 前端技术栈

  - **UI 框架**: Bootstrap 5.1.3（后期项目前端会使用 Vue3 搭建，并考虑多端适配）
  - **交互实现**: JavaScript ES6+ jQuery
  - **样式处理**: CSS3 + SCSS
  - **Markdown 渲染**: Marked.js

  ## 🚀 快速开始

  ### 环境要求

  - Python 3.11+
  - Ollama 服务
  - Intel CPU (本地使用 i9-13900K 或更高)
  - IPEX-LLM 加速库

  ### 安装步骤

  1. 克隆项目

  ```bash
  git clone https://atomgit.com/ipex-llm/learntower.git
  ```

  2. 安装依赖

  ```bash
  pip install -r requirements.txt
  pip install ipex-llm[xpu]>=2.5.0 intel-extension-for-pytorch
  ```

  3. 配置 IPEX-LLM

  ```bash
  pip install --pre --upgrade ipex-llm[xpu_lnl] --extra-index-url https://pytorch-extension.intel.com/release-whl/stable/lnl/cn/
  
  # 设置环境变量启用 IPEX 加速
  对于iGPU，需要设置以下环境变量：
  set SYCL_CACHE_PERSISTENT=1
  set BIGDL_LLM_XMX_DISABLED=1
  
  对于Arc™ GPU，需要设置以下环境变量：
  set SYCL_CACHE_PERSISTENT=1
  ```

  4. 启动 Ollama 服务（启用 IPEX 加速）

  ```bash
  OLLAMA_HOST=0.0.0.0 OLLAMA_IPEX=1 ollama serve
  ```

  5. 运行数据库迁移

  ```bash
  python manage.py migrate
  ```

  6. 启动开发服务器

  ```bash
  python manage.py runserver
  ```

  7. 访问系统

  ```bash
  http://localhost:8000
  ```

  8.如何更改模型
  在 settings.py 中更改模型

  ```python
    # Ollama配置
  OLLAMA_CONFIG = {
      'BASE_URL': 'http://localhost:11434',
      'DEFAULT_MODEL': 'qwen2.5:7b', #更换成ollama中下载的其他模型
  }
  ```

  ## 📁 项目结构

  ```
  LearnTower/
  ├── ai/                     # AI 服务相关
  │   ├── services.py        # AI 服务实现（翻译、对话、摘要等）
  │   ├── models.py          # AI 相关数据模型
  │   ├── utils.py           # AI 工具函数
  │   └── tests/             # AI 服务测试
  │
  ├── core/                   # 核心应用
  │   ├── models.py          # 核心数据模型
  │   ├── views.py           # 视图函数
  │   ├── urls.py            # URL 配置
  │   └── middleware.py      # 中间件
  │
  ├── users/                  # 用户管理
  │   ├── models.py          # 用户数据模型
  │   ├── views.py           # 用户相关视图
  │   ├── forms.py           # 表单处理
  │   └── auth.py           # 认证相关
  │
  ├── static/                 # 静态资源
  │   ├── css/               # 样式文件
  │   │   ├── main.css      # 主样式
  │   │   ├── markdown.css      # markdown样式
  │   ├── js/                # JavaScript 文件
  │   │   ├── main.js       # 主逻辑
  │   ├──bootstrap.min.js    #依赖文件
  │   ├──bootstrap.min.css
  │   ├──jquery-3.7.1.min.js
  │   ├──popper.min.js
  │   └── images/            # 图片资源
  ├── templates/             # HTML 模板
  │   ├── base.html         # 基础模板
  │   ├── index.html             # 对话相关模板
  │   ├── summarize.html           # 笔记相关模板
  │   ├── translate.html            # 翻译相关模板
  │   └──login.html             # 登录模板
  │   └──register.html             # 注册模板
  │   └──settings.html             # 设置模板
  ├── media/                 # 用户上传文件
  │   ├── avatars/          # 用户头像
  │   └── documents/        # 上传的文档
  ├── manage.py             # Django 管理脚本
  ├── requirements         # 依赖管理
  ├── README.md             # 项目说明
  ```

## 🖥️ 本地运行环境与效果

### 硬件环境

- **GPU**: Intel RaptorLake-S Mobile Graphics Controller
- **设备类型**: [level_zero:gpu:0]
- **驱动版本**: 1.3.30398

### 运行效果展示

#### 系统运行界面

![本地运行效果](./images/本地运行.png)
_系统主界面运行截图_

#### 后端性能监控

![后端记录](./images/后端信息.png)
_后端服务运行状态与性能指标_

#### Ollama 服务状态

![ollama](./images/ollama信息.png)
_Ollama 服务运行信息与资源使用情况_

由于本地使用的是 Intel 的集成显卡，所以性能指标并不是很高，但是可以正常使用，后期会将 AI 服务部署到云端 intel 平台，采用 intel arcs 独显进行更高性能的推理。

## 🔥 主要特性

### 用户体验

- 响应式设计，支持多端适配
- 实时对话反馈
- 流畅的动画过渡效果
- 直观的笔记管理界面

### 性能优化

- 异步请求处理
- 流式响应支持
- 智能缓存策略
- 资源懒加载
- IPEX-LLM 硬件加速
  - 自动批处理优化
  - INT8/BF16 动态量化
  - 智能内存管理
  - Intel CPU 特定优化
  - 算子融合和计算图优化
  - 缓存层级优化
  - 线程调度优化

### IPEX-LLM 性能提升

- 推理延迟降低 40-60%
- 内存占用减少 30-50%
- 吞吐量提升 2-3 倍
- 动态批处理效率提升 45%
- 启动时间缩短 35%

### 安全特性

- CSRF 保护
- 用户认证和授权
- 安全的文件上传处理
- 输入验证和清理


## ⚠️ 注意事项

1. 使用前请确保 Ollama 服务正常运行
2. 建议使用 Python 3.11+ 版本
3. 需要稳定的网络环境
4. 定期备份重要数据
5. 确保系统已正确配置 IPEX-LLM 环境变量
6. 推荐使用 Intel i9 处理器以获得最佳性能
7. 建议安装 Intel oneAPI Base Toolkit 获得完整优化支持
8. 对于较老的 Intel CPU，部分优化特性可能不可用
9. 系统内存建议 8GB 以上，推荐 16GB

## 📄 技术博客

项目开发过程中的技术总结和心得分享：
- [IPEX-LLM: 英特尔硬件大语言模型加速库部署](https://blog.csdn.net/JinYi_f/article/details/144875640) - 深入讲解了 IPEX-LLM 的部署和优化过程
- [IPEX-LLM PythonAPI 接口](https://blog.csdn.net/JinYi_f/article/details/144875607) - 介绍了 IPEX-LLM 的 Python API 使用方法和最佳实践
- [快速上手体验 AIGC-借助 ollama 和 gradio 本地搭建自己的聊天机器人](https://blog.csdn.net/JinYi_f/article/details/144875828) - 详细介绍了如何使用 Ollama 和 Gradio 快速搭建本地聊天机器人
- [如何使用 IPEX-LLM 优化 大模型，并保存到本地](https://blog.csdn.net/JinYi_f/article/details/145065624) - 介绍了如何使用IPEX-LLM优化大模型

## 🔗 相关链接

- [IPEX-LLM 官方文档](https://github.com/intel-analytics/ipex-llm)
- [Intel oneAPI 文档](https://www.intel.com/content/www/us/en/developer/tools/oneapi/overview.html)
- [Ollama 官方文档](https://ollama.ai/docs)
- [Intel Developer Documentation](https://www.intel.com/content/www/us/en/developer/overview.html)

# LearnTower Backend API

This is the backend API service for LearnTower, providing AI-powered learning assistance features.

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Configure your database in settings.py

3. Run migrations:
```bash
python manage.py migrate
```

4. Start the server:
```bash
python manage.py runserver
```


