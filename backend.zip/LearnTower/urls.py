"""
URL configuration for LearnTower project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path
from ai import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path("admin/", admin.site.urls),
    path('', views.index, name='index'),
    path('summarize/', views.summarize_page, name='summarize'),
    path('study-plan/', views.study_plan_page, name='study_plan'),
    path('translate/', views.translate_page, name='translate'),
    path('api/summarize', views.summarize, name='summarize'),
    path('api/chat', views.chat, name='chat'),
    path('api/study-plan', views.study_plan, name='study_plan'),
    path('api/translate', views.translate, name='translate'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('settings/', views.settings_view, name='settings'),
    path('settings/profile/', views.update_profile, name='update_profile'),
    path('settings/preferences/', views.update_settings, name='update_settings'),
    path('settings/password/', views.change_password, name='change_password'),
    path('history/', views.history_view, name='history'),
    path('api/chat/new', views.new_chat, name='new_chat'),
    path('api/chat/history/<int:chat_id>', views.chat_history, name='chat_history'),
    path('api/notes/<int:note_id>', views.get_note, name='get_note'),
    path('api/notes/save', views.save_note, name='save_note'),
    path('api/notes/summary', views.generate_note_summary, name='generate_note_summary'),
    path('api/notes/classify', views.classify_note, name='classify_note'),
    path('api/notes/<int:note_id>/delete', views.delete_note, name='delete_note'),
    path('api/notes/upload', views.upload_note, name='upload_note'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)  # 仅在开发环境中使用
