## API Documentation

### Authentication

All API endpoints require authentication unless specified otherwise.

#### Login

- **URL**: `/login/`
- **Method**: `POST`
- **Auth required**: No
- **Data**:

```json
{
  "username": "string",
  "password": "string"
}
```

- **Success Response**: `200 OK`

```json
{
  "token": "string"
}
```

#### Register

- **URL**: `/register/`
- **Method**: `POST`
- **Auth required**: No
- **Data**:

```json
{
  "username": "string",
  "email": "string",
  "password": "string"
}
```

- **Success Response**: `201 Created`

### AI Features

#### Text Summarization

- **URL**: `/api/summarize`
- **Method**: `POST`
- **Auth required**: Yes
- **Data**:

```json
{
  "text": "string",
  "max_length": "integer"
}
```

- **Success Response**: `200 OK`

```json
{
  "summary": "string"
}
```

#### Chat

- **URL**: `/api/chat`
- **Method**: `POST`
- **Auth required**: Yes
- **Data**:

```json
{
  "message": "string",
  "chat_id": "integer"
}
```

- **Success Response**: `200 OK`

```json
{
  "response": "string",
  "chat_id": "integer"
}
```

#### Study Plan Generation

- **URL**: `/api/study-plan`
- **Method**: `POST`
- **Auth required**: Yes
- **Data**:

```json
{
  "subject": "string",
  "duration": "string",
  "level": "string"
}
```

- **Success Response**: `200 OK`

```json
{
  "plan": "object"
}
```

#### Translation

- **URL**: `/api/translate`
- **Method**: `POST`
- **Auth required**: Yes
- **Data**:

```json
{
  "text": "string",
  "target_language": "string"
}
```

- **Success Response**: `200 OK`

```json
{
  "translation": "string"
}
```

### Notes Management

#### Get Note

- **URL**: `/api/notes/{note_id}`
- **Method**: `GET`
- **Auth required**: Yes
- **Success Response**: `200 OK`

```json
{
  "id": "integer",
  "title": "string",
  "content": "string",
  "created_at": "datetime",
  "updated_at": "datetime"
}
```

#### Save Note

- **URL**: `/api/notes/save`
- **Method**: `POST`
- **Auth required**: Yes
- **Data**:

```json
{
  "title": "string",
  "content": "string"
}
```

- **Success Response**: `201 Created`

#### Generate Note Summary

- **URL**: `/api/notes/summary`
- **Method**: `POST`
- **Auth required**: Yes
- **Data**:

```json
{
  "note_id": "integer"
}
```

- **Success Response**: `200 OK`

```json
{
  "summary": "string"
}
```

#### Delete Note

- **URL**: `/api/notes/{note_id}/delete`
- **Method**: `DELETE`
- **Auth required**: Yes
- **Success Response**: `204 No Content`

#### Upload Note

- **URL**: `/api/notes/upload`
- **Method**: `POST`
- **Auth required**: Yes
- **Content-Type**: `multipart/form-data`
- **Data**:
  - `file`: File
- **Success Response**: `201 Created`

## Error Responses

All endpoints may return the following error responses:

- `400 Bad Request`: Invalid request data
- `401 Unauthorized`: Authentication required or failed
- `403 Forbidden`: Insufficient permissions
- `404 Not Found`: Resource not found
- `500 Internal Server Error`: Server error

## Rate Limiting

API requests are limited to 100 requests per minute per user.

## Notes

- All timestamps are returned in ISO 8601 format
- All requests must include the session cookie or Authorization header
- File uploads are limited to 10MB
