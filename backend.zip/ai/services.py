"""
AI服务模块 - 使用Ollama API实现文本摘要和聊天机器人功能

本模块提供了两个主要类：
1. TextSummarizer: 用于生成文本摘要
2. ChatBot: 用于实现聊天对话功能

主要依赖:
- requests: 用于调用Ollama API
"""

import requests
import logging
from typing import List, Optional, Iterator
import json
from django.conf import settings
import os
from PIL import Image
import pytesseract
import docx
import PyPDF2
from pptx import Presentation
import io
import ollama

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class OllamaServiceError(Exception):
    """Ollama服务异常"""
    pass

class OllamaAPI:
    """Ollama API 封装类"""
    
    def __init__(self, model=None):
        """初始化Ollama API"""
        self.model = model or settings.OLLAMA_CONFIG['DEFAULT_MODEL']
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"Using Ollama model: {self.model}")

    def generate(self, prompt, chat_history=None, options=None):
        """生成文本响应"""
        try:
            # 构建消息历史
            messages = []
            if chat_history:
                for msg in chat_history:
                    messages.append({
                        'role': msg['role'],
                        'content': msg['content']
                    })
            
            # 添加当前问题
            messages.append({'role': 'user', 'content': prompt})
            
            # 设置默认参数
            default_options = {
                'num_predict': 500,
                'temperature': options.get('temperature', 0.7),
                'top_p': options.get('top_p', 0.9),
                'repeat_penalty': options.get('repeat_penalty', 1.1),
                'stop': options.get('stop', None)
            }
            
            response = ollama.chat(
                model=self.model,
                messages=messages,
                stream=False,
                options=default_options
            )
            
            # 直接返回内容文本，而不是字典
            return response['message']['content']
            
        except Exception as e:
            self.logger.error(f"Ollama API调用失败: {str(e)}")
            raise OllamaServiceError(str(e))

    def generate_stream(self, prompt, chat_history=None, options=None):
        """生成流式响应"""
        try:
            # 构建消息历史
            messages = []
            if chat_history:
                for msg in chat_history:
                    messages.append({
                        'role': msg['role'],
                        'content': msg['content']
                    })
            
            messages.append({'role': 'user', 'content': prompt})
            
            # 设置默认参数
            default_options = {
                'num_predict': 500,
                'temperature': options.get('temperature', 0.7),
                'top_p': options.get('top_p', 0.9),
                'repeat_penalty': options.get('repeat_penalty', 1.1),
                'stop': options.get('stop', None)
            }
            
            stream = ollama.chat(
                model=self.model,
                messages=messages,
                stream=True,
                options=default_options
            )
            
            for chunk in stream:
                if 'message' in chunk and 'content' in chunk['message']:
                    yield {
                        'content': chunk['message']['content'],
                        'role': 'assistant'
                    }
                    
        except Exception as e:
            self.logger.error(f"Ollama API流式调用失败: {str(e)}")
            raise OllamaServiceError(str(e))

class TextSummarizer:
    """文本摘要生成器"""
    
    def __init__(self):
        """初始化摘要生成器"""
        self.ollama = OllamaAPI()
        self.logger = logging.getLogger(__name__)
        
    def generate_summary(self, text: str) -> str:
        """
        生成文本摘要
        
        参数:
            text (str): 需要总结的文本
            
        返回:
            str: 生成的摘要
        """
        try:
            prompt = f"""请对以下文本进行精炼的总结，要求：
1. 提取核心观点和关键信息，用简洁的语言表达
2. 保持逻辑清晰，按重要性排序
3. 使用要点形式，每点以"•"开头
4. 每点不超过30字
5. 如果文本包含数据，请保留关键数据
6. 每个要点间空一行，增加可读性

原文：
{text}

总结："""
            
            summary = self.ollama.generate(
                prompt,
                options={
                    "temperature": 0.7,
                    "top_p": 0.9,
                    "max_tokens": min(len(text) // 2, 500),
                }
            )
            
            # 清理输出
            summary = summary.split("总结：")[-1].strip()
            if "原文：" in summary:
                summary = summary.split("原文：")[0].strip()
            
            # 格式化输出，确保每个要点之间有空行
            summary = summary.replace("• ", "\n• ").strip()
            summary = "\n\n".join(line for line in summary.split("\n") if line.strip())
                
            return summary
            
        except Exception as e:
            self.logger.error(f"生成摘要失败: {str(e)}")
            raise

    def batch_generate_summaries(self, texts: List[str], max_length: int = 32) -> List[str]:
        """批量生成文本摘要"""
        return [self.generate_summary(text, max_length) for text in texts]

class ChatBot:
    """聊天机器人类"""
    
    def __init__(self):
        """初始化聊天机器人"""
        self.logger = logging.getLogger(__name__)
        self.base_url = settings.OLLAMA_CONFIG.get('BASE_URL', 'http://localhost:11434')
        self.model = settings.OLLAMA_CONFIG.get('DEFAULT_MODEL', 'qwen2.5:7b')
        
    def chat(self, message, chat_history=None):
        """处理聊天消息"""
        try:
            # 构建请求URL
            url = f"{self.base_url}/api/chat"
            
            # 构建消息历史
            messages = []
            if chat_history:
                for msg in chat_history:
                    messages.append({
                        'role': msg.role,
                        'content': msg.content
                    })
            
            # 添加当前消息
            messages.append({
                'role': 'user',
                'content': message
            })
            
            # 构建请求数据
            data = {
                'model': self.model,
                'messages': messages,
                'stream': False,
                'options': {
                    'temperature': 0.7,
                    'top_p': 0.9,
                }
            }
            
            # 发送请求
            response = requests.post(url, json=data)
            response.raise_for_status()
            
            result = response.json()
            if not result or 'message' not in result:
                raise OllamaServiceError("无效的 Ollama API 响应")
                
            return result['message']['content']
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Ollama API 请求失败: {str(e)}")
            raise OllamaServiceError(f"无法连接到 AI 服务: {str(e)}")
        except Exception as e:
            self.logger.error(f"Ollama 聊天服务错误: {str(e)}")
            raise OllamaServiceError(f"AI 服务暂时不可用: {str(e)}")

    def get_response_stream(self, message, chat_history=None):
        """获取流式响应"""
        try:
            system_prompt = """你是一个AI学习助手，请用专业、友好的语气回答用户的问题。
支持 Markdown 格式输出。"""

            # 添加系统提示到历史记录开头
            if chat_history is None:
                chat_history = []
            
            if not chat_history:
                chat_history.append({
                    'role': 'system',
                    'content': system_prompt
                })
            
            # 使用流式生成
            for chunk in self.ollama.generate_stream(
                message,
                chat_history=chat_history,
                options={
                    "temperature": 0.7,
                    "top_p": 0.9,
                }
            ):
                yield chunk
                
        except Exception as e:
            self.logger.error(f"生成回答失败: {str(e)}")
            raise OllamaServiceError(str(e))

    def process_file(self, file_content, file_type, question=None):
        """处理上传的文件并回答相关问题"""
        try:
            # 构建提示
            prompt = f"""我有一个{file_type}文件，内容如下：

{file_content}

"""
            if question:
                prompt += f"\n请回答以下问题：{question}"
            else:
                prompt += "\n请总结文件的主要内容，并提供关键信息。"

            return self.chat(prompt)
            
        except Exception as e:
            self.logger.error(f"文件处理失败: {str(e)}")
            raise OllamaServiceError(str(e))

    def generate_study_plan(self, subject, goal, duration):
        """生成学习计划"""
        prompt = f"""请你作为一个专业的学习规划顾问，为以下学习目标制定详细的规划建议：

学习科目：{subject}
学习目标：{goal}
计划时长：{duration}

要求：
1. 分阶段规划学习内容和进度
2. 提供具体的学习方法建议
3. 包含阶段性检验方式
4. 注意学习效率和时间分配
5. 考虑可能遇到的困难并给出应对建议

学习规划："""

        return self.chat(prompt)

class TranslationService:
    """翻译服务类"""
    
    def __init__(self):
        self.ollama = OllamaAPI()
        self.logger = logging.getLogger(__name__)
        
    def translate(self, text: str, source_lang: str, target_lang: str) -> str:
        """翻译文本"""
        try:
            prompt = f"""请将以下{source_lang}文本翻译成{target_lang}（直接返回翻译结果，不要包含其他内容）：

{text}"""
            
            translation = self.ollama.generate(
                prompt,
                options={
                    'temperature': 0.3,  # 降低温度以获得更稳定的翻译
                    'top_p': 0.85,
                    'repeat_penalty': 1.1
                }
            )
            
            # 清理输出
            translation = translation.strip()
            
            # 验证翻译结果
            if not translation:
                raise ValueError("翻译结果为空")
                
            return translation
            
        except Exception as e:
            self.logger.error(f"翻译失败: {str(e)}")
            raise OllamaServiceError(str(e))

class NoteService:
    """笔记服务类"""
    
    def __init__(self):
        self.ollama = OllamaAPI()
        self.logger = logging.getLogger(__name__)
    
    def generate_summary(self, content: str) -> str:
        """生成笔记摘要"""
        try:
            prompt = f"""请为以下内容生成一个简洁的摘要，突出重点：

{content}

摘要："""
            
            summary = self.ollama.generate(
                prompt,
                options={
                    "temperature": 0.3,
                    "top_p": 0.85,
                    "max_tokens": min(len(content) // 4, 500),  # 摘要长度限制
                    "repeat_penalty": 1.1,
                }
            )
            
            return summary.strip()
            
        except Exception as e:
            self.logger.error(f"生成摘要失败: {str(e)}")
            raise
    
    def classify_note(self, content: str) -> str:
        """智能分类笔记"""
        try:
            prompt = f"""请分析以下笔记内容，并从以下类别中选择最合适的一个（只返回分类名称）：
- 学习笔记
- 工作记录
- 项目文档
- 会议纪要
- 创意灵感
- 个人日记
- 其他

笔记内容：
{content}

分类："""
            
            category = self.ollama.generate(
                prompt,
                options={
                    "temperature": 0.3,
                    "top_p": 0.9,
                }
            )
            
            # 清理输出，只保留分类名称
            category = category.strip().split('\n')[0]
            return category
            
        except Exception as e:
            self.logger.error(f"笔记分类失败: {str(e)}")
            raise 

class FileProcessor:
    """文件处理类"""
    
    def __init__(self):
        self.supported_types = {
            'image': ['.jpg', '.jpeg', '.png', '.bmp'],
            'pdf': ['.pdf'],
            'word': ['.docx', '.doc'],
            'ppt': ['.pptx', '.ppt']
        }
    
    def get_file_type(self, filename):
        """获取文件类型"""
        ext = os.path.splitext(filename)[1].lower()
        for file_type, extensions in self.supported_types.items():
            if ext in extensions:
                return file_type
        return None
    
    def extract_text(self, file, file_type):
        """从文件中提取文本"""
        try:
            if file_type == 'image':
                # 图片类型直接返回空文本，后续可以添加图片描述
                return "[图片]"
            elif file_type == 'pdf':
                return self._extract_from_pdf(file)
            elif file_type == 'word':
                return self._extract_from_word(file)
            elif file_type == 'ppt':
                return self._extract_from_ppt(file)
            return ""
        except Exception as e:
            logger.error(f"文本提取失败: {str(e)}")
            return ""
    
    def _extract_from_pdf(self, file):
        """从PDF中提取文本"""
        try:
            pdf_reader = PyPDF2.PdfReader(file)
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text() + "\n"
            return text.strip()
        except Exception as e:
            logger.error(f"PDF文本提取失败: {str(e)}")
            return ""
    
    def _extract_from_word(self, file):
        """从Word文档中提取文本"""
        try:
            doc = docx.Document(file)
            text = ""
            for para in doc.paragraphs:
                text += para.text + "\n"
            return text.strip()
        except Exception as e:
            logger.error(f"Word文本提取失败: {str(e)}")
            return ""
    
    def _extract_from_ppt(self, file):
        """从PPT中提取文本"""
        try:
            prs = Presentation(file)
            text = ""
            for slide in prs.slides:
                for shape in slide.shapes:
                    if hasattr(shape, "text"):
                        text += shape.text + "\n"
            return text.strip()
        except Exception as e:
            logger.error(f"PPT文本提取失败: {str(e)}")
            return "" 