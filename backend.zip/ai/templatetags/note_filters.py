from django import template

register = template.Library()

@register.filter(name='filter_by_category')
def filter_by_category(notes, category):
    """按分类筛选笔记"""
    return [note for note in notes if note.category == category] 