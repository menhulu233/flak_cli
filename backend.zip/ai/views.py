from django.http import JsonResponse, StreamingHttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt, ensure_csrf_cookie
import json
from .services import TextSummarizer, ChatBot, OllamaServiceError, TranslationService, NoteService, FileProcessor
import logging
from django.contrib.auth import login, authenticate, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.utils import timezone
from .models import UserProfile, UserLoginHistory, UserSettings, UserOperationHistory, ChatHistory, ChatMessage, Note
import os
from django.views.decorators.http import require_POST

# 创建服务实例
summarizer = TextSummarizer()
chatbot = ChatBot()
logger = logging.getLogger(__name__)
note_service = NoteService()
file_processor = FileProcessor()

@ensure_csrf_cookie
@login_required(login_url='login')
def index(request):
    """渲染首页"""
    chat_id = request.GET.get('chat_id')
    
    # 获取所有聊天历史，并按更新时间倒序排序
    chat_histories = request.user.chat_histories.all().order_by('-updated_at')
    
    if chat_id:
        current_chat = get_object_or_404(ChatHistory, id=chat_id, user=request.user)
    else:
        # 如果没有指定chat_id，创建新对话或获取最新对话
        current_chat = chat_histories.first() or ChatHistory.objects.create(user=request.user)
    
    context = {
        'chat_histories': chat_histories,
        'current_chat': current_chat,
        'messages': current_chat.messages.all()
    }
    
    # 添加调试信息
    for history in chat_histories:
        print(f"Chat ID: {history.id}, Title: {history.title}, Updated: {history.updated_at}")
    
    logger.info("Rendering index page with chat_id: %s", chat_id)  # 添加日志
    return render(request, 'index.html', context)

@login_required(login_url='login')
def summarize_page(request):
    """笔记管理页面"""
    notes = request.user.notes.all().order_by('-updated_at')
    
    # 获取所有分类及其计数
    categories = {}
    image_count = 0  # 图片计数
    
    for note in notes:
        # 如果是图片类型,单独统计
        if note.file_type == 'image':
            image_count += 1
        else:
            if note.category in categories:
                categories[note.category] += 1
            else:
                categories[note.category] = 1
    
    # 如果有图片,添加图片分类
    if image_count > 0:
        categories['图片'] = image_count
    
    context = {
        'notes': notes,
        'categories': categories,
        'total_notes': len(notes)
    }
    return render(request, 'summarize.html', context)

@login_required(login_url='login')
def study_plan_page(request):
    """渲染学习规划页面"""
    return render(request, 'study_plan.html')

@login_required(login_url='login')
def translate_page(request):
    """渲染翻译页面"""
    return render(request, 'translate.html')

@login_required(login_url='login')
def settings_view(request):
    """用户设置页面"""
    # 确保用户有 profile
    if not hasattr(request.user, 'profile'):
        UserProfile.objects.create(user=request.user)
    
    # 确保用户有 settings
    if not hasattr(request.user, 'settings'):
        UserSettings.objects.create(user=request.user)
        
    return render(request, 'settings.html')

@login_required(login_url='login')
def update_profile(request):
    """更新用户资料"""
    if request.method == 'POST':
        try:
            # 更新邮箱
            request.user.email = request.POST.get('email', '')
            request.user.save()
            
            # 处理头像上传
            if 'avatar' in request.FILES:
                avatar = request.FILES['avatar']
                # 验证文件类型
                if not avatar.content_type.startswith('image/'):
                    messages.error(request, '请上传有效的图片文件')
                    return redirect('settings')
                
                # 验证文件大小
                if avatar.size > 2 * 1024 * 1024:  # 2MB
                    messages.error(request, '图片大小不能超过 2MB')
                    return redirect('settings')
                
                # 保存头像
                request.user.profile.avatar = avatar
                request.user.profile.save()
            
            messages.success(request, '个人资料已更新')
        except Exception as e:
            messages.error(request, f'更新失败：{str(e)}')
            
    return redirect('settings')

@login_required(login_url='login')
def update_settings(request):
    """更新用户设置"""
    if request.method == 'POST':
        user = request.user
        settings = user.settings
        
        settings.theme = request.POST.get('theme', 'light')
        settings.language = request.POST.get('language', 'zh')
        settings.notification_enabled = 'notification_enabled' in request.POST
        
        settings.save()
        messages.success(request, '设置已更新')
        
    return redirect('settings')

@login_required(login_url='login')
def change_password(request):
    """修改密码"""
    if request.method == 'POST':
        user = request.user
        current_password = request.POST.get('current_password')
        new_password1 = request.POST.get('new_password1')
        new_password2 = request.POST.get('new_password2')
        
        if not user.check_password(current_password):
            messages.error(request, '当前密码错误')
            return redirect('settings')
            
        if new_password1 != new_password2:
            messages.error(request, '两次输入的新密码不一致')
            return redirect('settings')
            
        if len(new_password1) < 8:
            messages.error(request, '密码长度不能少于8位')
            return redirect('settings')
            
        user.set_password(new_password1)
        user.save()
        
        # 更新session，避免用户被登出
        update_session_auth_hash(request, user)
        
        messages.success(request, '密码已修改')
        
    return redirect('settings')

@csrf_exempt
@require_http_methods(["POST"])
def summarize(request):
    """处理文本摘要请求"""
    try:
        data = json.loads(request.body)
        text = data.get('text')
        
        if not text:
            return JsonResponse({'error': '请提供需要总结的文本'}, status=400)
            
        summary = summarizer.generate_summary(text)
        
        # 记录操作历史
        UserOperationHistory.objects.create(
            user=request.user,
            operation_type='summarize',
            content=text,
            result=summary
        )
        
        return JsonResponse({'summary': summary})
        
    except Exception as e:
        logger.error(f"Summarization error: {str(e)}")
        return JsonResponse({'error': str(e)}, status=500)

@ensure_csrf_cookie
@login_required
def chat(request):
    """处理聊天请求"""
    try:
        logger.info("Received chat request body: %s", request.body.decode('utf-8'))  # 添加请求体日志
        data = json.loads(request.body)
        message = data.get('message', '').strip()
        chat_id = data.get('chat_id')
        
        logger.info(f"Processing chat request: message={message}, chat_id={chat_id}")
        
        if not message:
            return JsonResponse({'error': '消息不能为空'}, status=400)
            
        # 获取或创建聊天历史
        if chat_id:
            chat_history = get_object_or_404(ChatHistory, id=chat_id, user=request.user)
            logger.info(f"使用现有对话: {chat_id}")
        else:
            chat_history = ChatHistory.objects.create(
                user=request.user,
                title=message[:20] + ('...' if len(message) > 20 else '')
            )
            logger.info(f"创建新对话: {chat_history.id}")
        
        # 获取历史消息
        history_messages = list(chat_history.messages.all().order_by('created_at'))
        
        # 保存用户消息
        ChatMessage.objects.create(
            chat_history=chat_history,
            role='user',
            content=message
        )
        
        try:
            logger.info("开始调用 AI 服务...")
            chatbot = ChatBot()
            response = chatbot.chat(message, history_messages)
            logger.info("AI 响应成功")
            
            # 保存AI响应
            ChatMessage.objects.create(
                chat_history=chat_history,
                role='assistant',
                content=response
            )
            
            return JsonResponse({
                'success': True,
                'answer': response,
                'chat_id': chat_history.id
            })
            
        except OllamaServiceError as e:
            logger.error(f"AI 服务错误: {str(e)}")
            return JsonResponse({
                'error': str(e),
                'error_code': 'OLLAMA_SERVICE_ERROR',
                'details': str(e)
            }, status=503)
            
    except json.JSONDecodeError as e:
        logger.error(f"JSON decode error: {str(e)}")
        return JsonResponse({'error': '无效的请求格式'}, status=400)
    except Exception as e:
        logger.error(f"Chat error: {str(e)}")
        return JsonResponse({'error': '服务器内部错误', 'details': str(e)}, status=500)

@login_required
@require_http_methods(["POST"])
def new_chat(request):
    """创建新的聊天会话"""
    chat = ChatHistory.objects.create(user=request.user)
    return JsonResponse({
        'success': True,
        'chat_id': chat.id
    })

@csrf_exempt
@require_http_methods(["POST"])
def study_plan(request):
    """处理学习规划请求"""
    try:
        data = json.loads(request.body)
        subject = data.get('subject')
        goal = data.get('goal')
        duration = data.get('duration')
        
        if not all([subject, goal, duration]):
            return JsonResponse({'error': '请提供完整的学习规划信息'}, status=400)
            
        plan = chatbot.generate_study_plan(subject, goal, duration)
        
        # 记录操作历史
        UserOperationHistory.objects.create(
            user=request.user,
            operation_type='study_plan',
            content=f"subject: {subject}, goal: {goal}, duration: {duration}",
            result=plan
        )
        
        return JsonResponse({'plan': plan})
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@require_http_methods(["POST"])
def translate(request):
    """处理翻译请求"""
    try:
        data = json.loads(request.body)
        text = data.get('text')
        source_lang = data.get('source_lang')
        target_lang = data.get('target_lang')
        
        if not text or not target_lang:
            return JsonResponse({'error': '请提供完整的翻译信息'}, status=400)
            
        translation_service = TranslationService()
        translation = translation_service.translate(text, source_lang, target_lang)
        
        # 添加日志输出以便调试
        logger.info(f"Translation request - Text: {text}, Result: {translation}")
        
        # 记录操作历史
        UserOperationHistory.objects.create(
            user=request.user,
            operation_type='translate',
            content=f"text: {text}, source_lang: {source_lang}, target_lang: {target_lang}",
            result=translation
        )
        
        return JsonResponse({'translation': translation})
        
    except Exception as e:
        logger.error(f"Translation error: {str(e)}")
        return JsonResponse({
            'error': '翻译失败',
            'error_code': 'TRANSLATION_ERROR',
            'details': str(e)
        }, status=500)

def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

def login_view(request):
    if request.user.is_authenticated:
        return redirect('index')
        
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        remember = request.POST.get('remember')
        
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            
            # 记录登录历史
            UserLoginHistory.objects.create(
                user=user,
                ip_address=get_client_ip(request),
                user_agent=request.META.get('HTTP_USER_AGENT', '')
            )
            
            # 更新用户资料的最后登录IP
            profile, created = UserProfile.objects.get_or_create(user=user)
            profile.last_login_ip = get_client_ip(request)
            profile.save()
            
            if not remember:
                request.session.set_expiry(0)
            return redirect('index')
        else:
            messages.error(request, '用户名或密码错误')
            
    return render(request, 'login.html')

def register_view(request):
    if request.user.is_authenticated:
        return redirect('index')
        
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        
        if password1 != password2:
            messages.error(request, '两次输入的密码不一致')
            return render(request, 'register.html')
            
        if User.objects.filter(username=username).exists():
            messages.error(request, '用户名已存在')
            return render(request, 'register.html')
            
        if User.objects.filter(email=email).exists():
            messages.error(request, '邮箱已被注册')
            return render(request, 'register.html')
            
        # 创建用户
        user = User.objects.create_user(username=username, email=email, password=password1)
        
        # 创建用户资料
        UserProfile.objects.create(
            user=user,
            last_login_ip=get_client_ip(request)
        )
        
        # 创建用户设置
        UserSettings.objects.create(user=user)
        
        # 记录首次登录历史
        UserLoginHistory.objects.create(
            user=user,
            ip_address=get_client_ip(request),
            user_agent=request.META.get('HTTP_USER_AGENT', '')
        )
        
        login(request, user)
        messages.success(request, '注册成功')
        return redirect('index')
        
    return render(request, 'register.html')

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required(login_url='login')
def history_view(request):
    """查看历史记录"""
    histories = request.user.operation_history.all()
    return render(request, 'history.html', {'histories': histories})

@login_required
@require_http_methods(["GET"])
def chat_history(request, chat_id):
    """获取聊天历史记录"""
    try:
        chat = get_object_or_404(ChatHistory, id=chat_id, user=request.user)
        messages = chat.messages.all()
        
        return JsonResponse({
            'success': True,
            'messages': [{
                'role': msg.role,
                'content': msg.content,
                'created_at': msg.created_at.strftime("%Y-%m-%d %H:%M:%S")
            } for msg in messages]
        })
        
    except Exception as e:
        logger.error(f"获取聊天历史失败: {str(e)}")
        return JsonResponse({
            'error': '获取聊天历史失败',
            'error_code': 'HISTORY_ERROR'
        }, status=500)

@login_required
@require_http_methods(["GET", "POST"])
def notes_view(request):
    """笔记管理页面"""
    # 获取所有笔记分类
    categories = Note.objects.filter(user=request.user).values_list('category', flat=True).distinct()
    
    context = {
        'notes': request.user.notes.all(),
        'categories': categories
    }
    return render(request, 'summarize.html', context)

@login_required
@require_http_methods(["GET"])
def get_note(request, note_id):
    """获取单个笔记"""
    try:
        note = get_object_or_404(Note, id=note_id, user=request.user)
        return JsonResponse({
            'id': note.id,
            'title': note.title,
            'content': note.content,
            'summary': note.summary,
            'category': note.category,
            'tags': note.tags,
            'updated_at': note.updated_at.strftime("%Y-%m-%d %H:%M:%S")
        })
    except Exception as e:
        logger.error(f"获取笔记失败: {str(e)}")
        return JsonResponse({'error': '获取笔记失败'}, status=500)

@login_required
@require_http_methods(["POST"])
def save_note(request):
    """保存笔记"""
    try:
        data = json.loads(request.body)
        note_id = data.get('note_id')
        title = data.get('title')
        content = data.get('content')
        tags = data.get('tags', '')
        
        if not title or not content:
            return JsonResponse({'error': '标题和内容不能为空'}, status=400)
        
        # 生成摘要和分类
        try:
            summary = note_service.generate_summary(content)
            category = note_service.classify_note(content)
            # 确保分类长度不超过限制
            category = category[:100] if category else '未分类'
        except Exception as e:
            logger.warning(f"AI处理失败: {str(e)}")
            summary = ''
            category = '未分类'
            
        if note_id:
            # 更新现有笔记
            note = get_object_or_404(Note, id=note_id, user=request.user)
            note.title = title
            note.content = content
            note.tags = tags
            note.summary = summary
            note.category = category
        else:
            # 创建新笔记
            note = Note(
                user=request.user,
                title=title,
                content=content,
                summary=summary,
                category=category,
                tags=tags
            )
            
        note.save()
        
        # 获取所有分类供前端更新
        all_categories = list(Note.objects.filter(user=request.user)
                            .values_list('category', flat=True)
                            .distinct())
        
        return JsonResponse({
            'success': True,
            'note': {
                'id': note.id,
                'title': note.title,
                'content': note.content,
                'summary': note.summary,
                'category': note.category,
                'tags': note.tags,
                'updated_at': note.updated_at.strftime("%Y-%m-%d %H:%M:%S")
            },
            'categories': all_categories
        })
        
    except Exception as e:
        logger.error(f"保存笔记失败: {str(e)}")
        return JsonResponse({'error': '保存笔记失败'}, status=500)

@login_required
@require_http_methods(["POST"])
def generate_note_summary(request):
    """生成笔记摘要"""
    try:
        data = json.loads(request.body)
        content = data.get('content')
        
        if not content:
            return JsonResponse({'error': '请提供笔记内容'}, status=400)
            
        summary = note_service.generate_summary(content)
        return JsonResponse({'success': True, 'summary': summary})
        
    except Exception as e:
        logger.error(f"生成摘要失败: {str(e)}")
        return JsonResponse({'error': '生成摘要失败'}, status=500)

@login_required
@require_http_methods(["POST"])
def classify_note(request):
    """智能分类笔记"""
    try:
        data = json.loads(request.body)
        content = data.get('content')
        
        if not content:
            return JsonResponse({'error': '请提供笔记内容'}, status=400)
            
        category = note_service.classify_note(content)
        return JsonResponse({'success': True, 'category': category})
        
    except Exception as e:
        logger.error(f"分类失败: {str(e)}")
        return JsonResponse({'error': '分类失败'}, status=500)

@login_required
@require_http_methods(["POST"])
def delete_note(request, note_id):
    """删除笔记"""
    try:
        note = get_object_or_404(Note, id=note_id, user=request.user)
        note.delete()
        return JsonResponse({'success': True})
    except Exception as e:
        logger.error(f"删除笔记失败: {str(e)}")
        return JsonResponse({'error': '删除笔记失败'}, status=500)

@login_required
@require_http_methods(["POST"])
def upload_note(request):
    """上传笔记文件"""
    try:
        file = request.FILES.get('file')
        if not file:
            return JsonResponse({'error': '请选择文件'}, status=400)
            
        # 获取文件类型
        file_type = file_processor.get_file_type(file.name)
        if not file_type:
            return JsonResponse({'error': '不支持的文件类型'}, status=400)
            
        # 提取文本
        text_content = file_processor.extract_text(file, file_type)
        
        # 创建笔记
        note = Note.objects.create(
            user=request.user,
            title=os.path.splitext(file.name)[0],
            content=text_content,
            file_type=file_type,
            original_file=file,
            category='图片' if file_type == 'image' else '未分类'  # 图片类型直接归类为"图片"
        )
        
        # 如果不是图片，则生成摘要和分类
        if file_type != 'image':
            note.summary = summarizer.generate_summary(text_content)
            note.category = summarizer.classify_note(text_content)
            note.save()
        
        return JsonResponse({
            'success': True,
            'note_id': note.id,
            'title': note.title,
            'content': text_content,
            'summary': note.summary,
            'category': note.category,
            'updated_at': note.updated_at.strftime('%Y-%m-%d %H:%M:%S'),
            'file_type': file_type,  # 添加文件类型信息
            'file_url': note.original_file.url if note.original_file else None  # 添加文件URL
        })
        
    except Exception as e:
        logger.error(f"文件上传失败: {str(e)}")
        return JsonResponse({'error': '文件处理失败'}, status=500)

@login_required
@require_POST
def update_theme(request):
    try:
        data = json.loads(request.body)
        theme = data.get('theme')
        
        if theme not in ['light', 'dark']:
            return JsonResponse({'error': '无效的主题设置'}, status=400)
            
        # 更新用户设置
        request.user.settings.theme = theme
        request.user.settings.save()
        
        return JsonResponse({'status': 'success'})
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)
