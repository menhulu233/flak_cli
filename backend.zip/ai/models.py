from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    avatar = models.ImageField(upload_to='avatars/', null=True, blank=True)
    bio = models.TextField(max_length=500, blank=True)
    created_at = models.DateTimeField(default=timezone.now)
    last_login_ip = models.GenericIPAddressField(null=True, blank=True)
    
    class Meta:
        db_table = 'user_profiles'
        
    def __str__(self):
        return f"{self.user.username}'s profile"

class UserLoginHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='login_history')
    login_time = models.DateTimeField(default=timezone.now)
    ip_address = models.GenericIPAddressField()
    user_agent = models.CharField(max_length=500)
    
    class Meta:
        db_table = 'user_login_history'
        ordering = ['-login_time']
        
    def __str__(self):
        return f"{self.user.username} - {self.login_time}"

class UserSettings(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='settings')
    theme = models.CharField(max_length=20, default='light')
    language = models.CharField(max_length=10, default='zh')
    notification_enabled = models.BooleanField(default=True)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'user_settings'
        
    def __str__(self):
        return f"{self.user.username}'s settings"

class UserOperationHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='operation_history')
    operation_type = models.CharField(max_length=50)  # 操作类型：summarize, chat, translate 等
    content = models.TextField()  # 操作内容
    result = models.TextField()   # 操作结果
    created_at = models.DateTimeField(default=timezone.now)
    
    class Meta:
        db_table = 'user_operation_history'
        ordering = ['-created_at']
        
    def __str__(self):
        return f"{self.user.username} - {self.operation_type} - {self.created_at}"

class ChatHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='chat_histories')
    title = models.CharField(max_length=100, default="新对话")
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'chat_histories'
        ordering = ['-updated_at']
        
    def __str__(self):
        return f"{self.user.username} - {self.title}"

class ChatMessage(models.Model):
    chat_history = models.ForeignKey(ChatHistory, on_delete=models.CASCADE, related_name='messages')
    role = models.CharField(max_length=10)  # user 或 assistant
    content = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)
    
    class Meta:
        db_table = 'chat_messages'
        ordering = ['created_at']

class Note(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notes')
    title = models.CharField(max_length=200)
    content = models.TextField()
    summary = models.TextField(blank=True)
    category = models.CharField(max_length=100)
    tags = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    
    # 添加文件相关字段
    original_file = models.FileField(upload_to='notes/files/%Y/%m/', null=True, blank=True)
    file_type = models.CharField(max_length=20, blank=True)  # 文件类型：image, pdf, word, ppt
    
    class Meta:
        db_table = 'notes'
        ordering = ['-updated_at']
        
    def __str__(self):
        return f"{self.user.username} - {self.title}"
