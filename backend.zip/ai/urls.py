from django.urls import path
from . import views

urlpatterns = [
    path('api/chat', views.chat, name='chat'),
    path('api/chat/upload', views.chat_upload, name='chat_upload'),
    # ... 其他路由
] 