from app import login_required
from loginapp import app
from loginapp import db
from flask import redirect, render_template, session, url_for, request

@app.route('/admin/users')
@login_required('admin')
def list_users():
    q_role   = request.args.get('role')
    q_status = request.args.get('status')
    sql = "SELECT u.user_id,u.username,u.full_name,u.email,u.role,u.status FROM users u WHERE 1=1"
    args = []
    if q_role:
        sql += " AND u.role=?"
        args.append(q_role)
    if q_status:
        sql += " AND u.status=?"
        args.append(q_status)
    cur = db.get_db().cursor()
    cur.execute(sql, args)
    users = cur.fetchall()
    return render_template('user_list.html', users=users)

@app.route('/admin/user/<int:uid>/status', methods=['POST'])
@login_required('admin')
def toggle_user_status(uid):
    new_status = request.form['status']  # 'active' or 'inactive'
    cur = db.get_db().cursor()
    cur.execute("UPDATE users SET status=? WHERE user_id=?", (new_status,uid))
    db.get_db().commit()
    return ('',204)
