import os
from flask import flash, render_template, redirect, url_for, session, request

from app import login_required
from loginapp.user import ALLOWED_RESUME_EXT, allowed_file
from . import app, db

@app.route('/student/home')
def student_home():
    # Check if logged in and correct role
    if not session.get('loggedin') or session.get('role') != 'student':
        return redirect(url_for('login'))
    return render_template('student_home.html')

@app.route('/student/internships')
@login_required('student')
def browse_internships():
    # Optional filters:
    cat    = request.args.get('category')
    loc    = request.args.get('location')
    dur    = request.args.get('duration')
    sql = "SELECT * FROM internship WHERE deadline >= CURDATE()"
    args = []
    if cat:
        sql += " AND FIND_IN_SET(%s, skills_required)"
        args.append(cat)
    if loc:
        sql += " AND location LIKE %s"
        args.append(f"%{loc}%")
    if dur:
        sql += " AND duration = %s"
        args.append(dur)
    cur = db.get_db().cursor()
    cur.execute(sql, args)
    internships = cur.fetchall()
    return render_template('internships.html', internships=internships)

@app.route('/student/apply/<int:iid>', methods=['GET','POST'])
@login_required('student')
def apply_internship(iid):
    sid = session['user_id']
    if request.method=='POST':
        note = request.form['cover_letter']
        # Optionally replace resume
        resume = request.files.get('resume')
        resume_path = None
        if resume and allowed_file(resume.filename, ALLOWED_RESUME_EXT):
            fn = secure_filename(f"app_{sid}_{iid}_" + resume.filename)
            resume.save(os.path.join(app.config['UPLOAD_FOLDER'],fn))
            resume_path = fn
            # update student.resume_path if you want…
        cur = db.get_db().cursor()
        cur.execute(
          "INSERT INTO application (student_id,internship_id,feedback) "
          "VALUES (%s,%s,%s) ON DUPLICATE KEY UPDATE feedback=%s, status='submitted'",
          (sid, iid, note, note)
        )
        db.get_db().commit()
        flash('Application submitted')
        return redirect(url_for('view_my_applications'))
    # GET:
    cur = db.get_db().cursor()
    cur.execute("SELECT * FROM internship WHERE internship_id=%s", (iid,))
    internship = cur.fetchone()
    return render_template('apply.html', internship=internship)

@app.route('/student/applications')
@login_required('student')
def view_my_applications():
    sid = session['user_id']
    cur = db.get_db().cursor()
    cur.execute("""
      SELECT i.title,a.status,a.feedback 
        FROM application a
        JOIN internship i ON a.internship_id=i.internship_id
       WHERE a.student_id=%s
    """, (sid,))
    apps = cur.fetchall()
    return render_template('applications.html', apps=apps)