from loginapp import app
from flask import (
    Flask, render_template, request, redirect,
    url_for, session, flash
)
import pymysql
from werkzeug.security import generate_password_hash, check_password_hash

app.secret_key = 'replace-me-with-a-secure-random-key'

# --- adjust these to match your local MySQL setup ---
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'db': 'brightpathcareers',
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

def get_db_connection():
    return pymysql.connect(**DB_CONFIG)

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db_connection()
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM users WHERE username=%s", (username,))
            user = cur.fetchone()
        conn.close()

        if user and check_password_hash(user['password_hash'], password):
            session.clear()
            session['user_id']  = user['user_id']
            session['username'] = user['username']
            session['role']     = user['role']
            return redirect(url_for(f"{user['role']}_home"))
        else:
            flash('Invalid username or password')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

def login_required(role):
    """Simple decorator factory to enforce login & role checks."""
    def wrapper(fn):
        def decorated_view(*args, **kwargs):
            if 'role' not in session or session['role'] != role:
                return redirect(url_for('login'))
            return fn(*args, **kwargs)
        decorated_view.__name__ = fn.__name__
        return decorated_view
    return wrapper

@app.route('/customer_home')
@login_required('customer')
def customer_home():
    return render_template('customer_home.html')

@app.route('/staff_home')
@login_required('staff')
def staff_home():
    return render_template('staff_home.html')

@app.route('/admin_home')
@login_required('admin')
def admin_home():
    return render_template('admin_home.html')

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = get_db_connection()
    with conn.cursor() as cur:
        cur.execute(
            "SELECT user_id, username, full_name, email, role "
            "FROM users WHERE user_id=%s",
            (session['user_id'],)
        )
        profile = cur.fetchone()
    conn.close()
    return render_template('profile.html', profile=profile)

if __name__ == '__main__':
    app.run(debug=True)