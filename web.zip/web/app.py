"""
中医药知识图谱Web平台主应用
基于Flask与Neo4j构建
"""

from flask import Flask, render_template, request, jsonify, redirect, url_for, session, g, flash
from py2neo import Graph, Node, Relationship
from pyvis.network import Network
import json
from config import Config
import os
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import hashlib
try:
    getattr(hashlib, 'scrypt')
except AttributeError:
    import pyscrypt


    def _scrypt_compat(password_bytes, salt, n, r, p, maxmem=None):
        return pyscrypt.hash(password_bytes, salt, n, r, p, dkLen=64)
    hashlib.scrypt = _scrypt_compat
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from functools import wraps
from datetime import datetime

app = Flask(__name__)
app.config.from_object(Config)

# 初始化Neo4j连接
try:
    graph = Graph(
        app.config['NEO4J_URI'],
        auth=(app.config['NEO4J_USER'], app.config['NEO4J_PASSWORD'])
    )
    print("Neo4j连接成功！")
except Exception as e:
    print(f"Neo4j连接失败: {e}")
    graph = None


########################################
#           用户认证与存储层
########################################
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'users.db')


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_user_db():
    conn = get_db()
    try:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE,
            password_hash TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
        """)
        conn.commit()
    finally:
        conn.close()


init_user_db()


def generate_reset_token(email: str) -> str:
    serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])
    return serializer.dumps(email, salt='password-reset')


def verify_reset_token(token: str, max_age_seconds: int = 3600) -> str:
    serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])
    try:
        email = serializer.loads(token, salt='password-reset', max_age=max_age_seconds)
        return email
    except (BadSignature, SignatureExpired):
        return ''


def login_required(view_func):
    @wraps(view_func)
    def wrapped_view(*args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('login', next=request.path))
        return view_func(*args, **kwargs)
    return wrapped_view


@app.before_request
def load_logged_in_user():
    user_id = session.get('user_id')
    g.user = None
    if user_id:
        conn = get_db()
        try:
            cur = conn.execute("SELECT id, username, email FROM users WHERE id = ?", (user_id,))
            row = cur.fetchone()
            if row:
                g.user = dict(row)
        finally:
            conn.close()


########################################
#               认证路由
########################################
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        next_url = request.args.get('next') or url_for('index')
        if not username or not password:
            flash('用户名或密码不能为空', 'danger')
            return render_template('login.html')
        conn = get_db()
        try:
            cur = conn.execute("SELECT id, username, email, password_hash FROM users WHERE username = ?", (username,))
            user = cur.fetchone()
            if not user:
                flash('用户名或密码错误', 'danger')
                return render_template('login.html')
            try:
                ok = check_password_hash(user['password_hash'], password)
            except Exception:
                flash('密码校验失败：当前环境不支持该加密算法，请使用“忘记密码”重置密码或重新注册', 'danger')
                return render_template('login.html')
            if not ok:
                flash('用户名或密码错误', 'danger')
                return render_template('login.html')
            session['user_id'] = user['id']
            flash('登录成功', 'success')
            return redirect(next_url)
        finally:
            conn.close()
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()
        confirm = request.form.get('confirm', '').strip()
        if not username or not password:
            flash('用户名与密码必填', 'danger')
            return render_template('register.html')
        if password != confirm:
            flash('两次输入的密码不一致', 'danger')
            return render_template('register.html')
        conn = get_db()
        try:
            cur = conn.execute("SELECT 1 FROM users WHERE username = ? OR email = ?", (username, email or None))
            if cur.fetchone():
                flash('用户名或邮箱已存在', 'danger')
                return render_template('register.html')
            password_hash = generate_password_hash(password, method='pbkdf2:sha256')
            conn.execute("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)", (username, email or None, password_hash))
            conn.commit()
            flash('注册成功，请登录', 'success')
            return redirect(url_for('login'))
        finally:
            conn.close()
    return render_template('register.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('您已退出登录', 'info')
    return redirect(url_for('login'))


@app.route('/forgot', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        if not email:
            flash('请输入注册邮箱', 'danger')
            return render_template('forgot_password.html')
        conn = get_db()
        try:
            cur = conn.execute("SELECT id FROM users WHERE email = ?", (email,))
            user = cur.fetchone()
            if not user:
                flash('该邮箱未注册', 'warning')
                return render_template('forgot_password.html')
        finally:
            conn.close()
        token = generate_reset_token(email)
        # 这里可集成邮件发送。当前展示重置链接以便测试。
        reset_link = url_for('reset_password', token=token, _external=True)
        flash(f'重置链接已生成：{reset_link}', 'info')
        return redirect(url_for('login'))
    return render_template('forgot_password.html')


@app.route('/reset/<token>', methods=['GET', 'POST'])
def reset_password(token):
    email = verify_reset_token(token)
    if not email:
        flash('重置链接无效或已过期', 'danger')
        return redirect(url_for('forgot_password'))
    if request.method == 'POST':
        password = request.form.get('password', '').strip()
        confirm = request.form.get('confirm', '').strip()
        if not password:
            flash('请输入新密码', 'danger')
            return render_template('reset_password.html')
        if password != confirm:
            flash('两次输入的密码不一致', 'danger')
            return render_template('reset_password.html')
        conn = get_db()
        try:
            conn.execute("UPDATE users SET password_hash = ? WHERE email = ?", (generate_password_hash(password, method='pbkdf2:sha256'), email))
            conn.commit()
            flash('密码已重置，请登录', 'success')
            return redirect(url_for('login'))
        finally:
            conn.close()
    return render_template('reset_password.html')


@app.route('/')
@login_required
def index():
    """首页"""
    return render_template('index.html')


@app.route('/api/demo')
def api_demo():
    """简单的演示API - 返回一些示例数据"""
    if not graph:
        return jsonify({
            'status': 'warning',
            'message': '数据库未连接，返回示例数据',
            'data': {
                'herbs': ['金银花', '人参', '黄芪', '当归', '枸杞', '甘草'],
                'efficacies': ['清热解毒', '大补元气', '补气升阳', '补血活血'],
                'diseases': ['感冒', '气虚乏力', '脾虚泄泻', '月经不调']
            }
        })
    
    try:
        # 获取前6个中药
        herbs_query = """
        MATCH (h:Herb)
        RETURN h.name as name
        LIMIT 6
        """
        herbs_result = graph.run(herbs_query).data()
        
        return jsonify({
            'status': 'success',
            'message': '数据获取成功',
            'data': {
                'herbs': [item['name'] for item in herbs_result] if herbs_result else []
            }
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'查询失败: {str(e)}'
        }), 500


@app.route('/api/popular-herbs')
def api_popular_herbs():
    if not graph:
        return jsonify({
            'status': 'warning',
            'data': {
                'herbs': [
                    {'name': '金银花', 'pinyin': '', 'class_chinese': '', 'degree': 0},
                    {'name': '人参', 'pinyin': '', 'class_chinese': '', 'degree': 0},
                    {'name': '黄芪', 'pinyin': '', 'class_chinese': '', 'degree': 0},
                    {'name': '当归', 'pinyin': '', 'class_chinese': '', 'degree': 0},
                    {'name': '枸杞', 'pinyin': '', 'class_chinese': '', 'degree': 0},
                    {'name': '甘草', 'pinyin': '', 'class_chinese': '', 'degree': 0}
                ]
            }
        })
    try:
        labels_rows = graph.run("""
        MATCH (n)
        UNWIND labels(n) AS label
        RETURN DISTINCT label
        """).data()
        all_labels = [row['label'] for row in labels_rows]

        def filter_labels(patterns, labels):
            pls = [p.lower() for p in patterns]
            return [l for l in labels if any(p in l.lower() for p in pls)]
        herb_labels = filter_labels(['Herb','中药','药材','草药','中药名'], all_labels)
        cond = "ANY(l IN labels(h) WHERE l IN $labels)" if herb_labels else "true"
        q = f"""
        MATCH (h)
        WHERE {cond}
        OPTIONAL MATCH (h)-[r]-()
        WITH h, count(r) AS deg
        RETURN coalesce(h.name,'') AS name, h.pinyin AS pinyin, h.class_chinese AS class_chinese, deg
        ORDER BY deg DESC, name
        LIMIT $limit
        """
        rows = graph.run(q, labels=herb_labels or [], limit=12).data()
        return jsonify({
            'status': 'success',
            'data': {
                'herbs': rows
            }
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'查询失败: {str(e)}'}), 500


@app.route('/api/test-db')
def api_test_db():
    """测试Neo4j数据库连接API"""
    if not graph:
        return jsonify({
            'status': 'failed',
            'message': '数据库连接失败',
            'connection_info': {
                'uri': app.config['NEO4J_URI'],
                'user': app.config['NEO4J_USER']
            }
        }), 500
    
    try:
        # 测试查询
        test_query = "RETURN 'Hello from Neo4j!' as message"
        result = graph.run(test_query).data()
        
        # 获取节点数量统计
        count_query = """
        MATCH (n)
        RETURN count(n) as total_nodes
        """
        count_result = graph.run(count_query).data()
        total_nodes = count_result[0]['total_nodes'] if count_result else 0
        
        # 获取节点类型统计
        type_query = """
        MATCH (n)
        RETURN labels(n)[0] as type, count(n) as count
        ORDER BY type
        """
        type_results = graph.run(type_query).data()
        
        return jsonify({
            'status': 'success',
            'message': 'Neo4j数据库连接成功！',
            'connection_info': {
                'uri': app.config['NEO4J_URI'],
                'user': app.config['NEO4J_USER']
            },
            'test_result': result[0] if result else None,
            'statistics': {
                'total_nodes': total_nodes,
                'node_types': {item['type']: item['count'] for item in type_results}
            }
        })
    
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'数据库查询失败: {str(e)}',
            'connection_info': {
                'uri': app.config['NEO4J_URI'],
                'user': app.config['NEO4J_USER']
            }
        }), 500


@app.route('/api/node-types')
def api_node_types():
    if not graph:
        return jsonify({
            'status': 'error',
            'message': '数据库未连接'
        }), 500
    try:
        query = """
        MATCH (n)
        UNWIND labels(n) AS label
        RETURN label, count(DISTINCT n) AS count
        ORDER BY label
        """
        result = graph.run(query).data()
        labels = [item['label'] for item in result]
        stats = {item['label']: item['count'] for item in result}
        return jsonify({
            'status': 'success',
            'labels': labels,
            'stats': stats
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'查询失败: {str(e)}'
        }), 500


@app.route('/search')
def search():
    """搜索页面"""
    query = request.args.get('q', '').strip()
    return render_template('search.html', query=query)


@app.route('/api/search')
def api_search():
    """搜索API - 支持搜索中药、疾病、功效"""
    if not graph:
        return jsonify({
            'status': 'error',
            'message': '数据库未连接'
        }), 500
    query = request.args.get('q', '').strip()
    if not query:
        return jsonify({
            'status': 'error',
            'message': '搜索关键词不能为空'
        }), 400
    try:
        q = query
        results = {'herbs': [], 'diseases': [], 'efficacies': [], 'syndromes': []}
        labels_query = """
        MATCH (n)
        UNWIND labels(n) AS label
        RETURN DISTINCT label
        """
        label_rows = graph.run(labels_query).data()
        all_labels = [row['label'] for row in label_rows]

        def filter_labels(patterns, labels):
            pls = [p.lower() for p in patterns]
            return [l for l in labels if any(p in l.lower() for p in pls)]
        herb_labels = filter_labels(['Herb','中药','药材','草药','中药名'], all_labels)
        disease_labels = filter_labels(['Disease','疾病'], all_labels)
        efficacy_labels = filter_labels(['Efficacy','功效','功能主治','主治','适应症'], all_labels)
        syndrome_labels = filter_labels(['Syndrome','证候'], all_labels)

        h_label_cond = "ANY(l IN labels(h) WHERE l IN $labels)" if herb_labels else "true"
        d_label_cond = "ANY(l IN labels(d) WHERE l IN $labels)" if disease_labels else "true"
        e_label_cond = "ANY(l IN labels(e) WHERE l IN $labels)" if efficacy_labels else "true"
        s_label_cond = "ANY(l IN labels(s) WHERE l IN $labels)" if syndrome_labels else "true"

        herbs_query = f"""
        MATCH (h)
        WHERE {h_label_cond}
          AND (
            toLower(coalesce(h.name,'')) CONTAINS toLower($q) OR
            toLower(coalesce(h.title,'')) CONTAINS toLower($q) OR
            toLower(coalesce(h.pinyin,'')) CONTAINS toLower($q)
          )
        RETURN coalesce(h.name,'') AS name, h.pinyin AS pinyin, h.class_chinese AS class_chinese
        LIMIT 20
        """
        results['herbs'] = [dict(row) for row in graph.run(herbs_query, q=q, labels=herb_labels or []).data()]

        diseases_query = f"""
        MATCH (d)
        WHERE {d_label_cond}
          AND (
            toLower(coalesce(d.name,'')) CONTAINS toLower($q) OR
            toLower(coalesce(d.title,'')) CONTAINS toLower($q) OR
            toLower(coalesce(d.definition,'')) CONTAINS toLower($q)
          )
        RETURN coalesce(d.name,'') AS name, coalesce(d.definition, d.description, '') AS definition
        LIMIT 20
        """
        if disease_labels:
            results['diseases'] = [dict(row) for row in graph.run(diseases_query, q=q, labels=disease_labels).data()]

        efficacies_query = f"""
        MATCH (e)
        WHERE {e_label_cond}
          AND (
            toLower(coalesce(e.name,'')) CONTAINS toLower($q) OR
            toLower(coalesce(e.title,'')) CONTAINS toLower($q) OR
            toLower(coalesce(e.description,'')) CONTAINS toLower($q)
          )
        RETURN coalesce(e.name,'') AS name, coalesce(e.description, e.title, '') AS description
        LIMIT 20
        """
        if efficacy_labels:
            results['efficacies'] = [dict(row) for row in graph.run(efficacies_query, q=q, labels=efficacy_labels).data()]

        syndromes_query = f"""
        MATCH (s)
        WHERE {s_label_cond}
          AND (
            toLower(coalesce(s.name,'')) CONTAINS toLower($q) OR
            toLower(coalesce(s.title,'')) CONTAINS toLower($q) OR
            toLower(coalesce(s.definition,'')) CONTAINS toLower($q)
          )
        RETURN coalesce(s.name,'') AS name, coalesce(s.definition, s.description, '') AS definition
        LIMIT 20
        """
        if syndrome_labels:
            results['syndromes'] = [dict(row) for row in graph.run(syndromes_query, q=q, labels=syndrome_labels).data()]

        total = sum(len(results[k]) for k in results.keys())

        return jsonify({'status': 'success', 'query': query, 'total': total, 'results': results})
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'搜索失败: {str(e)}'
        }), 500


@app.route('/herb/<herb_name>')
@login_required
def herb_detail(herb_name):
    """中药详情页"""
    return render_template('herb_detail.html', herb_name=herb_name)


@app.route('/api/herb/<herb_name>')
def api_herb_detail(herb_name):
    """获取中药详情API"""
    if not graph:
        return jsonify({
            'status': 'error',
            'message': '数据库未连接'
        }), 500
    
    try:
        # 动态识别中药标签并进行鲁棒匹配
        labels_rows = graph.run("""
        MATCH (n)
        UNWIND labels(n) AS label
        RETURN DISTINCT label
        """).data()
        all_labels = [row['label'] for row in labels_rows]

        def filter_labels(patterns, labels):
            pls = [p.lower() for p in patterns]
            return [l for l in labels if any(p in l.lower() for p in pls)]

        herb_labels = filter_labels(['Herb','中药','药材','草药','中药名'], all_labels)
        disease_labels = filter_labels(['Disease','疾病'], all_labels)
        efficacy_labels = filter_labels(['Efficacy','功效','功能主治','主治','适应症'], all_labels)

        h_label_cond = "ANY(l IN labels(h) WHERE l IN $hlabels)" if herb_labels else "true"
        d_label_cond = "ANY(l IN labels(d) WHERE l IN $dlabels)" if disease_labels else "true"
        e_label_cond = "ANY(l IN labels(e) WHERE l IN $elabels)" if efficacy_labels else "true"

        herb_query = f"""
        MATCH (h)
        WHERE {h_label_cond}
          AND (
            toLower(coalesce(h.name,'')) = toLower($name) OR
            toLower(coalesce(h.title,'')) = toLower($name) OR
            ANY(k IN keys(h) WHERE toLower(toString(h[k])) = toLower($name))
          )
        RETURN h
        LIMIT 1
        """
        herb_result = graph.run(herb_query, name=herb_name, hlabels=herb_labels or []).data()
        
        if not herb_result:
            return jsonify({
                'status': 'error',
                'message': '未找到该中药'
            }), 404
        
        herb_data = dict(herb_result[0]['h'])
        
        # 获取相关功效（不限定关系类型，按标签同义过滤）
        efficacies_query = f"""
        MATCH (h)
        WHERE {h_label_cond}
          AND (
            toLower(coalesce(h.name,'')) = toLower($name) OR
            toLower(coalesce(h.title,'')) = toLower($name) OR
            ANY(k IN keys(h) WHERE toLower(toString(h[k])) = toLower($name))
          )
        MATCH (h)-[r]-(e)
        WHERE {e_label_cond}
        RETURN DISTINCT e.name AS name, coalesce(e.description, e.title, '') AS description
        LIMIT 50
        """
        efficacies_result = graph.run(efficacies_query, name=herb_name, hlabels=herb_labels or [], elabels=efficacy_labels or []).data()
        herb_data['efficacies'] = [dict(item) for item in efficacies_result]
        
        # 获取相关疾病（通过功效或直接关系，标签同义过滤）
        diseases_query = f"""
        MATCH (h)
        WHERE {h_label_cond}
          AND (
            toLower(coalesce(h.name,'')) = toLower($name) OR
            toLower(coalesce(h.title,'')) = toLower($name) OR
            ANY(k IN keys(h) WHERE toLower(toString(h[k])) = toLower($name))
          )
        OPTIONAL MATCH (h)-[r1]-(e)
        WHERE {e_label_cond}
        OPTIONAL MATCH (e)-[r2]-(d1)
        WHERE {d_label_cond}
        OPTIONAL MATCH (h)-[r3]-(d2)
        WHERE {d_label_cond}
        WITH DISTINCT coalesce(d1, d2) AS d
        WHERE d IS NOT NULL
        RETURN d.name AS name, coalesce(d.definition, d.description, '') AS definition
        LIMIT 20
        """
        diseases_result = graph.run(diseases_query, name=herb_name, hlabels=herb_labels or [], elabels=efficacy_labels or [], dlabels=disease_labels or []).data()
        herb_data['related_diseases'] = [dict(item) for item in diseases_result]
        
        # 获取知识图谱数据（用于可视化，通用关系与标签过滤）
        graph_query = f"""
        MATCH (h)
        WHERE {h_label_cond}
          AND (
            toLower(coalesce(h.name,'')) = toLower($name) OR
            toLower(coalesce(h.title,'')) = toLower($name) OR
            ANY(k IN keys(h) WHERE toLower(toString(h[k])) = toLower($name))
          )
        MATCH (h)-[r]-(related)
        RETURN h, r, related
        LIMIT 80
        """
        graph_result = graph.run(graph_query, name=herb_name, hlabels=herb_labels or []).data()
        
        nodes = []
        edges = []
        node_ids = set()
        
        # 处理节点
        for record in graph_result:
            h = record['h']
            related = record['related']
            
            if h.identity not in node_ids:
                nodes.append({
                    'id': h.identity,
                    'label': h.get('name', ''),
                    'type': 'Herb',
                    'properties': dict(h)
                })
                node_ids.add(h.identity)
            
            if related.identity not in node_ids:
                label = list(related.labels)[0] if related.labels else 'Unknown'
                nodes.append({
                    'id': related.identity,
                    'label': related.get('name', ''),
                    'type': label,
                    'properties': dict(related)
                })
                node_ids.add(related.identity)
            
            # 处理关系
            r = record['r']
            edges.append({
                'from': h.identity,
                'to': related.identity,
                'label': type(r).__name__,
                'type': type(r).__name__
            })
        
        herb_data['graph'] = {
            'nodes': nodes,
            'edges': edges
        }
        
        return jsonify({
            'status': 'success',
            'data': herb_data
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'查询失败: {str(e)}'
        }), 500


@app.route('/disease/<disease_name>')
@login_required
def disease_detail(disease_name):
    """疾病详情页"""
    return render_template('disease_detail.html', disease_name=disease_name)


@app.route('/api/disease/<disease_name>')
def api_disease_detail(disease_name):
    """获取疾病详情API"""
    if not graph:
        return jsonify({
            'status': 'error',
            'message': '数据库未连接'
        }), 500
    
    try:
        # 获取疾病基本信息
        disease_query = """
        MATCH (d:Disease {name: $name})
        RETURN d
        """
        disease_result = graph.run(disease_query, name=disease_name).data()
        
        if not disease_result:
            return jsonify({
                'status': 'error',
                'message': '未找到该疾病'
            }), 404
        
        disease_data = dict(disease_result[0]['d'])
        
        # 获取相关中药（通过功效或直接关系）
        herbs_query = """
        MATCH (d:Disease {name: $name})
        OPTIONAL MATCH (d)<-[:TREATS]-(e:Efficacy)<-[:HAS_EFFICACY]-(h1:Herb)
        OPTIONAL MATCH (d)<-[:TREATS]-(h2:Herb)
        WITH DISTINCT COALESCE(h1, h2) as h
        WHERE h IS NOT NULL
        RETURN h.name as name, h.pinyin as pinyin, h.class_chinese as class_chinese
        LIMIT 20
        """
        herbs_result = graph.run(herbs_query, name=disease_name).data()
        disease_data['related_herbs'] = [dict(item) for item in herbs_result]
        
        return jsonify({
            'status': 'success',
            'data': disease_data
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'查询失败: {str(e)}'
        }), 500


@app.route('/graph')
@login_required
def graph_explorer():
    """知识图谱探索页面"""
    return render_template('global_explorer.html')


@app.route('/api/graph')
def api_graph():
    """获取知识图谱数据API"""
    if not graph:
        return jsonify({
            'status': 'error',
            'message': '数据库未连接'
        }), 500
    
    try:
        limit = int(request.args.get('limit', 100))
        node_type = request.args.get('type', '').strip()
        rel_type = request.args.get('rel', '').strip()
        q = request.args.get('q', '').strip()

        def sanitize(s):
            return ''.join(c for c in s if c.isalnum() or c == '_')

        label = sanitize(node_type) if node_type else ''
        rel = sanitize(rel_type) if rel_type else ''

        if q:
            if label:
                query = f"""
                MATCH (n:{label})
                WHERE n.name CONTAINS $q
                MATCH (n)-[r]-(related)
                """
                if rel:
                    query = f"""
                    MATCH (n:{label})
                    WHERE n.name CONTAINS $q
                    MATCH (n)-[r:{rel}]-(related)
                    """
            else:
                query = """
                MATCH (n)
                WHERE n.name CONTAINS $q
                MATCH (n)-[r]-(related)
                """
                if rel:
                    query = f"""
                    MATCH (n)
                    WHERE n.name CONTAINS $q
                    MATCH (n)-[r:{rel}]-(related)
                    """
            query += "RETURN DISTINCT n, r, related, type(r) AS rtype LIMIT $limit"
            result = graph.run(query, q=q, limit=limit * 2).data()
        else:
            if label and rel:
                query = f"""
                MATCH (n:{label})-[r:{rel}]-(related)
                RETURN n, r, related, type(r) AS rtype
                LIMIT $limit
                """
            elif label:
                query = f"""
                MATCH (n:{label})-[r]-(related)
                RETURN n, r, related, type(r) AS rtype
                LIMIT $limit
                """
            elif rel:
                query = f"""
                MATCH (n)-[r:{rel}]-(related)
                RETURN n, r, related, type(r) AS rtype
                LIMIT $limit
                """
            else:
                query = """
                MATCH (n)-[r]-(related)
                RETURN n, r, related, type(r) AS rtype
                LIMIT $limit
                """
            result = graph.run(query, limit=limit * 2).data()

        nodes = []
        edges = []
        node_ids = set()

        for record in result:
            n = record['n']
            related = record['related']

            if n.identity not in node_ids:
                label_name = list(n.labels)[0] if n.labels else 'Unknown'
                node_props = dict(n)
                nodes.append({
                    'id': n.identity,
                    'label': n.get('name', '') or n.get('title', '') or '',
                    'type': label_name,
                    'properties': node_props
                })
                node_ids.add(n.identity)

            if related.identity not in node_ids:
                label_name = list(related.labels)[0] if related.labels else 'Unknown'
                node_props = dict(related)
                nodes.append({
                    'id': related.identity,
                    'label': related.get('name', '') or related.get('title', '') or '',
                    'type': label_name,
                    'properties': node_props
                })
                node_ids.add(related.identity)

            r = record['r']
            _rt = record.get('rtype')
            _rt = _rt if isinstance(_rt, str) and _rt else type(r).__name__
            edges.append({
                'from': n.identity,
                'to': related.identity,
                'label': _rt,
                'type': _rt
            })

        return jsonify({
            'status': 'success',
            'data': {
                'nodes': nodes,
                'edges': edges,
                'counts': {
                    'nodes': len(nodes),
                    'edges': len(edges)
                }
            }
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'查询失败: {str(e)}'
        }), 500


@app.route('/consult')
def consult():
    return render_template('consult.html')


@app.route('/api/consult')
def api_consult():
    if not graph:
        return jsonify({
            'status': 'error',
            'message': '数据库未连接'
        }), 500
    symptom = request.args.get('symptom', '').strip()
    if not symptom:
        return jsonify({
            'status': 'error',
            'message': '症状关键词不能为空'
        }), 400
    try:
        labels_query = """
        MATCH (n)
        UNWIND labels(n) AS label
        RETURN DISTINCT label
        """
        label_rows = graph.run(labels_query).data()
        all_labels = [row['label'] for row in label_rows]

        def filter_labels(patterns, labels):
            pls = [p.lower() for p in patterns]
            return [l for l in labels if any(p in l.lower() for p in pls)]

        herb_labels = filter_labels(['Herb', '中药', '药材', '草药'], all_labels)
        symptom_labels = filter_labels(['Symptom', '症状'], all_labels)
        formula_labels = filter_labels(['Formula', '方剂', '方名', 'PrescriptionName', '方药'], all_labels)
        prescription_labels = filter_labels(['Prescription', 'Recipe', '处方', '配方'], all_labels)
        indication_labels = filter_labels(['Indication', '功能主治', '主治', '适应症'], all_labels)

        s_label_cond = "ANY(l IN labels(s) WHERE l IN $slabels)" if symptom_labels else "true"
        h_label_cond = "ANY(l IN labels(h) WHERE l IN $hlabels)" if herb_labels else "true"
        f_label_cond = "ANY(l IN labels(f) WHERE l IN $flabels)" if formula_labels else "true"
        p_label_cond = "ANY(l IN labels(p) WHERE l IN $plabels)" if prescription_labels else "true"
        i_label_cond = "ANY(l IN labels(i) WHERE l IN $ilabels)" if indication_labels else "true"

        graph_query = f"""
        MATCH (s)
        WHERE {s_label_cond}
          AND ANY(k IN keys(s) WHERE toLower(toString(s[k])) CONTAINS toLower($q))
        WITH s
        OPTIONAL MATCH (f)
        WHERE {f_label_cond}
          AND (
            EXISTS {{ MATCH (f)-[rs]-(s) }}
            OR EXISTS {{ MATCH (f)-[rfi]-(i) WHERE {i_label_cond} AND ANY(k IN keys(i) WHERE toLower(toString(i[k])) CONTAINS toLower($q)) }}
          )
        WITH s, collect(DISTINCT f) AS fs
        UNWIND fs AS f
        OPTIONAL MATCH (f)-[rs]-(s)
        OPTIONAL MATCH (f)-[rfp]-(p)
        WHERE {p_label_cond}
        OPTIONAL MATCH (p)-[rph]-(h)
        WHERE {h_label_cond}
        OPTIONAL MATCH (f)-[rfi]-(i)
        WHERE {i_label_cond}
        RETURN s, f, p, h, i,
               type(rs) AS rs_type,
               type(rfp) AS rfp_type,
               type(rph) AS rph_type,
               type(rfi) AS rfi_type,
               rph AS rph_obj
        LIMIT 300
        """
        gdata = graph.run(
            graph_query,
            q=symptom,
            slabels=symptom_labels or [],
            hlabels=herb_labels or [],
            flabels=formula_labels or [],
            plabels=prescription_labels or [],
            ilabels=indication_labels or []
        ).data()

        nodes = []
        edges = []
        node_ids = set()

        def add_node(nobj):
            if not nobj:
                return
            if nobj.identity in node_ids:
                return
            label = list(nobj.labels)[0] if nobj.labels else 'Unknown'
            nodes.append({
                'id': nobj.identity,
                'label': nobj.get('name', '') or nobj.get('title', '') or '',
                'type': label,
                'properties': dict(nobj)
            })
            node_ids.add(nobj.identity)

        for rec in gdata:
            s = rec.get('s')
            f = rec.get('f')
            p = rec.get('p')
            h = rec.get('h')
            i = rec.get('i')
            add_node(s)
            add_node(f)
            add_node(p)
            add_node(h)
            add_node(i)

            rs_type = rec.get('rs_type')
            rfp_type = rec.get('rfp_type')
            rph_type = rec.get('rph_type')
            rfi_type = rec.get('rfi_type')
            rph_obj = rec.get('rph_obj')

            if s and f and rs_type:
                edges.append({'from': s.identity, 'to': f.identity, 'label': rs_type, 'type': rs_type})
            if f and p and rfp_type:
                edges.append({'from': f.identity, 'to': p.identity, 'label': rfp_type, 'type': rfp_type})
            if p and h:
                _rt = rph_type if isinstance(rph_type, str) and rph_type else (type(rph_obj).__name__ if rph_obj else '')
                edge = {'from': p.identity, 'to': h.identity, 'label': _rt, 'type': _rt}
                if rph_obj:
                    try:
                        rprops = dict(rph_obj)
                    except Exception:
                        rprops = {}
                    dose = ''
                    unit = ''
                    for k, v in rprops.items():
                        lk = str(k).lower()
                        if lk in ('dose','dosage','amount','quantity','剂量','用量') and not dose:
                            dose = str(v)
                        if lk in ('unit','units','单位') and not unit:
                            unit = str(v)
                    if dose:
                        edge['dose'] = dose
                    if unit:
                        edge['unit'] = unit
                edges.append(edge)
            if f and i and rfi_type:
                edges.append({'from': f.identity, 'to': i.identity, 'label': rfi_type, 'type': rfi_type})

        table_query = f"""
        MATCH (s)
        WHERE {s_label_cond}
          AND ANY(k IN keys(s) WHERE toLower(toString(s[k])) CONTAINS toLower($q))
        WITH s
        MATCH (f)
        WHERE {f_label_cond}
          AND (
            EXISTS {{ MATCH (f)-[rs]-(s) }}
            OR EXISTS {{ MATCH (f)-[rfi]-(i) WHERE {i_label_cond} AND ANY(k IN keys(i) WHERE toLower(toString(i[k])) CONTAINS toLower($q)) }}
          )
        WITH DISTINCT f
        OPTIONAL MATCH (f)-[rfi]-(i)
        WHERE {i_label_cond}
        WITH f, collect(DISTINCT coalesce(i.name, i.description)) AS indications
        OPTIONAL MATCH (f)-[rfp]-(p)
        WHERE {p_label_cond}
        OPTIONAL MATCH (p)-[rph]-(h)
        WHERE {h_label_cond}
        WITH f, indications,
             collect(DISTINCT {{
                 name: h.name,
                 dose: reduce(val = '', k IN keys(rph) |
                       CASE WHEN val <> '' THEN val
                            WHEN k IN ['dose','dosage','amount','quantity','剂量','用量'] THEN toString(rph[k])
                            ELSE val END),
                 unit: reduce(val = '', k IN keys(rph) |
                       CASE WHEN val <> '' THEN val
                            WHEN k IN ['unit','units','单位'] THEN toString(rph[k])
                            ELSE val END)
             }}) AS herbs
        RETURN f.name AS formula, indications, herbs, size(herbs) AS herb_count
        ORDER BY herb_count DESC, formula
        LIMIT 30
        """
        trows = graph.run(
            table_query,
            q=symptom,
            slabels=symptom_labels or [],
            hlabels=herb_labels or [],
            flabels=formula_labels or [],
            plabels=prescription_labels or [],
            ilabels=indication_labels or []
        ).data()

        table = []
        for row in trows:
            item = dict(row)
            herbs = item.get('herbs') or []
            herb_list = []
            for h in herbs:
                herb_name = h.get('name') or ''
                dose = h.get('dose') or ''
                unit = h.get('unit') or ''
                if herb_name:
                    if dose and unit:
                        herb_list.append(f"{herb_name} {dose}{unit}")
                    elif dose:
                        herb_list.append(f"{herb_name} {dose}")
                    else:
                        herb_list.append(herb_name)
            table.append({
                'formula': item.get('formula') or '',
                'indications': item.get('indications') or [],
                'herbs': herbs,
                'herb_list': herb_list,
                'herb_count': item.get('herb_count') or 0
            })

        top = table[:5]
        parts = []
        for item in top:
            formula_name = item.get('formula') or ''
            inds = item.get('indications') or []
            desc = f"{formula_name}" + (f"（功能主治：{', '.join([i for i in inds if i])}）" if inds else "")
            if formula_name:
                parts.append(desc)
        answer = f"根据症状“{symptom}”，推荐方剂：" + ("、".join(parts) if parts else "暂无推荐")

        return jsonify({
            'status': 'success',
            'data': {
                'answer': answer,
                'table': table,
                'graph': {
                    'nodes': nodes,
                    'edges': edges
                }
            }
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'查询失败: {str(e)}'
        }), 500


# 采用 UI 项目的 PyVis 流程生成图谱 HTML 与表格数据
def build_graph_pyvis(symptom: str):
    if not graph:
        return None, []
    q = """
    MATCH (fj:方剂)-[:包含]->(fn:方名)-[:功能主治]->(gn:功能主治)
    WHERE gn.name CONTAINS $symptom
    MATCH (fn)-[:配方]->(cf:处方)
    WITH DISTINCT fj, fn, gn, cf
    MATCH (cf)-[:中药组成]->(herb:中药名)
    RETURN fj, fn, gn, cf, herb
    """
    rows = graph.run(q, symptom=symptom).data()
    if not rows:
        return None, []

    net = Network(height='600px', width='100%', directed=True)
    net.set_options('''
        {
          "nodes": { "font": { "size": 18 } },
          "edges": { "font": { "size": 10 } }
        }
    ''')

    nodes_added = set()
    edges_added = set()

    def add_node(nobj, label):
        nid = getattr(nobj, 'identity', None)
        if nid is None:
            return None
        if nid in nodes_added:
            return nid
        nodes_added.add(nid)
        color_map = {
            "方剂": "#C6EB87",
            "方名": "#87EBC1",
            "功能主治": "#EE90A1",
            "处方": "#FFD700",
            "中药名": "#69B2FF"
        }
        net.add_node(nid, label=nobj.get('name', ''), title=nobj.get('name', ''), color=color_map.get(label, "#D3D3D3"))
        return nid

    def add_edge(s, t, label):
        key = (s, t, label)
        if key in edges_added:
            return
        edges_added.add(key)
        net.add_edge(s, t, label=label)

    for rec in rows:
        fj = rec['fj']
        fn = rec['fn']
        gn = rec['gn']
        cf = rec['cf']
        herb = rec['herb']
        id_fj = add_node(fj, "方剂")
        id_fn = add_node(fn, "方名")
        id_gn = add_node(gn, "功能主治")
        id_cf = add_node(cf, "处方")
        id_herb = add_node(herb, "中药名")
        if id_fj and id_fn:
            add_edge(id_fj, id_fn, "包含")
        if id_fn and id_gn:
            add_edge(id_fn, id_gn, "功能主治")
        if id_fn and id_cf:
            add_edge(id_fn, id_cf, "配方")
        if id_cf and id_herb:
            add_edge(id_cf, id_herb, "中药组成")

    q_table = """
    MATCH (fj:方剂)-[:包含]->(fn:方名)-[:功能主治]->(gn:功能主治)
    WHERE gn.name CONTAINS $symptom
    MATCH (fn)-[:配方]->(cf:处方)-[r:中药组成]->(herb)
    OPTIONAL MATCH (fn)-[:功能主治]->(hgn:功能主治)
    RETURN fn.name AS formula_name, herb.name AS herb_name, r.weight AS weight, collect(DISTINCT hgn.name) AS herb_gn
    """
    trows = graph.run(q_table, symptom=symptom).data()
    table_data = [{
        "方名": row.get("formula_name"),
        "中药": row.get("herb_name"),
        "剂量": row.get("weight"),
        "中药功能主治": "；".join(row.get("herb_gn") or [])
    } for row in trows]

    static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
    os.makedirs(static_dir, exist_ok=True)
    graph_file = os.path.join(static_dir, 'graph.html')
    net.write_html(graph_file)
    return 'graph.html', table_data


@app.route('/consult', methods=['GET', 'POST'])
def consult_page():
    if request.method == 'POST':
        symptom = request.form.get('symptom', '').strip()
        graph_path, table_data = (None, [])
        if symptom:
            graph_path, table_data = build_graph_pyvis(symptom)
        return render_template('consult.html', graph_path=graph_path, table_data=table_data, symptom_value=symptom)
    return render_template('consult.html')


@app.route('/api/consult_pyvis')
def api_consult_pyvis():
    if not graph:
        return jsonify({'status': 'error', 'message': '数据库未连接'}), 500
    symptom = request.args.get('symptom', '').strip()
    if not symptom:
        return jsonify({'status': 'error', 'message': '症状关键词不能为空'}), 400
    graph_path, table_data = build_graph_pyvis(symptom)
    return jsonify({'status': 'success', 'graph_path': graph_path, 'table_data': table_data})


@app.route('/screen')
@login_required
def screen():
    return render_template('screen.html')


@app.route('/api/screen')
def api_screen():
    if not graph:
        return jsonify({'status': 'error', 'message': '数据库未连接'}), 500
    try:
        labels_rows = graph.run("""
        MATCH (n)
        UNWIND labels(n) AS label
        RETURN DISTINCT label
        """
        ).data()
        all_labels = [row['label'] for row in labels_rows]

        def filter_labels(patterns, labels):
            pls = [p.lower() for p in patterns]
            return [l for l in labels if any(p in l.lower() for p in pls)]
        herb_labels = filter_labels(['Herb','中药','药材','草药','中药名'], all_labels)
        formula_labels = filter_labels(['Formula','方剂','方名'], all_labels)
        prescription_labels = filter_labels(['Prescription','Recipe','处方','配方'], all_labels)
        indication_labels = filter_labels(['Indication','Efficacy','功效','功能','功能主治','主治','适应症'], all_labels)

        def count_by_labels(lbls):
            if not lbls:
                return 0
            q = """
            MATCH (n)
            WHERE ANY(l IN labels(n) WHERE l IN $labels)
            RETURN count(DISTINCT n) AS c
            """
            r = graph.run(q, labels=lbls).data()
            return r[0]['c'] if r else 0

        herbs_count = count_by_labels(herb_labels)
        formulas_count = count_by_labels(formula_labels)
        prescriptions_count = count_by_labels(prescription_labels)

        indications_count = 0
        if indication_labels:
            r = graph.run("""
            MATCH (i)
            WHERE ANY(l IN labels(i) WHERE l IN $labels)
            RETURN count(i) AS c
            """, labels=indication_labels).data()
            indications_count = r[0]['c'] if r else 0

        top_formulas = graph.run("""
        MATCH (f)
        WHERE $flabels = [] OR ANY(l IN labels(f) WHERE l IN $flabels)
        OPTIONAL MATCH (f)-[rfp]-(p)
        WHERE $plabels = [] OR ANY(l IN labels(p) WHERE l IN $plabels)
        OPTIONAL MATCH (p)-[rph]-(h)
        WHERE $hlabels = [] OR ANY(l IN labels(h) WHERE l IN $hlabels)
        WITH f, collect(DISTINCT h) AS herbs
        RETURN coalesce(f.name, '') AS name, size(herbs) AS herb_count
        ORDER BY herb_count DESC, name
        LIMIT 10
        """, flabels=formula_labels or [], plabels=prescription_labels or [], hlabels=herb_labels or []).data()

        herb_class = graph.run("""
        MATCH (h)
        WHERE $hlabels = [] OR ANY(l IN labels(h) WHERE l IN $hlabels)
        RETURN coalesce(h.class_chinese, '未分类') AS cls, count(DISTINCT h) AS cnt
        ORDER BY cnt DESC
        LIMIT 12
        """, hlabels=herb_labels or []).data()

        efficacy_dist = graph.run("""
        MATCH (i)
        WHERE $ilabels = [] OR ANY(l IN labels(i) WHERE l IN $ilabels)
        WITH i
        WHERE coalesce(i.name, i.title, i.description, '') <> ''
        OPTIONAL MATCH (h)-[*1..4]-(i)
        WHERE $hlabels = [] OR ANY(l IN labels(h) WHERE l IN $hlabels)
        WITH coalesce(i.name, i.title, i.description) AS name, count(DISTINCT h) AS cnt
        WHERE name <> '' AND cnt > 0
        RETURN name, cnt
        ORDER BY cnt DESC
        LIMIT 12
        """, ilabels=indication_labels or [], hlabels=herb_labels or []).data()

        degrees = graph.run("""
        MATCH (n)
        OPTIONAL MATCH (n)-[r]-()
        RETURN id(n) AS id, count(r) AS deg
        LIMIT 2000
        """
        ).data()
        buckets = {'0':0,'1-2':0,'3-5':0,'6-10':0,'>10':0}
        for row in degrees:
            d = int(row['deg'])
            if d == 0:
                buckets['0'] += 1
            elif d <= 2:
                buckets['1-2'] += 1
            elif d <= 5:
                buckets['3-5'] += 1
            elif d <= 10:
                buckets['6-10'] += 1
            else:
                buckets['>10'] += 1

        fnames = [row['name'] for row in top_formulas] if top_formulas else []
        pairs_rows = []
        if fnames:
            pairs_rows = graph.run(
                """
                MATCH (f)
                WHERE coalesce(f.name,'') IN $fnames
                  AND ($flabels = [] OR ANY(l IN labels(f) WHERE l IN $flabels))
                OPTIONAL MATCH (f)-[rfp]-(p)
                WHERE $plabels = [] OR ANY(l IN labels(p) WHERE l IN $plabels)
                OPTIONAL MATCH (p)-[rph]-(h)
                WHERE $hlabels = [] OR ANY(l IN labels(h) WHERE l IN $hlabels)
                RETURN DISTINCT coalesce(f.name,'') AS formula, coalesce(h.name,'') AS herb
                """,
                fnames=fnames,
                flabels=formula_labels or [],
                plabels=prescription_labels or [],
                hlabels=herb_labels or []
            ).data()
        herb_freq = {}
        for row in pairs_rows:
            herb = row.get('herb') or ''
            if herb:
                herb_freq[herb] = herb_freq.get(herb, 0) + 1
        top_herbs_for_matrix = [k for k, _ in sorted(herb_freq.items(), key=lambda x: (-x[1], x[0]))[:20]]
        pair_set = {(row['formula'], row['herb']) for row in pairs_rows if row.get('formula') and row.get('herb')}
        co_data = []
        for fi, f in enumerate(fnames):
            for hi, h in enumerate(top_herbs_for_matrix):
                co_data.append([hi, fi, 1 if (f, h) in pair_set else 0])

        top_herbs = graph.run("""
        MATCH (h)
        WHERE $hlabels = [] OR ANY(l IN labels(h) WHERE l IN $hlabels)
        OPTIONAL MATCH (h)-[r]-()
        RETURN coalesce(h.name, '') AS name, count(r) AS cnt
        ORDER BY cnt DESC, name
        LIMIT 80
        """, hlabels=herb_labels or []).data()
        herb_cloud = [{'name': row['name'], 'count': row['cnt']} for row in top_herbs if row.get('name')]

        return jsonify({
            'status': 'success',
            'data': {
                'metrics': {
                    'herbs': herbs_count,
                    'formulas': formulas_count,
                    'prescriptions': prescriptions_count,
                    'indications': indications_count
                },
                'top_formulas': [{'name': row['name'], 'herb_count': row['herb_count']} for row in top_formulas],
                'herb_class': [{'name': row['cls'], 'count': row['cnt']} for row in herb_class],
                'efficacy': [{'name': row['name'], 'count': row['cnt']} for row in efficacy_dist if row.get('name')],
                'degree_buckets': buckets,
                'co_matrix': {
                    'formulas': fnames,
                    'herbs': top_herbs_for_matrix,
                    'data': co_data
                },
                'herb_cloud': herb_cloud
            }
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'查询失败: {str(e)}'}), 500


@app.route('/api/relation-types')
def api_relation_types():
    if not graph:
        return jsonify({'status': 'error', 'message': '数据库未连接'}), 500
    try:
        query = """
        MATCH ()-[r]-()
        RETURN type(r) AS rel, count(r) AS cnt
        ORDER BY cnt DESC, rel
        """
        res = graph.run(query).data()
        rels = [row['rel'] for row in res]
        stats = {row['rel']: row['cnt'] for row in res}
        return jsonify({'status': 'success', 'relations': rels, 'stats': stats})
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'查询失败: {str(e)}'}), 500


@app.route('/api/herb_geo')
def api_herb_geo():
    if not graph:
        return jsonify({'status': 'error', 'message': '数据库未连接'}), 500
    herb = request.args.get('herb', '').strip()
    if not herb:
        return jsonify({'status': 'error', 'message': '药材名不能为空'}), 400
    try:
        labels_rows = graph.run("""
        MATCH (n)
        UNWIND labels(n) AS label
        RETURN DISTINCT label
        """
        ).data()
        all_labels = [row['label'] for row in labels_rows]

        def filter_labels(patterns, labels):
            pls = [p.lower() for p in patterns]
            return [l for l in labels if any(p in l.lower() for p in pls)]
        herb_labels = filter_labels(['Herb','中药','药材','草药','中药名'], all_labels)
        cond = "ANY(l IN labels(h) WHERE l IN $labels)" if herb_labels else "true"
        q = f"""
        MATCH (h)
        WHERE {cond}
          AND (
            toLower(coalesce(h.name,'')) CONTAINS toLower($herb) OR
            toLower(coalesce(h.title,'')) CONTAINS toLower($herb)
          )
        OPTIONAL MATCH (h)-[]-(n)
        RETURN h, collect(n) AS neighbors
        LIMIT 200
        """
        rows = graph.run(q, labels=herb_labels or [], herb=herb).data()
        provinces = {
            '北京市': ['北京'],
            '天津市': ['天津'],
            '上海市': ['上海'],
            '重庆市': ['重庆'],
            '河北省': ['河北'],
            '山西省': ['山西'],
            '辽宁省': ['辽宁'],
            '吉林省': ['吉林'],
            '黑龙江省': ['黑龙江'],
            '江苏省': ['江苏'],
            '浙江省': ['浙江'],
            '安徽省': ['安徽'],
            '福建省': ['福建'],
            '江西省': ['江西'],
            '山东省': ['山东'],
            '河南省': ['河南'],
            '湖北省': ['湖北'],
            '湖南省': ['湖南'],
            '广东省': ['广东'],
            '广西壮族自治区': ['广西'],
            '海南省': ['海南'],
            '四川省': ['四川'],
            '贵州省': ['贵州'],
            '云南省': ['云南'],
            '西藏自治区': ['西藏'],
            '陕西省': ['陕西'],
            '甘肃省': ['甘肃'],
            '青海省': ['青海'],
            '台湾省': ['台湾'],
            '内蒙古自治区': ['内蒙古'],
            '宁夏回族自治区': ['宁夏'],
            '新疆维吾尔自治区': ['新疆'],
            '香港特别行政区': ['香港'],
            '澳门特别行政区': ['澳门']
        }
        abbrev = {
            '北京市': ['京'], '天津市': ['津'], '上海市': ['沪'], '重庆市': ['渝'],
            '河北省': ['冀'], '山西省': ['晋'], '辽宁省': ['辽'], '吉林省': ['吉'], '黑龙江省': ['黑'],
            '江苏省': ['苏'], '浙江省': ['浙'], '安徽省': ['皖'], '福建省': ['闽'], '江西省': ['赣'],
            '山东省': ['鲁'], '河南省': ['豫', '怀'], '湖北省': ['鄂'], '湖南省': ['湘'], '广东省': ['粤', '广'],
            '广西壮族自治区': ['桂'], '海南省': ['琼'], '四川省': ['川', '蜀'], '贵州省': ['黔', '贵'], '云南省': ['云', '滇'],
            '西藏自治区': ['藏'], '陕西省': ['陕', '秦'], '甘肃省': ['甘', '陇'], '青海省': ['青'], '台湾省': ['台'],
            '内蒙古自治区': ['蒙'], '宁夏回族自治区': ['宁'], '新疆维吾尔自治区': ['新'], '香港特别行政区': ['港'], '澳门特别行政区': ['澳']
        }
        alias_map = {
            '甘草': ['内蒙古自治区', '甘肃省', '新疆维吾尔自治区', '宁夏回族自治区'],
            '当归': ['甘肃省'],
            '黄芪': ['内蒙古自治区', '甘肃省', '宁夏回族自治区'],
            '人参': ['吉林省', '黑龙江省', '辽宁省'],
            '西洋参': ['吉林省', '黑龙江省'],
            '枸杞': ['宁夏回族自治区'],
            '党参': ['甘肃省', '宁夏回族自治区'],
            '三七': ['云南省'],
            '天麻': ['云南省', '贵州省', '四川省'],
            '羌活': ['四川省', '甘肃省'],
            '独活': ['甘肃省', '陕西省', '四川省'],
            '川芎': ['四川省'], '川贝母': ['四川省'], '浙贝母': ['浙江省'], '浙贝': ['浙江省'],
            '怀山药': ['河南省'], '怀地黄': ['河南省'],
            '广陈皮': ['广东省'], '广藿香': ['广东省'],
            '东阿阿胶': ['山东省'],
            '杭菊': ['浙江省'], '浙菊花': ['浙江省'],
            '云木香': ['云南省'], '桂皮': ['广西壮族自治区'], '肉桂': ['广西壮族自治区'],
            '杜仲': ['四川省'], '川杜仲': ['四川省']
        }
        counts = {k: 0 for k in provinces.keys()}
        for r in rows:
            h = r['h']
            neighbors = r.get('neighbors') or []
            texts = []
            texts.append(h.get('name', '') or '')
            for v in dict(h).values():
                texts.append(str(v))
            for n in neighbors:
                texts.append(n.get('name', '') or '')
                for v in dict(n).values():
                    texts.append(str(v))
                for lbl in list(n.labels):
                    texts.append(str(lbl))
            blob = ' '.join(texts)
            for alias, provs in alias_map.items():
                if alias in blob:
                    if isinstance(provs, list):
                        for prov in provs:
                            counts[prov] += 1
                    else:
                        counts[provs] += 1
            for name, kws in provinces.items():
                if any(kw in blob for kw in kws):
                    counts[name] += 1
            for name, kws in abbrev.items():
                if any(kw in blob for kw in kws):
                    counts[name] += 1
        data = [{'name': k, 'value': counts[k]} for k in counts.keys() if counts[k] > 0]
        return jsonify({'status': 'success', 'data': data})
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'查询失败: {str(e)}'}), 500


@app.route('/api/herb_geo_top')
def api_herb_geo_top():
    if not graph:
        return jsonify({'status': 'error', 'message': '数据库未连接'}), 500
    try:
        labels_rows = graph.run("""
        MATCH (n)
        UNWIND labels(n) AS label
        RETURN DISTINCT label
        """
        ).data()
        all_labels = [row['label'] for row in labels_rows]

        def filter_labels(patterns, labels):
            pls = [p.lower() for p in patterns]
            return [l for l in labels if any(p in l.lower() for p in pls)]
        herb_labels = filter_labels(['Herb','中药','药材','草药','中药名'], all_labels)
        prescription_labels = filter_labels(['Prescription','Recipe','处方','配方'], all_labels)

        top_rows = graph.run("""
        MATCH (h)
        WHERE $hlabels = [] OR ANY(l IN labels(h) WHERE l IN $hlabels)
        OPTIONAL MATCH (p)-[rph]-(h)
        WHERE $plabels = [] OR ANY(l IN labels(p) WHERE l IN $plabels)
        WITH h, count(rph) AS cnt
        ORDER BY cnt DESC, coalesce(h.name,'')
        LIMIT 20
        OPTIONAL MATCH (h)-[]-(n)
        RETURN h, cnt, collect(n) AS neighbors
        """, hlabels=herb_labels or [], plabels=prescription_labels or []).data()
        provinces = {
            '北京市': ['北京'], '天津市': ['天津'], '上海市': ['上海'], '重庆市': ['重庆'],
            '河北省': ['河北'], '山西省': ['山西'], '辽宁省': ['辽宁'], '吉林省': ['吉林'], '黑龙江省': ['黑龙江'],
            '江苏省': ['江苏'], '浙江省': ['浙江'], '安徽省': ['安徽'], '福建省': ['福建'], '江西省': ['江西'],
            '山东省': ['山东'], '河南省': ['河南'], '湖北省': ['湖北'], '湖南省': ['湖南'], '广东省': ['广东'],
            '广西壮族自治区': ['广西'], '海南省': ['海南'], '四川省': ['四川'], '贵州省': ['贵州'], '云南省': ['云南'],
            '西藏自治区': ['西藏'], '陕西省': ['陕西'], '甘肃省': ['甘肃'], '青海省': ['青海'], '台湾省': ['台湾'],
            '内蒙古自治区': ['内蒙古'], '宁夏回族自治区': ['宁夏'], '新疆维吾尔自治区': ['新疆'], '香港特别行政区': ['香港'], '澳门特别行政区': ['澳门']
        }
        abbrev = {
            '北京市': ['京'], '天津市': ['津'], '上海市': ['沪'], '重庆市': ['渝'],
            '河北省': ['冀'], '山西省': ['晋'], '辽宁省': ['辽'], '吉林省': ['吉'], '黑龙江省': ['黑'],
            '江苏省': ['苏'], '浙江省': ['浙'], '安徽省': ['皖'], '福建省': ['闽'], '江西省': ['赣'],
            '山东省': ['鲁'], '河南省': ['豫', '怀'], '湖北省': ['鄂'], '湖南省': ['湘'], '广东省': ['粤', '广'],
            '广西壮族自治区': ['桂'], '海南省': ['琼'], '四川省': ['川', '蜀'], '贵州省': ['黔', '贵'], '云南省': ['云', '滇'],
            '西藏自治区': ['藏'], '陕西省': ['陕', '秦'], '甘肃省': ['甘', '陇'], '青海省': ['青'], '台湾省': ['台'],
            '内蒙古自治区': ['蒙'], '宁夏回族自治区': ['宁'], '新疆维吾尔自治区': ['新'], '香港特别行政区': ['港'], '澳门特别行政区': ['澳']
        }
        alias_map = {
            '甘草': ['内蒙古自治区', '甘肃省', '新疆维吾尔自治区', '宁夏回族自治区'],
            '当归': ['甘肃省'],
            '黄芪': ['内蒙古自治区', '甘肃省', '宁夏回族自治区'],
            '人参': ['吉林省', '黑龙江省', '辽宁省'],
            '西洋参': ['吉林省', '黑龙江省'],
            '枸杞': ['宁夏回族自治区'],
            '党参': ['甘肃省', '宁夏回族自治区'],
            '三七': ['云南省'],
            '天麻': ['云南省', '贵州省', '四川省'],
            '羌活': ['四川省', '甘肃省'],
            '独活': ['甘肃省', '陕西省', '四川省'],
            '川芎': ['四川省'], '川贝母': ['四川省'], '浙贝母': ['浙江省'], '浙贝': ['浙江省'],
            '怀山药': ['河南省'], '怀地黄': ['河南省'],
            '广陈皮': ['广东省'], '广藿香': ['广东省'],
            '东阿阿胶': ['山东省'],
            '杭菊': ['浙江省'], '浙菊花': ['浙江省'],
            '云木香': ['云南省'], '桂皮': ['广西壮族自治区'], '肉桂': ['广西壮族自治区'],
            '杜仲': ['四川省'], '川杜仲': ['四川省']
        }
        counts = {k: 0 for k in provinces.keys()}
        selected_herbs = []
        for r in top_rows:
            h = r['h']
            neighbors = r.get('neighbors') or []
            selected_herbs.append(h.get('name',''))
            texts = []
            texts.append(h.get('name', '') or '')
            for v in dict(h).values():
                texts.append(str(v))
            for n in neighbors:
                texts.append(n.get('name', '') or '')
                for v in dict(n).values():
                    texts.append(str(v))
                for lbl in list(n.labels):
                    texts.append(str(lbl))
            blob = ' '.join(texts)
            for alias, provs in alias_map.items():
                if alias in blob:
                    if isinstance(provs, list):
                        for prov in provs:
                            counts[prov] += 1
                    else:
                        counts[provs] += 1
            for name, kws in provinces.items():
                if any(kw in blob for kw in kws):
                    counts[name] += 1
            for name, kws in abbrev.items():
                if any(kw in blob for kw in kws):
                    counts[name] += 1
        data = [{'name': k, 'value': counts[k]} for k in counts.keys() if counts[k] > 0]
        return jsonify({'status': 'success', 'herbs': selected_herbs, 'data': data})
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'查询失败: {str(e)}'}), 500


@app.route('/api/herb_geo_export')
def api_herb_geo_export():
    if not graph:
        return jsonify({'status': 'error', 'message': '数据库未连接'}), 500
    try:
        labels_rows = graph.run("""
        MATCH (n)
        UNWIND labels(n) AS label
        RETURN DISTINCT label
        """
        ).data()
        all_labels = [row['label'] for row in labels_rows]
        def filter_labels(patterns, labels):
            pls = [p.lower() for p in patterns]
            return [l for l in labels if any(p in l.lower() for p in pls)]
        herb_labels = filter_labels(['Herb','中药','药材','草药','中药名'], all_labels)
        rows = graph.run("""
        MATCH (h)
        WHERE $hlabels = [] OR ANY(l IN labels(h) WHERE l IN $hlabels)
        OPTIONAL MATCH (h)-[]-(n)
        RETURN h, collect(n) AS neighbors
        """, hlabels=herb_labels or []).data()
        provinces = {
            '北京市': ['北京'], '天津市': ['天津'], '上海市': ['上海'], '重庆市': ['重庆'],
            '河北省': ['河北'], '山西省': ['山西'], '辽宁省': ['辽宁'], '吉林省': ['吉林'], '黑龙江省': ['黑龙江'],
            '江苏省': ['江苏'], '浙江省': ['浙江'], '安徽省': ['安徽'], '福建省': ['福建'], '江西省': ['江西'],
            '山东省': ['山东'], '河南省': ['河南'], '湖北省': ['湖北'], '湖南省': ['湖南'], '广东省': ['广东'],
            '广西壮族自治区': ['广西'], '海南省': ['海南'], '四川省': ['四川'], '贵州省': ['贵州'], '云南省': ['云南'],
            '西藏自治区': ['西藏'], '陕西省': ['陕西'], '甘肃省': ['甘肃'], '青海省': ['青海'], '台湾省': ['台湾'],
            '内蒙古自治区': ['内蒙古'], '宁夏回族自治区': ['宁夏'], '新疆维吾尔自治区': ['新疆'], '香港特别行政区': ['香港'], '澳门特别行政区': ['澳门']
        }
        abbrev = {
            '北京市': ['京'], '天津市': ['津'], '上海市': ['沪'], '重庆市': ['渝'],
            '河北省': ['冀'], '山西省': ['晋'], '辽宁省': ['辽'], '吉林省': ['吉'], '黑龙江省': ['黑'],
            '江苏省': ['苏'], '浙江省': ['浙'], '安徽省': ['皖'], '福建省': ['闽'], '江西省': ['赣'],
            '山东省': ['鲁'], '河南省': ['豫', '怀'], '湖北省': ['鄂'], '湖南省': ['湘'], '广东省': ['粤', '广'],
            '广西壮族自治区': ['桂'], '海南省': ['琼'], '四川省': ['川', '蜀'], '贵州省': ['黔', '贵'], '云南省': ['云', '滇'],
            '西藏自治区': ['藏'], '陕西省': ['陕', '秦'], '甘肃省': ['甘', '陇'], '青海省': ['青'], '台湾省': ['台'],
            '内蒙古自治区': ['蒙'], '宁夏回族自治区': ['宁'], '新疆维吾尔自治区': ['新'], '香港特别行政区': ['港'], '澳门特别行政区': ['澳']
        }
        alias_map = {
            '甘草': ['内蒙古自治区', '甘肃省', '新疆维吾尔自治区', '宁夏回族自治区'],
            '当归': ['甘肃省'],
            '黄芪': ['内蒙古自治区', '甘肃省', '宁夏回族自治区'],
            '人参': ['吉林省', '黑龙江省', '辽宁省'],
            '西洋参': ['吉林省', '黑龙江省'],
            '枸杞': ['宁夏回族自治区'],
            '党参': ['甘肃省', '宁夏回族自治区'],
            '三七': ['云南省'],
            '天麻': ['云南省', '贵州省', '四川省'],
            '羌活': ['四川省', '甘肃省'],
            '独活': ['甘肃省', '陕西省', '四川省'],
            '川芎': ['四川省'], '川贝母': ['四川省'], '浙贝母': ['浙江省'], '浙贝': ['浙江省'],
            '怀山药': ['河南省'], '怀地黄': ['河南省'],
            '广陈皮': ['广东省'], '广藿香': ['广东省'],
            '东阿阿胶': ['山东省'],
            '杭菊': ['浙江省'], '浙菊花': ['浙江省'],
            '云木香': ['云南省'], '桂皮': ['广西壮族自治区'], '肉桂': ['广西壮族自治区'],
            '杜仲': ['四川省'], '川杜仲': ['四川省']
        }
        herbs_data = {}
        for r in rows:
            h = r['h']
            neighbors = r.get('neighbors') or []
            name = h.get('name') or ''
            if not name:
                continue
            counts = {k: 0 for k in provinces.keys()}
            texts = []
            texts.append(name)
            for v in dict(h).values():
                texts.append(str(v))
            for n in neighbors:
                texts.append(n.get('name', '') or '')
                for v in dict(n).values():
                    texts.append(str(v))
                for lbl in list(n.labels):
                    texts.append(str(lbl))
            blob = ' '.join(texts)
            for alias, provs in alias_map.items():
                if alias in blob:
                    if isinstance(provs, list):
                        for prov in provs:
                            counts[prov] += 1
                    else:
                        counts[provs] += 1
            for pname, kws in provinces.items():
                if any(kw in blob for kw in kws):
                    counts[pname] += 1
            for pname, kws in abbrev.items():
                if any(kw in blob for kw in kws):
                    counts[pname] += 1
            herbs_data[name] = [{'name': k, 'value': counts[k]} for k in counts.keys() if counts[k] > 0]
        summary_counts = {k: 0 for k in provinces.keys()}
        for items in herbs_data.values():
            for item in items:
                summary_counts[item['name']] += item['value']
        summary = [{'name': k, 'value': summary_counts[k]} for k in summary_counts.keys() if summary_counts[k] > 0]
        out = {
            'updated_at': datetime.utcnow().isoformat() + 'Z',
            'count': len(herbs_data),
            'herbs': herbs_data,
            'summary': summary
        }
        out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'data')
        os.makedirs(out_dir, exist_ok=True)
        out_path = os.path.join(out_dir, 'herb_geo.json')
        with open(out_path, 'w', encoding='utf-8') as f:
            json.dump(out, f, ensure_ascii=False)
        return jsonify({'status': 'success', 'path': '/static/data/herb_geo.json', 'count': len(herbs_data)})
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'导出失败: {str(e)}'}), 500


@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404


@app.errorhandler(500)
def internal_error(error):
    return render_template('500.html'), 500


if __name__ == '__main__':
    port = int(os.environ.get('PORT', '5000'))
    app.run(debug=True, host='0.0.0.0', port=port)
