

from PyQt5.QtWidgets import QWidget
from PyQt5.QtCore import Qt, QCoreApplication
import socket
from .SendMessageUI import Ui_SendMessageForm


class SendMessageForm(QWidget):
    _translate = QCoreApplication.translate

    def __init__(self, parent=None):
        super(SendMessageForm, self).__init__()
        self.parent = parent
        self.ui = Ui_SendMessageForm()
        self.ui.setupUi(self)

    def add_message(self, is_receive, message):
        if is_receive:
            direction = self._translate('SendMessageForm', 'Received')
        else:
            direction = self._translate('SendMessageForm', 'Send')
        self.ui.message_area.append('%s: %s' % (direction, message))

    def send_message(self):
        message = self.ui.message_input.text()
        self.parent.private_message_object.send_message(message)
        self.add_message(False, message)
        self.ui.message_input.clear()

    def update_input_text(self):
        self.ui.send.setEnabled(len(self.ui.message_input.text()) > 0)
