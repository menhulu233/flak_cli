

from PyQt5.QtCore import QLocale
import os
import sys

SUPPORTED_TRANSLATION = ['zh_CN']


def load_translation():
    language = QLocale.system().name()
    if language in SUPPORTED_TRANSLATION:
        return language
    return None


def load_path(translation):
    bundle_dir = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
    return os.path.join(bundle_dir, f'Translation/{translation}.qm')
