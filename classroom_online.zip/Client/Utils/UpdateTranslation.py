

import subprocess
import os
import glob
import argparse

SEARCH_DIRS = ['../UI', '../Module']


def generate(file, target='zh_CN'):
    if type(file) == list:
        file = ' '.join(file)
    command = f'pylupdate5 {file} -ts Translation/{target}.ts -noobsolete -verbose'
    try:
        result = subprocess.getoutput(command)
        print(result)
    except OSError as e:
        print(e)


def auto_generate(args):
    translate_files = []
    base_dir = os.path.dirname(os.path.abspath(__file__))
    for path in SEARCH_DIRS:
        translate_files.extend(list(map(os.path.abspath, glob.glob(f'{os.path.join(base_dir, path)}/[!__]*.py'))))
    generate(translate_files, args.lang)


parser = argparse.ArgumentParser(description='PYCM Translation File Generator')
parser.add_argument('--lang', type=str, default='zh_CN', help='The target language for translation')
parser.set_defaults(func=auto_generate)

args = parser.parse_args()
args.func(args)
