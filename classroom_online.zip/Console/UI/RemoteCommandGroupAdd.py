

from PyQt5.QtWidgets import QDialog, QListWidgetItem, QMessageBox
from PyQt5.QtCore import Qt, QCoreApplication
from .RemoteCommandGroupAddUI import Ui_RemoteCommandGroupAddDialog


class RemoteCommandGroupAddForm(QDialog):
    _translate = QCoreApplication.translate

    def __init__(self, parent=None):
        super(RemoteCommandGroupAddForm, self).__init__(parent)
        self.ui = Ui_RemoteCommandGroupAddDialog()
        self.parent = parent
        self.ui.setupUi(self)

    def accept(self):
        if self.ui.title.text() == '':
            QMessageBox.critical(self, self._translate('RemoteCommandGroupAddDialog', 'Error'),
                                 self._translate('RemoteCommandGroupAddDialog', 'Please set a name for the command'))
        elif self.ui.command.document().lineCount() != 1:
            QMessageBox.critical(self, self._translate('RemoteCommandGroupAddDialog', 'Error'),
                                 self._translate('RemoteCommandGroupAddDialog',
                                                 'Please input only one line of command'))
        elif '/' in self.ui.title.text():
            QMessageBox.critical(self, self._translate('RemoteCommandGroupAddDialog', 'Error'),
                                 self._translate('RemoteCommandGroupAddDialog', "Name cannot contain '/'"))
        else:
            super(RemoteCommandGroupAddForm, self).accept()
